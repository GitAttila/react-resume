# @ra-wcftcloud/ra-ftc-communication

## About

This javascript library is a communication library to support any client application which is using InfoPlatform based server API.

## Adding to an Angular CLI app

When adding this library to new application please check out the
[Angular CLI](https://cli.angular.io/).

### Use npm to install the @ra-wcftcloud/ra-ftc-communication library

NOTE: The library should be installed using over SSH connection using SSH key from your GitLab profile.
[How to generate SSH key](https://git-scm.com/book/en/v2/Git-on-the-Server-Generating-Your-SSH-Public-Key).

Install with npm using the release version (`1.0.0` in the examples below).

```sh
npm install git+ssh://git@gitlabpra.ra.rockwell.com:CAT_WCFTCloud/releases/ra-ftc-communication.git#1.0.0
```

or add the @ra-wcftcloud/ra-ftc-communication library to your `package.json`

````
"@ra-wcftcloud/ra-ftc-communication": "git+ssh://git@gitlabpra.ra.rockwell.com:CAT_WCFTCloud/releases/ra-ftc-communication.git#1.0.0"
````

#### Add peer dependencies

Add peer dependencies to your `package.json` file:
````
"@angular/common": "^6.0.1",
"@angular/core": "^6.0.1",
"rxjs": "^6.1.0",
"lodash": "^4.17.10",
"moment": "^2.22.1"
````

Run `npm install` to install all of the packages that you just added.

### Add library to your app's module file

In your app (preferably main module), import library module, e.g.:

For production:

```ts
import { RaFtcCommunicationModule } from '@ra-wcftcloud/ra-ftc-communication';

@NgModule({
  ...
  imports: [
    ...
    RaFtcCommunicationModule.forRoot({
        baseUrl: 'https://your.production-domain.net',
    )
  ],
  ...
}
```

For local UI development enabling CORS / credentials:

```ts
import { RaFtcCommunicationModule } from '@ra-wcftcloud/ra-ftc-communication';

@NgModule({
  ...
  imports: [
    ...
    RaFtcCommunicationModule.forRoot({
        baseUrl: 'https://your.development-domain.net',
        httpOptions: {
            withCredentials: true
        }
    )
  ],
  ...
}
```