import { CommonModule } from '@angular/common';
import { Observable, Subject, timer } from 'rxjs';
import { utc, tz } from 'moment-timezone';
import { __extends } from 'tslib';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { InjectionToken, Inject, Injectable, NgModule } from '@angular/core';
import { map, expand, concatMap } from 'rxjs/operators';
import { isString, isNil, extend, isEmpty, clone, values, some, indexOf, each, filter, sumBy, last, first, find, sortBy } from 'lodash';

var DEFAULT_REPEATED_DATA_INTERVAL = 5;
var COMMUNICATION_CONFIG = new InjectionToken('COMMUNICATION_CONFIGURATION');

var BaseService = (function () {
    function BaseService(relativeApiEndpoint, config, http) {
        this.relativeApiEndpoint = relativeApiEndpoint;
        this.config = config;
        this.http = http;
    }
    Object.defineProperty(BaseService.prototype, "endpointUrl", {
        get: function () {
            return this.config.baseUrl + this.relativeApiEndpoint;
        },
        enumerable: true,
        configurable: true
    });
    BaseService.prototype._sendPostRequest = function (request) {
        return this.http.post(this.endpointUrl, request, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
    };
    BaseService.prototype._sendGetRequest = function (url, extraHttpOptions) {
        if (extraHttpOptions === void 0) { extraHttpOptions = {}; }
        var httpOptions = extend(extraHttpOptions, this.config.httpOptions);
        var endpointUrl = !isEmpty(url) ? url : this.endpointUrl;
        return this.http.get(endpointUrl, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, httpOptions));
    };
    return BaseService;
}());

var InstanceService = (function (_super) {
    __extends(InstanceService, _super);
    function InstanceService(config, http) {
        return _super.call(this, '/api/1/instance/', config, http) || this;
    }
    InstanceService.prototype.getInstances = function (instanceRequest) {
        return this._sendPostRequest(instanceRequest);
    };
    InstanceService.decorators = [
        { type: Injectable }
    ];
    InstanceService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return InstanceService;
}(BaseService));
var InstanceRequest = (function () {
    function InstanceRequest(camelCasePropertyNames) {
        if (!isNil(camelCasePropertyNames)) {
            this.camelCasePropertyNames = camelCasePropertyNames;
        }
        else {
            this.camelCasePropertyNames = true;
        }
    }
    InstanceRequest.prototype.addResponseFormat = function (instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts) {
        instanceFqnItem.responseFormat = {};
        if (includeAccessControl) {
            instanceFqnItem.responseFormat.includeAcl = includeAccessControl;
        }
        if (!isNil(retrievalDepth) && retrievalDepth > 0) {
            instanceFqnItem.responseFormat.depth = retrievalDepth;
        }
        if (includeShortcuts) {
            instanceFqnItem.responseFormat.includeShortcuts = includeShortcuts;
        }
    };
    InstanceRequest.prototype.addItemFqn = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        var instanceFqnItem = {
            fqn: fqn
        };
        ((this)).addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnItem);
        return ((this));
    };
    InstanceRequest.prototype.addItemFqnExcludeVolatile = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        var instanceFqnItem = {
            fqn: fqn,
            excludeVolatileProperties: true
        };
        ((this)).addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnItem);
        return ((this));
    };
    InstanceRequest.prototype.addPropertyFqn = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts, pageSize, page) {
        var instanceFqnPropertyItem = {
            propertyFqn: fqn,
            excludeVolatileProperties: true
        };
        ((this)).addResponseFormat(instanceFqnPropertyItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!isNil(pageSize)) {
            instanceFqnPropertyItem.pageSize = pageSize;
        }
        if (!isNil(page)) {
            instanceFqnPropertyItem.page = page;
        }
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnPropertyItem);
        return ((this));
    };
    InstanceRequest.prototype.addQuery = function (queryExpression, includeAccessControl, retrievalDepth, includeShortcuts) {
        var instanceQueryItem = {
            query: queryExpression
        };
        ((this)).addResponseFormat(instanceQueryItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).queries) {
            ((this)).queries = [];
        }
        ((this)).queries.push(instanceQueryItem);
        return ((this));
    };
    return InstanceRequest;
}());

var LiveRequest = (function () {
    function LiveRequest(fqns) {
        this.fqns = fqns;
        this.fqns = clone(fqns);
    }
    LiveRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    LiveRequest.prototype.removeFqn = function (fqn) {
        var index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    return LiveRequest;
}());
var LiveDataService = (function (_super) {
    __extends(LiveDataService, _super);
    function LiveDataService(config, http) {
        var _this = _super.call(this, '/api/1/live/', config, http) || this;
        _this._fqns = new Map();
        return _this;
    }
    LiveDataService.prototype.getOnce = function (request) {
        return this._sendPostRequest(request).pipe(map(function (response) {
            var ret = [];
            each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._getInnerRepeatedObservable = function () {
        return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
            .pipe(map(function (response) {
            var ret = [];
            each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._initializeRepeatedData = function () {
        var _this = this;
        if (!this._repeatedDataSubject) {
            this._repeatedDataSubject = new Subject();
        }
        if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
            var repeatedInterval_1 = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval_1 = repeatedInterval_1 * 1000;
            this._repeatedDataObservable = this._getInnerRepeatedObservable();
            this._repeatedDataSubscription = this._repeatedDataObservable.pipe(expand(function () { return timer(repeatedInterval_1).pipe(concatMap(function () { return _this._getInnerRepeatedObservable(); })); })).subscribe(function (response) {
                _this._repeatedDataSubject.next(response);
            }, function (err) {
                _this._repeatedDataSubscription.unsubscribe();
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.error(err);
            }, function () {
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.complete();
            });
            this._reinitializeRepeatedObservable = false;
        }
        return this._repeatedDataObservable;
    };
    LiveDataService.prototype.getRepeatedly = function (request) {
        var _this = this;
        return new Observable(function (observer) {
            each(request.fqns, function (fqn) {
                var newVal = 0;
                if (_this._fqns.has(fqn)) {
                    newVal = _this._fqns.get(fqn);
                }
                _this._fqns.set(fqn, ++newVal);
            });
            _this._initializeRepeatedData();
            var subscription = _this._repeatedDataSubject.asObservable().pipe(map(function (currentResponse) {
                return filter(currentResponse, function (o) {
                    return indexOf(request.fqns, o.fqn) > -1;
                });
            })).subscribe(function (response) {
                observer.next(response);
            }, function (error) {
                observer.error(error);
            }, function () {
                observer.complete();
            });
            return function () {
                each(request.fqns, function (fqn) {
                    var newVal = 1;
                    if (_this._fqns.has(fqn)) {
                        newVal = _this._fqns.get(fqn);
                    }
                    if (newVal === 1) {
                        _this._fqns.delete(fqn);
                    }
                    else {
                        _this._fqns.set(fqn, --newVal);
                    }
                });
                subscription.unsubscribe();
                observer.unsubscribe();
                if (_this._fqns.size === 0) {
                    if (_this._repeatedDataSubscription) {
                        _this._repeatedDataSubscription.unsubscribe();
                    }
                    _this._repeatedDataSubject.complete();
                    delete _this._repeatedDataSubject;
                    _this._reinitializeRepeatedObservable = true;
                }
            };
        });
    };
    LiveDataService.decorators = [
        { type: Injectable }
    ];
    LiveDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return LiveDataService;
}(BaseService));

var OpcQualityService = (function () {
    function OpcQualityService() {
        this.opcDaQualityMask = 0xfffC;
        this.opcDaQualityMasterMask = 0x00C0;
        this.opcHdaQualityMask = 0xffff0000;
        this.opcDaQualityFieldMasks = {
            limitField: 0x0003,
            subStatusField: 0x003C,
            quality: 0x00C0
        };
        this.opcDaQualityMaster = {
            bad: 0x0000,
            uncertain: 0x0040,
            notDefined: 0x0080,
            good: 0x00C0
        };
        this.opcDaQualityStatus = {
            bad: 0x0000,
            configError: 0x0004,
            notConnected: 0x0008,
            deviceFailure: 0x000c,
            sensorFailure: 0x0010,
            lastKnown: 0x0014,
            commFailure: 0x0018,
            outOfService: 0x001c,
            initializing: 0x0020,
            uncertain: 0x0040,
            lastUsable: 0x0044,
            sensorNotAccurate: 0x0050,
            engUnitsExceeded: 0x0054,
            subNormal: 0x0058,
            good: 0x00C0,
            localOverride: 0x00D8
        };
        this.opcDaQualityLimit = {
            limitOk: 0x0000,
            limitLow: 0x0001,
            limitHigh: 0x0002,
            constant: 0x0003
        };
        this.opcHdaQuality = {
            extraData: 0x00010000,
            interpolated: 0x00020000,
            raw: 0x00040000,
            calculated: 0x00080000,
            noBound: 0x00100000,
            noData: 0x00200000,
            dataLost: 0x00400000,
            conversion: 0x00800000,
            partial: 0x01000000
        };
        this.overallMessages = {
            0x0000: 'Bad',
            0x0040: 'Uncertain',
            0x0080: 'Not defined',
            0x00C0: 'Good'
        };
        this.detailsMessages = {
            0x0000: 'Not limited',
            0x0001: 'Low limited',
            0x0002: 'High limited',
            0x0003: 'Constant',
            0x0004: 'Config error',
            0x0008: 'Not connected',
            0x000c: 'Device failure',
            0x0010: 'Sensor failure',
            0x0014: 'Last known',
            0x0018: 'Comm failure',
            0x001C: 'Out of service',
            0x0020: 'Initializing',
            0x0044: 'Last usable',
            0x0050: 'Sensors not accurate',
            0x0054: 'Engineering units exceeded',
            0x0058: 'Sub-Normal',
            0x00D8: 'Local override',
            0x00010000: 'Extra data',
            0x00020000: 'Interpolated',
            0x00040000: 'Raw',
            0x00080000: 'Calculated',
            0x00100000: 'No bound',
            0x00200000: 'No data',
            0x00400000: 'Data lost',
            0x00800000: 'Conversion',
            0x01000000: 'Partial'
        };
    }
    OpcQualityService.prototype.asObject = function (qualityAsInt) {
        var mask;
        var quality = (({}));
        mask = qualityAsInt & this.opcDaQualityMasterMask;
        quality.overall = this.overallMessages[mask];
        mask = qualityAsInt & this.opcDaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.da = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        if (mask && this.detailsMessages[mask]) {
            quality.limit = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcHdaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.hda = this.detailsMessages[mask];
        }
        return quality;
    };
    OpcQualityService.prototype.asString = function (qualityAsInt) {
        var hasDaQuality = false;
        var qObj = this.asObject(qualityAsInt);
        var qString;
        qString = qObj.overall;
        if (qObj.da) {
            qString = qString + ': ' + qObj.da;
            hasDaQuality = true;
        }
        if (qObj.limit) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.limit;
            hasDaQuality = true;
        }
        if (qObj.hda) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.hda;
        }
        return qString;
    };
    OpcQualityService.prototype.getOpcDaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMask;
    };
    OpcQualityService.prototype.getOpcLimitStatus = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
    };
    OpcQualityService.prototype.getSimpleQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMasterMask;
    };
    OpcQualityService.prototype.getOpcHdaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcHdaQualityMask;
    };
    OpcQualityService.prototype.isGood = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
    };
    OpcQualityService.prototype.isUncertain = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
    };
    OpcQualityService.prototype.isBad = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
    };
    OpcQualityService.prototype.isDaConfigError = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
    };
    OpcQualityService.prototype.isDaNotConnected = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
    };
    OpcQualityService.prototype.isDaDeviceFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
    };
    OpcQualityService.prototype.isDaSensorFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
    };
    OpcQualityService.prototype.isDaLastKnown = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
    };
    OpcQualityService.prototype.isDaCommFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
    };
    OpcQualityService.prototype.isDaOutOfService = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
    };
    OpcQualityService.prototype.isDaInitializing = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
    };
    OpcQualityService.prototype.isDaLastUsable = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
    };
    OpcQualityService.prototype.isDaSensorNotAccurate = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
    };
    OpcQualityService.prototype.isDaEngUnitsExceeded = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
    };
    OpcQualityService.prototype.isDaSubNormal = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
    };
    OpcQualityService.prototype.isDaLocalOverride = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
    };
    OpcQualityService.prototype.isLimitOk = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
    };
    OpcQualityService.prototype.isLimitLow = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
    };
    OpcQualityService.prototype.isLimitHigh = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
    };
    OpcQualityService.prototype.isLimitConstant = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
    };
    OpcQualityService.prototype.isHdaExtraData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
    };
    OpcQualityService.prototype.isHdaInterpolated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
    };
    OpcQualityService.prototype.isHdaRaw = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
    };
    OpcQualityService.prototype.isHdaCalculated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
    };
    OpcQualityService.prototype.isHdaNoBound = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
    };
    OpcQualityService.prototype.isHdaNoData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
    };
    OpcQualityService.prototype.isHdaDataLost = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
    };
    OpcQualityService.prototype.isHdaConversion = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
    };
    OpcQualityService.prototype.isHdaPartial = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
    };
    OpcQualityService.decorators = [
        { type: Injectable }
    ];
    return OpcQualityService;
}());

var MomentHelperService = (function () {
    function MomentHelperService() {
    }
    MomentHelperService.applyTimezone = function (datetime, timezone) {
        var mDate = utc(datetime);
        mDate.tz(timezone);
        return mDate.format(this.MOMENT_DATETIME_FORMAT_TZ_FULL);
    };
    MomentHelperService.getAllTimezones = function () {
        return tz.names();
    };
    MomentHelperService.isValidTimezone = function (timezone) {
        return timezone && tz.zone(timezone);
    };
    MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL = 'YYYY-MM-DDTHH:mm:ss.SSS[Z]';
    MomentHelperService.MOMENT_DATETIME_FORMAT_TZ_FULL = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
    MomentHelperService.decorators = [
        { type: Injectable }
    ];
    return MomentHelperService;
}());

var TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = 'includeGood';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = 'includeBad';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = 'includeUncertain';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = 'includeAll';
var TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
var SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
    PointsInTime: 'PointsInTime',
};
var TimeseriesRequest = (function () {
    function TimeseriesRequest(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    TimeseriesRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    TimeseriesRequest.prototype.removeFqn = function (fqn) {
        var index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    TimeseriesRequest.prototype.setFqns = function (fqns) {
        this.fqns = clone(fqns);
    };
    TimeseriesRequest.prototype.getFqns = function () {
        return clone(this.fqns);
    };
    TimeseriesRequest.prototype.setTimePeriod = function (timePeriod) {
        this.timePeriod = clone(timePeriod);
    };
    TimeseriesRequest.prototype.getTimePeriod = function () {
        return clone(this.timePeriod);
    };
    TimeseriesRequest.prototype.setSamplingDefinition = function (samplingDefinition) {
        this.samplingDefinition = clone(samplingDefinition);
    };
    TimeseriesRequest.prototype.getSamplingDefinition = function () {
        return clone(this.samplingDefinition);
    };
    TimeseriesRequest.prototype.setTimeDeadBand = function (timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    };
    TimeseriesRequest.prototype.getTimeDeadband = function () {
        return this.timeDeadBand;
    };
    TimeseriesRequest.prototype.setValueDeadBand = function (valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    };
    TimeseriesRequest.prototype.getValueDeadBand = function () {
        return this.valueDeadBand;
    };
    TimeseriesRequest.prototype.setQualityFilter = function (qualityFilter) {
        this.qualityFilter = qualityFilter;
    };
    TimeseriesRequest.prototype.getQualityFilter = function () {
        return this.qualityFilter;
    };
    return TimeseriesRequest;
}());
var TimeseriesDataService = (function (_super) {
    __extends(TimeseriesDataService, _super);
    function TimeseriesDataService(config, http, opcQualitySvc) {
        var _this = _super.call(this, '/api/1/timeseries/', config, http) || this;
        _this.opcQualitySvc = opcQualitySvc;
        return _this;
    }
    TimeseriesDataService.prototype.getOnce = function (request, timezone) {
        var _this = this;
        var tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        return this._sendPostRequest(request).pipe(map(function (response) {
            return _this._transformTimeseriesInternalResponse(response, tz$$1);
        }));
    };
    TimeseriesDataService.prototype._getErrorObservable = function (errorString) {
        return new Observable(function (observer) {
            observer.error(errorString);
            return function () {
                observer.unsubscribe();
            };
        });
    };
    TimeseriesDataService.prototype._applyTimezoneToVqtData = function (vqtData, timezone) {
        each(vqtData, function (vqt) {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    };
    TimeseriesDataService.prototype._getRequestDataNextStartValues = function (response, nextStartMoment) {
        var beforeNextRequestValues = new Map();
        var last$$1;
        each(response.fqnsResults, function (el) {
            if (!isNil(el) && el.values.length) {
                last$$1 = last(el.values);
                beforeNextRequestValues.set(el.fqn, last$$1);
            }
        });
        return beforeNextRequestValues;
    };
    TimeseriesDataService.prototype._getStartForNextRequest = function (response, originalDuration, repeatedInterval) {
        var opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            var timeString = first(fqnResult.values).t;
            for (var i = fqnResult.values.length - 1; i >= 0; i--) {
                var val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        var result;
        var currentTimeMinusDuration = utc().subtract(Math.abs(originalDuration), 'seconds');
        each(response.fqnsResults, function (fqnResult) {
            if (isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            var lastValue = utc(getLastTimeToUse(fqnResult));
            if (isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (isNil(result)) {
            result = utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    };
    TimeseriesDataService.prototype._filterStartResponseData = function (response, previousResponseLastData, requestTimePeriod) {
        var firstVqt;
        var firstVqtMoment;
        var secondVqt;
        var opcQualitySvc = this.opcQualitySvc;
        var cutBeforeDate = utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        each(response.fqnsResults, function (el) {
            if (!isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                var onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                var onePreviousResponseLastDataMoment = utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    };
    TimeseriesDataService.prototype._transformTimeseriesInternalResponse = function (response, timezone) {
        var _this = this;
        var applyTimezone = false;
        if (!isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        var ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        each(response.fqnsResults, function (oneResult) {
            if (isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                _this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    };
    TimeseriesDataService.prototype._filterDuplicateDataAndCut = function (values$$1, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        var ids = [];
        var objectToAddToArray;
        var firstIsAfter = false;
        function arrayFilter(o) {
            var currentItemMoment = utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = clone(o);
                    var cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        var filteredArray = values$$1.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            var lastValue = last(filteredArray);
            if (!lastValue || !utc(lastValue.t).isSame(utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    };
    TimeseriesDataService.prototype._getRepeatedlyWhole = function (request, customInterval, timezone) {
        var _this = this;
        var lastMergedResponse;
        var tz$$1 = timezone;
        var repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map(function (response) {
            if (!isNil(lastMergedResponse)) {
                var requestTimePeriod = request.getTimePeriod();
                var cutBeforeDate_1 = utc(response.timePeriod.end);
                cutBeforeDate_1.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                var cutBeforeDateUTCFormat = cutBeforeDate_1.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!isNil(tz$$1)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz$$1);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                each(lastMergedResponse.results, function (result) {
                    var newResults = find(response.results, { fqn: result.fqn });
                    if (!isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = sortBy(result.values, [function (o) {
                                return utc(o.t);
                            }]);
                        result.values = _this._filterDuplicateDataAndCut(result.values, cutBeforeDate_1, false, tz$$1);
                    }
                });
                each(response.results, function (newResult) {
                    if (!find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    };
    TimeseriesDataService.prototype._getRepeatedlyIncrements = function (request, customInterval, timezone) {
        var _this = this;
        var requestTimePeriod = request.getTimePeriod();
        var lastResponseData;
        var repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        var lastRepeatedRequest = clone(request);
        var originalDuration = requestTimePeriod.duration;
        var nextRequestStartMoment;
        var repeatedDataObservable = this._sendPostRequest(request).pipe(map(function (response) {
            nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return _this._transformTimeseriesInternalResponse(response, timezone);
        }));
        var expandedObservable = repeatedDataObservable.pipe(expand(function () { return timer(repeatedInterval).pipe(concatMap(function () {
            if (!isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return _this._sendPostRequest(lastRepeatedRequest).pipe(map(function (response) {
                if (lastResponseData.size > 0) {
                    _this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return _this._transformTimeseriesInternalResponse(response, timezone);
            }));
        })); }));
        return expandedObservable;
    };
    TimeseriesDataService.prototype.getRepeatedly = function (request, customInterval, format, timezone) {
        var requestTimePeriod = request.getTimePeriod();
        if (!isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        var tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        if (isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz$$1);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz$$1);
        }
    };
    TimeseriesDataService.decorators = [
        { type: Injectable }
    ];
    TimeseriesDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient },
        { type: OpcQualityService }
    ]; };
    return TimeseriesDataService;
}(BaseService));

var OperationService = (function (_super) {
    __extends(OperationService, _super);
    function OperationService(config, http) {
        return _super.call(this, '/api/1/operation/', config, http) || this;
    }
    OperationService.prototype.getOperationData = function (operationReq) {
        return this._sendPostRequest(operationReq);
    };
    OperationService.decorators = [
        { type: Injectable }
    ];
    OperationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return OperationService;
}(BaseService));
var OperationRequest = (function () {
    function OperationRequest(target, operation, parameters) {
        this.target = target;
        this.operation = operation;
        this.parameters = parameters;
    }
    return OperationRequest;
}());

var PersistenceService = (function (_super) {
    __extends(PersistenceService, _super);
    function PersistenceService(config, http) {
        return _super.call(this, '/api/1/persistence/', config, http) || this;
    }
    PersistenceService.prototype.commit = function (persistRequest) {
        return this._sendPostRequest(persistRequest);
    };
    PersistenceService.decorators = [
        { type: Injectable }
    ];
    PersistenceService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return PersistenceService;
}(BaseService));
var PropNameValues = (function () {
    function PropNameValues() {
    }
    PropNameValues.prototype.add = function (name, value) {
        if (name) {
            this[name] = value;
        }
    };
    PropNameValues.prototype.remove = function (name) {
        if (!isNil(this[name])) {
            delete this[name];
        }
    };
    PropNameValues.prototype.isEmpty = function () {
        return !some(this);
    };
    return PropNameValues;
}());
var PersistRequest = (function () {
    function PersistRequest() {
    }
    PersistRequest.prototype.createItem = function (parentPropertyFqn, itemType, propNameValues) {
        var createRequest = {
            parentPropertyFqn: parentPropertyFqn,
            itemType: itemType
        };
        if (propNameValues) {
            createRequest.props = propNameValues;
        }
        if (!this.newItems) {
            this.newItems = [];
        }
        this.newItems.push(createRequest);
        return this;
    };
    PersistRequest.prototype.renameItem = function (itemFqn, newName) {
        this.renamedItem = {
            fqn: itemFqn,
            newName: newName
        };
        return this;
    };
    PersistRequest.prototype.changeItem = function (itemFqn, propNameValues) {
        if (!propNameValues.isEmpty()) {
            var changeRequest = {
                FullyQualifiedName: itemFqn
            };
            extend(changeRequest, propNameValues);
            if (!this.changedItems) {
                this.changedItems = [];
            }
            this.changedItems.push(changeRequest);
        }
        return this;
    };
    PersistRequest.prototype.deleteItem = function (itemFqn) {
        if (!this.deletedItems) {
            this.deletedItems = [];
        }
        this.deletedItems.push(itemFqn);
        return this;
    };
    return PersistRequest;
}());

var NavigationService = (function (_super) {
    __extends(NavigationService, _super);
    function NavigationService(config, http) {
        return _super.call(this, '/api/1/navigation/', config, http) || this;
    }
    NavigationService.prototype.getNavigationData = function (navigationRequest) {
        var request = navigationRequest;
        if (isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
            if (isNil(request.hideRules) && isNil(request.skipRules) && !isNil(this.config.defaultNavigationRules)) {
                var clonedRequest = clone(navigationRequest);
                if (this.config.defaultNavigationRules.skipRules) {
                    clonedRequest.skipRules = clone(this.config.defaultNavigationRules.skipRules);
                    request = clonedRequest;
                }
                if (this.config.defaultNavigationRules.hideRules) {
                    clonedRequest.hideRules = clone(this.config.defaultNavigationRules.hideRules);
                    request = clonedRequest;
                }
            }
        }
        return this._sendPostRequest(request);
    };
    NavigationService.decorators = [
        { type: Injectable }
    ];
    NavigationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return NavigationService;
}(BaseService));
var NavigationRequest = (function () {
    function NavigationRequest(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
        this.fqn = fqn;
        this.propNames = propNames;
        this.includeParents = includeParents;
        this.navHandlerFqn = navHandlerFqn;
        this.hideRules = hideRules;
        this.skipRules = skipRules;
    }
    return NavigationRequest;
}());

var SecurityContextService = (function (_super) {
    __extends(SecurityContextService, _super);
    function SecurityContextService(config, http) {
        return _super.call(this, '/api/1/securitycontext/', config, http) || this;
    }
    SecurityContextService.prototype.getSecurityContextData = function () {
        return this._sendGetRequest();
    };
    SecurityContextService.decorators = [
        { type: Injectable }
    ];
    SecurityContextService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return SecurityContextService;
}(BaseService));

var MimeService = (function (_super) {
    __extends(MimeService, _super);
    function MimeService(config, http) {
        return _super.call(this, '/api/1/mime/', config, http) || this;
    }
    MimeService.prototype.getMimeItemPath = function (fqn) {
        return this.endpointUrl.concat(fqn);
    };
    MimeService.prototype.getMimeProperty = function (fqn) {
        return this._sendGetRequest(this.getMimeItemPath(fqn), { responseType: 'text' });
    };
    MimeService.decorators = [
        { type: Injectable }
    ];
    MimeService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return MimeService;
}(BaseService));

var NavigationHandlerService = (function (_super) {
    __extends(NavigationHandlerService, _super);
    function NavigationHandlerService(config, http) {
        return _super.call(this, '/api/1/navigationhandler/', config, http) || this;
    }
    NavigationHandlerService.prototype.getNavigationHandlerData = function (navigationHandlerReq) {
        return this._sendPostRequest(navigationHandlerReq);
    };
    NavigationHandlerService.decorators = [
        { type: Injectable }
    ];
    NavigationHandlerService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return NavigationHandlerService;
}(BaseService));
var NavigationHandlerRequest = (function () {
    function NavigationHandlerRequest(fqn, currentNavHandlerFqn, navHandlerProviderFqn) {
        this.fqn = fqn;
        this.currentNavHandlerFqn = currentNavHandlerFqn;
        this.navHandlerProviderFqn = navHandlerProviderFqn;
    }
    return NavigationHandlerRequest;
}());

var FqnService = (function () {
    function FqnService() {
    }
    FqnService.prototype.getCombinedNameParts = function (anchorFqnParts, includedAnchorPartsCount, relativeFqnParts) {
        return anchorFqnParts.slice(0, includedAnchorPartsCount).concat(relativeFqnParts);
    };
    FqnService.prototype.unescapeRawPart = function (rawPart) {
        var unescapedRawPart;
        if (rawPart.charAt(0) === FqnService.startPartChar) {
            if (rawPart.charAt(rawPart.length - 1) === FqnService.endPartChar) {
                unescapedRawPart = rawPart.substr(1, rawPart.length - 2);
            }
            else {
                unescapedRawPart = rawPart.substr(1);
            }
        }
        else if (rawPart.charAt(rawPart.length - 1) === FqnService.endPartChar) {
            unescapedRawPart = rawPart.substr(0, rawPart.length - 1);
        }
        if (unescapedRawPart) {
            var regex = new RegExp(FqnService.escapedEndPartChar, 'g');
            return unescapedRawPart.replace(regex, FqnService.endPartChar);
        }
        if (rawPart === FqnService.endPartChar || rawPart === FqnService.startPartChar) {
            return '';
        }
        return rawPart;
    };
    FqnService.prototype.escape = function (part) {
        var escapedPart = FqnService.startPartChar;
        var regex = new RegExp(FqnService.endPartChar, 'g');
        escapedPart = escapedPart.concat(part.replace(regex, FqnService.escapedEndPartChar));
        return escapedPart.concat(FqnService.endPartChar);
    };
    FqnService.prototype.requiresEscaping = function (part, checkWhitespace) {
        if (checkWhitespace === void 0) { checkWhitespace = false; }
        var charCount = function (str, ch) { return sumBy(str, function (x) { return x === ch ? 1 : 0; }); };
        if (part[0] === FqnService.startPartChar && part[part.length - 1] === FqnService.endPartChar) {
            var unescapedPart = this.unescapeRawPart(part);
            if (charCount(unescapedPart, FqnService.startPartChar) === charCount(unescapedPart, FqnService.endPartChar)) {
                return false;
            }
            return true;
        }
        var basicAssumption = part.charAt(0) === FqnService.startPartChar || part.indexOf(FqnService.delimiterChar) >= 0;
        return checkWhitespace ? basicAssumption || part.indexOf(' ') >= 0 : basicAssumption;
    };
    FqnService.prototype.relativeFqnDepth = function (relativeFqn) {
        if (relativeFqn[0] !== FqnService.delimiterChar) {
            return 0;
        }
        var depth = 0;
        while (depth < relativeFqn.length &&
            relativeFqn[depth] === FqnService.delimiterChar) {
            depth++;
        }
        return depth;
    };
    FqnService.prototype.getLastPart = function (fqn) {
        if (this.areEqual(fqn, '')) {
            return '';
        }
        else {
            if (isString(fqn)) {
                var parts = this.splitFqn(fqn);
                return parts[parts.length - 1];
            }
            else {
                return '';
            }
        }
    };
    FqnService.prototype.removeLastPart = function (fqn) {
        var parts = this.splitFqn(fqn);
        parts.splice(-1, 1);
        return this.buildFqn(parts);
    };
    FqnService.prototype.areEqual = function (fqn1, fqn2) {
        if (fqn1 === fqn2) {
            return true;
        }
        if (isString(fqn1) && isString(fqn2)) {
            return fqn1.toLowerCase() === fqn2.toLowerCase();
        }
        return false;
    };
    FqnService.prototype.splitFqn = function (fqn) {
        var parts = [];
        if (fqn && fqn.length > 0) {
            var rawParts = fqn.split(FqnService.delimiterChar);
            for (var i = 0; i < rawParts.length; i++) {
                if (rawParts[i].indexOf(FqnService.startPartChar) === 0) {
                    var partSequence = [];
                    for (; i < rawParts.length; i++) {
                        partSequence.push(this.unescapeRawPart(rawParts[i]));
                        var tmpString = rawParts[i].replace(new RegExp(FqnService.escapedEndPartChar, 'g'), '');
                        if (tmpString.charAt(tmpString.length - 1) === FqnService.endPartChar) {
                            break;
                        }
                    }
                    parts.push(partSequence.join(FqnService.delimiterChar));
                }
                else {
                    parts.push(rawParts[i]);
                }
            }
        }
        return parts;
    };
    FqnService.prototype.buildFqn = function (parts) {
        var fqn = [];
        for (var i = 0; i < parts.length; i++) {
            if (this.requiresEscaping(parts[i])) {
                fqn.push(this.escape(parts[i]));
            }
            else {
                fqn.push(parts[i]);
            }
        }
        return fqn.join(FqnService.delimiterChar);
    };
    FqnService.prototype.buildFqnWithEscaping = function (parts) {
        var fqn = [];
        for (var i = 0; i < parts.length; i++) {
            if (this.requiresEscaping(parts[i], true)) {
                fqn.push(this.escape(parts[i]));
            }
            else {
                fqn.push(parts[i]);
            }
        }
        return fqn.join(FqnService.delimiterChar);
    };
    FqnService.prototype.appendNamePart = function (baseName, part) {
        return [baseName, this.buildFqn([part])].join(FqnService.delimiterChar);
    };
    FqnService.prototype.appendNameParts = function (baseName, parts) {
        return [baseName, this.buildFqn(parts)].join(FqnService.delimiterChar);
    };
    FqnService.prototype.isRelative = function (fqn) {
        return fqn[0] === FqnService.delimiterChar;
    };
    FqnService.prototype.absoluteToRelative = function (anchorFqn, fqn) {
        if (!anchorFqn) {
            if (this.isRelative(fqn)) {
                return fqn;
            }
            else {
                return FqnService.delimiterChar + fqn;
            }
        }
        var anchorFqnParts = this.splitFqn(anchorFqn);
        var fqnParts = this.splitFqn(fqn);
        var commonCount = 0;
        var ii;
        for (ii = 0; ii < anchorFqnParts.length; ii++) {
            if (!this.areEqual(anchorFqnParts[ii], fqnParts[ii])) {
                break;
            }
            commonCount++;
        }
        var relativeFqnParts = fqnParts.slice(commonCount, fqnParts.length);
        var relativeFqn = this.buildFqn(relativeFqnParts);
        commonCount = (anchorFqnParts.length - commonCount) + 1;
        for (ii = 0; ii < commonCount; ii++) {
            relativeFqn = FqnService.delimiterChar + relativeFqn;
        }
        return relativeFqn;
    };
    FqnService.prototype.relativeToAbsolute = function (anchorFqn, relativeFqn) {
        var trimmedAnchorFqn = anchorFqn.trim();
        var trimmedRelativeFqn = relativeFqn.trim();
        if (relativeFqn.length === 0) {
            return trimmedAnchorFqn;
        }
        var relativeDepth = this.relativeFqnDepth(trimmedRelativeFqn);
        var finalRelativeFqn = (relativeDepth < 1) ? trimmedRelativeFqn :
            trimmedRelativeFqn.slice(relativeDepth, trimmedRelativeFqn.length);
        var relativeFqnParts = this.splitFqn(finalRelativeFqn);
        var anchorFqnParts = this.splitFqn(trimmedAnchorFqn);
        if (relativeDepth > anchorFqnParts.length + 1) {
            return '';
        }
        if (relativeDepth > 0) {
            relativeDepth--;
        }
        var fullNameParts = this.getCombinedNameParts(anchorFqnParts, anchorFqnParts.length - relativeDepth, relativeFqnParts);
        return this.buildFqn(fullNameParts);
    };
    FqnService.delimiterChar = '.';
    FqnService.startPartChar = '[';
    FqnService.endPartChar = ']';
    FqnService.escapedEndPartChar = ']]';
    FqnService.decorators = [
        { type: Injectable }
    ];
    return FqnService;
}());

var ItemPermissions = (function () {
    function ItemPermissions(readPerm, writePerm, deletePerm, executePerm) {
        this._read = readPerm;
        this._write = writePerm;
        this._delete = deletePerm;
        this._execute = executePerm;
    }
    Object.defineProperty(ItemPermissions.prototype, "read", {
        get: function () {
            return this._read;
        },
        set: function (param) {
            this._read = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "write", {
        get: function () {
            return this._write;
        },
        set: function (param) {
            this._write = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "delete", {
        get: function () {
            return this._delete;
        },
        set: function (param) {
            this._delete = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "execute", {
        get: function () {
            return this._execute;
        },
        set: function (param) {
            this._execute = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    ItemPermissions.create = function (rwde) {
        if (rwde instanceof ItemPermissions) {
            return rwde;
        }
        var _rwde = isString(rwde) ? rwde.toLowerCase() : 'nnnn';
        return new ItemPermissions(_rwde[0] === 'y', _rwde[1] === 'y', _rwde[2] === 'y', _rwde[3] === 'y');
    };
    ItemPermissions.prototype.satisfiesRequired = function (requiredPermissions) {
        var requiredPermissionsLocal = ItemPermissions.create(requiredPermissions);
        if (requiredPermissionsLocal.read && !this.read) {
            return false;
        }
        if (requiredPermissionsLocal.write && !this.write) {
            return false;
        }
        if (requiredPermissionsLocal.delete && !this.delete) {
            return false;
        }
        if (requiredPermissionsLocal.execute && !this.execute) {
            return false;
        }
        return true;
    };
    return ItemPermissions;
}());

var PermissionsService = (function () {
    function PermissionsService(instanceSvc) {
        this.instanceSvc = instanceSvc;
    }
    PermissionsService.prototype.checkItemsPermissions = function (fqns, requiredPermissions) {
        var checkPerm = ItemPermissions.create(requiredPermissions);
        var req = new InstanceRequest();
        var result = {};
        fqns.forEach(function (fqn) {
            result[fqn] = false;
            req.addItemFqn(fqn, false, 0);
        });
        return this.instanceSvc.getInstances(req).pipe(map(function (response) {
            for (var index = 0; index < response.fqnsResults.length; index++) {
                var itemData = response.fqnsResults[index];
                var item = itemData.item;
                if (!item || !item.fqn || isNil(result[item.fqn])) {
                    continue;
                }
                var itemPermissions = ItemPermissions.create(item.rwde);
                result[item.fqn] = itemPermissions.satisfiesRequired(checkPerm);
            }
            return values(result);
        }));
    };
    PermissionsService.decorators = [
        { type: Injectable }
    ];
    PermissionsService.ctorParameters = function () { return [
        { type: InstanceService }
    ]; };
    return PermissionsService;
}());

function setupInstanceSvc(config, httpClient) {
    return new InstanceService(config, httpClient);
}
function setupLiveDataSvc(config, httpClient) {
    return new LiveDataService(config, httpClient);
}
function setupTimeseriesDataSvc(config, httpClient, qualitySvc) {
    return new TimeseriesDataService(config, httpClient, qualitySvc);
}
function setupOperationSvc(config, httpClient) {
    return new OperationService(config, httpClient);
}
function setupPersistenceSvc(config, httpClient) {
    return new PersistenceService(config, httpClient);
}
function setupNavigationSvc(config, httpClient) {
    return new NavigationService(config, httpClient);
}
function setupSecurityContextSvc(config, httpClient) {
    return new SecurityContextService(config, httpClient);
}
function setupMimeSvc(config, httpClient) {
    return new MimeService(config, httpClient);
}
function setupNavigationHandlerSvc(config, httpClient) {
    return new NavigationHandlerService(config, httpClient);
}
var RaFtcCommunicationModule = (function () {
    function RaFtcCommunicationModule() {
    }
    RaFtcCommunicationModule.forRoot = function (config) {
        return {
            ngModule: RaFtcCommunicationModule,
            providers: [
                {
                    provide: InstanceService,
                    useFactory: setupInstanceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: LiveDataService,
                    useFactory: setupLiveDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: TimeseriesDataService,
                    useFactory: setupTimeseriesDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient, OpcQualityService
                    ]
                },
                {
                    provide: OperationService,
                    useFactory: setupOperationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: PersistenceService,
                    useFactory: setupPersistenceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationService,
                    useFactory: setupNavigationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: SecurityContextService,
                    useFactory: setupSecurityContextSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: MimeService,
                    useFactory: setupMimeSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationHandlerService,
                    useFactory: setupNavigationHandlerSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                { provide: COMMUNICATION_CONFIG, useValue: config },
                OpcQualityService,
                FqnService,
                PermissionsService
            ]
        };
    };
    RaFtcCommunicationModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        HttpClientModule
                    ],
                    providers: [OpcQualityService, FqnService],
                    declarations: []
                },] }
    ];
    return RaFtcCommunicationModule;
}());

export { setupInstanceSvc, setupLiveDataSvc, setupTimeseriesDataSvc, setupOperationSvc, setupPersistenceSvc, setupNavigationSvc, setupSecurityContextSvc, setupMimeSvc, setupNavigationHandlerSvc, RaFtcCommunicationModule, BaseService, InstanceService, InstanceRequest, LiveRequest, LiveDataService, NavigationService, NavigationRequest, OperationService, OperationRequest, PersistenceService, PropNameValues, PersistRequest, TimeseriesRequestQuality, TimeseriesRepeatedDataFormat, SamplingTypes, TimeseriesRequest, TimeseriesDataService, OpcQualityService, SecurityContextService, MomentHelperService, MimeService, NavigationHandlerService, NavigationHandlerRequest, FqnService, PermissionsService, DEFAULT_REPEATED_DATA_INTERVAL, COMMUNICATION_CONFIG, ItemPermissions };

//# sourceMappingURL=ra-wcftcloud-ra-ftc-communication.js.map