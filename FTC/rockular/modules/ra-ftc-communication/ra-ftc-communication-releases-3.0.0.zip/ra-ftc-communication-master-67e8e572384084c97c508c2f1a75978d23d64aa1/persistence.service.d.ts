import { BaseService } from './base.service';
import { ICommunicationConfig } from './config';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { identifier } from './shared';
export interface INewItem {
    parentPropertyFqn: string;
    itemType: string;
    props?: PropNameValues;
}
export interface IRenamedItem {
    fqn: string;
    newName: string;
}
export interface IChangedItem {
    FullyQualifiedName: string;
    [key: string]: any;
}
export declare class PersistenceService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    commit(persistRequest: PersistRequest): Observable<any>;
}
export declare class PropNameValues {
    add(name: string, value: string): void;
    remove(name: string): void;
    isEmpty(): boolean;
}
export declare class PersistRequest {
    newItems: INewItem[];
    renamedItem: IRenamedItem;
    changedItems: IChangedItem[];
    deletedItems: identifier[];
    createItem(parentPropertyFqn: string, itemType: string, propNameValues?: PropNameValues): PersistRequest;
    renameItem(itemFqn: string, newName: string): PersistRequest;
    changeItem(itemFqn: string, propNameValues: PropNameValues): PersistRequest;
    deleteItem(itemFqn: string): PersistRequest;
}
