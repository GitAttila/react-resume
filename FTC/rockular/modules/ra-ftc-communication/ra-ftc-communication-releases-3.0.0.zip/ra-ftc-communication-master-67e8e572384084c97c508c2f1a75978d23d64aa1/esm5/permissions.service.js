import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import * as _ from 'lodash';
import { ItemPermissions } from './models/item-permissions';
import { InstanceService, InstanceRequest } from './instance.service';
var PermissionsService = (function () {
    function PermissionsService(instanceSvc) {
        this.instanceSvc = instanceSvc;
    }
    PermissionsService.prototype.checkItemsPermissions = function (fqns, requiredPermissions) {
        var checkPerm = ItemPermissions.create(requiredPermissions);
        var req = new InstanceRequest();
        var result = {};
        fqns.forEach(function (fqn) {
            result[fqn] = false;
            req.addItemFqn(fqn, false, 0);
        });
        return this.instanceSvc.getInstances(req).pipe(map(function (response) {
            for (var index = 0; index < response.fqnsResults.length; index++) {
                var itemData = response.fqnsResults[index];
                var item = itemData.item;
                if (!item || !item.fqn || _.isNil(result[item.fqn])) {
                    continue;
                }
                var itemPermissions = ItemPermissions.create(item.rwde);
                result[item.fqn] = itemPermissions.satisfiesRequired(checkPerm);
            }
            return _.values(result);
        }));
    };
    PermissionsService.decorators = [
        { type: Injectable }
    ];
    PermissionsService.ctorParameters = function () { return [
        { type: InstanceService }
    ]; };
    return PermissionsService;
}());
export { PermissionsService };
if (false) {
    PermissionsService.prototype.instanceSvc;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVybWlzc2lvbnMuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJwZXJtaXNzaW9ucy5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3JDLE9BQU8sS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBR3RFO0lBR0ksNEJBQW9CLFdBQTRCO1FBQTVCLGdCQUFXLEdBQVgsV0FBVyxDQUFpQjtJQUFJLENBQUM7SUFRckQsa0RBQXFCLEdBQXJCLFVBQXNCLElBQWMsRUFBRSxtQkFBNkM7WUFDekUsU0FBUyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUM7WUFDdkQsR0FBRyxHQUFHLElBQUksZUFBZSxFQUFFO1lBQzNCLE1BQU0sR0FBRyxFQUFFO1FBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHO1lBQ2IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUVwQixHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FDMUMsR0FBRyxDQUFDLFVBQUMsUUFBYTtZQUNkLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtvQkFDeEQsUUFBUSxHQUFHLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO29CQUN0QyxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUk7Z0JBQzFCLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUNqRCxTQUFTO2lCQUNaO29CQUNLLGVBQWUsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Z0JBQ3pELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsZUFBZSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ25FO1lBQ0QsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUNMLENBQUM7SUFDTixDQUFDOztnQkFsQ0osVUFBVTs7O2dCQUhGLGVBQWU7O0lBc0N4Qix5QkFBQztDQUFBLEFBbkNELElBbUNDO1NBbENZLGtCQUFrQjs7SUFFZix5Q0FBb0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBJdGVtUGVybWlzc2lvbnMgfSBmcm9tICcuL21vZGVscy9pdGVtLXBlcm1pc3Npb25zJztcclxuaW1wb3J0IHsgSW5zdGFuY2VTZXJ2aWNlLCBJbnN0YW5jZVJlcXVlc3QgfSBmcm9tICcuL2luc3RhbmNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBQZXJtaXNzaW9uc1NlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgaW5zdGFuY2VTdmM6IEluc3RhbmNlU2VydmljZSkgeyB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gY2hlY2sgZnFuIGl0ZW1zIHBlcm1pc3Npb25zLlxyXG4gICAgICogQHBhcmFtIGZxbnMgbGlzdCBvZiBmcW5zXHJcbiAgICAgKiBAcGFyYW0gcmVxdWlyZWRQZXJtaXNzaW9ucyBwZXJtaXNzaW9ucyB0byBjaGVjayBhcyBpbiByd2RlIGZvcm1hdCBvciBJdGVtUGVybWlzc2lvbnMgaW5zdGFuY2VcclxuICAgICAqIHJ3ZGUgZXhhbXBsZXMgKGNhc2UgaW5zZW5zaXRpdmUpOiAneXlubicsICdZWU5OJywgWU5ZTlxyXG4gICAgICovXHJcbiAgICBjaGVja0l0ZW1zUGVybWlzc2lvbnMoZnFuczogc3RyaW5nW10sIHJlcXVpcmVkUGVybWlzc2lvbnM6IHN0cmluZyB8IEl0ZW1QZXJtaXNzaW9ucyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgY29uc3QgY2hlY2tQZXJtID0gSXRlbVBlcm1pc3Npb25zLmNyZWF0ZShyZXF1aXJlZFBlcm1pc3Npb25zKTtcclxuICAgICAgICBjb25zdCByZXEgPSBuZXcgSW5zdGFuY2VSZXF1ZXN0KCk7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0ge307XHJcbiAgICAgICAgZnFucy5mb3JFYWNoKChmcW4pID0+IHtcclxuICAgICAgICAgICAgcmVzdWx0W2Zxbl0gPSBmYWxzZTtcclxuICAgICAgICAgICAgLy8gd2UgZG8gbm90IGluY2x1ZGUgQUNMIHdpdGggcm9sZXMsIHdlIHdhbnQgb25seSByZXN1bHRpbmcgUldERVxyXG4gICAgICAgICAgICByZXEuYWRkSXRlbUZxbihmcW4sIGZhbHNlLCAwKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZVN2Yy5nZXRJbnN0YW5jZXMocmVxKS5waXBlKFxyXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCByZXNwb25zZS5mcW5zUmVzdWx0cy5sZW5ndGg7IGluZGV4KyspIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtRGF0YSA9IHJlc3BvbnNlLmZxbnNSZXN1bHRzW2luZGV4XTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gaXRlbURhdGEuaXRlbTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIWl0ZW0gfHwgIWl0ZW0uZnFuIHx8IF8uaXNOaWwocmVzdWx0W2l0ZW0uZnFuXSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW1QZXJtaXNzaW9ucyA9IEl0ZW1QZXJtaXNzaW9ucy5jcmVhdGUoaXRlbS5yd2RlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRbaXRlbS5mcW5dID0gaXRlbVBlcm1pc3Npb25zLnNhdGlzZmllc1JlcXVpcmVkKGNoZWNrUGVybSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXy52YWx1ZXMocmVzdWx0KTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICApO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==