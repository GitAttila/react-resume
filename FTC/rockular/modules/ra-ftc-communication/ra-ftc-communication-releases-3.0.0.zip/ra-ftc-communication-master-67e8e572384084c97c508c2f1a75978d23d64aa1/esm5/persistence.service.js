import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { COMMUNICATION_CONFIG } from './config';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
export function INewItem() { }
if (false) {
    INewItem.prototype.parentPropertyFqn;
    INewItem.prototype.itemType;
    INewItem.prototype.props;
}
export function IRenamedItem() { }
if (false) {
    IRenamedItem.prototype.fqn;
    IRenamedItem.prototype.newName;
}
export function IChangedItem() { }
if (false) {
    IChangedItem.prototype.FullyQualifiedName;
}
var PersistenceService = (function (_super) {
    tslib_1.__extends(PersistenceService, _super);
    function PersistenceService(config, http) {
        return _super.call(this, '/api/1/persistence/', config, http) || this;
    }
    PersistenceService.prototype.commit = function (persistRequest) {
        return this._sendPostRequest(persistRequest);
    };
    PersistenceService.decorators = [
        { type: Injectable }
    ];
    PersistenceService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return PersistenceService;
}(BaseService));
export { PersistenceService };
var PropNameValues = (function () {
    function PropNameValues() {
    }
    PropNameValues.prototype.add = function (name, value) {
        if (name) {
            this[name] = value;
        }
    };
    PropNameValues.prototype.remove = function (name) {
        if (!_.isNil(this[name])) {
            delete this[name];
        }
    };
    PropNameValues.prototype.isEmpty = function () {
        return !_.some(this);
    };
    return PropNameValues;
}());
export { PropNameValues };
var PersistRequest = (function () {
    function PersistRequest() {
    }
    PersistRequest.prototype.createItem = function (parentPropertyFqn, itemType, propNameValues) {
        var createRequest = {
            parentPropertyFqn: parentPropertyFqn,
            itemType: itemType
        };
        if (propNameValues) {
            createRequest.props = propNameValues;
        }
        if (!this.newItems) {
            this.newItems = [];
        }
        this.newItems.push(createRequest);
        return this;
    };
    PersistRequest.prototype.renameItem = function (itemFqn, newName) {
        this.renamedItem = {
            fqn: itemFqn,
            newName: newName
        };
        return this;
    };
    PersistRequest.prototype.changeItem = function (itemFqn, propNameValues) {
        if (!propNameValues.isEmpty()) {
            var changeRequest = {
                FullyQualifiedName: itemFqn
            };
            _.extend(changeRequest, propNameValues);
            if (!this.changedItems) {
                this.changedItems = [];
            }
            this.changedItems.push(changeRequest);
        }
        return this;
    };
    PersistRequest.prototype.deleteItem = function (itemFqn) {
        if (!this.deletedItems) {
            this.deletedItems = [];
        }
        this.deletedItems.push(itemFqn);
        return this;
    };
    return PersistRequest;
}());
export { PersistRequest };
if (false) {
    PersistRequest.prototype.newItems;
    PersistRequest.prototype.renamedItem;
    PersistRequest.prototype.changedItems;
    PersistRequest.prototype.deletedItems;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyc2lzdGVuY2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJwZXJzaXN0ZW5jZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUMsTUFBTSxFQUFFLFVBQVUsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUNqRCxPQUFPLEVBQUMsV0FBVyxFQUFDLE1BQU0sZ0JBQWdCLENBQUM7QUFDM0MsT0FBTyxFQUFDLG9CQUFvQixFQUF1QixNQUFNLFVBQVUsQ0FBQztBQUNwRSxPQUFPLEVBQUMsVUFBVSxFQUFDLE1BQU0sc0JBQXNCLENBQUM7QUFHaEQsT0FBTyxLQUFLLENBQUMsTUFBTSxRQUFRLENBQUM7QUFFNUIsOEJBSUM7O0lBSEcscUNBQTBCO0lBQzFCLDRCQUFpQjtJQUNqQix5QkFBdUI7O0FBRzNCLGtDQUdDOztJQUZHLDJCQUFZO0lBQ1osK0JBQWdCOztBQUdwQixrQ0FHQzs7SUFGRywwQ0FBMkI7O0FBSS9CO0lBQ3dDLDhDQUFXO0lBRS9DLDRCQUEwQyxNQUE0QixFQUFFLElBQWdCO2VBQ3BGLGtCQUFNLHFCQUFxQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUM7SUFDOUMsQ0FBQztJQUtELG1DQUFNLEdBQU4sVUFBTyxjQUE4QjtRQUNqQyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNqRCxDQUFDOztnQkFaSixVQUFVOzs7Z0RBR00sTUFBTSxTQUFDLG9CQUFvQjtnQkF4QnBDLFVBQVU7O0lBa0NsQix5QkFBQztDQUFBLEFBYkQsQ0FDd0MsV0FBVyxHQVlsRDtTQVpZLGtCQUFrQjtBQWMvQjtJQUFBO0lBMEJBLENBQUM7SUFuQkcsNEJBQUcsR0FBSCxVQUFJLElBQVksRUFBRSxLQUFhO1FBQzNCLElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFNRCwrQkFBTSxHQUFOLFVBQU8sSUFBWTtRQUNmLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JCO0lBQ0wsQ0FBQztJQUVELGdDQUFPLEdBQVA7UUFDSSxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBQ0wscUJBQUM7QUFBRCxDQUFDLEFBMUJELElBMEJDOztBQUVEO0lBQUE7SUErRUEsQ0FBQztJQS9ERyxtQ0FBVSxHQUFWLFVBQVcsaUJBQXlCLEVBQUUsUUFBZ0IsRUFBRSxjQUErQjtZQUM3RSxhQUFhLEdBQWE7WUFDNUIsaUJBQWlCLEVBQUUsaUJBQWlCO1lBQ3BDLFFBQVEsRUFBRSxRQUFRO1NBQ3JCO1FBRUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIsYUFBYSxDQUFDLEtBQUssR0FBRyxjQUFjLENBQUM7U0FDeEM7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztTQUN0QjtRQUVELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ2xDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFPRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZSxFQUFFLE9BQWU7UUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRztZQUNmLEdBQUcsRUFBRSxPQUFPO1lBQ1osT0FBTyxFQUFFLE9BQU87U0FDbkIsQ0FBQztRQUVGLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFPRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZSxFQUFFLGNBQThCO1FBQ3RELElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLEVBQUU7Z0JBQ3JCLGFBQWEsR0FBaUI7Z0JBQ2hDLGtCQUFrQixFQUFFLE9BQU87YUFDOUI7WUFDRCxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUV4QyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDcEIsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7YUFDMUI7WUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUN6QztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFNRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZTtRQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNwQixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFDTCxxQkFBQztBQUFELENBQUMsQUEvRUQsSUErRUM7OztJQTdFRyxrQ0FBcUI7SUFFckIscUNBQTBCO0lBRTFCLHNDQUE2QjtJQUU3QixzQ0FBMkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0luamVjdCwgSW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7QmFzZVNlcnZpY2V9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7aWRlbnRpZmllcn0gZnJvbSAnLi9zaGFyZWQnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElOZXdJdGVtIHtcclxuICAgIHBhcmVudFByb3BlcnR5RnFuOiBzdHJpbmc7XHJcbiAgICBpdGVtVHlwZTogc3RyaW5nO1xyXG4gICAgcHJvcHM/OiBQcm9wTmFtZVZhbHVlcztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUmVuYW1lZEl0ZW0ge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuZXdOYW1lOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNoYW5nZWRJdGVtIHtcclxuICAgIEZ1bGx5UXVhbGlmaWVkTmFtZTogc3RyaW5nO1xyXG4gICAgW2tleTogc3RyaW5nXTogYW55O1xyXG59XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBQZXJzaXN0ZW5jZVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgICAgIHN1cGVyKCcvYXBpLzEvcGVyc2lzdGVuY2UvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gUGVyc2lzdGVuY2Ugc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAqL1xyXG4gICAgY29tbWl0KHBlcnNpc3RSZXF1ZXN0OiBQZXJzaXN0UmVxdWVzdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChwZXJzaXN0UmVxdWVzdCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQcm9wTmFtZVZhbHVlcyB7XHJcblxyXG4gIC8qKlxyXG4gICAqIEFkZHMgcHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyIGZvciBOZXcgSXRlbSBDcmVhdGlvblxyXG4gICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gYWRkXHJcbiAgICogQHBhcmFtIHZhbHVlIC0gVmFsdWUgdG8gYWRkIGF0IE5hbWUgcHJvcGVydHkgbmFtZVxyXG4gICAqL1xyXG4gICAgYWRkKG5hbWU6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xyXG4gICAgICAgIGlmIChuYW1lKSB7XHJcbiAgICAgICAgICAgIHRoaXNbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmVzIHByb3BlcnR5IE5hbWVcclxuICAgICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZShuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoIV8uaXNOaWwodGhpc1tuYW1lXSkpIHtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXNbbmFtZV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlzRW1wdHkoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICFfLnNvbWUodGhpcyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAvKiogTGlzdCBvZiBuZXcgaXRlbXMgdG8gcGVyc2lzdCAqL1xyXG4gICAgbmV3SXRlbXM6IElOZXdJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byByZW5hbWUgKi9cclxuICAgIHJlbmFtZWRJdGVtOiBJUmVuYW1lZEl0ZW07XHJcbiAgICAvKiogTGlzdCBvZiBjaGFuZ2VkIGl0ZW1zIHRvIHBlcnNpc3QgKi9cclxuICAgIGNoYW5nZWRJdGVtczogSUNoYW5nZWRJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byBkZWxldGUgKi9cclxuICAgIGRlbGV0ZWRJdGVtczogaWRlbnRpZmllcltdO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ3JlYXRlIEl0ZW0gdmlhIFBlcnNpc3RlbmNlIFNlcnZpY2VcclxuICAgICAqIEBwYXJhbSBwYXJlbnRQcm9wZXJ0eUZxbiAtIEZRTiBvZiBQYXJlbnQgUHJvcGVydHlcclxuICAgICAqIEBwYXJhbSBpdGVtVHlwZSAtIEl0ZW0gVHlwZVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyc1xyXG4gICAgICovXHJcbiAgICBjcmVhdGVJdGVtKHBhcmVudFByb3BlcnR5RnFuOiBzdHJpbmcsIGl0ZW1UeXBlOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzPzogUHJvcE5hbWVWYWx1ZXMpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgY29uc3QgY3JlYXRlUmVxdWVzdDogSU5ld0l0ZW0gPSB7XHJcbiAgICAgICAgICAgIHBhcmVudFByb3BlcnR5RnFuOiBwYXJlbnRQcm9wZXJ0eUZxbixcclxuICAgICAgICAgICAgaXRlbVR5cGU6IGl0ZW1UeXBlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKHByb3BOYW1lVmFsdWVzKSB7XHJcbiAgICAgICAgICAgIGNyZWF0ZVJlcXVlc3QucHJvcHMgPSBwcm9wTmFtZVZhbHVlcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5uZXdJdGVtcykge1xyXG4gICAgICAgICAgICB0aGlzLm5ld0l0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5ld0l0ZW1zLnB1c2goY3JlYXRlUmVxdWVzdCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW5hbWUgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIG5ld05hbWUgLSBOZXcgTmFtZSBvZiBJdGVtXHJcbiAgICAgKi9cclxuICAgIHJlbmFtZUl0ZW0oaXRlbUZxbjogc3RyaW5nLCBuZXdOYW1lOiBzdHJpbmcpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgdGhpcy5yZW5hbWVkSXRlbSA9IHtcclxuICAgICAgICAgICAgZnFuOiBpdGVtRnFuLFxyXG4gICAgICAgICAgICBuZXdOYW1lOiBuZXdOYW1lXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDaGFuZ2UgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydGllcyB0byBjaGFuZ2VcclxuICAgICAqL1xyXG4gICAgY2hhbmdlSXRlbShpdGVtRnFuOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzOiBQcm9wTmFtZVZhbHVlcyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXByb3BOYW1lVmFsdWVzLmlzRW1wdHkoKSkge1xyXG4gICAgICAgICAgICBjb25zdCBjaGFuZ2VSZXF1ZXN0OiBJQ2hhbmdlZEl0ZW0gPSB7XHJcbiAgICAgICAgICAgICAgICBGdWxseVF1YWxpZmllZE5hbWU6IGl0ZW1GcW5cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgXy5leHRlbmQoY2hhbmdlUmVxdWVzdCwgcHJvcE5hbWVWYWx1ZXMpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNoYW5nZWRJdGVtcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VkSXRlbXMgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmNoYW5nZWRJdGVtcy5wdXNoKGNoYW5nZVJlcXVlc3QpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIERlbGV0ZSBJdGVtIHZpYSBQZXJzaXN0ZW5jZSBTZXJ2aWNlXHJcbiAgICAgKiBAcGFyYW0gaXRlbUZxbiAtIEZRTiBvZiBJdGVtIHRvIGRlbGV0ZVxyXG4gICAgICovXHJcbiAgICBkZWxldGVJdGVtKGl0ZW1GcW46IHN0cmluZyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXRoaXMuZGVsZXRlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zLnB1c2goaXRlbUZxbik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcbn1cclxuIl19