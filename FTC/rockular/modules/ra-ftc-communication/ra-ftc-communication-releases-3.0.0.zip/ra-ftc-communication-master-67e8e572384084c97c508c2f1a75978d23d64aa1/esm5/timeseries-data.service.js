import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { OpcQualityService } from './opc-quality.service';
import { Observable, timer } from 'rxjs';
import { map, concatMap, expand } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
import { MomentHelperService } from './moment-helper.service';
export function ITimeseriesValuesResponseVqts() { }
if (false) {
    ITimeseriesValuesResponseVqts.prototype.v;
    ITimeseriesValuesResponseVqts.prototype.q;
    ITimeseriesValuesResponseVqts.prototype.t;
}
export function ITimeseriesValuesResponse() { }
if (false) {
    ITimeseriesValuesResponse.prototype.values;
}
export function ITimeseriesResponse() { }
if (false) {
    ITimeseriesResponse.prototype.timePeriod;
    ITimeseriesResponse.prototype.results;
}
function ITimeseriesValuesResponseInternalObject() { }
if (false) {
    ITimeseriesValuesResponseInternalObject.prototype.fqn;
    ITimeseriesValuesResponseInternalObject.prototype.name;
    ITimeseriesValuesResponseInternalObject.prototype.engineeringUnit;
    ITimeseriesValuesResponseInternalObject.prototype.valueType;
    ITimeseriesValuesResponseInternalObject.prototype.values;
}
export function ITimePeriodResponse() { }
if (false) {
    ITimePeriodResponse.prototype.start;
    ITimePeriodResponse.prototype.end;
    ITimePeriodResponse.prototype.duration;
}
function ITimeseriesValuesResponseInternal() { }
if (false) {
    ITimeseriesValuesResponseInternal.prototype.timePeriod;
    ITimeseriesValuesResponseInternal.prototype.fqnsResults;
    ITimeseriesValuesResponseInternal.prototype.queryResults;
}
export function ITimePeriod() { }
if (false) {
    ITimePeriod.prototype.start;
    ITimePeriod.prototype.end;
    ITimePeriod.prototype.duration;
}
var TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
export { TimeseriesRequestQuality };
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = 'includeGood';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = 'includeBad';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = 'includeUncertain';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = 'includeAll';
var TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
export { TimeseriesRepeatedDataFormat };
var SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
    PointsInTime: 'PointsInTime',
};
export { SamplingTypes };
export function ISamplingDefinition() { }
if (false) {
    ISamplingDefinition.prototype.sliceCount;
    ISamplingDefinition.prototype.deltaT;
    ISamplingDefinition.prototype.samplingType;
}
var TimeseriesRequest = (function () {
    function TimeseriesRequest(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    TimeseriesRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    TimeseriesRequest.prototype.removeFqn = function (fqn) {
        var index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    TimeseriesRequest.prototype.setFqns = function (fqns) {
        this.fqns = _.clone(fqns);
    };
    TimeseriesRequest.prototype.getFqns = function () {
        return _.clone(this.fqns);
    };
    TimeseriesRequest.prototype.setTimePeriod = function (timePeriod) {
        this.timePeriod = _.clone(timePeriod);
    };
    TimeseriesRequest.prototype.getTimePeriod = function () {
        return _.clone(this.timePeriod);
    };
    TimeseriesRequest.prototype.setSamplingDefinition = function (samplingDefinition) {
        this.samplingDefinition = _.clone(samplingDefinition);
    };
    TimeseriesRequest.prototype.getSamplingDefinition = function () {
        return _.clone(this.samplingDefinition);
    };
    TimeseriesRequest.prototype.setTimeDeadBand = function (timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    };
    TimeseriesRequest.prototype.getTimeDeadband = function () {
        return this.timeDeadBand;
    };
    TimeseriesRequest.prototype.setValueDeadBand = function (valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    };
    TimeseriesRequest.prototype.getValueDeadBand = function () {
        return this.valueDeadBand;
    };
    TimeseriesRequest.prototype.setQualityFilter = function (qualityFilter) {
        this.qualityFilter = qualityFilter;
    };
    TimeseriesRequest.prototype.getQualityFilter = function () {
        return this.qualityFilter;
    };
    return TimeseriesRequest;
}());
export { TimeseriesRequest };
if (false) {
    TimeseriesRequest.prototype.fqns;
    TimeseriesRequest.prototype.timePeriod;
    TimeseriesRequest.prototype.samplingDefinition;
    TimeseriesRequest.prototype.timeDeadBand;
    TimeseriesRequest.prototype.valueDeadBand;
    TimeseriesRequest.prototype.qualityFilter;
}
var TimeseriesDataService = (function (_super) {
    tslib_1.__extends(TimeseriesDataService, _super);
    function TimeseriesDataService(config, http, opcQualitySvc) {
        var _this = _super.call(this, '/api/1/timeseries/', config, http) || this;
        _this.opcQualitySvc = opcQualitySvc;
        return _this;
    }
    TimeseriesDataService.prototype.getOnce = function (request, timezone) {
        var _this = this;
        var tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        return this._sendPostRequest(request).pipe(map(function (response) {
            return _this._transformTimeseriesInternalResponse(response, tz);
        }));
    };
    TimeseriesDataService.prototype._getErrorObservable = function (errorString) {
        return new Observable(function (observer) {
            observer.error(errorString);
            return function () {
                observer.unsubscribe();
            };
        });
    };
    TimeseriesDataService.prototype._applyTimezoneToVqtData = function (vqtData, timezone) {
        _.each(vqtData, function (vqt) {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    };
    TimeseriesDataService.prototype._getRequestDataNextStartValues = function (response, nextStartMoment) {
        var beforeNextRequestValues = new Map();
        var last;
        _.each(response.fqnsResults, function (el) {
            if (!_.isNil(el) && el.values.length) {
                last = _.last(el.values);
                beforeNextRequestValues.set(el.fqn, last);
            }
        });
        return beforeNextRequestValues;
    };
    TimeseriesDataService.prototype._getStartForNextRequest = function (response, originalDuration, repeatedInterval) {
        var opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            var timeString = _.first(fqnResult.values).t;
            for (var i = fqnResult.values.length - 1; i >= 0; i--) {
                var val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        var result;
        var currentTimeMinusDuration = moment.utc().subtract(Math.abs(originalDuration), 'seconds');
        _.each(response.fqnsResults, function (fqnResult) {
            if (_.isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            var lastValue = moment.utc(getLastTimeToUse(fqnResult));
            if (_.isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (_.isNil(result)) {
            result = moment.utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    };
    TimeseriesDataService.prototype._filterStartResponseData = function (response, previousResponseLastData, requestTimePeriod) {
        var firstVqt;
        var firstVqtMoment;
        var secondVqt;
        var opcQualitySvc = this.opcQualitySvc;
        var cutBeforeDate = moment.utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        _.each(response.fqnsResults, function (el) {
            if (!_.isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                var onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                var onePreviousResponseLastDataMoment = moment.utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = moment.utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < moment.utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    };
    TimeseriesDataService.prototype._transformTimeseriesInternalResponse = function (response, timezone) {
        var _this = this;
        var applyTimezone = false;
        if (!_.isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        var ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        _.each(response.fqnsResults, function (oneResult) {
            if (_.isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                _this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    };
    TimeseriesDataService.prototype._filterDuplicateDataAndCut = function (values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        var ids = [];
        var objectToAddToArray;
        var firstIsAfter = false;
        function arrayFilter(o) {
            var currentItemMoment = moment.utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = _.clone(o);
                    var cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!_.isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        var filteredArray = values.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            var lastValue = _.last(filteredArray);
            if (!lastValue || !moment.utc(lastValue.t).isSame(moment.utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    };
    TimeseriesDataService.prototype._getRepeatedlyWhole = function (request, customInterval, timezone) {
        var _this = this;
        var lastMergedResponse;
        var tz = timezone;
        var repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map(function (response) {
            if (!_.isNil(lastMergedResponse)) {
                var requestTimePeriod = request.getTimePeriod();
                var cutBeforeDate_1 = moment.utc(response.timePeriod.end);
                cutBeforeDate_1.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                var cutBeforeDateUTCFormat = cutBeforeDate_1.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!_.isNil(tz)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        moment.utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                _.each(lastMergedResponse.results, function (result) {
                    var newResults = _.find(response.results, { fqn: result.fqn });
                    if (!_.isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = _.sortBy(result.values, [function (o) {
                                return moment.utc(o.t);
                            }]);
                        result.values = _this._filterDuplicateDataAndCut(result.values, cutBeforeDate_1, false, tz);
                    }
                });
                _.each(response.results, function (newResult) {
                    if (!_.find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    };
    TimeseriesDataService.prototype._getRepeatedlyIncrements = function (request, customInterval, timezone) {
        var _this = this;
        var requestTimePeriod = request.getTimePeriod();
        var lastResponseData;
        var repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        var lastRepeatedRequest = _.clone(request);
        var originalDuration = requestTimePeriod.duration;
        var nextRequestStartMoment;
        var repeatedDataObservable = this._sendPostRequest(request).pipe(map(function (response) {
            nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return _this._transformTimeseriesInternalResponse(response, timezone);
        }));
        var expandedObservable = repeatedDataObservable.pipe(expand(function () { return timer(repeatedInterval).pipe(concatMap(function () {
            if (!_.isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(_.extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return _this._sendPostRequest(lastRepeatedRequest).pipe(map(function (response) {
                if (lastResponseData.size > 0) {
                    _this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return _this._transformTimeseriesInternalResponse(response, timezone);
            }));
        })); }));
        return expandedObservable;
    };
    TimeseriesDataService.prototype.getRepeatedly = function (request, customInterval, format, timezone) {
        var requestTimePeriod = request.getTimePeriod();
        if (!_.isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (_.isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        var tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        if (_.isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz);
        }
    };
    TimeseriesDataService.decorators = [
        { type: Injectable }
    ];
    TimeseriesDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient },
        { type: OpcQualityService }
    ]; };
    return TimeseriesDataService;
}(BaseService));
export { TimeseriesDataService };
if (false) {
    TimeseriesDataService.prototype.opcQualitySvc;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXNlcmllcy1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsidGltZXNlcmllcy1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLEtBQUssTUFBTSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzFELE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsOEJBQThCLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFFdEcsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBRzlELG1EQUlDOztJQUhHLDBDQUE2QjtJQUM3QiwwQ0FBVTtJQUNWLDBDQUFVOztBQUlkLCtDQUVDOztJQURHLDJDQUF3Qzs7QUFJNUMseUNBR0M7O0lBRkcseUNBQWdDO0lBQ2hDLHNDQUFxQzs7QUFNekMsc0RBTUM7O0lBTEcsc0RBQVk7SUFDWix1REFBYztJQUNkLGtFQUF5QjtJQUN6Qiw0REFBbUI7SUFDbkIseURBQXdDOztBQUk1Qyx5Q0FJQzs7SUFIRyxvQ0FBYztJQUNkLGtDQUFZO0lBQ1osdUNBQWlCOztBQUlyQixnREFJQzs7SUFIRyx1REFBZ0M7SUFDaEMsd0RBQXdEO0lBQ3hELHlEQUF5RDs7QUFJN0QsaUNBSUM7O0lBSEcsNEJBQTZCO0lBQzdCLDBCQUEyQjtJQUMzQiwrQkFBa0I7OztJQUlsQixjQUFlO0lBQ2YsYUFBYztJQUNkLG1CQUFvQjtJQUNwQixhQUFjOzs7Ozs7OztJQUlkLGVBQWdCLGVBQWU7SUFDL0IsWUFBYSxZQUFZOzs7O0lBSXpCLGVBQWdCLGVBQWU7SUFDL0IsZUFBZ0IsZUFBZTtJQUMvQixRQUFTLFFBQVE7SUFDakIsT0FBUSxPQUFPO0lBQ2YsS0FBTSxLQUFLO0lBQ1gsU0FBVSxTQUFTO0lBQ25CLGFBQWMsYUFBYTtJQUMzQixPQUFRLE9BQU87SUFDZixtQkFBb0IsbUJBQW1CO0lBQ3ZDLG1CQUFvQixtQkFBbUI7SUFDdkMsU0FBVSxTQUFTO0lBQ25CLE9BQVEsT0FBTztJQUNmLEtBQU0sS0FBSztJQUNYLE9BQVEsT0FBTztJQUNmLFVBQVcsVUFBVTtJQUNyQixPQUFRLE9BQU87SUFDZixjQUFlLGNBQWM7SUFDN0IsYUFBYyxhQUFhO0lBQzNCLGFBQWMsYUFBYTtJQUMzQixZQUFhLFlBQVk7SUFDekIsY0FBZSxjQUFjO0lBQzdCLDBCQUEyQiwwQkFBMEI7SUFDckQsb0JBQXFCLG9CQUFvQjtJQUN6QyxrQkFBbUIsa0JBQWtCO0lBQ3JDLGtCQUFtQixrQkFBa0I7SUFDckMsaUJBQWtCLGlCQUFpQjtJQUNuQyxjQUFlLGNBQWM7OztBQUdqQyx5Q0FVQzs7SUFQRyx5Q0FBb0I7SUFJcEIscUNBQWdCO0lBRWhCLDJDQUE0Qjs7QUFHaEM7SUFlSSwyQkFDWSxJQUFrQixFQUNsQixVQUF1QixFQUN2QixrQkFBd0MsRUFDeEMsWUFBcUIsRUFDckIsYUFBc0IsRUFDdEIsYUFBaUQ7UUFMakQsU0FBSSxHQUFKLElBQUksQ0FBYztRQUNsQixlQUFVLEdBQVYsVUFBVSxDQUFhO1FBQ3ZCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBc0I7UUFDeEMsaUJBQVksR0FBWixZQUFZLENBQVM7UUFDckIsa0JBQWEsR0FBYixhQUFhLENBQVM7UUFDdEIsa0JBQWEsR0FBYixhQUFhLENBQW9DO1FBRXpELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBTUQsa0NBQU0sR0FBTixVQUFPLEdBQWU7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQU1ELHFDQUFTLEdBQVQsVUFBVSxHQUFlO1lBQ2YsS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQU1ELG1DQUFPLEdBQVAsVUFBUSxJQUFrQjtRQUN0QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUtELG1DQUFPLEdBQVA7UUFDSSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFNRCx5Q0FBYSxHQUFiLFVBQWMsVUFBdUI7UUFDakMsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFLRCx5Q0FBYSxHQUFiO1FBQ0ksT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBTUQsaURBQXFCLEdBQXJCLFVBQXNCLGtCQUF3QztRQUMxRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFLRCxpREFBcUIsR0FBckI7UUFDSSxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDNUMsQ0FBQztJQU1ELDJDQUFlLEdBQWYsVUFBZ0IsWUFBcUI7UUFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7SUFDckMsQ0FBQztJQUtELDJDQUFlLEdBQWY7UUFDSSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDN0IsQ0FBQztJQU1ELDRDQUFnQixHQUFoQixVQUFpQixhQUFzQjtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztJQUN2QyxDQUFDO0lBS0QsNENBQWdCLEdBQWhCO1FBQ0ksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzlCLENBQUM7SUFNRCw0Q0FBZ0IsR0FBaEIsVUFBaUIsYUFBaUQ7UUFDOUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7SUFDdkMsQ0FBQztJQUtELDRDQUFnQixHQUFoQjtRQUNJLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM5QixDQUFDO0lBQ0wsd0JBQUM7QUFBRCxDQUFDLEFBeElELElBd0lDOzs7SUF4SE8saUNBQTBCO0lBQzFCLHVDQUErQjtJQUMvQiwrQ0FBZ0Q7SUFDaEQseUNBQTZCO0lBQzdCLDBDQUE4QjtJQUM5QiwwQ0FBeUQ7O0FBd0hqRTtJQUMyQyxpREFBVztJQUVsRCwrQkFDa0MsTUFBNEIsRUFDMUQsSUFBZ0IsRUFBVSxhQUFnQztRQUY5RCxZQUdJLGtCQUFNLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FDNUM7UUFGNkIsbUJBQWEsR0FBYixhQUFhLENBQW1COztJQUU5RCxDQUFDO0lBZUQsdUNBQU8sR0FBUCxVQUFRLE9BQTBCLEVBQUUsUUFBaUI7UUFBckQsaUJBT0M7WUFOTyxFQUFVO1FBQ2QsSUFBSSxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDL0MsRUFBRSxHQUFHLFFBQVEsQ0FBQztTQUNqQjtRQUNELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUEyQztZQUN2RixPQUFBLEtBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO1FBQXZELENBQXVELENBQUMsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFNTyxtREFBbUIsR0FBM0IsVUFBNEIsV0FBbUI7UUFDM0MsT0FBTyxJQUFJLFVBQVUsQ0FBcUIsVUFBQyxRQUFRO1lBQy9DLFFBQVEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDNUIsT0FBTztnQkFDSCxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0IsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBT08sdURBQXVCLEdBQS9CLFVBQWdDLE9BQXdDLEVBQUUsUUFBUTtRQUM5RSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFDLEdBQWtDO1lBQy9DLEdBQUcsQ0FBQyxDQUFDLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDL0QsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBTU8sOERBQThCLEdBQXRDLFVBQXVDLFFBQTJDLEVBQUUsZUFBOEI7WUFFeEcsdUJBQXVCLEdBQXFCLElBQUksR0FBRyxFQUFFO1lBQ3ZELElBQW1DO1FBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ2xDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDekIsdUJBQXVCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0M7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sdUJBQXVCLENBQUM7SUFDbkMsQ0FBQztJQUtPLHVEQUF1QixHQUEvQixVQUNJLFFBQTJDLEVBQUUsZ0JBQXdCLEVBQUUsZ0JBQXdCO1lBQ3pGLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYTtRQUN4QyxTQUFTLGdCQUFnQixDQUFDLFNBQWtEO2dCQUNsRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUU5QyxLQUFLLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM3QyxHQUFHLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUN6QyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ2hCO2FBQ0o7WUFFRCxPQUFPLFVBQVUsQ0FBQztRQUN0QixDQUFDO1lBRUcsTUFBcUI7WUFDbkIsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsU0FBUyxDQUFDO1FBRTdGLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7WUFDbkMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFFckQsT0FBTzthQUNWO2dCQUNLLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3pELElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUM5QyxNQUFNLEdBQUcsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQzlCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFFakIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDeEY7UUFFRCxJQUFJLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQyxNQUFNLEdBQUcsd0JBQXdCLENBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ25GO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQU1PLHdEQUF3QixHQUFoQyxVQUNJLFFBQTJDLEVBQzNDLHdCQUFvRSxFQUFFLGlCQUE4QjtZQUNoRyxRQUFRO1lBQ1IsY0FBYztZQUNkLFNBQVM7WUFDUCxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWE7WUFDbEMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7UUFDekQsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3hFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3hFLDJCQUEyQixHQUFHLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO29CQUNsRSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztnQkFDbkYsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzdDLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksY0FBYyxHQUFHLGlDQUFpQzt3QkFDbEQsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEMsYUFBYSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUM7d0JBQ25ELGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNuQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQzFCO2lCQUNKO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxvRUFBb0MsR0FBNUMsVUFBNkMsUUFBMkMsRUFBRSxRQUFpQjtRQUEzRyxpQkFtQ0M7WUFsQ08sYUFBYSxHQUFHLEtBQUs7UUFFekIsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFFcEIsYUFBYSxHQUFHLElBQUksQ0FBQztZQUVyQixRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQ2xHO1lBRUssR0FBRyxHQUF1QjtZQUM1QixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVU7WUFDL0IsT0FBTyxFQUFFLEVBQUU7U0FDZDtRQUVELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7WUFDbkMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUVwQixPQUFPO2FBQ1Y7WUFFRCxJQUFJLGFBQWEsRUFBRTtnQkFDZixLQUFJLENBQUMsdUJBQXVCLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQzthQUM1RDtZQUVELEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2dCQUNiLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTtnQkFDcEIsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHO2dCQUNsQixTQUFTLEVBQUUsU0FBUyxDQUFDLFNBQVM7Z0JBQzlCLGVBQWUsRUFBRSxTQUFTLENBQUMsZUFBZTtnQkFDMUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxNQUFNO2FBQzNCLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0lBS08sMERBQTBCLEdBQWxDLFVBQ0ksTUFBdUMsRUFBRSxlQUE4QixFQUN2RSxvQkFBOEIsRUFBRSxRQUFpQjtZQUMzQyxHQUFHLEdBQWtCLEVBQUU7WUFDekIsa0JBQWlEO1lBQ2pELFlBQVksR0FBRyxLQUFLO1FBRXhCLFNBQVMsV0FBVyxDQUFDLENBQWdDO2dCQUMzQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQ2Ysa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDMUIsd0JBQXdCLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQywrQkFBK0IsQ0FBQztvQkFDNUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3BCLGtCQUFrQixDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ2hHO3lCQUFNO3dCQUNILGtCQUFrQixDQUFDLENBQUMsR0FBRyx3QkFBd0IsQ0FBQztxQkFDbkQ7b0JBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQztpQkFDdkI7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDaEI7WUFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN6QixPQUFPLEtBQUssQ0FBQzthQUNoQjtZQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2QsT0FBTyxJQUFJLENBQUM7UUFDaEIsQ0FBQztZQUNLLGFBQWEsR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUMxRCxJQUFJLENBQUMsb0JBQW9CLElBQUksWUFBWSxFQUFFO2dCQUNqQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDdkMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBRWpGLGFBQWEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUMxQztTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkMsQ0FBQztJQU9PLG1EQUFtQixHQUEzQixVQUE0QixPQUEwQixFQUFFLGNBQXVCLEVBQUUsUUFBaUI7UUFBbEcsaUJBOENDO1lBN0NPLGtCQUFzQztZQUNwQyxFQUFFLEdBQUcsUUFBUTtZQUViLGFBQWEsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUM7YUFDakYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLFFBQTRCO1lBQ25DLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7b0JBQ3hCLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQzNDLGVBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO2dCQUN6RCxlQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQ2xFLHNCQUFzQixHQUFHLGVBQWEsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsK0JBQStCLENBQUM7Z0JBRXhHLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFO29CQUNkLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLHNCQUFzQixFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUNwRyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO2lCQUMvRDtxQkFBTTtvQkFDSCxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLHNCQUFzQixDQUFDO29CQUM3RCxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsR0FBRzt3QkFDN0IsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO2lCQUN2RztnQkFFRCxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxVQUFDLE1BQU07d0JBQ2hDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUNoRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRTt3QkFDdEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBRXhELE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsVUFBQyxDQUFnQztnQ0FDdEUsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFSixNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUksQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGVBQWEsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7cUJBQzVGO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUVILENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFNBQVM7b0JBQy9CLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRTt3QkFDN0Qsa0JBQWtCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDOUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsT0FBTyxrQkFBa0IsQ0FBQzthQUM3QjtpQkFBTTtnQkFDSCxrQkFBa0IsR0FBRyxRQUFRLENBQUM7Z0JBQzlCLE9BQU8sUUFBUSxDQUFDO2FBQ25CO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBT08sd0RBQXdCLEdBQWhDLFVBQ0ksT0FBMEIsRUFBRSxjQUF1QixFQUFFLFFBQWlCO1FBRDFFLGlCQThDQztZQTNDUyxpQkFBaUIsR0FBRyxPQUFPLENBQUMsYUFBYSxFQUFFO1lBRTdDLGdCQUFrQztZQUNsQyxnQkFBZ0IsR0FBRyxjQUFjLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSw4QkFBOEI7UUFDbEgsZ0JBQWdCLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBRXJDLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1lBQ3RDLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDLFFBQVE7WUFDL0Msc0JBQXFDO1lBRW5DLHNCQUFzQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQUMsUUFBMkM7WUFDL0csc0JBQXNCLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBS3BHLGdCQUFnQixHQUFHLEtBQUksQ0FBQyw4QkFBOEIsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztZQUN6RixPQUFPLEtBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDekUsQ0FBQyxDQUFDLENBQUM7WUFDRyxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQ2xELE1BQU0sQ0FBQyxjQUFNLE9BQUEsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUNoRCxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO2dCQUNsQyxtQkFBbUIsQ0FBQyxhQUFhLENBQzdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUMvRztZQUNELE9BQU8sS0FBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLFFBQTJDO2dCQUNuRyxJQUFJLGdCQUFnQixDQUFDLElBQUksR0FBRyxDQUFDLEVBQUU7b0JBSTNCLEtBQUksQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztpQkFDaEY7Z0JBQ0Qsc0JBQXNCLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUtwRyxnQkFBZ0IsR0FBRyxLQUFJLENBQUMsOEJBQThCLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUM7Z0JBQ3pGLE9BQU8sS0FBSSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUN6RSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ1IsQ0FBQyxDQUFDLENBQUMsRUFwQlUsQ0FvQlYsQ0FBQyxDQUNQO1FBQ0QsT0FBTyxrQkFBa0IsQ0FBQztJQUM5QixDQUFDO0lBb0JELDZDQUFhLEdBQWIsVUFBYyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsTUFBcUMsRUFBRSxRQUFpQjtZQUdqSCxpQkFBaUIsR0FBRyxPQUFPLENBQUMsYUFBYSxFQUFFO1FBQ2pELElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ25DLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLHlEQUF5RDtrQkFDbkYsa0VBQWtFO2tCQUNsRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLHVCQUF1QixDQUFDLENBQUM7U0FDNUQ7YUFBTSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksaUJBQWlCLENBQUMsUUFBUSxHQUFHLENBQUMsRUFBRTtZQUM5RSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx5REFBeUQ7a0JBQ25GLG9EQUFvRDtrQkFDcEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVEO1lBRUcsRUFBVTtRQUNkLElBQUksbUJBQW1CLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQy9DLEVBQUUsR0FBRyxRQUFRLENBQUM7U0FDakI7UUFDRCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxLQUFLLDRCQUE0QixDQUFDLGFBQWEsRUFBRTtZQUMxRSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ2hFO2FBQU07WUFDSCxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3JFO0lBQ0wsQ0FBQzs7Z0JBelhKLFVBQVU7OztnREFJRixNQUFNLFNBQUMsb0JBQW9CO2dCQXBRM0IsVUFBVTtnQkFHVixpQkFBaUI7O0lBdW5CMUIsNEJBQUM7Q0FBQSxBQTFYRCxDQUMyQyxXQUFXLEdBeVhyRDtTQXpYWSxxQkFBcUI7O0lBSVIsOENBQXdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCAqIGFzIF8gZnJvbSAnbG9kYXNoJztcclxuaW1wb3J0ICogYXMgbW9tZW50IGZyb20gJ21vbWVudC10aW1lem9uZSc7XHJcbmltcG9ydCB7IE9wY1F1YWxpdHlTZXJ2aWNlIH0gZnJvbSAnLi9vcGMtcXVhbGl0eS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgbWFwLCBjb25jYXRNYXAsIGV4cGFuZCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnLCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUwgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IGlkZW50aWZpZXIsIElSZXNwb25zZSB9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE1vbWVudEhlbHBlclNlcnZpY2UgfSBmcm9tICcuL21vbWVudC1oZWxwZXIuc2VydmljZSc7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB2cXQgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzIHtcclxuICAgIHY6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW47XHJcbiAgICBxOiBudW1iZXI7XHJcbiAgICB0OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHZxdCBsaXN0IHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlIGV4dGVuZHMgSVJlc3BvbnNlIHtcclxuICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2Ugc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzUmVzcG9uc2Uge1xyXG4gICAgdGltZVBlcmlvZDogSVRpbWVQZXJpb2RSZXNwb25zZTtcclxuICAgIHJlc3VsdHM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VbXTtcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgVGltZXNlcmllc1Jlc3BvbnNlID0gSVRpbWVzZXJpZXNSZXNwb25zZTtcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIGludGVybmFsIG9iamVjdCBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3Qge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuYW1lPzogc3RyaW5nO1xyXG4gICAgZW5naW5lZXJpbmdVbml0Pzogc3RyaW5nO1xyXG4gICAgdmFsdWVUeXBlPzogc3RyaW5nO1xyXG4gICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB0aW1lIHBlcmlvZCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVQZXJpb2RSZXNwb25zZSB7XHJcbiAgICBzdGFydDogc3RyaW5nO1xyXG4gICAgZW5kOiBzdHJpbmc7XHJcbiAgICBkdXJhdGlvbjogbnVtYmVyO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBpbnRlcm5hbCAocmF3KSBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwge1xyXG4gICAgdGltZVBlcmlvZDogSVRpbWVQZXJpb2RSZXNwb25zZTtcclxuICAgIGZxbnNSZXN1bHRzPzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbiAgICBxdWVyeVJlc3VsdHM/OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVxdWVzdCB0aW1lIHBlcmlvZCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVQZXJpb2Qge1xyXG4gICAgc3RhcnQ/OiBEYXRlIHwgbW9tZW50Lk1vbWVudDtcclxuICAgIGVuZD86IERhdGUgfCBtb21lbnQuTW9tZW50O1xyXG4gICAgZHVyYXRpb24/OiBudW1iZXI7XHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB7XHJcbiAgICBpbmNsdWRlR29vZCA9IDEsXHJcbiAgICBpbmNsdWRlQmFkID0gMixcclxuICAgIGluY2x1ZGVVbmNlcnRhaW4gPSA0LFxyXG4gICAgaW5jbHVkZUFsbCA9IDdcclxufVxyXG5cclxuZXhwb3J0IGVudW0gVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdCB7XHJcbiAgICB3aG9sZUludGVydmFsID0gJ3dob2xlSW50ZXJ2YWwnLFxyXG4gICAgaW5jcmVtZW50cyA9ICdpbmNyZW1lbnRzJ1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBTYW1wbGluZ1R5cGVzIHtcclxuICAgIEludGVycG9sYXRpdmUgPSAnSW50ZXJwb2xhdGl2ZScsXHJcbiAgICBTYW1wbGVBbmRIb2xkID0gJ1NhbXBsZUFuZEhvbGQnLFxyXG4gICAgTGluZWFyID0gJ0xpbmVhcicsXHJcbiAgICBUb3RhbCA9ICdUb3RhbCcsXHJcbiAgICBTdW0gPSAnU3VtJyxcclxuICAgIEF2ZXJhZ2UgPSAnQXZlcmFnZScsXHJcbiAgICBUaW1lQXZlcmFnZSA9ICdUaW1lQXZlcmFnZScsXHJcbiAgICBDb3VudCA9ICdDb3VudCcsXHJcbiAgICBTdGFuZGFyZERldmlhdGlvbiA9ICdTdGFuZGFyZERldmlhdGlvbicsXHJcbiAgICBNaW5pbXVtQWN0dWFsVGltZSA9ICdNaW5pbXVtQWN0dWFsVGltZScsXHJcbiAgICBNYXhpbXVtID0gJ01heGltdW0nLFxyXG4gICAgU3RhcnQgPSAnU3RhcnQnLFxyXG4gICAgRW5kID0gJ0VuZCcsXHJcbiAgICBEZWx0YSA9ICdEZWx0YScsXHJcbiAgICBWYXJpYW5jZSA9ICdWYXJpYW5jZScsXHJcbiAgICBSYW5nZSA9ICdSYW5nZScsXHJcbiAgICBEdXJhdGlvbkdvb2QgPSAnRHVyYXRpb25Hb29kJyxcclxuICAgIER1cmF0aW9uQmFkID0gJ0R1cmF0aW9uQmFkJyxcclxuICAgIFBlcmNlbnRHb29kID0gJ1BlcmNlbnRHb29kJyxcclxuICAgIFBlcmNlbnRCYWQgPSAnUGVyY2VudEJhZCcsXHJcbiAgICBXb3JzdFF1YWxpdHkgPSAnV29yc3RRdWFsaXR5JyxcclxuICAgIFRpbWVBdmVyYWdlU2FtcGxlQW5kSG9sZCA9ICdUaW1lQXZlcmFnZVNhbXBsZUFuZEhvbGQnLFxyXG4gICAgVG90YWxTYW1wbGVBbmRIb2xkID0gJ1RvdGFsU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBNaW5TYW1wbGVBbmRIb2xkID0gJ01pblNhbXBsZUFuZEhvbGQnLFxyXG4gICAgTWF4U2FtcGxlQW5kSG9sZCA9ICdNYXhTYW1wbGVBbmRIb2xkJyxcclxuICAgIEN1bXVsYXRpdmVUb3RhbCA9ICdDdW11bGF0aXZlVG90YWwnLFxyXG4gICAgUG9pbnRzSW5UaW1lID0gJ1BvaW50c0luVGltZSdcclxufVxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyBzYW1wbGluZyBkZWZpbml0aW9uLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElTYW1wbGluZ0RlZmluaXRpb24ge1xyXG4gICAgLyoqIFRoZSBudW1iZXIgb2YgdGhlIHNsaWNlcyB0aGF0IHRoZSBwcm92aWRlZCB0aW1lIHBlcmlvZCBzaG91bGQgYmUgY3V0IGludG8uXHJcbiAgICAgKiBJZiB6ZXJvIHRoZW4gYSBub24temVybyBEZWx0YVQgdmFsdWUgbmVlZHMgdG8gYmUgcHJvdmlkZWQuICovXHJcbiAgICBzbGljZUNvdW50PzogbnVtYmVyO1xyXG4gICAgLyoqIElmIHRoZSBzbGljZSBjb3VudCBpcyB6ZXJvLCB0aGVuIGEgbm9uLXplcm8gdmFsdWUgcmVwcmVzZW50aW5nIHRoZSB3aWR0aCBvZiBhIHRpbWUgc2xpY2UgaW4gc2Vjb25kc1xyXG4gICAgICogbXVzdCBiZSBwcm92aWRlZC4gQSBwb3NpdGl2ZSB2YWx1ZSBtZWFucyB0aGUgc2xpY2VzIGFyZSBhbmNob3JlZCBhdCB0aGUgc3RhcnQgdGltZSBvZiB0aGUgcmVxdWVzdGVkIHRpbWUgcGVyaW9kLlxyXG4gICAgICogQSBuZWdhdGl2ZSB2YWx1ZSBpbmRpY2F0ZXMgYW5jaG9yaW5nIGF0IHRoZSBlbmQgb2YgdGhlIHRpbWUgcGVyaW9kLiAqL1xyXG4gICAgZGVsdGFUPzogbnVtYmVyO1xyXG4gICAgLyoqIE9uZSBvZiB0aGUgc2FtcGxpbmcgdHlwZXMgc3VwcG9ydGVkIGJ5IHRoZSB0aW1lc2VyaWVzLiBTZWUgU2FtcGxpbmdUeXBlcyBlbnVtLiAqL1xyXG4gICAgc2FtcGxpbmdUeXBlOiBTYW1wbGluZ1R5cGVzO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgVGltZXNlcmllc1JlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBUaW1lc2VyaWVzIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSBmcW5zIExpc3Qgb2YgZnFucyAoaWRlbnRpZmljYXRvcnMpIHRvIGJlIHVzZWQgZm9yIHJlcXVlc3RcclxuICAgICAqIEBwYXJhbSB0aW1lUGVyaW9kIFNldHRpbmdzIGZvciB0aW1lIHBlcmlvZCBvZiB0aW1lc2VyaWVzIHJlcXVlc3QsIGUuZy4gc3RhcnQgdGltZSwgZW5kIHRpbWUgYW5kIGR1cmF0aW9uXHJcbiAgICAgKiBAcGFyYW0gc2FtcGxpbmdEZWZpbml0aW9uIChPcHRpb25hbCkgZGVmaW5pdGlvbiBmb3IgdGltZXNlcmllcyB0byBzZXQgaG93IHRvIHByb2Nlc3MgZGF0YSwgd2hpY2ggU2FtcGxpbmcgdHlwZSB0byB1c2VcclxuICAgICAqIEBwYXJhbSB0aW1lRGVhZEJhbmQgKE9wdGlvbmFsKSBTZXR0aW5ncyBmb3IgdGltZSBkZWFkYmFuZCAtIHBvc3NpYmxlIHN0cnVjdHVyZSBbd3NdWy1dIGQgfCBkLmhoOm1tWzpzc1suZmZdXSB8IGhoOm1tWzpzc1suZmZdXSBbd3NdXHJcbiAgICAgKiBAcGFyYW0gdmFsdWVEZWFkQmFuZCAoT3B0aW9uYWwpIFNwZWNpZmllcyB0aGUgdmFsdWUgZGVhZCBiYW5kLCBjYW4gYmUgYW55IGZsb2F0IG51bWJlci5cclxuICAgICAqIEBwYXJhbSBxdWFsaXR5RmlsdGVyIChPcHRpb25hbCkgVGhpcyBpcyBhIGJpdCBmbGFnIHZhbHVlIHdpdGggdGhlIGZvbGxvd2luZyBvcHRpb25zOlxyXG4gICAgICogSW5jbHVkZUdvb2QgOiAxXHJcbiAgICAgKiBJbmNsdWRlQmFkIDogMlxyXG4gICAgICogSW5jbHVkZVVuY2VydGFpbiA6IDRcclxuICAgICAqIEluY2x1ZGVBbGwgOiA3XHJcbiAgICAgKiBVc2UgYSB2YWx1ZSBmcm9tIHByZWRlZmluZWQgZW51bSBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgb3Igc3BlY2lmeSBhIHZhbGx1ZS5cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBmcW5zOiBpZGVudGlmaWVyW10sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZCxcclxuICAgICAgICBwcml2YXRlIHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lRGVhZEJhbmQ/OiBzdHJpbmcsXHJcbiAgICAgICAgcHJpdmF0ZSB2YWx1ZURlYWRCYW5kPzogbnVtYmVyLFxyXG4gICAgICAgIHByaXZhdGUgcXVhbGl0eUZpbHRlcj86IFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB8IG51bWJlclxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5zZXRGcW5zKGZxbnMpO1xyXG4gICAgICAgIHRoaXMuc2V0VGltZVBlcmlvZCh0aW1lUGVyaW9kKTtcclxuICAgICAgICB0aGlzLnNldFNhbXBsaW5nRGVmaW5pdGlvbihzYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIG9uZSBmcW4gdG8gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gYWRkXHJcbiAgICAgKi9cclxuICAgIGFkZEZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICB0aGlzLmZxbnMucHVzaChmcW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmVtb3ZlIG9uZSBmcW4gZnJvbSByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byByZW1vdmVcclxuICAgICAqL1xyXG4gICAgcmVtb3ZlRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIGNvbnN0IGluZGV4ID0gXy5pbmRleE9mKHRoaXMuZnFucywgZnFuKTtcclxuICAgICAgICBpZiAoaW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlcGxhY2UgY3VycmVudCBmcW5zIGluIHJlcXVlc3QgdG8gbmV3IG9uZXMuXHJcbiAgICAgKiBAcGFyYW0gZnFucyBsaXN0IG9mIGZxbiBpZGVudGlmaWNhdG9ycyB0byBzZXRcclxuICAgICAqL1xyXG4gICAgc2V0RnFucyhmcW5zOiBpZGVudGlmaWVyW10pIHtcclxuICAgICAgICB0aGlzLmZxbnMgPSBfLmNsb25lKGZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IGZxbiBpZGVudGlmaWNhdG9ycy5cclxuICAgICAqL1xyXG4gICAgZ2V0RnFucygpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLmZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHJlcXVlc3QgdGltZSBwZXJpb2QuXHJcbiAgICAgKiBAcGFyYW0gdGltZVBlcmlvZFxyXG4gICAgICovXHJcbiAgICBzZXRUaW1lUGVyaW9kKHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kKSB7XHJcbiAgICAgICAgdGhpcy50aW1lUGVyaW9kID0gXy5jbG9uZSh0aW1lUGVyaW9kKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCByZXF1ZXN0IHRpbWUgcGVyaW9kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lUGVyaW9kKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMudGltZVBlcmlvZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgc2FtcGxpbmcgZGVmaW5pdGlvbi5cclxuICAgICAqIEBwYXJhbSBzYW1wbGluZ0RlZmluaXRpb25cclxuICAgICAqL1xyXG4gICAgc2V0U2FtcGxpbmdEZWZpbml0aW9uKHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24pIHtcclxuICAgICAgICB0aGlzLnNhbXBsaW5nRGVmaW5pdGlvbiA9IF8uY2xvbmUoc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBzYW1wbGluZyBkZWZpbml0aW9uLlxyXG4gICAgICovXHJcbiAgICBnZXRTYW1wbGluZ0RlZmluaXRpb24oKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy5zYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHRpbWUgZGVhZGJhbmQuXHJcbiAgICAgKiBAcGFyYW0gdGltZURlYWRCYW5kXHJcbiAgICAgKi9cclxuICAgIHNldFRpbWVEZWFkQmFuZCh0aW1lRGVhZEJhbmQ/OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLnRpbWVEZWFkQmFuZCA9IHRpbWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB0aW1lIGRlYWRiYW5kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lRGVhZGJhbmQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudGltZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHZhbHVlIGRlYWRiYW5kLlxyXG4gICAgICogQHBhcmFtIHZhbHVlRGVhZEJhbmRcclxuICAgICAqL1xyXG4gICAgc2V0VmFsdWVEZWFkQmFuZCh2YWx1ZURlYWRCYW5kPzogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy52YWx1ZURlYWRCYW5kID0gdmFsdWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB2YWx1ZSBkZWFkYmFuZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VmFsdWVEZWFkQmFuZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy52YWx1ZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHF1YWxpdHkgZmlsdGVyLlxyXG4gICAgICogQHBhcmFtIHF1YWxpdHlGaWx0ZXJcclxuICAgICAqL1xyXG4gICAgc2V0UXVhbGl0eUZpbHRlcihxdWFsaXR5RmlsdGVyPzogVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHwgbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5xdWFsaXR5RmlsdGVyID0gcXVhbGl0eUZpbHRlcjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBxdWFsaXR5IGZpbHRlci5cclxuICAgICAqL1xyXG4gICAgZ2V0UXVhbGl0eUZpbHRlcigpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5xdWFsaXR5RmlsdGVyO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogVGhpcyBzZXJ2aWNlIHByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgZm9yIHNlbmRpbmcgcmVxdWVzdHMgdG8gb2J0YWluIHRpbWVzZXJpZXMgZGF0YS5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFRpbWVzZXJpZXNEYXRhU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLFxyXG4gICAgICAgIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgb3BjUXVhbGl0eVN2YzogT3BjUXVhbGl0eVNlcnZpY2UpIHtcclxuICAgICAgICBzdXBlcignL2FwaS8xL3RpbWVzZXJpZXMvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdCB0byBzZXJ2ZXIsIGJ1dCBvbmx5IG9uY2UuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIHRpbWV6b25lIHRvIGFwcGx5IHRvIHRpbWVzZXJpZXMgcmVzcG9uc2UgZGF0YSwgb25seSBtb21lbnQgdGltZXpvbmVzIGFyZSBzdXBwb3J0ZWRcclxuICAgICAqIElmIHdvcmtpbmcgd2l0aCB0aW1lem9uZSBpbiBkYXRldGltZSBzdHJpbmcgaXQgaXMgcmVjb21tZW5kZWQgdG8gdXNlIG1vbWVudC5wYXJzZVpvbmUgdG8gcHJlc2VydmUgdGltZXpvbmUgaW5mb3JtYXRpb24uXHJcbiAgICAgKiBNb21lbnQgdGltZXpvbmVzIHRoYXQgc3RhcnQgd2l0aCBcIkV0Yy9HTVRcIiB1c2UgUE9TSVgtc3R5bGUgc2lnbnMgaW4gdGhlIFpvbmUgbmFtZXMgYW5kIHRoZSBvdXRwdXQgYWJicmV2aWF0aW9ucyxcclxuICAgICAqIGV2ZW4gdGhvdWdoIHRoaXMgaXMgdGhlIG9wcG9zaXRlIG9mIHdoYXQgbWFueSBwZW9wbGUgZXhwZWN0LlxyXG4gICAgICogUE9TSVggaGFzIHBvc2l0aXZlIHNpZ25zIHdlc3Qgb2YgR3JlZW53aWNoLCBidXQgbWFueSBwZW9wbGUgZXhwZWN0XHJcbiAgICAgKiBwb3NpdGl2ZSBzaWducyBlYXN0IG9mIEdyZWVud2ljaC4gIEZvciBleGFtcGxlLCBUWj0nRXRjL0dNVCs0JyB1c2VzXHJcbiAgICAgKiB0aGUgYWJicmV2aWF0aW9uIFwiR01UKzRcIiBhbmQgY29ycmVzcG9uZHMgdG8gNCBob3VycyBiZWhpbmQgVVRcclxuICAgICAqIChpLmUuIHdlc3Qgb2YgR3JlZW53aWNoKSBldmVuIHRob3VnaCBtYW55IHBlb3BsZSB3b3VsZCBleHBlY3QgaXQgdG9cclxuICAgICAqIG1lYW4gNCBob3VycyBhaGVhZCBvZiBVVCAoaS5lLiBlYXN0IG9mIEdyZWVud2ljaCkuXHJcbiAgICAgKi9cclxuICAgIGdldE9uY2UocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICBsZXQgdHo6IHN0cmluZztcclxuICAgICAgICBpZiAoTW9tZW50SGVscGVyU2VydmljZS5pc1ZhbGlkVGltZXpvbmUodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIHR6ID0gdGltZXpvbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+XHJcbiAgICAgICAgICAgIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0eikpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byByZXR1cm4gYW4gb2JzZXJ2YWJsZSB3aGljaCBpbW1lZGlhdGVsbHkgZXJyb3JzIG91dCB3aXRoIGdpdmVuIGVycm9yIHN0cmluZy5cclxuICAgICAqIEBwYXJhbSBlcnJvclN0cmluZ1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRFcnJvck9ic2VydmFibGUoZXJyb3JTdHJpbmc6IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4oKG9ic2VydmVyKSA9PiB7XHJcbiAgICAgICAgICAgIG9ic2VydmVyLmVycm9yKGVycm9yU3RyaW5nKTtcclxuICAgICAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gYXBwbHkgdGltZXpvbmUgdG8gd2hvbGVcclxuICAgICAqIEBwYXJhbSB2cXREYXRhIGxpc3Qgb2YgVlFUIGRhdGFcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSB0aW1lem9uZSBzdHJpbmdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfYXBwbHlUaW1lem9uZVRvVnF0RGF0YSh2cXREYXRhOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdLCB0aW1lem9uZSkge1xyXG4gICAgICAgIF8uZWFjaCh2cXREYXRhLCAodnF0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykgPT4ge1xyXG4gICAgICAgICAgICB2cXQudCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZSh2cXQudCwgdGltZXpvbmUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiB2cXREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIGdldCBmaXJzdCB2YWx1ZSBiZWZvcmUgbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgaW4gY3VycmVudCBkYXRhLlxyXG4gICAgICpcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgbmV4dFN0YXJ0TW9tZW50OiBtb21lbnQuTW9tZW50KTpcclxuICAgICAgICBNYXA8c3RyaW5nLCBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cz4ge1xyXG4gICAgICAgIGNvbnN0IGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzOiBNYXA8c3RyaW5nLCBhbnk+ID0gbmV3IE1hcCgpO1xyXG4gICAgICAgIGxldCBsYXN0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cztcclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChlbCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIV8uaXNOaWwoZWwpICYmIGVsLnZhbHVlcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGxhc3QgPSBfLmxhc3QoZWwudmFsdWVzKTtcclxuICAgICAgICAgICAgICAgIGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzLnNldChlbC5mcW4sIGxhc3QpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldHMgc3RhcnQgdGltZSBmb3IgbmV4dCByZXF1ZXN0IHdoZW4gZ2V0dGluZyBkYXRhIHJlcGVhdGVkbHkuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QoXHJcbiAgICAgICAgcmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgb3JpZ2luYWxEdXJhdGlvbjogbnVtYmVyLCByZXBlYXRlZEludGVydmFsOiBudW1iZXIpOiBtb21lbnQuTW9tZW50IHtcclxuICAgICAgICBjb25zdCBvcGNRdWFsaXR5U3ZjID0gdGhpcy5vcGNRdWFsaXR5U3ZjO1xyXG4gICAgICAgIGZ1bmN0aW9uIGdldExhc3RUaW1lVG9Vc2UoZnFuUmVzdWx0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3QpOiBzdHJpbmcge1xyXG4gICAgICAgICAgICBjb25zdCB0aW1lU3RyaW5nID0gXy5maXJzdChmcW5SZXN1bHQudmFsdWVzKS50O1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IGZxblJlc3VsdC52YWx1ZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGZxblJlc3VsdC52YWx1ZXNbaV07XHJcbiAgICAgICAgICAgICAgICBpZiAoIW9wY1F1YWxpdHlTdmMuaXNIZGFJbnRlcnBvbGF0ZWQodmFsLnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbC50O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gdGltZVN0cmluZztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCByZXN1bHQ6IG1vbWVudC5Nb21lbnQ7XHJcbiAgICAgICAgY29uc3QgY3VycmVudFRpbWVNaW51c0R1cmF0aW9uID0gbW9tZW50LnV0YygpLnN1YnRyYWN0KE1hdGguYWJzKG9yaWdpbmFsRHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG5cclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChmcW5SZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwoZnFuUmVzdWx0KSB8fCBmcW5SZXN1bHQudmFsdWVzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgLy8gbm8gdGltZXNlcmllcyBkYXRhXHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY29uc3QgbGFzdFZhbHVlID0gbW9tZW50LnV0YyhnZXRMYXN0VGltZVRvVXNlKGZxblJlc3VsdCkpO1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChyZXN1bHQpIHx8IHJlc3VsdC5pc0FmdGVyKGxhc3RWYWx1ZSkpIHtcclxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IGxhc3RWYWx1ZS5jbG9uZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChfLmlzTmlsKHJlc3VsdCkpIHtcclxuICAgICAgICAgICAgLy8gbm8gZ29vZCBxdWFsaXR5IC0gYWRkIHBlcmlvZCB0byByZXNwb25zZSBzdGFydCB0aW1lIC0gYXMgZGVmYXVsdCBmb3IgbmV4dCByZXF1ZXN0XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCkuYWRkKHJlcGVhdGVkSW50ZXJ2YWwsICdtaWxsaXNlY29uZHMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50VGltZU1pbnVzRHVyYXRpb24uaXNBZnRlcihyZXN1bHQpKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbi5jbG9uZSgpLmFkZChyZXBlYXRlZEludGVydmFsLCAnbWlsbGlzZWNvbmRzJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgKiBGdW5jdGlvbiB0byBvcHRpb25hbGx5IGZpbHRlciBmaXJzdCB2YWx1ZSBpbiByZXBlYXRlZCByZXF1ZXN0IHdoZW4gaXQgaXMgaW50ZXJwb2xhdGVkIGJldHdlZW5cclxuICAgICogdHdvIGdvb2QvYmFkIG9uZXMuIERpcmVjdGx5IG1vZGlmaWVzIHJlc3BvbnNlIGlucHV0IHBhcmFtZXRlci5cclxuICAgICovXHJcbiAgICBwcml2YXRlIF9maWx0ZXJTdGFydFJlc3BvbnNlRGF0YShcclxuICAgICAgICByZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLFxyXG4gICAgICAgIHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YTogTWFwPHN0cmluZywgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM+LCByZXF1ZXN0VGltZVBlcmlvZDogSVRpbWVQZXJpb2QpIHtcclxuICAgICAgICBsZXQgZmlyc3RWcXQ7XHJcbiAgICAgICAgbGV0IGZpcnN0VnF0TW9tZW50O1xyXG4gICAgICAgIGxldCBzZWNvbmRWcXQ7XHJcbiAgICAgICAgY29uc3Qgb3BjUXVhbGl0eVN2YyA9IHRoaXMub3BjUXVhbGl0eVN2YztcclxuICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCk7XHJcbiAgICAgICAgY3V0QmVmb3JlRGF0ZS5zdWJ0cmFjdChNYXRoLmFicyhyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZWwpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGVsKSAmJiBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEuaGFzKGVsLmZxbikgJiYgZWwudmFsdWVzLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YSA9IHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5nZXQoZWwuZnFuKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YU1vbWVudCA9IG1vbWVudC51dGMob25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhLnQpO1xyXG4gICAgICAgICAgICAgICAgZmlyc3RWcXQgPSBlbC52YWx1ZXMuc2xpY2UoMCwgMSlbMF07XHJcbiAgICAgICAgICAgICAgICBmaXJzdFZxdE1vbWVudCA9IG1vbWVudC51dGMoZmlyc3RWcXQudCk7XHJcbiAgICAgICAgICAgICAgICBpZiAob3BjUXVhbGl0eVN2Yy5pc0hkYUludGVycG9sYXRlZChmaXJzdFZxdC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNlY29uZFZxdCA9IGVsLnZhbHVlcy5zbGljZSgxLCAyKVswXTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWcXRNb21lbnQgPiBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGFNb21lbnQgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlyc3RWcXRNb21lbnQgPCBtb21lbnQudXRjKHNlY29uZFZxdC50KSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGNRdWFsaXR5U3ZjLmlzR29vZChvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEucSkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3BjUXVhbGl0eVN2Yy5pc0dvb2Qoc2Vjb25kVnF0LnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsLnZhbHVlcy5zcGxpY2UoMCwgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgdGltZXpvbmU/OiBzdHJpbmcpOiBUaW1lc2VyaWVzUmVzcG9uc2Uge1xyXG4gICAgICAgIGxldCBhcHBseVRpbWV6b25lID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICghXy5pc05pbCh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgLy8gd2UgZG8gaGF2ZSB0aW1lem9uZVxyXG4gICAgICAgICAgICBhcHBseVRpbWV6b25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgLy8gYXBwbHkgdGltZXpvbmUgYWxzbyB0byByZXNwb25zZSB0aW1lIHBlcmlvZCB0byBtYXRjaCBkYXRhXHJcbiAgICAgICAgICAgIHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUocmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICByZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShyZXNwb25zZS50aW1lUGVyaW9kLmVuZCwgdGltZXpvbmUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmV0OiBUaW1lc2VyaWVzUmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgIHRpbWVQZXJpb2Q6IHJlc3BvbnNlLnRpbWVQZXJpb2QsXHJcbiAgICAgICAgICAgIHJlc3VsdHM6IFtdXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAob25lUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKG9uZVJlc3VsdCkpIHtcclxuICAgICAgICAgICAgICAgIC8vIG5vIHRpbWVzZXJpZXMgZGF0YVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoYXBwbHlUaW1lem9uZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYXBwbHlUaW1lem9uZVRvVnF0RGF0YShvbmVSZXN1bHQudmFsdWVzLCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldC5yZXN1bHRzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogb25lUmVzdWx0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICBmcW46IG9uZVJlc3VsdC5mcW4sXHJcbiAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6IG9uZVJlc3VsdC52YWx1ZVR5cGUsXHJcbiAgICAgICAgICAgICAgICBlbmdpbmVlcmluZ1VuaXQ6IG9uZVJlc3VsdC5lbmdpbmVlcmluZ1VuaXQsXHJcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IG9uZVJlc3VsdC52YWx1ZXNcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJldDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEZ1bmN0aW9uIHRvIGZpbHRlciBub3QgbmVlZGVkIGRhdGEgYW5kIGR1cGxpY2F0ZSBkYXRhLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9maWx0ZXJEdXBsaWNhdGVEYXRhQW5kQ3V0KFxyXG4gICAgICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXSwgY3V0QmVmb3JlTW9tZW50OiBtb21lbnQuTW9tZW50LFxyXG4gICAgICAgIGRvTm90U2hpZnRGaXJzdFZhbHVlPzogYm9vbGVhbiwgdGltZXpvbmU/OiBzdHJpbmcpIHtcclxuICAgICAgICBjb25zdCBpZHM6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICBsZXQgb2JqZWN0VG9BZGRUb0FycmF5OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cztcclxuICAgICAgICBsZXQgZmlyc3RJc0FmdGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGFycmF5RmlsdGVyKG86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRJdGVtTW9tZW50ID0gbW9tZW50LnV0YyhvLnQpO1xyXG4gICAgICAgICAgICBpZiAoY3V0QmVmb3JlTW9tZW50LmlzQWZ0ZXIoY3VycmVudEl0ZW1Nb21lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWZpcnN0SXNBZnRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheSA9IF8uY2xvbmUobyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0ID0gY3V0QmVmb3JlTW9tZW50LmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbCh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5LnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUoY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0LCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5LnQgPSBjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpcnN0SXNBZnRlciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGlkcy5pbmRleE9mKG8udCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWRzLnB1c2goby50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZpbHRlcmVkQXJyYXkgPSB2YWx1ZXMucmV2ZXJzZSgpLmZpbHRlcihhcnJheUZpbHRlcik7XHJcbiAgICAgICAgaWYgKCFkb05vdFNoaWZ0Rmlyc3RWYWx1ZSAmJiBmaXJzdElzQWZ0ZXIpIHtcclxuICAgICAgICAgICAgY29uc3QgbGFzdFZhbHVlID0gXy5sYXN0KGZpbHRlcmVkQXJyYXkpO1xyXG4gICAgICAgICAgICBpZiAoIWxhc3RWYWx1ZSB8fCAhbW9tZW50LnV0YyhsYXN0VmFsdWUudCkuaXNTYW1lKG1vbWVudC51dGMob2JqZWN0VG9BZGRUb0FycmF5LnQpKSkge1xyXG4gICAgICAgICAgICAgICAgLy8gaXQgaXMgcmV2ZXJzZWQgYXJyYXkgc28gcHVzaCB0byBpdFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRBcnJheS5wdXNoKG9iamVjdFRvQWRkVG9BcnJheSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZpbHRlcmVkQXJyYXkucmV2ZXJzZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0cyByZXBlYXRlZGx5IGFuZCByZXR1cm4gYWxsIGRhdGEgaW4gZ2l2ZW4gcmVxdWVzdCBpbnRlcnZhbCAoYnkgZHVyYXRpb24sIHN0YXJ0IGFuZC9vciBlbmQgdGltZSkuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGludGVydmFsIGluIHNlY29uZHNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVwZWF0ZWRseVdob2xlKHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIGxldCBsYXN0TWVyZ2VkUmVzcG9uc2U6IFRpbWVzZXJpZXNSZXNwb25zZTtcclxuICAgICAgICBjb25zdCB0eiA9IHRpbWV6b25lO1xyXG5cclxuICAgICAgICBjb25zdCByZXBlYXRlZGx5T2JzID0gdGhpcy5fZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHRpbWV6b25lKVxyXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlc3BvbnNlOiBUaW1lc2VyaWVzUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChsYXN0TWVyZ2VkUmVzcG9uc2UpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY3V0QmVmb3JlRGF0ZS5zdWJ0cmFjdChNYXRoLmFicyhyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdCA9IGN1dEJlZm9yZURhdGUuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbCh0eikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUoY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdCwgdHopO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPSByZXNwb25zZS50aW1lUGVyaW9kLmVuZDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IGN1dEJlZm9yZURhdGVVVENGb3JtYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKS5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIF8uZWFjaChsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cywgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXN1bHRzID0gXy5maW5kKHJlc3BvbnNlLnJlc3VsdHMsIHsgZnFuOiByZXN1bHQuZnFuIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobmV3UmVzdWx0cykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSByZXN1bHQudmFsdWVzLmNvbmNhdChuZXdSZXN1bHRzLnZhbHVlcyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IF8uc29ydEJ5KHJlc3VsdC52YWx1ZXMsIFsobzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9tZW50LnV0YyhvLnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfV0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSB0aGlzLl9maWx0ZXJEdXBsaWNhdGVEYXRhQW5kQ3V0KHJlc3VsdC52YWx1ZXMsIGN1dEJlZm9yZURhdGUsIGZhbHNlLCB0eik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgYW55IG5ldyBmcW5zIGRhdGFcclxuICAgICAgICAgICAgICAgICAgICBfLmVhY2gocmVzcG9uc2UucmVzdWx0cywgKG5ld1Jlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uZmluZChsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cywgeyBmcW46IG5ld1Jlc3VsdC5mcW4gfSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLnB1c2gobmV3UmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBsYXN0TWVyZ2VkUmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZSA9IHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgIHJldHVybiByZXBlYXRlZGx5T2JzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0cyByZXBlYXRlZGx5IGFuZCByZXR1cm4gZGF0YSBhcyBpbmNyZW1lbnRzLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBpbnRlcnZhbCBpbiBzZWNvbmRzXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKFxyXG4gICAgICAgIHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG5cclxuICAgICAgICBsZXQgbGFzdFJlc3BvbnNlRGF0YTogTWFwPHN0cmluZywgYW55PjtcclxuICAgICAgICBsZXQgcmVwZWF0ZWRJbnRlcnZhbCA9IGN1c3RvbUludGVydmFsIHx8IHRoaXMuY29uZmlnLmRlZmF1bHRSZXBlYXRlZERhdGFJbnRlcnZhbCB8fCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUw7XHJcbiAgICAgICAgcmVwZWF0ZWRJbnRlcnZhbCA9IHJlcGVhdGVkSW50ZXJ2YWwgKiAxMDAwO1xyXG5cclxuICAgICAgICBjb25zdCBsYXN0UmVwZWF0ZWRSZXF1ZXN0ID0gXy5jbG9uZShyZXF1ZXN0KTtcclxuICAgICAgICBjb25zdCBvcmlnaW5hbER1cmF0aW9uID0gcmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb247XHJcbiAgICAgICAgbGV0IG5leHRSZXF1ZXN0U3RhcnRNb21lbnQ6IG1vbWVudC5Nb21lbnQ7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcGVhdGVkRGF0YU9ic2VydmFibGUgPSB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgbmV4dFJlcXVlc3RTdGFydE1vbWVudCA9IHRoaXMuX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QocmVzcG9uc2UsIG9yaWdpbmFsRHVyYXRpb24sIHJlcGVhdGVkSW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICAvLyB3ZSByZW1lbWJlciBsYXN0IHZhbHVlIGJlZm9yZSBuZXh0U3RhcnQgaW4gY3VycmVudCByZXF1ZXN0IHRvIGNoZWNrIGl0c1xyXG4gICAgICAgICAgICAvLyBxdWFsaXR5IHZzLiBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSB2YWx1ZSBxdWFsaXR5LCBwb3NzaWJseVxyXG4gICAgICAgICAgICAvLyB0byBvbWl0IHN0YXJ0IHZhbHVlXHJcbiAgICAgICAgICAgIC8vIC0gaXQgbWF5IGJlIGludGVycG9sYXRlZCBiZXR3ZWVuIHR3byBnb29kIHF1YWxpdHkgdmFsdWVzXHJcbiAgICAgICAgICAgIGxhc3RSZXNwb25zZURhdGEgPSB0aGlzLl9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZSwgbmV4dFJlcXVlc3RTdGFydE1vbWVudCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdGltZXpvbmUpO1xyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBjb25zdCBleHBhbmRlZE9ic2VydmFibGUgPSByZXBlYXRlZERhdGFPYnNlcnZhYmxlLnBpcGUoXHJcbiAgICAgICAgICAgIGV4cGFuZCgoKSA9PiB0aW1lcihyZXBlYXRlZEludGVydmFsKS5waXBlKGNvbmNhdE1hcCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobmV4dFJlcXVlc3RTdGFydE1vbWVudCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsYXN0UmVwZWF0ZWRSZXF1ZXN0LnNldFRpbWVQZXJpb2QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF8uZXh0ZW5kKGxhc3RSZXBlYXRlZFJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpLCB7IGR1cmF0aW9uOiAwLCBzdGFydDogbmV4dFJlcXVlc3RTdGFydE1vbWVudC50b0RhdGUoKSB9KSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KGxhc3RSZXBlYXRlZFJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RSZXNwb25zZURhdGEuc2l6ZSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgY2hlY2sgcHJldmlvdXMgdmFsdWVzIHRvIGN1cnJlbnQgc3RhcnRpbmcgb25lc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBmaWx0ZXIgb3V0IHBvc3NpYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0YXJ0IGludGVycG9sYXRlZCBvbmVzIGlmIHRoZXkgYXJlIGJldHdlZW4gZ29vZCBvbmVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZpbHRlclN0YXJ0UmVzcG9uc2VEYXRhKHJlc3BvbnNlLCBsYXN0UmVzcG9uc2VEYXRhLCByZXF1ZXN0VGltZVBlcmlvZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQgPSB0aGlzLl9nZXRTdGFydEZvck5leHRSZXF1ZXN0KHJlc3BvbnNlLCBvcmlnaW5hbER1cmF0aW9uLCByZXBlYXRlZEludGVydmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB3ZSByZW1lbWJlciBsYXN0IHZhbHVlIGJlZm9yZSBuZXh0U3RhcnQgaW4gY3VycmVudCByZXF1ZXN0IHRvIGNoZWNrIGl0c1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHF1YWxpdHkgdnMuIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIHZhbHVlIHF1YWxpdHksIHBvc3NpYmx5XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdG8gb21pdCBzdGFydCB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIC0gaXQgbWF5IGJlIGludGVycG9sYXRlZCBiZXR3ZWVuIHR3byBnb29kIHF1YWxpdHkgdmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdFJlc3BvbnNlRGF0YSA9IHRoaXMuX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlLCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfSkpKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgcmV0dXJuIGV4cGFuZGVkT2JzZXJ2YWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHJlcXVlc3QgZm9yIHRpbWVzZXJpZXMgZGF0YSByZXBlYXRlZGx5LiBJdCByZXBlYXRlZGx5IHNlbmRzIHJlcXVlc3RzIHRvIHNlcnZlci5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgY3VzdG9tIGludGVydmFsIGZvciByZXBlYXRlZCBkYXRhLCBpbiBzZWNvbmRzXHJcbiAgICAgKiBAcGFyYW0gZm9ybWF0IChPcHRpb25hbCkgZm9ybWF0IGZvciByZXBlYXRlZCBkYXRhIHJlc3BvbnNlXHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgKE9wdGlvbmFsKSBTZXQgdGhlIHRpbWV6b25lIHRvIGFwcGx5IHRvIGRhdGV0aW1lIHN0cmluZ3MgZm9yIHRpbWVzZXJpZXMgcmVzcG9uc2UgZGF0YS5cclxuICAgICAqIFJldHVybmVkIGRhdGUgc3RyaW5ncyBhcmUgaW4gbWF4aW11bSBqYXZhc2NyaXB0IHJlc29sdXRpb24gcG9zc2libGVcclxuICAgICAqIHN1cHBvcnRlZCBieSB1c2luZyBtb21lbnQgbGlicmFyeSAoSmF2YXNjcmlwdCBkYXRlIC0gbWlsbGlzZWNvbmRzKS5cclxuICAgICAqIFJlc29sdXRpb24gZm9yIHRpbWUgYWZ0ZXIgbWlsbGlzZWNvbmRzIHdpbGwgYmUgbG9zdC5cclxuICAgICAqIElmIHdvcmtpbmcgd2l0aCB0aW1lem9uZSBpbiBkYXRldGltZSBzdHJpbmcgaXQgaXMgcmVjb21tZW5kZWQgdG8gdXNlIG1vbWVudC5wYXJzZVpvbmUgdG8gcHJlc2VydmUgdGltZXpvbmUgaW5mb3JtYXRpb24uXHJcbiAgICAgKiBNb21lbnQgdGltZXpvbmVzIHRoYXQgc3RhcnQgd2l0aCBcIkV0Yy9HTVRcIiB1c2UgUE9TSVgtc3R5bGUgc2lnbnMgaW4gdGhlIFpvbmUgbmFtZXMgYW5kIHRoZSBvdXRwdXQgYWJicmV2aWF0aW9ucyxcclxuICAgICAqIGV2ZW4gdGhvdWdoIHRoaXMgaXMgdGhlIG9wcG9zaXRlIG9mIHdoYXQgbWFueSBwZW9wbGUgZXhwZWN0LlxyXG4gICAgICogUE9TSVggaGFzIHBvc2l0aXZlIHNpZ25zIHdlc3Qgb2YgR3JlZW53aWNoLCBidXQgbWFueSBwZW9wbGUgZXhwZWN0XHJcbiAgICAgKiBwb3NpdGl2ZSBzaWducyBlYXN0IG9mIEdyZWVud2ljaC4gIEZvciBleGFtcGxlLCBUWj0nRXRjL0dNVCs0JyB1c2VzXHJcbiAgICAgKiB0aGUgYWJicmV2aWF0aW9uIFwiR01UKzRcIiBhbmQgY29ycmVzcG9uZHMgdG8gNCBob3VycyBiZWhpbmQgVVRcclxuICAgICAqIChpLmUuIHdlc3Qgb2YgR3JlZW53aWNoKSBldmVuIHRob3VnaCBtYW55IHBlb3BsZSB3b3VsZCBleHBlY3QgaXQgdG9cclxuICAgICAqIG1lYW4gNCBob3VycyBhaGVhZCBvZiBVVCAoaS5lLiBlYXN0IG9mIEdyZWVud2ljaCkuXHJcbiAgICAgKi9cclxuICAgIGdldFJlcGVhdGVkbHkocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCBmb3JtYXQ/OiBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0LCB0aW1lem9uZT86IHN0cmluZyk6XHJcbiAgICAgICAgT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuICAgICAgICBpZiAoIV8uaXNOaWwocmVxdWVzdFRpbWVQZXJpb2Quc3RhcnQpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRFcnJvck9ic2VydmFibGUoJ1RpbWVzZXJpZXNEYXRhU2VydmljZSBnZXRSZXBlYXRlZGx5OiBBcmd1bWVudCBleGNlcHRpb24nXHJcbiAgICAgICAgICAgICAgICArICcgLSBSZXF1ZXN0IHN0YXJ0IHRpbWUgY2Fubm90IGJlIHNldCBmb3IgcmVwZWF0ZWQgZGF0YSAocmVxdWVzdDogJ1xyXG4gICAgICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KSArICcgY2Fubm90IGJlIHByb2Nlc3NlZC4nKTtcclxuICAgICAgICB9IGVsc2UgaWYgKF8uaXNOaWwocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pIHx8IHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uID4gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0RXJyb3JPYnNlcnZhYmxlKCdUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZ2V0UmVwZWF0ZWRseTogQXJndW1lbnQgZXhjZXB0aW9uJ1xyXG4gICAgICAgICAgICAgICAgKyAnIC0gUmVxdWVzdCBkdXJhdGlvbiBoYXZlIHRvIGJlIG5lZ2F0aXZlIChyZXF1ZXN0OiAnXHJcbiAgICAgICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpICsgJyBjYW5ub3QgYmUgcHJvY2Vzc2VkLicpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHR6OiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKE1vbWVudEhlbHBlclNlcnZpY2UuaXNWYWxpZFRpbWV6b25lKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICB0eiA9IHRpbWV6b25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoXy5pc05pbChmb3JtYXQpIHx8IGZvcm1hdCA9PT0gVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdC53aG9sZUludGVydmFsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRSZXBlYXRlZGx5V2hvbGUocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHR6KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHR6KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19