import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import { Observable, Subject, timer } from 'rxjs';
import { map, expand, concatMap } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
export function ILiveResponseProxyValue() { }
if (false) {
    ILiveResponseProxyValue.prototype.fqn;
    ILiveResponseProxyValue.prototype.name;
    ILiveResponseProxyValue.prototype.type;
    ILiveResponseProxyValue.prototype.createdOn;
    ILiveResponseProxyValue.prototype.createdOnOffset;
    ILiveResponseProxyValue.prototype.modifiedOn;
    ILiveResponseProxyValue.prototype.modifiedOnOffset;
}
export function ILiveResponse() { }
if (false) {
    ILiveResponse.prototype.v;
    ILiveResponse.prototype.q;
    ILiveResponse.prototype.t;
}
function ILiveResponseInternalVqtObject() { }
if (false) {
    ILiveResponseInternalVqtObject.prototype.v;
    ILiveResponseInternalVqtObject.prototype.q;
    ILiveResponseInternalVqtObject.prototype.t;
}
function ILiveResponseInternalObject() { }
if (false) {
    ILiveResponseInternalObject.prototype.fqn;
    ILiveResponseInternalObject.prototype.name;
    ILiveResponseInternalObject.prototype.engineeringUnit;
    ILiveResponseInternalObject.prototype.valueType;
    ILiveResponseInternalObject.prototype.value;
}
function ILiveResponseInternal() { }
if (false) {
    ILiveResponseInternal.prototype.fqnsResults;
    ILiveResponseInternal.prototype.queryResults;
}
var LiveRequest = (function () {
    function LiveRequest(fqns) {
        this.fqns = fqns;
        this.fqns = _.clone(fqns);
    }
    LiveRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    LiveRequest.prototype.removeFqn = function (fqn) {
        var index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    return LiveRequest;
}());
export { LiveRequest };
if (false) {
    LiveRequest.prototype.fqns;
}
var LiveDataService = (function (_super) {
    tslib_1.__extends(LiveDataService, _super);
    function LiveDataService(config, http) {
        var _this = _super.call(this, '/api/1/live/', config, http) || this;
        _this._fqns = new Map();
        return _this;
    }
    LiveDataService.prototype.getOnce = function (request) {
        return this._sendPostRequest(request).pipe(map(function (response) {
            var ret = [];
            _.each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._getInnerRepeatedObservable = function () {
        return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
            .pipe(map(function (response) {
            var ret = [];
            _.each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._initializeRepeatedData = function () {
        var _this = this;
        if (!this._repeatedDataSubject) {
            this._repeatedDataSubject = new Subject();
        }
        if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
            var repeatedInterval_1 = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval_1 = repeatedInterval_1 * 1000;
            this._repeatedDataObservable = this._getInnerRepeatedObservable();
            this._repeatedDataSubscription = this._repeatedDataObservable.pipe(expand(function () { return timer(repeatedInterval_1).pipe(concatMap(function () { return _this._getInnerRepeatedObservable(); })); })).subscribe(function (response) {
                _this._repeatedDataSubject.next(response);
            }, function (err) {
                _this._repeatedDataSubscription.unsubscribe();
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.error(err);
            }, function () {
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.complete();
            });
            this._reinitializeRepeatedObservable = false;
        }
        return this._repeatedDataObservable;
    };
    LiveDataService.prototype.getRepeatedly = function (request) {
        var _this = this;
        return new Observable(function (observer) {
            _.each(request.fqns, function (fqn) {
                var newVal = 0;
                if (_this._fqns.has(fqn)) {
                    newVal = _this._fqns.get(fqn);
                }
                _this._fqns.set(fqn, ++newVal);
            });
            _this._initializeRepeatedData();
            var subscription = _this._repeatedDataSubject.asObservable().pipe(map(function (currentResponse) {
                return _.filter(currentResponse, function (o) {
                    return _.indexOf(request.fqns, o.fqn) > -1;
                });
            })).subscribe(function (response) {
                observer.next(response);
            }, function (error) {
                observer.error(error);
            }, function () {
                observer.complete();
            });
            return function () {
                _.each(request.fqns, function (fqn) {
                    var newVal = 1;
                    if (_this._fqns.has(fqn)) {
                        newVal = _this._fqns.get(fqn);
                    }
                    if (newVal === 1) {
                        _this._fqns.delete(fqn);
                    }
                    else {
                        _this._fqns.set(fqn, --newVal);
                    }
                });
                subscription.unsubscribe();
                observer.unsubscribe();
                if (_this._fqns.size === 0) {
                    if (_this._repeatedDataSubscription) {
                        _this._repeatedDataSubscription.unsubscribe();
                    }
                    _this._repeatedDataSubject.complete();
                    delete _this._repeatedDataSubject;
                    _this._reinitializeRepeatedObservable = true;
                }
            };
        });
    };
    LiveDataService.decorators = [
        { type: Injectable }
    ];
    LiveDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return LiveDataService;
}(BaseService));
export { LiveDataService };
if (false) {
    LiveDataService.prototype._fqns;
    LiveDataService.prototype._repeatedDataObservable;
    LiveDataService.prototype._repeatedDataSubscription;
    LiveDataService.prototype._repeatedDataSubject;
    LiveDataService.prototype._reinitializeRepeatedObservable;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGl2ZS1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsibGl2ZS1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLEVBQUUsVUFBVSxFQUFnQixPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ2hFLE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsOEJBQThCLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFFdEcsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRzdDLDZDQVFDOztJQVBHLHNDQUFZO0lBQ1osdUNBQWE7SUFDYix1Q0FBYTtJQUNiLDRDQUFtQjtJQUNuQixrREFBeUI7SUFDekIsNkNBQW9CO0lBQ3BCLG1EQUEwQjs7QUFJOUIsbUNBSUM7O0lBSEcsMEJBQXlEO0lBQ3pELDBCQUFVO0lBQ1YsMEJBQVU7O0FBTWQsNkNBSUM7O0lBSEcsMkNBQXlEO0lBQ3pELDJDQUFVO0lBQ1YsMkNBQVU7O0FBSWQsMENBTUM7O0lBTEcsMENBQVk7SUFDWiwyQ0FBYztJQUNkLHNEQUF5QjtJQUN6QixnREFBbUI7SUFDbkIsNENBQXNDOztBQUcxQyxvQ0FHQzs7SUFGRyw0Q0FBNEM7SUFDNUMsNkNBQTZDOztBQUdqRDtJQUtJLHFCQUFxQixJQUFrQjtRQUFsQixTQUFJLEdBQUosSUFBSSxDQUFjO1FBRW5DLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBTUQsNEJBQU0sR0FBTixVQUFPLEdBQWU7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQU1ELCtCQUFTLEdBQVQsVUFBVSxHQUFlO1lBQ2YsS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUM7UUFDdkMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQUNMLGtCQUFDO0FBQUQsQ0FBQyxBQTVCRCxJQTRCQzs7O0lBdkJlLDJCQUEyQjs7QUE0QjNDO0lBQ3FDLDJDQUFXO0lBUTVDLHlCQUEwQyxNQUE0QixFQUFFLElBQWdCO1FBQXhGLFlBQ0ksa0JBQU0sY0FBYyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FDdEM7UUFSTyxXQUFLLEdBQXdCLElBQUksR0FBRyxFQUFFLENBQUM7O0lBUS9DLENBQUM7SUFNRCxpQ0FBTyxHQUFQLFVBQVEsT0FBb0I7UUFDeEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUN0QyxHQUFHLENBQUMsVUFBQyxRQUErQjtnQkFDMUIsR0FBRyxHQUFpQixFQUFFO1lBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7Z0JBQ25DLEdBQUcsQ0FBQyxJQUFJLENBQUM7b0JBQ0wsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO29CQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7b0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztvQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO29CQUMxQyxDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN2QixDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sR0FBRyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNaLENBQUM7SUFFTyxxREFBMkIsR0FBbkM7UUFDSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDO2FBQ2hFLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUErQjtnQkFDaEMsR0FBRyxHQUFpQixFQUFFO1lBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7Z0JBQ25DLEdBQUcsQ0FBQyxJQUFJLENBQUM7b0JBQ0wsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO29CQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7b0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztvQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO29CQUMxQyxDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN2QixDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sR0FBRyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNaLENBQUM7SUFFTyxpREFBdUIsR0FBL0I7UUFBQSxpQkE4QkM7UUE3QkcsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRTtZQUM1QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxPQUFPLEVBQWdCLENBQUM7U0FDM0Q7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixJQUFJLElBQUksQ0FBQywrQkFBK0IsRUFBRTtnQkFDbkUsa0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSw4QkFBOEI7WUFDaEcsa0JBQWdCLEdBQUcsa0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBRTNDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztZQUtsRSxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FDOUQsTUFBTSxDQUFDLGNBQU0sT0FBQSxLQUFLLENBQUMsa0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsMkJBQTJCLEVBQUUsRUFBbEMsQ0FBa0MsQ0FBQyxDQUFDLEVBQWpGLENBQWlGLENBQUMsQ0FDbEcsQ0FBQyxTQUFTLENBQUMsVUFBQyxRQUFzQjtnQkFDL0IsS0FBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM3QyxDQUFDLEVBQUUsVUFBQyxHQUFHO2dCQUNILEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDN0MsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztnQkFDNUMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN6QyxDQUFDLEVBQUU7Z0JBQ0MsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztnQkFDNUMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3pDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLCtCQUErQixHQUFHLEtBQUssQ0FBQztTQUNoRDtRQUVELE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3hDLENBQUM7SUFNRCx1Q0FBYSxHQUFiLFVBQWMsT0FBb0I7UUFBbEMsaUJBa0RDO1FBaERHLE9BQU8sSUFBSSxVQUFVLENBQWUsVUFBQyxRQUFRO1lBRXpDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxVQUFDLEdBQUc7b0JBQ2pCLE1BQU0sR0FBRyxDQUFDO2dCQUNkLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3JCLE1BQU0sR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDaEM7Z0JBQ0QsS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDSCxLQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztnQkFDekIsWUFBWSxHQUFHLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQUMsZUFBNkI7Z0JBQ2pHLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsVUFBQyxDQUFDO29CQUMvQixPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQy9DLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQyxRQUFzQjtnQkFDakMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM1QixDQUFDLEVBQUUsVUFBQyxLQUFLO2dCQUNMLFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUIsQ0FBQyxFQUFFO2dCQUNDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUN4QixDQUFDLENBQUM7WUFFRixPQUFPO2dCQUVILENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxVQUFDLEdBQUc7d0JBQ2pCLE1BQU0sR0FBRyxDQUFDO29CQUNkLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQ3JCLE1BQU0sR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDaEM7b0JBQ0QsSUFBSSxNQUFNLEtBQUssQ0FBQyxFQUFFO3dCQUNkLEtBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUMxQjt5QkFBTTt3QkFDSCxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztxQkFDakM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMzQixRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFO29CQUN2QixJQUFJLEtBQUksQ0FBQyx5QkFBeUIsRUFBRTt3QkFDaEMsS0FBSSxDQUFDLHlCQUF5QixDQUFDLFdBQVcsRUFBRSxDQUFDO3FCQUNoRDtvQkFDRCxLQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3JDLE9BQU8sS0FBSSxDQUFDLG9CQUFvQixDQUFDO29CQUNqQyxLQUFJLENBQUMsK0JBQStCLEdBQUcsSUFBSSxDQUFDO2lCQUMvQztZQUNMLENBQUMsQ0FBQztRQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQzs7Z0JBN0lKLFVBQVU7OztnREFTTSxNQUFNLFNBQUMsb0JBQW9CO2dCQTNGbkMsVUFBVTs7SUFnT25CLHNCQUFDO0NBQUEsQUE5SUQsQ0FDcUMsV0FBVyxHQTZJL0M7U0E3SVksZUFBZTs7SUFFeEIsZ0NBQStDO0lBQy9DLGtEQUEwRDtJQUMxRCxvREFBZ0Q7SUFDaEQsK0NBQW9EO0lBQ3BELDBEQUFpRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YnNjcmlwdGlvbiwgU3ViamVjdCwgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgbWFwLCBleHBhbmQsIGNvbmNhdE1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnLCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUwgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IGlkZW50aWZpZXIsIElSZXNwb25zZSB9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHByb3h5IHZhbHVlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJTGl2ZVJlc3BvbnNlUHJveHlWYWx1ZSB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIHR5cGU6IHN0cmluZztcclxuICAgIGNyZWF0ZWRPbj86IHN0cmluZztcclxuICAgIGNyZWF0ZWRPbk9mZnNldD86IG51bWJlcjtcclxuICAgIG1vZGlmaWVkT24/OiBzdHJpbmc7XHJcbiAgICBtb2RpZmllZE9uT2Zmc2V0PzogbnVtYmVyO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHJlc3BvbnNlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJTGl2ZVJlc3BvbnNlIGV4dGVuZHMgSVJlc3BvbnNlIHtcclxuICAgIHY6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBJTGl2ZVJlc3BvbnNlUHJveHlWYWx1ZVtdO1xyXG4gICAgcTogbnVtYmVyO1xyXG4gICAgdDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBMaXZlUmVzcG9uc2UgPSBJTGl2ZVJlc3BvbnNlW107XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHZxdCBpbnRlcm5hbCBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxWcXRPYmplY3Qge1xyXG4gICAgdjogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbiB8IElMaXZlUmVzcG9uc2VQcm94eVZhbHVlW107XHJcbiAgICBxOiBudW1iZXI7XHJcbiAgICB0OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcmVzcG9uc2Ugb2JqZWN0IGludGVybmFsIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElMaXZlUmVzcG9uc2VJbnRlcm5hbE9iamVjdCB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU/OiBzdHJpbmc7XHJcbiAgICBlbmdpbmVlcmluZ1VuaXQ/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZVR5cGU/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZTogSUxpdmVSZXNwb25zZUludGVybmFsVnF0T2JqZWN0O1xyXG59XHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcmVzcG9uc2UgaW50ZXJuYWwgKHJhdykgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSUxpdmVSZXNwb25zZUludGVybmFsIHtcclxuICAgIGZxbnNSZXN1bHRzPzogSUxpdmVSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbiAgICBxdWVyeVJlc3VsdHM/OiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIExpdmVSZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogTGl2ZSByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFucyBMaXN0IG9mIGZxbnMgKGlkZW50aWZpY2F0b3JzKSB0byBiZSB1c2VkIGZvciByZXF1ZXN0XHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKHJlYWRvbmx5IGZxbnM6IGlkZW50aWZpZXJbXVxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zID0gXy5jbG9uZShmcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBvbmUgZnFuIHRvIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIGFkZFxyXG4gICAgICovXHJcbiAgICBhZGRGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zLnB1c2goZnFuKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbW92ZSBvbmUgZnFuIGZyb20gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IF8uaW5kZXhPZih0aGlzLmZxbnMsIGZxbik7XHJcbiAgICAgICAgaWYgKGluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmZxbnMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIHNlcnZpY2UgcHJvdmlkZXMgYSBzZXQgb2YgbWV0aG9kcyBmb3Igc2VuZGluZyByZXF1ZXN0cyB0byBvYnRhaW4gbGl2ZSBkYXRhLlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgTGl2ZURhdGFTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG4gICAgLyoqIEBpbnRlcm5hbCBhY3R1YWwgcmVwZWF0ZWQgbGl2ZSByZXF1ZXN0IGZxbnMgKi9cclxuICAgIHByaXZhdGUgX2ZxbnM6IE1hcDxzdHJpbmcsIG51bWJlcj4gPSBuZXcgTWFwKCk7XHJcbiAgICBwcml2YXRlIF9yZXBlYXRlZERhdGFPYnNlcnZhYmxlOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT47XHJcbiAgICBwcml2YXRlIF9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3JlcGVhdGVkRGF0YVN1YmplY3Q6IFN1YmplY3Q8TGl2ZVJlc3BvbnNlPjtcclxuICAgIHByaXZhdGUgX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZTogYm9vbGVhbjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoJy9hcGkvMS9saXZlLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCBsaXZlIHJlcXVlc3QgdG8gc2VydmVyLCBidXQgb25seSBvbmNlLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgbGl2ZSByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqL1xyXG4gICAgZ2V0T25jZShyZXF1ZXN0OiBMaXZlUmVxdWVzdCk6IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKFxyXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlOiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldDogTGl2ZVJlc3BvbnNlID0gW107XHJcbiAgICAgICAgICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChvbmVSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IG9uZVJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcW46IG9uZVJlc3VsdC5mcW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogb25lUmVzdWx0LnZhbHVlVHlwZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5naW5lZXJpbmdVbml0OiBvbmVSZXN1bHQuZW5naW5lZXJpbmdVbml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2OiBvbmVSZXN1bHQudmFsdWUudixcclxuICAgICAgICAgICAgICAgICAgICAgICAgcTogb25lUmVzdWx0LnZhbHVlLnEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQ6IG9uZVJlc3VsdC52YWx1ZS50XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXQ7XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRJbm5lclJlcGVhdGVkT2JzZXJ2YWJsZSgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHsgZnFuczogQXJyYXkuZnJvbSh0aGlzLl9mcW5zLmtleXMoKSkgfSlcclxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogSUxpdmVSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXQ6IExpdmVSZXNwb25zZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAob25lUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBvbmVSZXN1bHQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnFuOiBvbmVSZXN1bHQuZnFuLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6IG9uZVJlc3VsdC52YWx1ZVR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZ2luZWVyaW5nVW5pdDogb25lUmVzdWx0LmVuZ2luZWVyaW5nVW5pdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdjogb25lUmVzdWx0LnZhbHVlLnYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHE6IG9uZVJlc3VsdC52YWx1ZS5xLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0OiBvbmVSZXN1bHQudmFsdWUudFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmV0O1xyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdGlhbGl6ZVJlcGVhdGVkRGF0YSgpOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4ge1xyXG4gICAgICAgIGlmICghdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0ID0gbmV3IFN1YmplY3Q8TGl2ZVJlc3BvbnNlPigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlIHx8IHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSkge1xyXG4gICAgICAgICAgICBsZXQgcmVwZWF0ZWRJbnRlcnZhbCA9IHRoaXMuY29uZmlnLmRlZmF1bHRSZXBlYXRlZERhdGFJbnRlcnZhbCB8fCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUw7XHJcbiAgICAgICAgICAgIHJlcGVhdGVkSW50ZXJ2YWwgPSByZXBlYXRlZEludGVydmFsICogMTAwMDtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YU9ic2VydmFibGUgPSB0aGlzLl9nZXRJbm5lclJlcGVhdGVkT2JzZXJ2YWJsZSgpO1xyXG4gICAgICAgICAgICAvLyBFeHBhbmQgY3VycmVudCBvYnNlcnZhYmxlIHNlcXVlbmNlIGJ5IHJlY3Vyc2l2ZWx5IGludm9raW5nIHNlbGVjdG9yIC1cclxuICAgICAgICAgICAgLy8gYSB0aW1lciBiYXNlZCBvbiBpbnRlcnZhbCwgd2hpY2ggd2lsbCByZXBlYXQgcmVxdWVzdCBhbmQgcHJvY2VzcyByZXNwb25zZS5cclxuICAgICAgICAgICAgLy8gT2JzZXJ2YWJsZSB0aW1lcjpcclxuICAgICAgICAgICAgLy8gUmV0dXJucyBhbiBvYnNlcnZhYmxlIHNlcXVlbmNlIHRoYXQgcHJvZHVjZXMgYSB2YWx1ZSBhZnRlciBkdWVUaW1lIGhhcyBlbGFwc2VkIGFuZCB0aGVuIGFmdGVyIGVhY2ggcGVyaW9kLlxyXG4gICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb24gPSB0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlLnBpcGUoXHJcbiAgICAgICAgICAgICAgICBleHBhbmQoKCkgPT4gdGltZXIocmVwZWF0ZWRJbnRlcnZhbCkucGlwZShjb25jYXRNYXAoKCkgPT4gdGhpcy5fZ2V0SW5uZXJSZXBlYXRlZE9ic2VydmFibGUoKSkpKVxyXG4gICAgICAgICAgICApLnN1YnNjcmliZSgocmVzcG9uc2U6IExpdmVSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfSwgKGVycikgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHJlcXVlc3QgZm9yIGxpdmUgZGF0YSByZXBlYXRlZGx5LiBJdCByZXBlYXRlZGx5IHNlbmRzIHJlcXVlc3RzIHRvIHNlcnZlci5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IGxpdmUgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKi9cclxuICAgIGdldFJlcGVhdGVkbHkocmVxdWVzdDogTGl2ZVJlcXVlc3QpOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPigob2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICAgICAgLy8gd2UgcmVnaXN0ZXIgbmV3IGlkZW50aWZpY2F0b3JzIGZvciBwZXJpb2RpYyBsaXZlIHVwZGF0ZXNcclxuICAgICAgICAgICAgXy5lYWNoKHJlcXVlc3QuZnFucywgKGZxbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld1ZhbCA9IDA7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZnFucy5oYXMoZnFuKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld1ZhbCA9IHRoaXMuX2ZxbnMuZ2V0KGZxbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mcW5zLnNldChmcW4sICsrbmV3VmFsKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRpYWxpemVSZXBlYXRlZERhdGEoKTtcclxuICAgICAgICAgICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5hc09ic2VydmFibGUoKS5waXBlKG1hcCgoY3VycmVudFJlc3BvbnNlOiBMaXZlUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfLmZpbHRlcihjdXJyZW50UmVzcG9uc2UsIChvKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF8uaW5kZXhPZihyZXF1ZXN0LmZxbnMsIG8uZnFuKSA+IC0xO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pKS5zdWJzY3JpYmUoKHJlc3BvbnNlOiBMaXZlUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLmVycm9yKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gd2UgdW5yZWdpc3RlciBpZGVudGlmaWNhdG9ycyBmb3IgcGVyaW9kaWMgbGl2ZSB1cGRhdGVzXHJcbiAgICAgICAgICAgICAgICBfLmVhY2gocmVxdWVzdC5mcW5zLCAoZnFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5ld1ZhbCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2ZxbnMuaGFzKGZxbikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3VmFsID0gdGhpcy5fZnFucy5nZXQoZnFuKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5ld1ZhbCA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9mcW5zLmRlbGV0ZShmcW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZxbnMuc2V0KGZxbiwgLS1uZXdWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mcW5zLnNpemUgPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0LmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3Q7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufVxyXG4iXX0=