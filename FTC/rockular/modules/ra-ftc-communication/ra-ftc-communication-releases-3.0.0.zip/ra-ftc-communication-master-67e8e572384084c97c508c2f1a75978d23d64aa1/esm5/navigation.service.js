import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import * as _ from 'lodash';
var NavigationService = (function (_super) {
    tslib_1.__extends(NavigationService, _super);
    function NavigationService(config, http) {
        return _super.call(this, '/api/1/navigation/', config, http) || this;
    }
    NavigationService.prototype.getNavigationData = function (navigationRequest) {
        var request = navigationRequest;
        if (_.isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
            if (_.isNil(request.hideRules) && _.isNil(request.skipRules) && !_.isNil(this.config.defaultNavigationRules)) {
                var clonedRequest = _.clone(navigationRequest);
                if (this.config.defaultNavigationRules.skipRules) {
                    clonedRequest.skipRules = _.clone(this.config.defaultNavigationRules.skipRules);
                    request = clonedRequest;
                }
                if (this.config.defaultNavigationRules.hideRules) {
                    clonedRequest.hideRules = _.clone(this.config.defaultNavigationRules.hideRules);
                    request = clonedRequest;
                }
            }
        }
        return this._sendPostRequest(request);
    };
    NavigationService.decorators = [
        { type: Injectable }
    ];
    NavigationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return NavigationService;
}(BaseService));
export { NavigationService };
var NavigationRequest = (function () {
    function NavigationRequest(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
        this.fqn = fqn;
        this.propNames = propNames;
        this.includeParents = includeParents;
        this.navHandlerFqn = navHandlerFqn;
        this.hideRules = hideRules;
        this.skipRules = skipRules;
    }
    return NavigationRequest;
}());
export { NavigationRequest };
if (false) {
    NavigationRequest.prototype.fqn;
    NavigationRequest.prototype.propNames;
    NavigationRequest.prototype.includeParents;
    NavigationRequest.prototype.navHandlerFqn;
    NavigationRequest.prototype.hideRules;
    NavigationRequest.prototype.skipRules;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmF2aWdhdGlvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbIm5hdmlnYXRpb24uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUVsRCxPQUFPLEVBQUUsb0JBQW9CLEVBQXdCLE1BQU0sVUFBVSxDQUFDO0FBQ3RFLE9BQU8sS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBRzVCO0lBQ3VDLDZDQUFXO0lBRTlDLDJCQUEwQyxNQUE0QixFQUFFLElBQWdCO2VBQ3BGLGtCQUFNLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUtELDZDQUFpQixHQUFqQixVQUFrQixpQkFBb0M7WUFDOUMsT0FBTyxHQUFHLGlCQUFpQjtRQUMvQixJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLElBQUksaUJBQWlCLENBQUMsYUFBYSxLQUFLLEVBQUUsRUFBRTtZQUNwRixJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEVBQUU7b0JBQ3BHLGFBQWEsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDO2dCQUNoRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFO29CQUM5QyxhQUFhLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDaEYsT0FBTyxHQUFHLGFBQWEsQ0FBQztpQkFDM0I7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRTtvQkFDOUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ2hGLE9BQU8sR0FBRyxhQUFhLENBQUM7aUJBQzNCO2FBQ0o7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzFDLENBQUM7O2dCQTFCSixVQUFVOzs7Z0RBR00sTUFBTSxTQUFDLG9CQUFvQjtnQkFUbkMsVUFBVTs7SUFpQ25CLHdCQUFDO0NBQUEsQUEzQkQsQ0FDdUMsV0FBVyxHQTBCakQ7U0ExQlksaUJBQWlCO0FBNEI5QjtJQVdJLDJCQUNXLEdBQVcsRUFBUyxTQUFvQixFQUFTLGNBQXdCLEVBQ3pFLGFBQXNCLEVBQVMsU0FBMkIsRUFBUyxTQUEyQjtRQUQ5RixRQUFHLEdBQUgsR0FBRyxDQUFRO1FBQVMsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUFTLG1CQUFjLEdBQWQsY0FBYyxDQUFVO1FBQ3pFLGtCQUFhLEdBQWIsYUFBYSxDQUFTO1FBQVMsY0FBUyxHQUFULFNBQVMsQ0FBa0I7UUFBUyxjQUFTLEdBQVQsU0FBUyxDQUFrQjtJQUN6RyxDQUFDO0lBRUwsd0JBQUM7QUFBRCxDQUFDLEFBaEJELElBZ0JDOzs7SUFKTyxnQ0FBa0I7SUFBRSxzQ0FBMkI7SUFBRSwyQ0FBK0I7SUFDaEYsMENBQTZCO0lBQUUsc0NBQWtDO0lBQUUsc0NBQWtDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uUnVsZXMgfSBmcm9tICcuL3NoYXJlZCc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0aW9uU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoJy9hcGkvMS9uYXZpZ2F0aW9uLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gSlNPTiBOYXZpZ2F0aW9uIHNlcnZpY2Ugb24gdGhlIHNlcnZlci5cclxuICAgICAqL1xyXG4gICAgZ2V0TmF2aWdhdGlvbkRhdGEobmF2aWdhdGlvblJlcXVlc3Q6IE5hdmlnYXRpb25SZXF1ZXN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICBsZXQgcmVxdWVzdCA9IG5hdmlnYXRpb25SZXF1ZXN0O1xyXG4gICAgICAgIGlmIChfLmlzTmlsKG5hdmlnYXRpb25SZXF1ZXN0Lm5hdkhhbmRsZXJGcW4pIHx8IG5hdmlnYXRpb25SZXF1ZXN0Lm5hdkhhbmRsZXJGcW4gPT09ICcnKSB7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKHJlcXVlc3QuaGlkZVJ1bGVzKSAmJiBfLmlzTmlsKHJlcXVlc3Quc2tpcFJ1bGVzKSAmJiAhXy5pc05pbCh0aGlzLmNvbmZpZy5kZWZhdWx0TmF2aWdhdGlvblJ1bGVzKSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY2xvbmVkUmVxdWVzdCA9IF8uY2xvbmUobmF2aWdhdGlvblJlcXVlc3QpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmRlZmF1bHROYXZpZ2F0aW9uUnVsZXMuc2tpcFJ1bGVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2xvbmVkUmVxdWVzdC5za2lwUnVsZXMgPSBfLmNsb25lKHRoaXMuY29uZmlnLmRlZmF1bHROYXZpZ2F0aW9uUnVsZXMuc2tpcFJ1bGVzKTtcclxuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0ID0gY2xvbmVkUmVxdWVzdDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5kZWZhdWx0TmF2aWdhdGlvblJ1bGVzLmhpZGVSdWxlcykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsb25lZFJlcXVlc3QuaGlkZVJ1bGVzID0gXy5jbG9uZSh0aGlzLmNvbmZpZy5kZWZhdWx0TmF2aWdhdGlvblJ1bGVzLmhpZGVSdWxlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdCA9IGNsb25lZFJlcXVlc3Q7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE5hdmlnYXRpb25SZXF1ZXN0IHtcclxuXHJcbiAgICAvKipcclxuICAgICAqIE5hdmlnYXRpb24gcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIGZxbiAtIFRoZSBGUU4gb2YgTmF2aWdhdGlvblJlcXVlc3RcclxuICAgICAqIEBwYXJhbSBwcm9wTmFtZXMgLSBUaGUgUHJvcGVydHkgTmFtZXNcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlUGFyZW50cyAtIFdoZXRoZXIgdG8gaW5jbHVkZSBwYXJlbnRzIGluIHJlc3VsdHNcclxuICAgICAqIEBwYXJhbSBuYXZIYW5kbGVyRnFuIC0gVGhlIEZRTiBvZiBOYXZpZ2F0aW9uIEhhbmRsZXIgSXRlbVxyXG4gICAgICogQHBhcmFtIGhpZGVSdWxlcyAtIFRoZSBIaWRlIFJ1bGVzIGZvciBOYXZpZ2F0aW9uXHJcbiAgICAgKiBAcGFyYW0gc2tpcFJ1bGVzIC0gVGhlIFNraXAgUnVsZXMgZm9yIE5hdmlnYXRpb25cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHVibGljIGZxbjogc3RyaW5nLCBwdWJsaWMgcHJvcE5hbWVzPzogc3RyaW5nW10sIHB1YmxpYyBpbmNsdWRlUGFyZW50cz86IGJvb2xlYW4sXHJcbiAgICAgICAgcHVibGljIG5hdkhhbmRsZXJGcW4/OiBzdHJpbmcsIHB1YmxpYyBoaWRlUnVsZXM/OiBOYXZpZ2F0aW9uUnVsZXMsIHB1YmxpYyBza2lwUnVsZXM/OiBOYXZpZ2F0aW9uUnVsZXMpIHtcclxuICAgIH1cclxuXHJcbn1cclxuIl19