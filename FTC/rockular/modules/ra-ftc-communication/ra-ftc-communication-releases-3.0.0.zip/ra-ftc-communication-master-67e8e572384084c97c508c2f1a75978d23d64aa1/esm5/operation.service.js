import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
var OperationService = (function (_super) {
    tslib_1.__extends(OperationService, _super);
    function OperationService(config, http) {
        return _super.call(this, '/api/1/operation/', config, http) || this;
    }
    OperationService.prototype.getOperationData = function (operationReq) {
        return this._sendPostRequest(operationReq);
    };
    OperationService.decorators = [
        { type: Injectable }
    ];
    OperationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return OperationService;
}(BaseService));
export { OperationService };
var OperationRequest = (function () {
    function OperationRequest(target, operation, parameters) {
        this.target = target;
        this.operation = operation;
        this.parameters = parameters;
    }
    return OperationRequest;
}());
export { OperationRequest };
if (false) {
    OperationRequest.prototype.target;
    OperationRequest.prototype.operation;
    OperationRequest.prototype.parameters;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlcmF0aW9uLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsib3BlcmF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBQyxNQUFNLEVBQUUsVUFBVSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBQ2pELE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUNoRCxPQUFPLEVBQUMsb0JBQW9CLEVBQXVCLE1BQU0sVUFBVSxDQUFDO0FBRXBFLE9BQU8sRUFBQyxXQUFXLEVBQUMsTUFBTSxnQkFBZ0IsQ0FBQztBQUUzQztJQUNzQyw0Q0FBVztJQUU3QywwQkFBMEMsTUFBNEIsRUFBRSxJQUFnQjtlQUNwRixrQkFBTSxtQkFBbUIsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0lBQzVDLENBQUM7SUFLTSwyQ0FBZ0IsR0FBdkIsVUFBd0IsWUFBOEI7UUFDbEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0MsQ0FBQzs7Z0JBWkosVUFBVTs7O2dEQUdNLE1BQU0sU0FBQyxvQkFBb0I7Z0JBUnBDLFVBQVU7O0lBa0JsQix1QkFBQztDQUFBLEFBYkQsQ0FDc0MsV0FBVyxHQVloRDtTQVpZLGdCQUFnQjtBQWM3QjtJQU9JLDBCQUFtQixNQUFjLEVBQVMsU0FBaUIsRUFBUyxVQUFtQjtRQUFwRSxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQVMsY0FBUyxHQUFULFNBQVMsQ0FBUTtRQUFTLGVBQVUsR0FBVixVQUFVLENBQVM7SUFDdkYsQ0FBQztJQUNMLHVCQUFDO0FBQUQsQ0FBQyxBQVRELElBU0M7OztJQUZlLGtDQUFxQjtJQUFFLHFDQUF3QjtJQUFFLHNDQUEwQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0LCBJbmplY3RhYmxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7Q09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7QmFzZVNlcnZpY2V9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE9wZXJhdGlvblNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgICAgIHN1cGVyKCcvYXBpLzEvb3BlcmF0aW9uLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gSlNPTiBPcGVyYXRpb24gc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0T3BlcmF0aW9uRGF0YShvcGVyYXRpb25SZXE6IE9wZXJhdGlvblJlcXVlc3QpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3Qob3BlcmF0aW9uUmVxKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE9wZXJhdGlvblJlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBPcGVyYXRpb24gcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIHRhcmdldCAtIFRoZSBGUU4gb2YgdGFyZ2V0IGl0ZW1cclxuICAgICAqIEBwYXJhbSBvcGVyYXRpb24gLSBUaGUgbmFtZSBvZiB0aGUgb3BlcmF0aW9uXHJcbiAgICAgKiBAcGFyYW0gcGFyYW1ldGVycyAtIFRoZSBwYXJhbWV0ZXJzIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgdGFyZ2V0OiBzdHJpbmcsIHB1YmxpYyBvcGVyYXRpb246IHN0cmluZywgcHVibGljIHBhcmFtZXRlcnM/OiBvYmplY3QpIHtcclxuICAgIH1cclxufVxyXG4iXX0=