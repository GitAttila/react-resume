import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
var MimeService = (function (_super) {
    tslib_1.__extends(MimeService, _super);
    function MimeService(config, http) {
        return _super.call(this, '/api/1/mime/', config, http) || this;
    }
    MimeService.prototype.getMimeItemPath = function (fqn) {
        return this.endpointUrl.concat(fqn);
    };
    MimeService.prototype.getMimeProperty = function (fqn) {
        return this._sendGetRequest(this.getMimeItemPath(fqn), { responseType: 'text' });
    };
    MimeService.decorators = [
        { type: Injectable }
    ];
    MimeService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
        { type: HttpClient }
    ]; };
    return MimeService;
}(BaseService));
export { MimeService };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWltZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbIm1pbWUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsTUFBTSxVQUFVLENBQUM7QUFDdEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRzdDO0lBQ2lDLHVDQUFXO0lBRXhDLHFCQUEwQyxNQUE0QixFQUFFLElBQWdCO2VBQ3BGLGtCQUFNLGNBQWMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxxQ0FBZSxHQUFmLFVBQWdCLEdBQVc7UUFDdkIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBTUQscUNBQWUsR0FBZixVQUFnQixHQUFXO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDckYsQ0FBQzs7Z0JBakJKLFVBQVU7OztnREFHTSxNQUFNLFNBQUMsb0JBQW9CO2dCQVJuQyxVQUFVOztJQXVCbkIsa0JBQUM7Q0FBQSxBQWxCRCxDQUNpQyxXQUFXLEdBaUIzQztTQWpCWSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE1pbWVTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcignL2FwaS8xL21pbWUvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRNaW1lSXRlbVBhdGgoZnFuOiBzdHJpbmcpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5lbmRwb2ludFVybC5jb25jYXQoZnFuKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBtaW1lIHByb3BlcnR5IHZhbHVlLlxyXG4gICAgICogQHBhcmFtIGZxbiAtIG1pbWUgZnFuXHJcbiAgICAgKi9cclxuICAgIGdldE1pbWVQcm9wZXJ0eShmcW46IHN0cmluZyk6IE9ic2VydmFibGU8c3RyaW5nPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRHZXRSZXF1ZXN0KHRoaXMuZ2V0TWltZUl0ZW1QYXRoKGZxbiksIHsgcmVzcG9uc2VUeXBlOiAndGV4dCcgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19