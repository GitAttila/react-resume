import { isString, isNil } from 'lodash';
var ItemPermissions = (function () {
    function ItemPermissions(readPerm, writePerm, deletePerm, executePerm) {
        this._read = readPerm;
        this._write = writePerm;
        this._delete = deletePerm;
        this._execute = executePerm;
    }
    Object.defineProperty(ItemPermissions.prototype, "read", {
        get: function () {
            return this._read;
        },
        set: function (param) {
            this._read = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "write", {
        get: function () {
            return this._write;
        },
        set: function (param) {
            this._write = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "delete", {
        get: function () {
            return this._delete;
        },
        set: function (param) {
            this._delete = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ItemPermissions.prototype, "execute", {
        get: function () {
            return this._execute;
        },
        set: function (param) {
            this._execute = isNil(param) ? false : param;
        },
        enumerable: true,
        configurable: true
    });
    ItemPermissions.create = function (rwde) {
        if (rwde instanceof ItemPermissions) {
            return rwde;
        }
        var _rwde = isString(rwde) ? rwde.toLowerCase() : 'nnnn';
        return new ItemPermissions(_rwde[0] === 'y', _rwde[1] === 'y', _rwde[2] === 'y', _rwde[3] === 'y');
    };
    ItemPermissions.prototype.satisfiesRequired = function (requiredPermissions) {
        var requiredPermissionsLocal = ItemPermissions.create(requiredPermissions);
        if (requiredPermissionsLocal.read && !this.read) {
            return false;
        }
        if (requiredPermissionsLocal.write && !this.write) {
            return false;
        }
        if (requiredPermissionsLocal.delete && !this.delete) {
            return false;
        }
        if (requiredPermissionsLocal.execute && !this.execute) {
            return false;
        }
        return true;
    };
    return ItemPermissions;
}());
export { ItemPermissions };
if (false) {
    ItemPermissions.prototype._read;
    ItemPermissions.prototype._write;
    ItemPermissions.prototype._delete;
    ItemPermissions.prototype._execute;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1wZXJtaXNzaW9ucy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJtb2RlbHMvaXRlbS1wZXJtaXNzaW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLFFBQVEsQ0FBQztBQUV6QztJQXdESSx5QkFBWSxRQUFpQixFQUFFLFNBQWtCLEVBQUUsVUFBbUIsRUFBRSxXQUFvQjtRQUN4RixJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQztRQUMxQixJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztJQUNoQyxDQUFDO0lBM0RELHNCQUFJLGlDQUFJO2FBQVI7WUFDSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdEIsQ0FBQzthQUNELFVBQVMsS0FBYztZQUNuQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDOUMsQ0FBQzs7O09BSEE7SUFNRCxzQkFBSSxrQ0FBSzthQUFUO1lBQ0ksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3ZCLENBQUM7YUFDRCxVQUFVLEtBQWM7WUFDcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQy9DLENBQUM7OztPQUhBO0lBTUQsc0JBQUksbUNBQU07YUFBVjtZQUNJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN4QixDQUFDO2FBQ0QsVUFBVyxLQUFjO1lBQ3JCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNoRCxDQUFDOzs7T0FIQTtJQU1ELHNCQUFJLG9DQUFPO2FBQVg7WUFDSSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDekIsQ0FBQzthQUNELFVBQVksS0FBYztZQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDakQsQ0FBQzs7O09BSEE7SUFVYSxzQkFBTSxHQUFwQixVQUFxQixJQUE4QjtRQUMvQyxJQUFJLElBQUksWUFBWSxlQUFlLEVBQUU7WUFDakMsT0FBTyxJQUFJLENBQUM7U0FDZjtZQUNLLEtBQUssR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTTtRQUMxRCxPQUFPLElBQUksZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQ3ZDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQ2hCLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQ2hCLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBb0JELDJDQUFpQixHQUFqQixVQUFrQixtQkFBNkM7WUFDckQsd0JBQXdCLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQztRQUM1RSxJQUFJLHdCQUF3QixDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDN0MsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxJQUFJLHdCQUF3QixDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDL0MsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxJQUFJLHdCQUF3QixDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDakQsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxJQUFJLHdCQUF3QixDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDbkQsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBQ0wsc0JBQUM7QUFBRCxDQUFDLEFBbkZELElBbUZDOzs7SUFsRkcsZ0NBQXVCO0lBUXZCLGlDQUF3QjtJQVF4QixrQ0FBeUI7SUFRekIsbUNBQTBCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaXNTdHJpbmcsIGlzTmlsIH0gZnJvbSAnbG9kYXNoJztcclxuXHJcbmV4cG9ydCBjbGFzcyBJdGVtUGVybWlzc2lvbnMge1xyXG4gICAgcHJpdmF0ZSBfcmVhZDogYm9vbGVhbjtcclxuICAgIGdldCByZWFkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9yZWFkO1xyXG4gICAgfVxyXG4gICAgc2V0IHJlYWQocGFyYW06IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9yZWFkID0gaXNOaWwocGFyYW0pID8gZmFsc2UgOiBwYXJhbTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF93cml0ZTogYm9vbGVhbjtcclxuICAgIGdldCB3cml0ZSgpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fd3JpdGU7XHJcbiAgICB9XHJcbiAgICBzZXQgd3JpdGUocGFyYW06IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl93cml0ZSA9IGlzTmlsKHBhcmFtKSA/IGZhbHNlIDogcGFyYW07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVsZXRlOiBib29sZWFuO1xyXG4gICAgZ2V0IGRlbGV0ZSgpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZGVsZXRlO1xyXG4gICAgfVxyXG4gICAgc2V0IGRlbGV0ZShwYXJhbTogYm9vbGVhbikge1xyXG4gICAgICAgIHRoaXMuX2RlbGV0ZSA9IGlzTmlsKHBhcmFtKSA/IGZhbHNlIDogcGFyYW07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZXhlY3V0ZTogYm9vbGVhbjtcclxuICAgIGdldCBleGVjdXRlKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9leGVjdXRlO1xyXG4gICAgfVxyXG4gICAgc2V0IGV4ZWN1dGUocGFyYW06IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9leGVjdXRlID0gaXNOaWwocGFyYW0pID8gZmFsc2UgOiBwYXJhbTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFN0YXRpYyBtZXRob2QgYXMgZmFjdG9yeSBmb3IgSXRlbVBlcm1pc3Npb25zIGluc3RhbmNlIGZyb20gUldERSBvciBJdGVtUGVybWlzc2lvbnMuXHJcbiAgICAgKiBJbiBjYXNlIG9mIEl0ZW1QZXJtaXNzaW9ucyBpdCByZXR1cm5zIGdpdmVuIGluc3RhbmNlLlxyXG4gICAgICogQHBhcmFtIHJ3ZGUgaXRlbSByd2RlLCBlLmcuICd5eW55JyBvciAnWU5ZTidcclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGUocndkZTogc3RyaW5nIHwgSXRlbVBlcm1pc3Npb25zKTogSXRlbVBlcm1pc3Npb25zIHtcclxuICAgICAgICBpZiAocndkZSBpbnN0YW5jZW9mIEl0ZW1QZXJtaXNzaW9ucykge1xyXG4gICAgICAgICAgICByZXR1cm4gcndkZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgX3J3ZGUgPSBpc1N0cmluZyhyd2RlKSA/IHJ3ZGUudG9Mb3dlckNhc2UoKSA6ICdubm5uJztcclxuICAgICAgICByZXR1cm4gbmV3IEl0ZW1QZXJtaXNzaW9ucyhfcndkZVswXSA9PT0gJ3knLFxyXG4gICAgICAgICAgICBfcndkZVsxXSA9PT0gJ3knLFxyXG4gICAgICAgICAgICBfcndkZVsyXSA9PT0gJ3knLFxyXG4gICAgICAgICAgICBfcndkZVszXSA9PT0gJ3knKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEl0ZW1QZXJtaXNzaW9ucyBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIHJlYWRQZXJtIGZsYWcgaW5kaWNhdGluZyBpdGVtIGhhcyByZWFkIHBlcm1pc3Npb25cclxuICAgICAqIEBwYXJhbSB3cml0ZVBlcm0gZmxhZyBpbmRpY2F0aW5nIGl0ZW0gaGFzIHdyaXRlIHBlcm1pc3Npb25cclxuICAgICAqIEBwYXJhbSBkZWxldGVQZXJtIGZsYWcgaW5kaWNhdGluZyBpdGVtIGhhcyBkZWxldGUgcGVybWlzc2lvblxyXG4gICAgICogQHBhcmFtIGV4ZWN1dGVQZXJtIGZsYWcgaW5kaWNhdGluZyBpdGVtIGhhcyBleGVjdXRlIHBlcm1pc3Npb25cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IocmVhZFBlcm06IGJvb2xlYW4sIHdyaXRlUGVybTogYm9vbGVhbiwgZGVsZXRlUGVybTogYm9vbGVhbiwgZXhlY3V0ZVBlcm06IGJvb2xlYW4pIHtcclxuICAgICAgICB0aGlzLl9yZWFkID0gcmVhZFBlcm07XHJcbiAgICAgICAgdGhpcy5fd3JpdGUgPSB3cml0ZVBlcm07XHJcbiAgICAgICAgdGhpcy5fZGVsZXRlID0gZGVsZXRlUGVybTtcclxuICAgICAgICB0aGlzLl9leGVjdXRlID0gZXhlY3V0ZVBlcm07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gY2hlY2sgYWxsIHJlcXVpcmVkIHBlcm1pc3Npb25zIHdpdGggZm9yIHRoaXMgaXRlbSBwZXJtaXNzaW9ucyBpbnN0YW5jZS5cclxuICAgICAqIEBwYXJhbSByZXF1aXJlZFBlcm1pc3Npb25zIGl0ZW0gcGVybWlzc2lvbnMgb2JqZWN0IHRvIGNoZWNrIHJlcXVpcmVkIHBlcm1pc3Npb25zIHdpdGhcclxuICAgICAqL1xyXG4gICAgc2F0aXNmaWVzUmVxdWlyZWQocmVxdWlyZWRQZXJtaXNzaW9uczogc3RyaW5nIHwgSXRlbVBlcm1pc3Npb25zKSB7XHJcbiAgICAgICAgY29uc3QgcmVxdWlyZWRQZXJtaXNzaW9uc0xvY2FsID0gSXRlbVBlcm1pc3Npb25zLmNyZWF0ZShyZXF1aXJlZFBlcm1pc3Npb25zKTtcclxuICAgICAgICBpZiAocmVxdWlyZWRQZXJtaXNzaW9uc0xvY2FsLnJlYWQgJiYgIXRoaXMucmVhZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChyZXF1aXJlZFBlcm1pc3Npb25zTG9jYWwud3JpdGUgJiYgIXRoaXMud3JpdGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVxdWlyZWRQZXJtaXNzaW9uc0xvY2FsLmRlbGV0ZSAmJiAhdGhpcy5kZWxldGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocmVxdWlyZWRQZXJtaXNzaW9uc0xvY2FsLmV4ZWN1dGUgJiYgIXRoaXMuZXhlY3V0ZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==