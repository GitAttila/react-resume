import * as _ from 'lodash';
var BaseService = (function () {
    function BaseService(relativeApiEndpoint, config, http) {
        this.relativeApiEndpoint = relativeApiEndpoint;
        this.config = config;
        this.http = http;
    }
    Object.defineProperty(BaseService.prototype, "endpointUrl", {
        get: function () {
            return this.config.baseUrl + this.relativeApiEndpoint;
        },
        enumerable: true,
        configurable: true
    });
    BaseService.prototype._sendPostRequest = function (request) {
        return this.http.post(this.endpointUrl, request, _.extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
    };
    BaseService.prototype._sendGetRequest = function (url, extraHttpOptions) {
        if (extraHttpOptions === void 0) { extraHttpOptions = {}; }
        var httpOptions = _.extend(extraHttpOptions, this.config.httpOptions);
        var endpointUrl = !_.isEmpty(url) ? url : this.endpointUrl;
        return this.http.get(endpointUrl, _.extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, httpOptions));
    };
    return BaseService;
}());
export { BaseService };
if (false) {
    BaseService.prototype.relativeApiEndpoint;
    BaseService.prototype.config;
    BaseService.prototype.http;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbImJhc2Uuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUc1QjtJQUVJLHFCQUNjLG1CQUEyQixFQUMzQixNQUE0QixFQUM1QixJQUFnQjtRQUZoQix3QkFBbUIsR0FBbkIsbUJBQW1CLENBQVE7UUFDM0IsV0FBTSxHQUFOLE1BQU0sQ0FBc0I7UUFDNUIsU0FBSSxHQUFKLElBQUksQ0FBWTtJQUFJLENBQUM7SUFFbkMsc0JBQUksb0NBQVc7YUFBZjtZQUNJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1FBQzFELENBQUM7OztPQUFBO0lBRVMsc0NBQWdCLEdBQTFCLFVBQTJCLE9BQVk7UUFDbkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sRUFDM0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxtQ0FBbUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ2pILENBQUM7SUFFUyxxQ0FBZSxHQUF6QixVQUEwQixHQUFZLEVBQUUsZ0JBQTBCO1FBQTFCLGlDQUFBLEVBQUEscUJBQTBCO1lBQ3hELFdBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO1lBQ2pFLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7UUFDNUQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsbUNBQW1DLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDckcsQ0FBQztJQUNMLGtCQUFDO0FBQUQsQ0FBQyxBQXRCRCxJQXNCQzs7O0lBbkJPLDBDQUFxQztJQUNyQyw2QkFBc0M7SUFDdEMsMkJBQTBCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcm90ZWN0ZWQgcmVsYXRpdmVBcGlFbmRwb2ludDogc3RyaW5nLFxyXG4gICAgICAgIHByb3RlY3RlZCBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLFxyXG4gICAgICAgIHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50KSB7IH1cclxuXHJcbiAgICBnZXQgZW5kcG9pbnRVcmwoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLmJhc2VVcmwgKyB0aGlzLnJlbGF0aXZlQXBpRW5kcG9pbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIF9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdDogYW55KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QodGhpcy5lbmRwb2ludFVybCwgcmVxdWVzdCxcclxuICAgICAgICAgICAgXy5leHRlbmQoeyBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyB9IH0sIHRoaXMuY29uZmlnLmh0dHBPcHRpb25zKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIF9zZW5kR2V0UmVxdWVzdCh1cmw/OiBzdHJpbmcsIGV4dHJhSHR0cE9wdGlvbnM6IGFueSA9IHt9KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICBjb25zdCBodHRwT3B0aW9ucyA9IF8uZXh0ZW5kKGV4dHJhSHR0cE9wdGlvbnMsIHRoaXMuY29uZmlnLmh0dHBPcHRpb25zKTtcclxuICAgICAgICBjb25zdCBlbmRwb2ludFVybCA9ICFfLmlzRW1wdHkodXJsKSA/IHVybCA6IHRoaXMuZW5kcG9pbnRVcmw7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoZW5kcG9pbnRVcmwsXHJcbiAgICAgICAgICAgIF8uZXh0ZW5kKHsgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcgfSB9LCBodHRwT3B0aW9ucykpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==