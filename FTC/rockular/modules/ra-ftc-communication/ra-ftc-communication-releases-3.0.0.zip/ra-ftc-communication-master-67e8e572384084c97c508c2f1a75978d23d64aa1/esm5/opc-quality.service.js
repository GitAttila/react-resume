import { Injectable } from '@angular/core';
export function IQuality() { }
if (false) {
    IQuality.prototype.overall;
    IQuality.prototype.da;
    IQuality.prototype.limit;
    IQuality.prototype.hda;
}
var OpcQualityService = (function () {
    function OpcQualityService() {
        this.opcDaQualityMask = 0xfffC;
        this.opcDaQualityMasterMask = 0x00C0;
        this.opcHdaQualityMask = 0xffff0000;
        this.opcDaQualityFieldMasks = {
            limitField: 0x0003,
            subStatusField: 0x003C,
            quality: 0x00C0
        };
        this.opcDaQualityMaster = {
            bad: 0x0000,
            uncertain: 0x0040,
            notDefined: 0x0080,
            good: 0x00C0
        };
        this.opcDaQualityStatus = {
            bad: 0x0000,
            configError: 0x0004,
            notConnected: 0x0008,
            deviceFailure: 0x000c,
            sensorFailure: 0x0010,
            lastKnown: 0x0014,
            commFailure: 0x0018,
            outOfService: 0x001c,
            initializing: 0x0020,
            uncertain: 0x0040,
            lastUsable: 0x0044,
            sensorNotAccurate: 0x0050,
            engUnitsExceeded: 0x0054,
            subNormal: 0x0058,
            good: 0x00C0,
            localOverride: 0x00D8
        };
        this.opcDaQualityLimit = {
            limitOk: 0x0000,
            limitLow: 0x0001,
            limitHigh: 0x0002,
            constant: 0x0003
        };
        this.opcHdaQuality = {
            extraData: 0x00010000,
            interpolated: 0x00020000,
            raw: 0x00040000,
            calculated: 0x00080000,
            noBound: 0x00100000,
            noData: 0x00200000,
            dataLost: 0x00400000,
            conversion: 0x00800000,
            partial: 0x01000000
        };
        this.overallMessages = {
            0x0000: 'Bad',
            0x0040: 'Uncertain',
            0x0080: 'Not defined',
            0x00C0: 'Good'
        };
        this.detailsMessages = {
            0x0000: 'Not limited',
            0x0001: 'Low limited',
            0x0002: 'High limited',
            0x0003: 'Constant',
            0x0004: 'Config error',
            0x0008: 'Not connected',
            0x000c: 'Device failure',
            0x0010: 'Sensor failure',
            0x0014: 'Last known',
            0x0018: 'Comm failure',
            0x001C: 'Out of service',
            0x0020: 'Initializing',
            0x0044: 'Last usable',
            0x0050: 'Sensors not accurate',
            0x0054: 'Engineering units exceeded',
            0x0058: 'Sub-Normal',
            0x00D8: 'Local override',
            0x00010000: 'Extra data',
            0x00020000: 'Interpolated',
            0x00040000: 'Raw',
            0x00080000: 'Calculated',
            0x00100000: 'No bound',
            0x00200000: 'No data',
            0x00400000: 'Data lost',
            0x00800000: 'Conversion',
            0x01000000: 'Partial'
        };
    }
    OpcQualityService.prototype.asObject = function (qualityAsInt) {
        var mask;
        var quality = (({}));
        mask = qualityAsInt & this.opcDaQualityMasterMask;
        quality.overall = this.overallMessages[mask];
        mask = qualityAsInt & this.opcDaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.da = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        if (mask && this.detailsMessages[mask]) {
            quality.limit = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcHdaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.hda = this.detailsMessages[mask];
        }
        return quality;
    };
    OpcQualityService.prototype.asString = function (qualityAsInt) {
        var hasDaQuality = false;
        var qObj = this.asObject(qualityAsInt);
        var qString;
        qString = qObj.overall;
        if (qObj.da) {
            qString = qString + ': ' + qObj.da;
            hasDaQuality = true;
        }
        if (qObj.limit) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.limit;
            hasDaQuality = true;
        }
        if (qObj.hda) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.hda;
        }
        return qString;
    };
    OpcQualityService.prototype.getOpcDaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMask;
    };
    OpcQualityService.prototype.getOpcLimitStatus = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
    };
    OpcQualityService.prototype.getSimpleQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMasterMask;
    };
    OpcQualityService.prototype.getOpcHdaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcHdaQualityMask;
    };
    OpcQualityService.prototype.isGood = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
    };
    OpcQualityService.prototype.isUncertain = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
    };
    OpcQualityService.prototype.isBad = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
    };
    OpcQualityService.prototype.isDaConfigError = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
    };
    OpcQualityService.prototype.isDaNotConnected = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
    };
    OpcQualityService.prototype.isDaDeviceFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
    };
    OpcQualityService.prototype.isDaSensorFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
    };
    OpcQualityService.prototype.isDaLastKnown = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
    };
    OpcQualityService.prototype.isDaCommFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
    };
    OpcQualityService.prototype.isDaOutOfService = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
    };
    OpcQualityService.prototype.isDaInitializing = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
    };
    OpcQualityService.prototype.isDaLastUsable = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
    };
    OpcQualityService.prototype.isDaSensorNotAccurate = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
    };
    OpcQualityService.prototype.isDaEngUnitsExceeded = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
    };
    OpcQualityService.prototype.isDaSubNormal = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
    };
    OpcQualityService.prototype.isDaLocalOverride = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
    };
    OpcQualityService.prototype.isLimitOk = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
    };
    OpcQualityService.prototype.isLimitLow = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
    };
    OpcQualityService.prototype.isLimitHigh = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
    };
    OpcQualityService.prototype.isLimitConstant = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
    };
    OpcQualityService.prototype.isHdaExtraData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
    };
    OpcQualityService.prototype.isHdaInterpolated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
    };
    OpcQualityService.prototype.isHdaRaw = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
    };
    OpcQualityService.prototype.isHdaCalculated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
    };
    OpcQualityService.prototype.isHdaNoBound = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
    };
    OpcQualityService.prototype.isHdaNoData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
    };
    OpcQualityService.prototype.isHdaDataLost = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
    };
    OpcQualityService.prototype.isHdaConversion = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
    };
    OpcQualityService.prototype.isHdaPartial = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
    };
    OpcQualityService.decorators = [
        { type: Injectable }
    ];
    return OpcQualityService;
}());
export { OpcQualityService };
if (false) {
    OpcQualityService.prototype.opcDaQualityMask;
    OpcQualityService.prototype.opcDaQualityMasterMask;
    OpcQualityService.prototype.opcHdaQualityMask;
    OpcQualityService.prototype.opcDaQualityFieldMasks;
    OpcQualityService.prototype.opcDaQualityMaster;
    OpcQualityService.prototype.opcDaQualityStatus;
    OpcQualityService.prototype.opcDaQualityLimit;
    OpcQualityService.prototype.opcHdaQuality;
    OpcQualityService.prototype.overallMessages;
    OpcQualityService.prototype.detailsMessages;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BjLXF1YWxpdHkuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJvcGMtcXVhbGl0eS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsOEJBU0M7O0lBUEMsMkJBQWdCO0lBRWhCLHNCQUFZO0lBRVoseUJBQWU7SUFFZix1QkFBYTs7QUFPZjtJQUFBO1FBR1UscUJBQWdCLEdBQUcsTUFBTSxDQUFDO1FBQzFCLDJCQUFzQixHQUFHLE1BQU0sQ0FBQztRQUNoQyxzQkFBaUIsR0FBRyxVQUFVLENBQUM7UUFDL0IsMkJBQXNCLEdBQUc7WUFDL0IsVUFBVSxFQUFFLE1BQU07WUFDbEIsY0FBYyxFQUFFLE1BQU07WUFDdEIsT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQztRQUNNLHVCQUFrQixHQUFHO1lBQzNCLEdBQUcsRUFBRSxNQUFNO1lBQ1gsU0FBUyxFQUFFLE1BQU07WUFDakIsVUFBVSxFQUFFLE1BQU07WUFDbEIsSUFBSSxFQUFFLE1BQU07U0FDYixDQUFDO1FBQ00sdUJBQWtCLEdBQUc7WUFDM0IsR0FBRyxFQUFFLE1BQU07WUFDWCxXQUFXLEVBQUUsTUFBTTtZQUNuQixZQUFZLEVBQUUsTUFBTTtZQUNwQixhQUFhLEVBQUUsTUFBTTtZQUNyQixhQUFhLEVBQUUsTUFBTTtZQUNyQixTQUFTLEVBQUUsTUFBTTtZQUNqQixXQUFXLEVBQUUsTUFBTTtZQUNuQixZQUFZLEVBQUUsTUFBTTtZQUNwQixZQUFZLEVBQUUsTUFBTTtZQUNwQixTQUFTLEVBQUUsTUFBTTtZQUNqQixVQUFVLEVBQUUsTUFBTTtZQUNsQixpQkFBaUIsRUFBRSxNQUFNO1lBQ3pCLGdCQUFnQixFQUFFLE1BQU07WUFDeEIsU0FBUyxFQUFFLE1BQU07WUFDakIsSUFBSSxFQUFFLE1BQU07WUFDWixhQUFhLEVBQUUsTUFBTTtTQUN0QixDQUFDO1FBQ00sc0JBQWlCLEdBQUc7WUFDMUIsT0FBTyxFQUFFLE1BQU07WUFDZixRQUFRLEVBQUUsTUFBTTtZQUNoQixTQUFTLEVBQUUsTUFBTTtZQUNqQixRQUFRLEVBQUUsTUFBTTtTQUNqQixDQUFDO1FBQ00sa0JBQWEsR0FBRztZQUN0QixTQUFTLEVBQUUsVUFBVTtZQUNyQixZQUFZLEVBQUUsVUFBVTtZQUN4QixHQUFHLEVBQUUsVUFBVTtZQUNmLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLE9BQU8sRUFBRSxVQUFVO1lBQ25CLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLE9BQU8sRUFBRSxVQUFVO1NBQ3BCLENBQUM7UUFDTSxvQkFBZSxHQUFHO1lBQ3hCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsTUFBTSxFQUFFLFdBQVc7WUFDbkIsTUFBTSxFQUFFLGFBQWE7WUFDckIsTUFBTSxFQUFFLE1BQU07U0FDZixDQUFDO1FBRU0sb0JBQWUsR0FBRztZQUV4QixNQUFNLEVBQUUsYUFBYTtZQUNyQixNQUFNLEVBQUUsYUFBYTtZQUNyQixNQUFNLEVBQUUsY0FBYztZQUN0QixNQUFNLEVBQUUsVUFBVTtZQUVsQixNQUFNLEVBQUUsY0FBYztZQUN0QixNQUFNLEVBQUUsZUFBZTtZQUN2QixNQUFNLEVBQUUsZ0JBQWdCO1lBQ3hCLE1BQU0sRUFBRSxnQkFBZ0I7WUFDeEIsTUFBTSxFQUFFLFlBQVk7WUFDcEIsTUFBTSxFQUFFLGNBQWM7WUFDdEIsTUFBTSxFQUFFLGdCQUFnQjtZQUN4QixNQUFNLEVBQUUsY0FBYztZQUV0QixNQUFNLEVBQUUsYUFBYTtZQUNyQixNQUFNLEVBQUUsc0JBQXNCO1lBQzlCLE1BQU0sRUFBRSw0QkFBNEI7WUFDcEMsTUFBTSxFQUFFLFlBQVk7WUFFcEIsTUFBTSxFQUFFLGdCQUFnQjtZQUV4QixVQUFVLEVBQUUsWUFBWTtZQUN4QixVQUFVLEVBQUUsY0FBYztZQUMxQixVQUFVLEVBQUUsS0FBSztZQUNqQixVQUFVLEVBQUUsWUFBWTtZQUN4QixVQUFVLEVBQUUsVUFBVTtZQUN0QixVQUFVLEVBQUUsU0FBUztZQUNyQixVQUFVLEVBQUUsV0FBVztZQUN2QixVQUFVLEVBQUUsWUFBWTtZQUN4QixVQUFVLEVBQUUsU0FBUztTQUN0QixDQUFDO0lBaVVKLENBQUM7SUEzVFEsb0NBQVEsR0FBZixVQUFnQixZQUFvQjtZQUM5QixJQUFZO1lBQ1YsT0FBTyxHQUFHLEVBQUEsRUFBRSxFQUFZO1FBRTlCLElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1FBQ2xELE9BQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUU3QyxJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM1QyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN6QztRQUVELElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQztRQUM3RCxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1QztRQUVELElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQzdDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdEMsT0FBTyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQU1NLG9DQUFRLEdBQWYsVUFBZ0IsWUFBb0I7WUFDOUIsWUFBWSxHQUFHLEtBQUs7WUFDbEIsSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO1lBQ3BDLE9BQWU7UUFFbkIsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDdkIsSUFBSSxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ1gsT0FBTyxHQUFHLE9BQU8sR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNuQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1NBQ3JCO1FBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2QsT0FBTyxHQUFHLE9BQU87Z0JBQ2YsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUM1QyxZQUFZLEdBQUcsSUFBSSxDQUFDO1NBQ3JCO1FBQ0QsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ1osT0FBTyxHQUFHLE9BQU87Z0JBQ2YsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUMzQztRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFNTSwyQ0FBZSxHQUF0QixVQUF1QixZQUFvQjtRQUN6QyxPQUFPLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7SUFDOUMsQ0FBQztJQU1NLDZDQUFpQixHQUF4QixVQUF5QixZQUFvQjtRQUMzQyxPQUFPLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDO0lBQy9ELENBQUM7SUFNTSw0Q0FBZ0IsR0FBdkIsVUFBd0IsWUFBb0I7UUFDMUMsT0FBTyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQ3BELENBQUM7SUFNTSw0Q0FBZ0IsR0FBdkIsVUFBd0IsWUFBb0I7UUFDMUMsT0FBTyxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQy9DLENBQUM7SUFNTSxrQ0FBTSxHQUFiLFVBQWMsWUFBb0I7UUFDaEMsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQztJQUMvRixDQUFDO0lBTU0sdUNBQVcsR0FBbEIsVUFBbUIsWUFBb0I7UUFDckMsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQztJQUNwRyxDQUFDO0lBTU0saUNBQUssR0FBWixVQUFhLFlBQW9CO1FBQy9CLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7SUFDOUYsQ0FBQztJQU1NLDJDQUFlLEdBQXRCLFVBQXVCLFlBQW9CO1FBQ3pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQztJQUNqRixDQUFDO0lBS00sNENBQWdCLEdBQXZCLFVBQXdCLFlBQW9CO1FBQzFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQztJQUNuRixDQUFDO0lBS00sNkNBQWlCLEdBQXhCLFVBQXlCLFlBQW9CO1FBQzNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQztJQUNyRixDQUFDO0lBS00sNkNBQWlCLEdBQXhCLFVBQXlCLFlBQW9CO1FBQzNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQztJQUNyRixDQUFDO0lBS00seUNBQWEsR0FBcEIsVUFBcUIsWUFBb0I7UUFDdkMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDO0lBQzdFLENBQUM7SUFLTSwyQ0FBZSxHQUF0QixVQUF1QixZQUFvQjtRQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUM7SUFDakYsQ0FBQztJQUtNLDRDQUFnQixHQUF2QixVQUF3QixZQUFvQjtRQUMxQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7SUFDbkYsQ0FBQztJQUtNLDRDQUFnQixHQUF2QixVQUF3QixZQUFvQjtRQUMxQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7SUFDbkYsQ0FBQztJQUtNLDBDQUFjLEdBQXJCLFVBQXNCLFlBQW9CO1FBQ3hDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQztJQUMvRSxDQUFDO0lBS00saURBQXFCLEdBQTVCLFVBQTZCLFlBQW9CO1FBQy9DLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUM7SUFDN0YsQ0FBQztJQUtNLGdEQUFvQixHQUEzQixVQUE0QixZQUFvQjtRQUM5QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDO0lBQzNGLENBQUM7SUFLTSx5Q0FBYSxHQUFwQixVQUFxQixZQUFvQjtRQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7SUFDN0UsQ0FBQztJQUtNLDZDQUFpQixHQUF4QixVQUF5QixZQUFvQjtRQUMzQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUM7SUFDckYsQ0FBQztJQU1NLHFDQUFTLEdBQWhCLFVBQWlCLFlBQW9CO1FBQ25DLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDO0lBQ3ZFLENBQUM7SUFLTSxzQ0FBVSxHQUFqQixVQUFrQixZQUFvQjtRQUNwQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztZQUMxQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztJQUN6RSxDQUFDO0lBS00sdUNBQVcsR0FBbEIsVUFBbUIsWUFBb0I7UUFDckMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUM7WUFDMUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7SUFDM0UsQ0FBQztJQUtNLDJDQUFlLEdBQXRCLFVBQXVCLFlBQW9CO1FBQ3pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDO0lBQ3pFLENBQUM7SUFLTSwwQ0FBYyxHQUFyQixVQUFzQixZQUFvQjtRQUN4QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO0lBQ25FLENBQUM7SUFLTSw2Q0FBaUIsR0FBeEIsVUFBeUIsWUFBb0I7UUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQztJQUN6RSxDQUFDO0lBS00sb0NBQVEsR0FBZixVQUFnQixZQUFvQjtRQUNsQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDO0lBQ3ZELENBQUM7SUFLTSwyQ0FBZSxHQUF0QixVQUF1QixZQUFvQjtRQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDO0lBQ3JFLENBQUM7SUFLTSx3Q0FBWSxHQUFuQixVQUFvQixZQUFvQjtRQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO0lBQy9ELENBQUM7SUFLTSx1Q0FBVyxHQUFsQixVQUFtQixZQUFvQjtRQUNyQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO0lBQzdELENBQUM7SUFLTSx5Q0FBYSxHQUFwQixVQUFxQixZQUFvQjtRQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDO0lBQ2pFLENBQUM7SUFLTSwyQ0FBZSxHQUF0QixVQUF1QixZQUFvQjtRQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDO0lBQ3JFLENBQUM7SUFLTSx3Q0FBWSxHQUFuQixVQUFvQixZQUFvQjtRQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO0lBQy9ELENBQUM7O2dCQTNaRixVQUFVOztJQTRaWCx3QkFBQztDQUFBLEFBNVpELElBNFpDO1NBM1pZLGlCQUFpQjs7SUFFNUIsNkNBQWtDO0lBQ2xDLG1EQUF3QztJQUN4Qyw4Q0FBdUM7SUFDdkMsbURBSUU7SUFDRiwrQ0FLRTtJQUNGLCtDQWlCRTtJQUNGLDhDQUtFO0lBQ0YsMENBVUU7SUFDRiw0Q0FLRTtJQUVGLDRDQWdDRSIsInNvdXJjZXNDb250ZW50IjpbIi8qIHRzbGludDpkaXNhYmxlOm5vLWJpdHdpc2UgKi9cclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRoZSBxdWFsaXR5LiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElRdWFsaXR5IHtcclxuICAvKiogZ29vZCwgYmFkLCB1bmNlcnRhaW4gb3Igbm90IGRlZmluZWQgcXVhbGl0eSB2YWx1ZSAqL1xyXG4gIG92ZXJhbGw6IHN0cmluZztcclxuICAvKiogT1BDIERBIHF1YWxpdHkgKi9cclxuICBkYT86IHN0cmluZztcclxuICAvKiogT1BDIGxpbWl0IHN0YXR1cyAqL1xyXG4gIGxpbWl0Pzogc3RyaW5nO1xyXG4gIC8qKiBPUEMgSERBIHF1YWxpdHkgKi9cclxuICBoZGE/OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIHNlcnZpY2UgcHJvdmlkZXMgYSBzZXQgb2YgbWV0aG9kcyBmb3IgZXZhbHVhdGluZyBPUEMgREEgcXVhbGl0eSwgT1BDIGxpbWl0XHJcbiAqIHN0YXR1cyBvciBPUEMgSERBIHF1YWxpdHkgYnkgcGFzc2VkIGFyZ3VtZW50LlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgT3BjUXVhbGl0eVNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eU1hc2sgPSAweGZmZkM7XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlNYXN0ZXJNYXNrID0gMHgwMEMwO1xyXG4gIHByaXZhdGUgb3BjSGRhUXVhbGl0eU1hc2sgPSAweGZmZmYwMDAwO1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5RmllbGRNYXNrcyA9IHtcclxuICAgIGxpbWl0RmllbGQ6IDB4MDAwMyxcclxuICAgIHN1YlN0YXR1c0ZpZWxkOiAweDAwM0MsXHJcbiAgICBxdWFsaXR5OiAweDAwQzBcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5TWFzdGVyID0ge1xyXG4gICAgYmFkOiAweDAwMDAsXHJcbiAgICB1bmNlcnRhaW46IDB4MDA0MCxcclxuICAgIG5vdERlZmluZWQ6IDB4MDA4MCxcclxuICAgIGdvb2Q6IDB4MDBDMFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlTdGF0dXMgPSB7XHJcbiAgICBiYWQ6IDB4MDAwMCxcclxuICAgIGNvbmZpZ0Vycm9yOiAweDAwMDQsXHJcbiAgICBub3RDb25uZWN0ZWQ6IDB4MDAwOCxcclxuICAgIGRldmljZUZhaWx1cmU6IDB4MDAwYyxcclxuICAgIHNlbnNvckZhaWx1cmU6IDB4MDAxMCxcclxuICAgIGxhc3RLbm93bjogMHgwMDE0LFxyXG4gICAgY29tbUZhaWx1cmU6IDB4MDAxOCxcclxuICAgIG91dE9mU2VydmljZTogMHgwMDFjLFxyXG4gICAgaW5pdGlhbGl6aW5nOiAweDAwMjAsXHJcbiAgICB1bmNlcnRhaW46IDB4MDA0MCxcclxuICAgIGxhc3RVc2FibGU6IDB4MDA0NCxcclxuICAgIHNlbnNvck5vdEFjY3VyYXRlOiAweDAwNTAsXHJcbiAgICBlbmdVbml0c0V4Y2VlZGVkOiAweDAwNTQsXHJcbiAgICBzdWJOb3JtYWw6IDB4MDA1OCxcclxuICAgIGdvb2Q6IDB4MDBDMCxcclxuICAgIGxvY2FsT3ZlcnJpZGU6IDB4MDBEOFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlMaW1pdCA9IHtcclxuICAgIGxpbWl0T2s6IDB4MDAwMCxcclxuICAgIGxpbWl0TG93OiAweDAwMDEsXHJcbiAgICBsaW1pdEhpZ2g6IDB4MDAwMixcclxuICAgIGNvbnN0YW50OiAweDAwMDNcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjSGRhUXVhbGl0eSA9IHtcclxuICAgIGV4dHJhRGF0YTogMHgwMDAxMDAwMCxcclxuICAgIGludGVycG9sYXRlZDogMHgwMDAyMDAwMCxcclxuICAgIHJhdzogMHgwMDA0MDAwMCxcclxuICAgIGNhbGN1bGF0ZWQ6IDB4MDAwODAwMDAsXHJcbiAgICBub0JvdW5kOiAweDAwMTAwMDAwLFxyXG4gICAgbm9EYXRhOiAweDAwMjAwMDAwLFxyXG4gICAgZGF0YUxvc3Q6IDB4MDA0MDAwMDAsXHJcbiAgICBjb252ZXJzaW9uOiAweDAwODAwMDAwLFxyXG4gICAgcGFydGlhbDogMHgwMTAwMDAwMFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvdmVyYWxsTWVzc2FnZXMgPSB7XHJcbiAgICAweDAwMDA6ICdCYWQnLFxyXG4gICAgMHgwMDQwOiAnVW5jZXJ0YWluJyxcclxuICAgIDB4MDA4MDogJ05vdCBkZWZpbmVkJyxcclxuICAgIDB4MDBDMDogJ0dvb2QnXHJcbiAgfTtcclxuXHJcbiAgcHJpdmF0ZSBkZXRhaWxzTWVzc2FnZXMgPSB7XHJcbiAgICAvLyBMaW1pdCBzdGF0dXNcclxuICAgIDB4MDAwMDogJ05vdCBsaW1pdGVkJyxcclxuICAgIDB4MDAwMTogJ0xvdyBsaW1pdGVkJyxcclxuICAgIDB4MDAwMjogJ0hpZ2ggbGltaXRlZCcsXHJcbiAgICAweDAwMDM6ICdDb25zdGFudCcsXHJcbiAgICAvLyBCYWRcclxuICAgIDB4MDAwNDogJ0NvbmZpZyBlcnJvcicsXHJcbiAgICAweDAwMDg6ICdOb3QgY29ubmVjdGVkJyxcclxuICAgIDB4MDAwYzogJ0RldmljZSBmYWlsdXJlJyxcclxuICAgIDB4MDAxMDogJ1NlbnNvciBmYWlsdXJlJyxcclxuICAgIDB4MDAxNDogJ0xhc3Qga25vd24nLFxyXG4gICAgMHgwMDE4OiAnQ29tbSBmYWlsdXJlJyxcclxuICAgIDB4MDAxQzogJ091dCBvZiBzZXJ2aWNlJyxcclxuICAgIDB4MDAyMDogJ0luaXRpYWxpemluZycsXHJcbiAgICAvLyBVbmNlcnRhaW5cclxuICAgIDB4MDA0NDogJ0xhc3QgdXNhYmxlJyxcclxuICAgIDB4MDA1MDogJ1NlbnNvcnMgbm90IGFjY3VyYXRlJyxcclxuICAgIDB4MDA1NDogJ0VuZ2luZWVyaW5nIHVuaXRzIGV4Y2VlZGVkJyxcclxuICAgIDB4MDA1ODogJ1N1Yi1Ob3JtYWwnLFxyXG4gICAgLy8gR29vZFxyXG4gICAgMHgwMEQ4OiAnTG9jYWwgb3ZlcnJpZGUnLFxyXG4gICAgLy8gSGRhIGZsYWdzXHJcbiAgICAweDAwMDEwMDAwOiAnRXh0cmEgZGF0YScsXHJcbiAgICAweDAwMDIwMDAwOiAnSW50ZXJwb2xhdGVkJyxcclxuICAgIDB4MDAwNDAwMDA6ICdSYXcnLFxyXG4gICAgMHgwMDA4MDAwMDogJ0NhbGN1bGF0ZWQnLFxyXG4gICAgMHgwMDEwMDAwMDogJ05vIGJvdW5kJyxcclxuICAgIDB4MDAyMDAwMDA6ICdObyBkYXRhJyxcclxuICAgIDB4MDA0MDAwMDA6ICdEYXRhIGxvc3QnLFxyXG4gICAgMHgwMDgwMDAwMDogJ0NvbnZlcnNpb24nLFxyXG4gICAgMHgwMTAwMDAwMDogJ1BhcnRpYWwnXHJcbiAgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24gb2YgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc09iamVjdChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IElRdWFsaXR5IHtcclxuICAgIGxldCBtYXNrOiBudW1iZXI7XHJcbiAgICBjb25zdCBxdWFsaXR5ID0ge30gYXMgSVF1YWxpdHk7XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyTWFzaztcclxuICAgIHF1YWxpdHkub3ZlcmFsbCA9IHRoaXMub3ZlcmFsbE1lc3NhZ2VzW21hc2tdO1xyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eU1hc2s7XHJcbiAgICBpZiAobWFzayAmJiB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXSkge1xyXG4gICAgICBxdWFsaXR5LmRhID0gdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza107XHJcbiAgICB9XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5saW1pdEZpZWxkO1xyXG4gICAgaWYgKG1hc2sgJiYgdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza10pIHtcclxuICAgICAgcXVhbGl0eS5saW1pdCA9IHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdO1xyXG4gICAgfVxyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0hkYVF1YWxpdHlNYXNrO1xyXG4gICAgaWYgKG1hc2sgJiYgdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza10pIHtcclxuICAgICAgcXVhbGl0eS5oZGEgPSB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXTtcclxuICAgIH1cclxuICAgIHJldHVybiBxdWFsaXR5O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhIHN0cmluZyB3aGljaCBpcyBhIHdyaXR0ZW4gcmVwcmVzZW50YXRpb24gb2YgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc1N0cmluZyhxdWFsaXR5QXNJbnQ6IG51bWJlcikge1xyXG4gICAgbGV0IGhhc0RhUXVhbGl0eSA9IGZhbHNlO1xyXG4gICAgY29uc3QgcU9iaiA9IHRoaXMuYXNPYmplY3QocXVhbGl0eUFzSW50KTtcclxuICAgIGxldCBxU3RyaW5nOiBzdHJpbmc7XHJcblxyXG4gICAgcVN0cmluZyA9IHFPYmoub3ZlcmFsbDtcclxuICAgIGlmIChxT2JqLmRhKSB7XHJcbiAgICAgIHFTdHJpbmcgPSBxU3RyaW5nICsgJzogJyArIHFPYmouZGE7XHJcbiAgICAgIGhhc0RhUXVhbGl0eSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAocU9iai5saW1pdCkge1xyXG4gICAgICBxU3RyaW5nID0gcVN0cmluZyArXHJcbiAgICAgICAgKGhhc0RhUXVhbGl0eSA/ICcsICcgOiAnOiAnKSArIHFPYmoubGltaXQ7XHJcbiAgICAgIGhhc0RhUXVhbGl0eSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAocU9iai5oZGEpIHtcclxuICAgICAgcVN0cmluZyA9IHFTdHJpbmcgK1xyXG4gICAgICAgIChoYXNEYVF1YWxpdHkgPyAnLCAnIDogJzogJykgKyBxT2JqLmhkYTtcclxuICAgIH1cclxuICAgIHJldHVybiBxU3RyaW5nO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgT1BDIERBIHF1YWxpdHkgcG9ydGlvbiAobG93ZXIgMTYgYml0cykuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzaztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBsaW1pdCBzdGF0dXMgcG9ydGlvbi4gKG5vdCBsaW1pdGVkLCBsb3cgbGltaXRlZCwgaGlnaCBsaW1pdGVkIG9yIGNvbnN0YW50KS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MubGltaXRGaWVsZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBEQSBNYXN0ZXIgcXVhbGl0eSBwb3J0aW9uIChnb29kLCB1bmNlcnRhaW4sIGJhZCwgb3IgdW5kZWZpbmVkKS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGdldFNpbXBsZVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyTWFzaztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBIREEgcXVhbGl0eSBwb3J0aW9uICh1cHBlciAxNiBiaXRzKS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50XHJcbiAgICovXHJcbiAgcHVibGljIGdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjSGRhUXVhbGl0eU1hc2s7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBIG1ldGhvZCBmb3IgY2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBpcyBvZiBnb29kIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0dvb2QocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAocXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLnF1YWxpdHkpID09PSB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlci5nb29kO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQSBtZXRob2QgZm9yIGNoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaXMgb2YgdW5jZXJ0YWluIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc1VuY2VydGFpbihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIChxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MucXVhbGl0eSkgPT09IHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyLnVuY2VydGFpbjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEEgbWV0aG9kIGZvciBjaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGlzIG9mIGJhZCBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNCYWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAocXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLnF1YWxpdHkpID09PSB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlci5iYWQ7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUNvbmZpZ0Vycm9yKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb25maWdFcnJvcikgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbmZpZ0Vycm9yO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYU5vdENvbm5lY3RlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubm90Q29ubmVjdGVkKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubm90Q29ubmVjdGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYURldmljZUZhaWx1cmUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmRldmljZUZhaWx1cmUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5kZXZpY2VGYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVNlbnNvckZhaWx1cmUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvckZhaWx1cmUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JGYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxhc3RLbm93bihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdEtub3duKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdEtub3duO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUNvbW1GYWlsdXJlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb21tRmFpbHVyZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbW1GYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYU91dE9mU2VydmljZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMub3V0T2ZTZXJ2aWNlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMub3V0T2ZTZXJ2aWNlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUluaXRpYWxpemluZyhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuaW5pdGlhbGl6aW5nKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuaW5pdGlhbGl6aW5nO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxhc3RVc2FibGUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxhc3RVc2FibGUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sYXN0VXNhYmxlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVNlbnNvck5vdEFjY3VyYXRlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JOb3RBY2N1cmF0ZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvck5vdEFjY3VyYXRlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUVuZ1VuaXRzRXhjZWVkZWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmVuZ1VuaXRzRXhjZWVkZWQpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5lbmdVbml0c0V4Y2VlZGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVN1Yk5vcm1hbChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc3ViTm9ybWFsKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc3ViTm9ybWFsO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxvY2FsT3ZlcnJpZGUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxvY2FsT3ZlcnJpZGUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sb2NhbE92ZXJyaWRlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRPayhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0T2spID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0T2s7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBsaW1pdCBzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0xpbWl0TG93KHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRMb3cpID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0TG93O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgbGltaXQgc3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNMaW1pdEhpZ2gocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdEhpZ2gpID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0SGlnaDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRDb25zdGFudChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmNvbnN0YW50KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5jb25zdGFudDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhRXh0cmFEYXRhKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmV4dHJhRGF0YSkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5leHRyYURhdGE7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUludGVycG9sYXRlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5pbnRlcnBvbGF0ZWQpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuaW50ZXJwb2xhdGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFSYXcocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkucmF3KSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LnJhdztcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhQ2FsY3VsYXRlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5jYWxjdWxhdGVkKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmNhbGN1bGF0ZWQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYU5vQm91bmQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkubm9Cb3VuZCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5ub0JvdW5kO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFOb0RhdGEocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkubm9EYXRhKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5Lm5vRGF0YTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhRGF0YUxvc3QocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuZGF0YUxvc3QpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuZGF0YUxvc3Q7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUNvbnZlcnNpb24ocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuY29udmVyc2lvbikgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5jb252ZXJzaW9uO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFQYXJ0aWFsKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LnBhcnRpYWwpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkucGFydGlhbDtcclxuICB9XHJcbn1cclxuXHJcbiJdfQ==