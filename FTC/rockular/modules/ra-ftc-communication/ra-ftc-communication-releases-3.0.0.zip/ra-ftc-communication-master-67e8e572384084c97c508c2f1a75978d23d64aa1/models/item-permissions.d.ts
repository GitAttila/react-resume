export declare class ItemPermissions {
    private _read;
    read: boolean;
    private _write;
    write: boolean;
    private _delete;
    delete: boolean;
    private _execute;
    execute: boolean;
    static create(rwde: string | ItemPermissions): ItemPermissions;
    constructor(readPerm: boolean, writePerm: boolean, deletePerm: boolean, executePerm: boolean);
    satisfiesRequired(requiredPermissions: string | ItemPermissions): boolean;
}
