export declare type identifier = string;
export interface IResponse {
    name?: string;
    shortName?: string;
    fqn: identifier;
    valueType?: string;
    engineeringUnit?: string;
}
export interface INavigationRuleItemInstance {
    fqn: string;
}
export interface INavigationRuleItemType {
    type: string;
    prop?: string;
    ignoreCollectionType?: boolean;
}
export declare type NavigationRules = Array<INavigationRuleItemInstance | INavigationRuleItemType>;
