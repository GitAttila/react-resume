import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { BaseService } from './base.service';
import { Observable } from 'rxjs';
export declare class MimeService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getMimeItemPath(fqn: string): string;
    getMimeProperty(fqn: string): Observable<string>;
}
