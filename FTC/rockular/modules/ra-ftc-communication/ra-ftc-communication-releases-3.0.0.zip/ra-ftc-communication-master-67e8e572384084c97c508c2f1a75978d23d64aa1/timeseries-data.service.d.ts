import { HttpClient } from '@angular/common/http';
import * as moment from 'moment-timezone';
import { OpcQualityService } from './opc-quality.service';
import { Observable } from 'rxjs';
import { ICommunicationConfig } from './config';
import { identifier, IResponse } from './shared';
import { BaseService } from './base.service';
export interface ITimeseriesValuesResponseVqts {
    v: string | number | boolean;
    q: number;
    t: string;
}
export interface ITimeseriesValuesResponse extends IResponse {
    values: ITimeseriesValuesResponseVqts[];
}
export interface ITimeseriesResponse {
    timePeriod: ITimePeriodResponse;
    results: ITimeseriesValuesResponse[];
}
export declare type TimeseriesResponse = ITimeseriesResponse;
export interface ITimePeriodResponse {
    start: string;
    end: string;
    duration: number;
}
export interface ITimePeriod {
    start?: Date | moment.Moment;
    end?: Date | moment.Moment;
    duration?: number;
}
export declare enum TimeseriesRequestQuality {
    includeGood = 1,
    includeBad = 2,
    includeUncertain = 4,
    includeAll = 7
}
export declare enum TimeseriesRepeatedDataFormat {
    wholeInterval = "wholeInterval",
    increments = "increments"
}
export declare enum SamplingTypes {
    Interpolative = "Interpolative",
    SampleAndHold = "SampleAndHold",
    Linear = "Linear",
    Total = "Total",
    Sum = "Sum",
    Average = "Average",
    TimeAverage = "TimeAverage",
    Count = "Count",
    StandardDeviation = "StandardDeviation",
    MinimumActualTime = "MinimumActualTime",
    Maximum = "Maximum",
    Start = "Start",
    End = "End",
    Delta = "Delta",
    Variance = "Variance",
    Range = "Range",
    DurationGood = "DurationGood",
    DurationBad = "DurationBad",
    PercentGood = "PercentGood",
    PercentBad = "PercentBad",
    WorstQuality = "WorstQuality",
    TimeAverageSampleAndHold = "TimeAverageSampleAndHold",
    TotalSampleAndHold = "TotalSampleAndHold",
    MinSampleAndHold = "MinSampleAndHold",
    MaxSampleAndHold = "MaxSampleAndHold",
    CumulativeTotal = "CumulativeTotal",
    PointsInTime = "PointsInTime"
}
export interface ISamplingDefinition {
    sliceCount?: number;
    deltaT?: number;
    samplingType: SamplingTypes;
}
export declare class TimeseriesRequest {
    private fqns;
    private timePeriod;
    private samplingDefinition?;
    private timeDeadBand?;
    private valueDeadBand?;
    private qualityFilter?;
    constructor(fqns: identifier[], timePeriod: ITimePeriod, samplingDefinition?: ISamplingDefinition, timeDeadBand?: string, valueDeadBand?: number, qualityFilter?: TimeseriesRequestQuality | number);
    addFqn(fqn: identifier): void;
    removeFqn(fqn: identifier): void;
    setFqns(fqns: identifier[]): void;
    getFqns(): string[];
    setTimePeriod(timePeriod: ITimePeriod): void;
    getTimePeriod(): ITimePeriod;
    setSamplingDefinition(samplingDefinition?: ISamplingDefinition): void;
    getSamplingDefinition(): ISamplingDefinition;
    setTimeDeadBand(timeDeadBand?: string): void;
    getTimeDeadband(): string;
    setValueDeadBand(valueDeadBand?: number): void;
    getValueDeadBand(): number;
    setQualityFilter(qualityFilter?: TimeseriesRequestQuality | number): void;
    getQualityFilter(): number;
}
export declare class TimeseriesDataService extends BaseService {
    private opcQualitySvc;
    constructor(config: ICommunicationConfig, http: HttpClient, opcQualitySvc: OpcQualityService);
    getOnce(request: TimeseriesRequest, timezone?: string): Observable<TimeseriesResponse>;
    private _getErrorObservable;
    private _applyTimezoneToVqtData;
    private _getRequestDataNextStartValues;
    private _getStartForNextRequest;
    private _filterStartResponseData;
    private _transformTimeseriesInternalResponse;
    private _filterDuplicateDataAndCut;
    private _getRepeatedlyWhole;
    private _getRepeatedlyIncrements;
    getRepeatedly(request: TimeseriesRequest, customInterval?: number, format?: TimeseriesRepeatedDataFormat, timezone?: string): Observable<TimeseriesResponse>;
}
