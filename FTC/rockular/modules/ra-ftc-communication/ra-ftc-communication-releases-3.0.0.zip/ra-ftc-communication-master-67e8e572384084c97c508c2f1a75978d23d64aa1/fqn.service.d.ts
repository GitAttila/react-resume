export declare class FqnService {
    static readonly delimiterChar = ".";
    static readonly startPartChar = "[";
    static readonly endPartChar = "]";
    static readonly escapedEndPartChar = "]]";
    private getCombinedNameParts;
    private unescapeRawPart;
    private escape;
    private requiresEscaping;
    private relativeFqnDepth;
    getLastPart(fqn: string): string;
    removeLastPart(fqn: string): string;
    areEqual(fqn1: string, fqn2: string): boolean;
    splitFqn(fqn: string): string[];
    buildFqn(parts: string[]): string;
    buildFqnWithEscaping(parts: string[]): string;
    appendNamePart(baseName: string, part: string): string;
    appendNameParts(baseName: string, parts: string[]): string;
    isRelative(fqn: any): boolean;
    absoluteToRelative(anchorFqn: string, fqn: string): string;
    relativeToAbsolute(anchorFqn: string, relativeFqn: string): string;
}
