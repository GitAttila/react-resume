import { InjectionToken } from '@angular/core';
import { NavigationRules } from './shared';
export interface ICommonHttpConfig {
    withCredentials: boolean;
}
export interface INavigationRules {
    hideRules?: NavigationRules;
    skipRules?: NavigationRules;
}
export declare const DEFAULT_REPEATED_DATA_INTERVAL = 5;
export interface ICommunicationConfig {
    baseUrl: string;
    defaultRepeatedDataInterval?: number;
    defaultNavigationRules?: INavigationRules;
    httpOptions?: ICommonHttpConfig;
}
export declare type CONFIG_TYPE = ICommunicationConfig;
export declare const COMMUNICATION_CONFIG: InjectionToken<ICommunicationConfig>;
