import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICommunicationConfig } from './config';
export declare class BaseService {
    protected relativeApiEndpoint: string;
    protected config: ICommunicationConfig;
    protected http: HttpClient;
    constructor(relativeApiEndpoint: string, config: ICommunicationConfig, http: HttpClient);
    readonly endpointUrl: string;
    protected _sendPostRequest(request: any): Observable<any>;
    protected _sendGetRequest(url?: string, extraHttpOptions?: any): Observable<any>;
}
