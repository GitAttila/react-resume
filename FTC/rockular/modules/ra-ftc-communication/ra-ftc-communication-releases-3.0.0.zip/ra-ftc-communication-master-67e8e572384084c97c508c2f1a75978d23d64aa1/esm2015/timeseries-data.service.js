import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { OpcQualityService } from './opc-quality.service';
import { Observable, timer } from 'rxjs';
import { map, concatMap, expand } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
import { MomentHelperService } from './moment-helper.service';
export function ITimeseriesValuesResponseVqts() { }
if (false) {
    ITimeseriesValuesResponseVqts.prototype.v;
    ITimeseriesValuesResponseVqts.prototype.q;
    ITimeseriesValuesResponseVqts.prototype.t;
}
export function ITimeseriesValuesResponse() { }
if (false) {
    ITimeseriesValuesResponse.prototype.values;
}
export function ITimeseriesResponse() { }
if (false) {
    ITimeseriesResponse.prototype.timePeriod;
    ITimeseriesResponse.prototype.results;
}
function ITimeseriesValuesResponseInternalObject() { }
if (false) {
    ITimeseriesValuesResponseInternalObject.prototype.fqn;
    ITimeseriesValuesResponseInternalObject.prototype.name;
    ITimeseriesValuesResponseInternalObject.prototype.engineeringUnit;
    ITimeseriesValuesResponseInternalObject.prototype.valueType;
    ITimeseriesValuesResponseInternalObject.prototype.values;
}
export function ITimePeriodResponse() { }
if (false) {
    ITimePeriodResponse.prototype.start;
    ITimePeriodResponse.prototype.end;
    ITimePeriodResponse.prototype.duration;
}
function ITimeseriesValuesResponseInternal() { }
if (false) {
    ITimeseriesValuesResponseInternal.prototype.timePeriod;
    ITimeseriesValuesResponseInternal.prototype.fqnsResults;
    ITimeseriesValuesResponseInternal.prototype.queryResults;
}
export function ITimePeriod() { }
if (false) {
    ITimePeriod.prototype.start;
    ITimePeriod.prototype.end;
    ITimePeriod.prototype.duration;
}
const TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
export { TimeseriesRequestQuality };
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = 'includeGood';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = 'includeBad';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = 'includeUncertain';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = 'includeAll';
const TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
export { TimeseriesRepeatedDataFormat };
const SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
    PointsInTime: 'PointsInTime',
};
export { SamplingTypes };
export function ISamplingDefinition() { }
if (false) {
    ISamplingDefinition.prototype.sliceCount;
    ISamplingDefinition.prototype.deltaT;
    ISamplingDefinition.prototype.samplingType;
}
export class TimeseriesRequest {
    constructor(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
    setFqns(fqns) {
        this.fqns = _.clone(fqns);
    }
    getFqns() {
        return _.clone(this.fqns);
    }
    setTimePeriod(timePeriod) {
        this.timePeriod = _.clone(timePeriod);
    }
    getTimePeriod() {
        return _.clone(this.timePeriod);
    }
    setSamplingDefinition(samplingDefinition) {
        this.samplingDefinition = _.clone(samplingDefinition);
    }
    getSamplingDefinition() {
        return _.clone(this.samplingDefinition);
    }
    setTimeDeadBand(timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    }
    getTimeDeadband() {
        return this.timeDeadBand;
    }
    setValueDeadBand(valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    }
    getValueDeadBand() {
        return this.valueDeadBand;
    }
    setQualityFilter(qualityFilter) {
        this.qualityFilter = qualityFilter;
    }
    getQualityFilter() {
        return this.qualityFilter;
    }
}
if (false) {
    TimeseriesRequest.prototype.fqns;
    TimeseriesRequest.prototype.timePeriod;
    TimeseriesRequest.prototype.samplingDefinition;
    TimeseriesRequest.prototype.timeDeadBand;
    TimeseriesRequest.prototype.valueDeadBand;
    TimeseriesRequest.prototype.qualityFilter;
}
export class TimeseriesDataService extends BaseService {
    constructor(config, http, opcQualitySvc) {
        super('/api/1/timeseries/', config, http);
        this.opcQualitySvc = opcQualitySvc;
    }
    getOnce(request, timezone) {
        let tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        return this._sendPostRequest(request).pipe(map((response) => this._transformTimeseriesInternalResponse(response, tz)));
    }
    _getErrorObservable(errorString) {
        return new Observable((observer) => {
            observer.error(errorString);
            return () => {
                observer.unsubscribe();
            };
        });
    }
    _applyTimezoneToVqtData(vqtData, timezone) {
        _.each(vqtData, (vqt) => {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    }
    _getRequestDataNextStartValues(response, nextStartMoment) {
        const beforeNextRequestValues = new Map();
        let last;
        _.each(response.fqnsResults, (el) => {
            if (!_.isNil(el) && el.values.length) {
                last = _.last(el.values);
                beforeNextRequestValues.set(el.fqn, last);
            }
        });
        return beforeNextRequestValues;
    }
    _getStartForNextRequest(response, originalDuration, repeatedInterval) {
        const opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            const timeString = _.first(fqnResult.values).t;
            for (let i = fqnResult.values.length - 1; i >= 0; i--) {
                const val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        let result;
        const currentTimeMinusDuration = moment.utc().subtract(Math.abs(originalDuration), 'seconds');
        _.each(response.fqnsResults, (fqnResult) => {
            if (_.isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            const lastValue = moment.utc(getLastTimeToUse(fqnResult));
            if (_.isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (_.isNil(result)) {
            result = moment.utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    }
    _filterStartResponseData(response, previousResponseLastData, requestTimePeriod) {
        let firstVqt;
        let firstVqtMoment;
        let secondVqt;
        const opcQualitySvc = this.opcQualitySvc;
        const cutBeforeDate = moment.utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        _.each(response.fqnsResults, (el) => {
            if (!_.isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                const onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                const onePreviousResponseLastDataMoment = moment.utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = moment.utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < moment.utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    }
    _transformTimeseriesInternalResponse(response, timezone) {
        let applyTimezone = false;
        if (!_.isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        const ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        _.each(response.fqnsResults, (oneResult) => {
            if (_.isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    }
    _filterDuplicateDataAndCut(values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        const ids = [];
        let objectToAddToArray;
        let firstIsAfter = false;
        function arrayFilter(o) {
            const currentItemMoment = moment.utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = _.clone(o);
                    const cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!_.isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        const filteredArray = values.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            const lastValue = _.last(filteredArray);
            if (!lastValue || !moment.utc(lastValue.t).isSame(moment.utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    }
    _getRepeatedlyWhole(request, customInterval, timezone) {
        let lastMergedResponse;
        const tz = timezone;
        const repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map((response) => {
            if (!_.isNil(lastMergedResponse)) {
                const requestTimePeriod = request.getTimePeriod();
                const cutBeforeDate = moment.utc(response.timePeriod.end);
                cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                const cutBeforeDateUTCFormat = cutBeforeDate.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!_.isNil(tz)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        moment.utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                _.each(lastMergedResponse.results, (result) => {
                    const newResults = _.find(response.results, { fqn: result.fqn });
                    if (!_.isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = _.sortBy(result.values, [(o) => {
                                return moment.utc(o.t);
                            }]);
                        result.values = this._filterDuplicateDataAndCut(result.values, cutBeforeDate, false, tz);
                    }
                });
                _.each(response.results, (newResult) => {
                    if (!_.find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    }
    _getRepeatedlyIncrements(request, customInterval, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        let lastResponseData;
        let repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        const lastRepeatedRequest = _.clone(request);
        const originalDuration = requestTimePeriod.duration;
        let nextRequestStartMoment;
        const repeatedDataObservable = this._sendPostRequest(request).pipe(map((response) => {
            nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return this._transformTimeseriesInternalResponse(response, timezone);
        }));
        const expandedObservable = repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => {
            if (!_.isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(_.extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return this._sendPostRequest(lastRepeatedRequest).pipe(map((response) => {
                if (lastResponseData.size > 0) {
                    this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return this._transformTimeseriesInternalResponse(response, timezone);
            }));
        }))));
        return expandedObservable;
    }
    getRepeatedly(request, customInterval, format, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        if (!_.isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (_.isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        let tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        if (_.isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz);
        }
    }
}
TimeseriesDataService.decorators = [
    { type: Injectable }
];
TimeseriesDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient },
    { type: OpcQualityService }
];
if (false) {
    TimeseriesDataService.prototype.opcQualitySvc;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXNlcmllcy1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsidGltZXNlcmllcy1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ2xELE9BQU8sS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sS0FBSyxNQUFNLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDMUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDekMsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDeEQsT0FBTyxFQUFFLG9CQUFvQixFQUF3Qiw4QkFBOEIsRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUV0RyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFHOUQsbURBSUM7O0lBSEcsMENBQTZCO0lBQzdCLDBDQUFVO0lBQ1YsMENBQVU7O0FBSWQsK0NBRUM7O0lBREcsMkNBQXdDOztBQUk1Qyx5Q0FHQzs7SUFGRyx5Q0FBZ0M7SUFDaEMsc0NBQXFDOztBQU16QyxzREFNQzs7SUFMRyxzREFBWTtJQUNaLHVEQUFjO0lBQ2Qsa0VBQXlCO0lBQ3pCLDREQUFtQjtJQUNuQix5REFBd0M7O0FBSTVDLHlDQUlDOztJQUhHLG9DQUFjO0lBQ2Qsa0NBQVk7SUFDWix1Q0FBaUI7O0FBSXJCLGdEQUlDOztJQUhHLHVEQUFnQztJQUNoQyx3REFBd0Q7SUFDeEQseURBQXlEOztBQUk3RCxpQ0FJQzs7SUFIRyw0QkFBNkI7SUFDN0IsMEJBQTJCO0lBQzNCLCtCQUFrQjs7O0lBSWxCLGNBQWU7SUFDZixhQUFjO0lBQ2QsbUJBQW9CO0lBQ3BCLGFBQWM7Ozs7Ozs7O0lBSWQsZUFBZ0IsZUFBZTtJQUMvQixZQUFhLFlBQVk7Ozs7SUFJekIsZUFBZ0IsZUFBZTtJQUMvQixlQUFnQixlQUFlO0lBQy9CLFFBQVMsUUFBUTtJQUNqQixPQUFRLE9BQU87SUFDZixLQUFNLEtBQUs7SUFDWCxTQUFVLFNBQVM7SUFDbkIsYUFBYyxhQUFhO0lBQzNCLE9BQVEsT0FBTztJQUNmLG1CQUFvQixtQkFBbUI7SUFDdkMsbUJBQW9CLG1CQUFtQjtJQUN2QyxTQUFVLFNBQVM7SUFDbkIsT0FBUSxPQUFPO0lBQ2YsS0FBTSxLQUFLO0lBQ1gsT0FBUSxPQUFPO0lBQ2YsVUFBVyxVQUFVO0lBQ3JCLE9BQVEsT0FBTztJQUNmLGNBQWUsY0FBYztJQUM3QixhQUFjLGFBQWE7SUFDM0IsYUFBYyxhQUFhO0lBQzNCLFlBQWEsWUFBWTtJQUN6QixjQUFlLGNBQWM7SUFDN0IsMEJBQTJCLDBCQUEwQjtJQUNyRCxvQkFBcUIsb0JBQW9CO0lBQ3pDLGtCQUFtQixrQkFBa0I7SUFDckMsa0JBQW1CLGtCQUFrQjtJQUNyQyxpQkFBa0IsaUJBQWlCO0lBQ25DLGNBQWUsY0FBYzs7O0FBR2pDLHlDQVVDOztJQVBHLHlDQUFvQjtJQUlwQixxQ0FBZ0I7SUFFaEIsMkNBQTRCOztBQUdoQyxNQUFNLE9BQU8saUJBQWlCO0lBZTFCLFlBQ1ksSUFBa0IsRUFDbEIsVUFBdUIsRUFDdkIsa0JBQXdDLEVBQ3hDLFlBQXFCLEVBQ3JCLGFBQXNCLEVBQ3RCLGFBQWlEO1FBTGpELFNBQUksR0FBSixJQUFJLENBQWM7UUFDbEIsZUFBVSxHQUFWLFVBQVUsQ0FBYTtRQUN2Qix1QkFBa0IsR0FBbEIsa0JBQWtCLENBQXNCO1FBQ3hDLGlCQUFZLEdBQVosWUFBWSxDQUFTO1FBQ3JCLGtCQUFhLEdBQWIsYUFBYSxDQUFTO1FBQ3RCLGtCQUFhLEdBQWIsYUFBYSxDQUFvQztRQUV6RCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDbkQsQ0FBQztJQU1ELE1BQU0sQ0FBQyxHQUFlO1FBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFNRCxTQUFTLENBQUMsR0FBZTtjQUNmLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO1FBQ3ZDLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRTtZQUNYLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFNRCxPQUFPLENBQUMsSUFBa0I7UUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFLRCxPQUFPO1FBQ0gsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBTUQsYUFBYSxDQUFDLFVBQXVCO1FBQ2pDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBS0QsYUFBYTtRQUNULE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQU1ELHFCQUFxQixDQUFDLGtCQUF3QztRQUMxRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFLRCxxQkFBcUI7UUFDakIsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFNRCxlQUFlLENBQUMsWUFBcUI7UUFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7SUFDckMsQ0FBQztJQUtELGVBQWU7UUFDWCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDN0IsQ0FBQztJQU1ELGdCQUFnQixDQUFDLGFBQXNCO1FBQ25DLElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBQ3ZDLENBQUM7SUFLRCxnQkFBZ0I7UUFDWixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDOUIsQ0FBQztJQU1ELGdCQUFnQixDQUFDLGFBQWlEO1FBQzlELElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0lBQ3ZDLENBQUM7SUFLRCxnQkFBZ0I7UUFDWixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDOUIsQ0FBQztDQUNKOztJQXhITyxpQ0FBMEI7SUFDMUIsdUNBQStCO0lBQy9CLCtDQUFnRDtJQUNoRCx5Q0FBNkI7SUFDN0IsMENBQThCO0lBQzlCLDBDQUF5RDs7QUF5SGpFLE1BQU0sT0FBTyxxQkFBc0IsU0FBUSxXQUFXO0lBRWxELFlBQ2tDLE1BQTRCLEVBQzFELElBQWdCLEVBQVUsYUFBZ0M7UUFDMUQsS0FBSyxDQUFDLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQURoQixrQkFBYSxHQUFiLGFBQWEsQ0FBbUI7SUFFOUQsQ0FBQztJQWVELE9BQU8sQ0FBQyxPQUEwQixFQUFFLFFBQWlCO1lBQzdDLEVBQVU7UUFDZCxJQUFJLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMvQyxFQUFFLEdBQUcsUUFBUSxDQUFDO1NBQ2pCO1FBQ0QsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQTJDLEVBQUUsRUFBRSxDQUMzRixJQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBTU8sbUJBQW1CLENBQUMsV0FBbUI7UUFDM0MsT0FBTyxJQUFJLFVBQVUsQ0FBcUIsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUNuRCxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzVCLE9BQU8sR0FBRyxFQUFFO2dCQUNSLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMzQixDQUFDLENBQUM7UUFDTixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFPTyx1QkFBdUIsQ0FBQyxPQUF3QyxFQUFFLFFBQVE7UUFDOUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFrQyxFQUFFLEVBQUU7WUFDbkQsR0FBRyxDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFNTyw4QkFBOEIsQ0FBQyxRQUEyQyxFQUFFLGVBQThCO2NBRXhHLHVCQUF1QixHQUFxQixJQUFJLEdBQUcsRUFBRTtZQUN2RCxJQUFtQztRQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRTtZQUNoQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDbEMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN6Qix1QkFBdUIsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM3QztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyx1QkFBdUIsQ0FBQztJQUNuQyxDQUFDO0lBS08sdUJBQXVCLENBQzNCLFFBQTJDLEVBQUUsZ0JBQXdCLEVBQUUsZ0JBQXdCO2NBQ3pGLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYTtRQUN4QyxTQUFTLGdCQUFnQixDQUFDLFNBQWtEO2tCQUNsRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUU5QyxLQUFLLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO3NCQUM3QyxHQUFHLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUN6QyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ2hCO2FBQ0o7WUFFRCxPQUFPLFVBQVUsQ0FBQztRQUN0QixDQUFDO1lBRUcsTUFBcUI7Y0FDbkIsd0JBQXdCLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsU0FBUyxDQUFDO1FBRTdGLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsRUFBRSxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBRXJELE9BQU87YUFDVjtrQkFDSyxTQUFTLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN6RCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDOUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUM5QjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBRWpCLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3hGO1FBRUQsSUFBSSx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDMUMsTUFBTSxHQUFHLHdCQUF3QixDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUNuRjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFNTyx3QkFBd0IsQ0FDNUIsUUFBMkMsRUFDM0Msd0JBQW9FLEVBQUUsaUJBQThCO1lBQ2hHLFFBQVE7WUFDUixjQUFjO1lBQ2QsU0FBUztjQUNQLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYTtjQUNsQyxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztRQUN6RCxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDeEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUU7WUFDaEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7c0JBQ3hFLDJCQUEyQixHQUFHLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO3NCQUNsRSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztnQkFDbkYsUUFBUSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzdDLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksY0FBYyxHQUFHLGlDQUFpQzt3QkFDbEQsY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzt3QkFDeEMsYUFBYSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUM7d0JBQ25ELGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNuQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQzFCO2lCQUNKO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxvQ0FBb0MsQ0FBQyxRQUEyQyxFQUFFLFFBQWlCO1lBQ25HLGFBQWEsR0FBRyxLQUFLO1FBRXpCLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBRXBCLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFFckIsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ25HLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztTQUNsRztjQUVLLEdBQUcsR0FBdUI7WUFDNUIsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVO1lBQy9CLE9BQU8sRUFBRSxFQUFFO1NBQ2Q7UUFFRCxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRTtZQUN2QyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBRXBCLE9BQU87YUFDVjtZQUVELElBQUksYUFBYSxFQUFFO2dCQUNmLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQzVEO1lBRUQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO2dCQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7Z0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztnQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO2dCQUMxQyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU07YUFDM0IsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFLTywwQkFBMEIsQ0FDOUIsTUFBdUMsRUFBRSxlQUE4QixFQUN2RSxvQkFBOEIsRUFBRSxRQUFpQjtjQUMzQyxHQUFHLEdBQWtCLEVBQUU7WUFDekIsa0JBQWlEO1lBQ2pELFlBQVksR0FBRyxLQUFLO1FBRXhCLFNBQVMsV0FBVyxDQUFDLENBQWdDO2tCQUMzQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQ2Ysa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzswQkFDMUIsd0JBQXdCLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQywrQkFBK0IsQ0FBQztvQkFDNUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3BCLGtCQUFrQixDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ2hHO3lCQUFNO3dCQUNILGtCQUFrQixDQUFDLENBQUMsR0FBRyx3QkFBd0IsQ0FBQztxQkFDbkQ7b0JBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQztpQkFDdkI7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDaEI7WUFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN6QixPQUFPLEtBQUssQ0FBQzthQUNoQjtZQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2QsT0FBTyxJQUFJLENBQUM7UUFDaEIsQ0FBQztjQUNLLGFBQWEsR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUMxRCxJQUFJLENBQUMsb0JBQW9CLElBQUksWUFBWSxFQUFFO2tCQUNqQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7WUFDdkMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBRWpGLGFBQWEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUMxQztTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkMsQ0FBQztJQU9PLG1CQUFtQixDQUFDLE9BQTBCLEVBQUUsY0FBdUIsRUFBRSxRQUFpQjtZQUMxRixrQkFBc0M7Y0FDcEMsRUFBRSxHQUFHLFFBQVE7Y0FFYixhQUFhLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDO2FBQ2pGLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUE0QixFQUFFLEVBQUU7WUFDdkMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsRUFBRTtzQkFDeEIsaUJBQWlCLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRTtzQkFDM0MsYUFBYSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7Z0JBQ3pELGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztzQkFDbEUsc0JBQXNCLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQywrQkFBK0IsQ0FBQztnQkFFeEcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUU7b0JBQ2Qsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3BHLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7aUJBQy9EO3FCQUFNO29CQUNILGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsc0JBQXNCLENBQUM7b0JBQzdELGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHO3dCQUM3QixNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7aUJBQ3ZHO2dCQUVELENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUU7MEJBQ3BDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUNoRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRTt3QkFDdEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBRXhELE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFnQyxFQUFFLEVBQUU7Z0NBQzFFLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRUosTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUM1RjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFFSCxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRTtvQkFDbkMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFO3dCQUM3RCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM5QztnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPLGtCQUFrQixDQUFDO2FBQzdCO2lCQUFNO2dCQUNILGtCQUFrQixHQUFHLFFBQVEsQ0FBQztnQkFDOUIsT0FBTyxRQUFRLENBQUM7YUFDbkI7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNQLE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFPTyx3QkFBd0IsQ0FDNUIsT0FBMEIsRUFBRSxjQUF1QixFQUFFLFFBQWlCO2NBRWhFLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUU7WUFFN0MsZ0JBQWtDO1lBQ2xDLGdCQUFnQixHQUFHLGNBQWMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLDJCQUEyQixJQUFJLDhCQUE4QjtRQUNsSCxnQkFBZ0IsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7Y0FFckMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Y0FDdEMsZ0JBQWdCLEdBQUcsaUJBQWlCLENBQUMsUUFBUTtZQUMvQyxzQkFBcUM7Y0FFbkMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUEyQyxFQUFFLEVBQUU7WUFDbkgsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBS3BHLGdCQUFnQixHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztZQUN6RixPQUFPLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDekUsQ0FBQyxDQUFDLENBQUM7Y0FDRyxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQ2xELE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNyRCxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO2dCQUNsQyxtQkFBbUIsQ0FBQyxhQUFhLENBQzdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUMvRztZQUNELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQTJDLEVBQUUsRUFBRTtnQkFDdkcsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFO29CQUkzQixJQUFJLENBQUMsd0JBQXdCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDLENBQUM7aUJBQ2hGO2dCQUNELHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFLcEcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO2dCQUN6RixPQUFPLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDekUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDUDtRQUNELE9BQU8sa0JBQWtCLENBQUM7SUFDOUIsQ0FBQztJQW9CRCxhQUFhLENBQUMsT0FBMEIsRUFBRSxjQUF1QixFQUFFLE1BQXFDLEVBQUUsUUFBaUI7Y0FHakgsaUJBQWlCLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRTtRQUNqRCxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNuQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx5REFBeUQ7a0JBQ25GLGtFQUFrRTtrQkFDbEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVEO2FBQU0sSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUU7WUFDOUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixvREFBb0Q7a0JBQ3BELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtZQUVHLEVBQVU7UUFDZCxJQUFJLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMvQyxFQUFFLEdBQUcsUUFBUSxDQUFDO1NBQ2pCO1FBQ0QsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sS0FBSyw0QkFBNEIsQ0FBQyxhQUFhLEVBQUU7WUFDMUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNoRTthQUFNO1lBQ0gsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNyRTtJQUNMLENBQUM7OztZQXpYSixVQUFVOzs7NENBSUYsTUFBTSxTQUFDLG9CQUFvQjtZQXBRM0IsVUFBVTtZQUdWLGlCQUFpQjs7O0lBa1FBLDhDQUF3QyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCAqIGFzIG1vbWVudCBmcm9tICdtb21lbnQtdGltZXpvbmUnO1xyXG5pbXBvcnQgeyBPcGNRdWFsaXR5U2VydmljZSB9IGZyb20gJy4vb3BjLXF1YWxpdHkuc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCwgY29uY2F0TWFwLCBleHBhbmQgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZywgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBpZGVudGlmaWVyLCBJUmVzcG9uc2UgfSBmcm9tICcuL3NoYXJlZCc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBNb21lbnRIZWxwZXJTZXJ2aWNlIH0gZnJvbSAnLi9tb21lbnQtaGVscGVyLnNlcnZpY2UnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdnF0IHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cyB7XHJcbiAgICB2OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuO1xyXG4gICAgcTogbnVtYmVyO1xyXG4gICAgdDogc3RyaW5nO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB2cXQgbGlzdCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZSBleHRlbmRzIElSZXNwb25zZSB7XHJcbiAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1Jlc3BvbnNlIHtcclxuICAgIHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kUmVzcG9uc2U7XHJcbiAgICByZXN1bHRzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlW107XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIFRpbWVzZXJpZXNSZXNwb25zZSA9IElUaW1lc2VyaWVzUmVzcG9uc2U7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBpbnRlcm5hbCBvYmplY3Qgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0IHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmFtZT86IHN0cmluZztcclxuICAgIGVuZ2luZWVyaW5nVW5pdD86IHN0cmluZztcclxuICAgIHZhbHVlVHlwZT86IHN0cmluZztcclxuICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdGltZSBwZXJpb2Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lUGVyaW9kUmVzcG9uc2Uge1xyXG4gICAgc3RhcnQ6IHN0cmluZztcclxuICAgIGVuZDogc3RyaW5nO1xyXG4gICAgZHVyYXRpb246IG51bWJlcjtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgaW50ZXJuYWwgKHJhdykgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsIHtcclxuICAgIHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kUmVzcG9uc2U7XHJcbiAgICBmcW5zUmVzdWx0cz86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG4gICAgcXVlcnlSZXN1bHRzPzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlcXVlc3QgdGltZSBwZXJpb2Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lUGVyaW9kIHtcclxuICAgIHN0YXJ0PzogRGF0ZSB8IG1vbWVudC5Nb21lbnQ7XHJcbiAgICBlbmQ/OiBEYXRlIHwgbW9tZW50Lk1vbWVudDtcclxuICAgIGR1cmF0aW9uPzogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkge1xyXG4gICAgaW5jbHVkZUdvb2QgPSAxLFxyXG4gICAgaW5jbHVkZUJhZCA9IDIsXHJcbiAgICBpbmNsdWRlVW5jZXJ0YWluID0gNCxcclxuICAgIGluY2x1ZGVBbGwgPSA3XHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQge1xyXG4gICAgd2hvbGVJbnRlcnZhbCA9ICd3aG9sZUludGVydmFsJyxcclxuICAgIGluY3JlbWVudHMgPSAnaW5jcmVtZW50cydcclxufVxyXG5cclxuZXhwb3J0IGVudW0gU2FtcGxpbmdUeXBlcyB7XHJcbiAgICBJbnRlcnBvbGF0aXZlID0gJ0ludGVycG9sYXRpdmUnLFxyXG4gICAgU2FtcGxlQW5kSG9sZCA9ICdTYW1wbGVBbmRIb2xkJyxcclxuICAgIExpbmVhciA9ICdMaW5lYXInLFxyXG4gICAgVG90YWwgPSAnVG90YWwnLFxyXG4gICAgU3VtID0gJ1N1bScsXHJcbiAgICBBdmVyYWdlID0gJ0F2ZXJhZ2UnLFxyXG4gICAgVGltZUF2ZXJhZ2UgPSAnVGltZUF2ZXJhZ2UnLFxyXG4gICAgQ291bnQgPSAnQ291bnQnLFxyXG4gICAgU3RhbmRhcmREZXZpYXRpb24gPSAnU3RhbmRhcmREZXZpYXRpb24nLFxyXG4gICAgTWluaW11bUFjdHVhbFRpbWUgPSAnTWluaW11bUFjdHVhbFRpbWUnLFxyXG4gICAgTWF4aW11bSA9ICdNYXhpbXVtJyxcclxuICAgIFN0YXJ0ID0gJ1N0YXJ0JyxcclxuICAgIEVuZCA9ICdFbmQnLFxyXG4gICAgRGVsdGEgPSAnRGVsdGEnLFxyXG4gICAgVmFyaWFuY2UgPSAnVmFyaWFuY2UnLFxyXG4gICAgUmFuZ2UgPSAnUmFuZ2UnLFxyXG4gICAgRHVyYXRpb25Hb29kID0gJ0R1cmF0aW9uR29vZCcsXHJcbiAgICBEdXJhdGlvbkJhZCA9ICdEdXJhdGlvbkJhZCcsXHJcbiAgICBQZXJjZW50R29vZCA9ICdQZXJjZW50R29vZCcsXHJcbiAgICBQZXJjZW50QmFkID0gJ1BlcmNlbnRCYWQnLFxyXG4gICAgV29yc3RRdWFsaXR5ID0gJ1dvcnN0UXVhbGl0eScsXHJcbiAgICBUaW1lQXZlcmFnZVNhbXBsZUFuZEhvbGQgPSAnVGltZUF2ZXJhZ2VTYW1wbGVBbmRIb2xkJyxcclxuICAgIFRvdGFsU2FtcGxlQW5kSG9sZCA9ICdUb3RhbFNhbXBsZUFuZEhvbGQnLFxyXG4gICAgTWluU2FtcGxlQW5kSG9sZCA9ICdNaW5TYW1wbGVBbmRIb2xkJyxcclxuICAgIE1heFNhbXBsZUFuZEhvbGQgPSAnTWF4U2FtcGxlQW5kSG9sZCcsXHJcbiAgICBDdW11bGF0aXZlVG90YWwgPSAnQ3VtdWxhdGl2ZVRvdGFsJyxcclxuICAgIFBvaW50c0luVGltZSA9ICdQb2ludHNJblRpbWUnXHJcbn1cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgc2FtcGxpbmcgZGVmaW5pdGlvbi4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJU2FtcGxpbmdEZWZpbml0aW9uIHtcclxuICAgIC8qKiBUaGUgbnVtYmVyIG9mIHRoZSBzbGljZXMgdGhhdCB0aGUgcHJvdmlkZWQgdGltZSBwZXJpb2Qgc2hvdWxkIGJlIGN1dCBpbnRvLlxyXG4gICAgICogSWYgemVybyB0aGVuIGEgbm9uLXplcm8gRGVsdGFUIHZhbHVlIG5lZWRzIHRvIGJlIHByb3ZpZGVkLiAqL1xyXG4gICAgc2xpY2VDb3VudD86IG51bWJlcjtcclxuICAgIC8qKiBJZiB0aGUgc2xpY2UgY291bnQgaXMgemVybywgdGhlbiBhIG5vbi16ZXJvIHZhbHVlIHJlcHJlc2VudGluZyB0aGUgd2lkdGggb2YgYSB0aW1lIHNsaWNlIGluIHNlY29uZHNcclxuICAgICAqIG11c3QgYmUgcHJvdmlkZWQuIEEgcG9zaXRpdmUgdmFsdWUgbWVhbnMgdGhlIHNsaWNlcyBhcmUgYW5jaG9yZWQgYXQgdGhlIHN0YXJ0IHRpbWUgb2YgdGhlIHJlcXVlc3RlZCB0aW1lIHBlcmlvZC5cclxuICAgICAqIEEgbmVnYXRpdmUgdmFsdWUgaW5kaWNhdGVzIGFuY2hvcmluZyBhdCB0aGUgZW5kIG9mIHRoZSB0aW1lIHBlcmlvZC4gKi9cclxuICAgIGRlbHRhVD86IG51bWJlcjtcclxuICAgIC8qKiBPbmUgb2YgdGhlIHNhbXBsaW5nIHR5cGVzIHN1cHBvcnRlZCBieSB0aGUgdGltZXNlcmllcy4gU2VlIFNhbXBsaW5nVHlwZXMgZW51bS4gKi9cclxuICAgIHNhbXBsaW5nVHlwZTogU2FtcGxpbmdUeXBlcztcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFRpbWVzZXJpZXNSZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogVGltZXNlcmllcyByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFucyBMaXN0IG9mIGZxbnMgKGlkZW50aWZpY2F0b3JzKSB0byBiZSB1c2VkIGZvciByZXF1ZXN0XHJcbiAgICAgKiBAcGFyYW0gdGltZVBlcmlvZCBTZXR0aW5ncyBmb3IgdGltZSBwZXJpb2Qgb2YgdGltZXNlcmllcyByZXF1ZXN0LCBlLmcuIHN0YXJ0IHRpbWUsIGVuZCB0aW1lIGFuZCBkdXJhdGlvblxyXG4gICAgICogQHBhcmFtIHNhbXBsaW5nRGVmaW5pdGlvbiAoT3B0aW9uYWwpIGRlZmluaXRpb24gZm9yIHRpbWVzZXJpZXMgdG8gc2V0IGhvdyB0byBwcm9jZXNzIGRhdGEsIHdoaWNoIFNhbXBsaW5nIHR5cGUgdG8gdXNlXHJcbiAgICAgKiBAcGFyYW0gdGltZURlYWRCYW5kIChPcHRpb25hbCkgU2V0dGluZ3MgZm9yIHRpbWUgZGVhZGJhbmQgLSBwb3NzaWJsZSBzdHJ1Y3R1cmUgW3dzXVstXSBkIHwgZC5oaDptbVs6c3NbLmZmXV0gfCBoaDptbVs6c3NbLmZmXV0gW3dzXVxyXG4gICAgICogQHBhcmFtIHZhbHVlRGVhZEJhbmQgKE9wdGlvbmFsKSBTcGVjaWZpZXMgdGhlIHZhbHVlIGRlYWQgYmFuZCwgY2FuIGJlIGFueSBmbG9hdCBudW1iZXIuXHJcbiAgICAgKiBAcGFyYW0gcXVhbGl0eUZpbHRlciAoT3B0aW9uYWwpIFRoaXMgaXMgYSBiaXQgZmxhZyB2YWx1ZSB3aXRoIHRoZSBmb2xsb3dpbmcgb3B0aW9uczpcclxuICAgICAqIEluY2x1ZGVHb29kIDogMVxyXG4gICAgICogSW5jbHVkZUJhZCA6IDJcclxuICAgICAqIEluY2x1ZGVVbmNlcnRhaW4gOiA0XHJcbiAgICAgKiBJbmNsdWRlQWxsIDogN1xyXG4gICAgICogVXNlIGEgdmFsdWUgZnJvbSBwcmVkZWZpbmVkIGVudW0gVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IG9yIHNwZWNpZnkgYSB2YWxsdWUuXHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgZnFuczogaWRlbnRpZmllcltdLFxyXG4gICAgICAgIHByaXZhdGUgdGltZVBlcmlvZDogSVRpbWVQZXJpb2QsXHJcbiAgICAgICAgcHJpdmF0ZSBzYW1wbGluZ0RlZmluaXRpb24/OiBJU2FtcGxpbmdEZWZpbml0aW9uLFxyXG4gICAgICAgIHByaXZhdGUgdGltZURlYWRCYW5kPzogc3RyaW5nLFxyXG4gICAgICAgIHByaXZhdGUgdmFsdWVEZWFkQmFuZD86IG51bWJlcixcclxuICAgICAgICBwcml2YXRlIHF1YWxpdHlGaWx0ZXI/OiBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgfCBudW1iZXJcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuc2V0RnFucyhmcW5zKTtcclxuICAgICAgICB0aGlzLnNldFRpbWVQZXJpb2QodGltZVBlcmlvZCk7XHJcbiAgICAgICAgdGhpcy5zZXRTYW1wbGluZ0RlZmluaXRpb24oc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBvbmUgZnFuIHRvIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIGFkZFxyXG4gICAgICovXHJcbiAgICBhZGRGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zLnB1c2goZnFuKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbW92ZSBvbmUgZnFuIGZyb20gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IF8uaW5kZXhPZih0aGlzLmZxbnMsIGZxbik7XHJcbiAgICAgICAgaWYgKGluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmZxbnMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZXBsYWNlIGN1cnJlbnQgZnFucyBpbiByZXF1ZXN0IHRvIG5ldyBvbmVzLlxyXG4gICAgICogQHBhcmFtIGZxbnMgbGlzdCBvZiBmcW4gaWRlbnRpZmljYXRvcnMgdG8gc2V0XHJcbiAgICAgKi9cclxuICAgIHNldEZxbnMoZnFuczogaWRlbnRpZmllcltdKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zID0gXy5jbG9uZShmcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBmcW4gaWRlbnRpZmljYXRvcnMuXHJcbiAgICAgKi9cclxuICAgIGdldEZxbnMoKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy5mcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCByZXF1ZXN0IHRpbWUgcGVyaW9kLlxyXG4gICAgICogQHBhcmFtIHRpbWVQZXJpb2RcclxuICAgICAqL1xyXG4gICAgc2V0VGltZVBlcmlvZCh0aW1lUGVyaW9kOiBJVGltZVBlcmlvZCkge1xyXG4gICAgICAgIHRoaXMudGltZVBlcmlvZCA9IF8uY2xvbmUodGltZVBlcmlvZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgcmVxdWVzdCB0aW1lIHBlcmlvZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VGltZVBlcmlvZCgpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLnRpbWVQZXJpb2QpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHNhbXBsaW5nIGRlZmluaXRpb24uXHJcbiAgICAgKiBAcGFyYW0gc2FtcGxpbmdEZWZpbml0aW9uXHJcbiAgICAgKi9cclxuICAgIHNldFNhbXBsaW5nRGVmaW5pdGlvbihzYW1wbGluZ0RlZmluaXRpb24/OiBJU2FtcGxpbmdEZWZpbml0aW9uKSB7XHJcbiAgICAgICAgdGhpcy5zYW1wbGluZ0RlZmluaXRpb24gPSBfLmNsb25lKHNhbXBsaW5nRGVmaW5pdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3Qgc2FtcGxpbmcgZGVmaW5pdGlvbi5cclxuICAgICAqL1xyXG4gICAgZ2V0U2FtcGxpbmdEZWZpbml0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMuc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCB0aW1lIGRlYWRiYW5kLlxyXG4gICAgICogQHBhcmFtIHRpbWVEZWFkQmFuZFxyXG4gICAgICovXHJcbiAgICBzZXRUaW1lRGVhZEJhbmQodGltZURlYWRCYW5kPzogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy50aW1lRGVhZEJhbmQgPSB0aW1lRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgdGltZSBkZWFkYmFuZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VGltZURlYWRiYW5kKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnRpbWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCB2YWx1ZSBkZWFkYmFuZC5cclxuICAgICAqIEBwYXJhbSB2YWx1ZURlYWRCYW5kXHJcbiAgICAgKi9cclxuICAgIHNldFZhbHVlRGVhZEJhbmQodmFsdWVEZWFkQmFuZD86IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMudmFsdWVEZWFkQmFuZCA9IHZhbHVlRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgdmFsdWUgZGVhZGJhbmQuXHJcbiAgICAgKi9cclxuICAgIGdldFZhbHVlRGVhZEJhbmQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudmFsdWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCBxdWFsaXR5IGZpbHRlci5cclxuICAgICAqIEBwYXJhbSBxdWFsaXR5RmlsdGVyXHJcbiAgICAgKi9cclxuICAgIHNldFF1YWxpdHlGaWx0ZXIocXVhbGl0eUZpbHRlcj86IFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB8IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMucXVhbGl0eUZpbHRlciA9IHF1YWxpdHlGaWx0ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgcXVhbGl0eSBmaWx0ZXIuXHJcbiAgICAgKi9cclxuICAgIGdldFF1YWxpdHlGaWx0ZXIoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucXVhbGl0eUZpbHRlcjtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFRoaXMgc2VydmljZSBwcm92aWRlcyBhIHNldCBvZiBtZXRob2RzIGZvciBzZW5kaW5nIHJlcXVlc3RzIHRvIG9idGFpbiB0aW1lc2VyaWVzIGRhdGEuXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZyxcclxuICAgICAgICBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIG9wY1F1YWxpdHlTdmM6IE9wY1F1YWxpdHlTZXJ2aWNlKSB7XHJcbiAgICAgICAgc3VwZXIoJy9hcGkvMS90aW1lc2VyaWVzLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gc2VydmVyLCBidXQgb25seSBvbmNlLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSB0aW1lem9uZSB0byBhcHBseSB0byB0aW1lc2VyaWVzIHJlc3BvbnNlIGRhdGEsIG9ubHkgbW9tZW50IHRpbWV6b25lcyBhcmUgc3VwcG9ydGVkXHJcbiAgICAgKiBJZiB3b3JraW5nIHdpdGggdGltZXpvbmUgaW4gZGF0ZXRpbWUgc3RyaW5nIGl0IGlzIHJlY29tbWVuZGVkIHRvIHVzZSBtb21lbnQucGFyc2Vab25lIHRvIHByZXNlcnZlIHRpbWV6b25lIGluZm9ybWF0aW9uLlxyXG4gICAgICogTW9tZW50IHRpbWV6b25lcyB0aGF0IHN0YXJ0IHdpdGggXCJFdGMvR01UXCIgdXNlIFBPU0lYLXN0eWxlIHNpZ25zIGluIHRoZSBab25lIG5hbWVzIGFuZCB0aGUgb3V0cHV0IGFiYnJldmlhdGlvbnMsXHJcbiAgICAgKiBldmVuIHRob3VnaCB0aGlzIGlzIHRoZSBvcHBvc2l0ZSBvZiB3aGF0IG1hbnkgcGVvcGxlIGV4cGVjdC5cclxuICAgICAqIFBPU0lYIGhhcyBwb3NpdGl2ZSBzaWducyB3ZXN0IG9mIEdyZWVud2ljaCwgYnV0IG1hbnkgcGVvcGxlIGV4cGVjdFxyXG4gICAgICogcG9zaXRpdmUgc2lnbnMgZWFzdCBvZiBHcmVlbndpY2guICBGb3IgZXhhbXBsZSwgVFo9J0V0Yy9HTVQrNCcgdXNlc1xyXG4gICAgICogdGhlIGFiYnJldmlhdGlvbiBcIkdNVCs0XCIgYW5kIGNvcnJlc3BvbmRzIHRvIDQgaG91cnMgYmVoaW5kIFVUXHJcbiAgICAgKiAoaS5lLiB3ZXN0IG9mIEdyZWVud2ljaCkgZXZlbiB0aG91Z2ggbWFueSBwZW9wbGUgd291bGQgZXhwZWN0IGl0IHRvXHJcbiAgICAgKiBtZWFuIDQgaG91cnMgYWhlYWQgb2YgVVQgKGkuZS4gZWFzdCBvZiBHcmVlbndpY2gpLlxyXG4gICAgICovXHJcbiAgICBnZXRPbmNlKHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgbGV0IHR6OiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKE1vbWVudEhlbHBlclNlcnZpY2UuaXNWYWxpZFRpbWV6b25lKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICB0eiA9IHRpbWV6b25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PlxyXG4gICAgICAgICAgICB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdHopKSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gcmV0dXJuIGFuIG9ic2VydmFibGUgd2hpY2ggaW1tZWRpYXRlbGx5IGVycm9ycyBvdXQgd2l0aCBnaXZlbiBlcnJvciBzdHJpbmcuXHJcbiAgICAgKiBAcGFyYW0gZXJyb3JTdHJpbmdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0RXJyb3JPYnNlcnZhYmxlKGVycm9yU3RyaW5nOiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+KChvYnNlcnZlcikgPT4ge1xyXG4gICAgICAgICAgICBvYnNlcnZlci5lcnJvcihlcnJvclN0cmluZyk7XHJcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIGFwcGx5IHRpbWV6b25lIHRvIHdob2xlXHJcbiAgICAgKiBAcGFyYW0gdnF0RGF0YSBsaXN0IG9mIFZRVCBkYXRhXHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgdGltZXpvbmUgc3RyaW5nXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2FwcGx5VGltZXpvbmVUb1ZxdERhdGEodnF0RGF0YTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXSwgdGltZXpvbmUpIHtcclxuICAgICAgICBfLmVhY2godnF0RGF0YSwgKHZxdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpID0+IHtcclxuICAgICAgICAgICAgdnF0LnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUodnF0LnQsIHRpbWV6b25lKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gdnF0RGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBnZXQgZmlyc3QgdmFsdWUgYmVmb3JlIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIGluIGN1cnJlbnQgZGF0YS5cclxuICAgICAqXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIG5leHRTdGFydE1vbWVudDogbW9tZW50Lk1vbWVudCk6XHJcbiAgICAgICAgTWFwPHN0cmluZywgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM+IHtcclxuICAgICAgICBjb25zdCBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlczogTWFwPHN0cmluZywgYW55PiA9IG5ldyBNYXAoKTtcclxuICAgICAgICBsZXQgbGFzdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM7XHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZWwpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGVsKSAmJiBlbC52YWx1ZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBsYXN0ID0gXy5sYXN0KGVsLnZhbHVlcyk7XHJcbiAgICAgICAgICAgICAgICBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlcy5zZXQoZWwuZnFuLCBsYXN0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXRzIHN0YXJ0IHRpbWUgZm9yIG5leHQgcmVxdWVzdCB3aGVuIGdldHRpbmcgZGF0YSByZXBlYXRlZGx5LlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRTdGFydEZvck5leHRSZXF1ZXN0KFxyXG4gICAgICAgIHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIG9yaWdpbmFsRHVyYXRpb246IG51bWJlciwgcmVwZWF0ZWRJbnRlcnZhbDogbnVtYmVyKTogbW9tZW50Lk1vbWVudCB7XHJcbiAgICAgICAgY29uc3Qgb3BjUXVhbGl0eVN2YyA9IHRoaXMub3BjUXVhbGl0eVN2YztcclxuICAgICAgICBmdW5jdGlvbiBnZXRMYXN0VGltZVRvVXNlKGZxblJlc3VsdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0KTogc3RyaW5nIHtcclxuICAgICAgICAgICAgY29uc3QgdGltZVN0cmluZyA9IF8uZmlyc3QoZnFuUmVzdWx0LnZhbHVlcykudDtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSBmcW5SZXN1bHQudmFsdWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBmcW5SZXN1bHQudmFsdWVzW2ldO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFvcGNRdWFsaXR5U3ZjLmlzSGRhSW50ZXJwb2xhdGVkKHZhbC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWwudDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHRpbWVTdHJpbmc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVzdWx0OiBtb21lbnQuTW9tZW50O1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbiA9IG1vbWVudC51dGMoKS5zdWJ0cmFjdChNYXRoLmFicyhvcmlnaW5hbER1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuXHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZnFuUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKGZxblJlc3VsdCkgfHwgZnFuUmVzdWx0LnZhbHVlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIC8vIG5vIHRpbWVzZXJpZXMgZGF0YVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IGxhc3RWYWx1ZSA9IG1vbWVudC51dGMoZ2V0TGFzdFRpbWVUb1VzZShmcW5SZXN1bHQpKTtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwocmVzdWx0KSB8fCByZXN1bHQuaXNBZnRlcihsYXN0VmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBsYXN0VmFsdWUuY2xvbmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoXy5pc05pbChyZXN1bHQpKSB7XHJcbiAgICAgICAgICAgIC8vIG5vIGdvb2QgcXVhbGl0eSAtIGFkZCBwZXJpb2QgdG8gcmVzcG9uc2Ugc3RhcnQgdGltZSAtIGFzIGRlZmF1bHQgZm9yIG5leHQgcmVxdWVzdFxyXG4gICAgICAgICAgICByZXN1bHQgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQpLmFkZChyZXBlYXRlZEludGVydmFsLCAnbWlsbGlzZWNvbmRzJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoY3VycmVudFRpbWVNaW51c0R1cmF0aW9uLmlzQWZ0ZXIocmVzdWx0KSkge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBjdXJyZW50VGltZU1pbnVzRHVyYXRpb24uY2xvbmUoKS5hZGQocmVwZWF0ZWRJbnRlcnZhbCwgJ21pbGxpc2Vjb25kcycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICogRnVuY3Rpb24gdG8gb3B0aW9uYWxseSBmaWx0ZXIgZmlyc3QgdmFsdWUgaW4gcmVwZWF0ZWQgcmVxdWVzdCB3aGVuIGl0IGlzIGludGVycG9sYXRlZCBiZXR3ZWVuXHJcbiAgICAqIHR3byBnb29kL2JhZCBvbmVzLiBEaXJlY3RseSBtb2RpZmllcyByZXNwb25zZSBpbnB1dCBwYXJhbWV0ZXIuXHJcbiAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZmlsdGVyU3RhcnRSZXNwb25zZURhdGEoXHJcbiAgICAgICAgcmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCxcclxuICAgICAgICBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGE6IE1hcDxzdHJpbmcsIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzPiwgcmVxdWVzdFRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kKSB7XHJcbiAgICAgICAgbGV0IGZpcnN0VnF0O1xyXG4gICAgICAgIGxldCBmaXJzdFZxdE1vbWVudDtcclxuICAgICAgICBsZXQgc2Vjb25kVnF0O1xyXG4gICAgICAgIGNvbnN0IG9wY1F1YWxpdHlTdmMgPSB0aGlzLm9wY1F1YWxpdHlTdmM7XHJcbiAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZSA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpO1xyXG4gICAgICAgIGN1dEJlZm9yZURhdGUuc3VidHJhY3QoTWF0aC5hYnMocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGVsKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghXy5pc05pbChlbCkgJiYgcHJldmlvdXNSZXNwb25zZUxhc3REYXRhLmhhcyhlbC5mcW4pICYmIGVsLnZhbHVlcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEgPSBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEuZ2V0KGVsLmZxbik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGFNb21lbnQgPSBtb21lbnQudXRjKG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS50KTtcclxuICAgICAgICAgICAgICAgIGZpcnN0VnF0ID0gZWwudmFsdWVzLnNsaWNlKDAsIDEpWzBdO1xyXG4gICAgICAgICAgICAgICAgZmlyc3RWcXRNb21lbnQgPSBtb21lbnQudXRjKGZpcnN0VnF0LnQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKG9wY1F1YWxpdHlTdmMuaXNIZGFJbnRlcnBvbGF0ZWQoZmlyc3RWcXQucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZWNvbmRWcXQgPSBlbC52YWx1ZXMuc2xpY2UoMSwgMilbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VnF0TW9tZW50ID4gb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhTW9tZW50ICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpcnN0VnF0TW9tZW50IDwgbW9tZW50LnV0YyhzZWNvbmRWcXQudCkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3BjUXVhbGl0eVN2Yy5pc0dvb2Qob25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhLnEpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wY1F1YWxpdHlTdmMuaXNHb29kKHNlY29uZFZxdC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbC52YWx1ZXMuc3BsaWNlKDAsIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIHRpbWV6b25lPzogc3RyaW5nKTogVGltZXNlcmllc1Jlc3BvbnNlIHtcclxuICAgICAgICBsZXQgYXBwbHlUaW1lem9uZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICBpZiAoIV8uaXNOaWwodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIC8vIHdlIGRvIGhhdmUgdGltZXpvbmVcclxuICAgICAgICAgICAgYXBwbHlUaW1lem9uZSA9IHRydWU7XHJcbiAgICAgICAgICAgIC8vIGFwcGx5IHRpbWV6b25lIGFsc28gdG8gcmVzcG9uc2UgdGltZSBwZXJpb2QgdG8gbWF0Y2ggZGF0YVxyXG4gICAgICAgICAgICByZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgcmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUocmVzcG9uc2UudGltZVBlcmlvZC5lbmQsIHRpbWV6b25lKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJldDogVGltZXNlcmllc1Jlc3BvbnNlID0ge1xyXG4gICAgICAgICAgICB0aW1lUGVyaW9kOiByZXNwb25zZS50aW1lUGVyaW9kLFxyXG4gICAgICAgICAgICByZXN1bHRzOiBbXVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKG9uZVJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChvbmVSZXN1bHQpKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBubyB0aW1lc2VyaWVzIGRhdGFcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFwcGx5VGltZXpvbmUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FwcGx5VGltZXpvbmVUb1ZxdERhdGEob25lUmVzdWx0LnZhbHVlcywgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXQucmVzdWx0cy5wdXNoKHtcclxuICAgICAgICAgICAgICAgIG5hbWU6IG9uZVJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgZnFuOiBvbmVSZXN1bHQuZnFuLFxyXG4gICAgICAgICAgICAgICAgdmFsdWVUeXBlOiBvbmVSZXN1bHQudmFsdWVUeXBlLFxyXG4gICAgICAgICAgICAgICAgZW5naW5lZXJpbmdVbml0OiBvbmVSZXN1bHQuZW5naW5lZXJpbmdVbml0LFxyXG4gICAgICAgICAgICAgICAgdmFsdWVzOiBvbmVSZXN1bHQudmFsdWVzXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBGdW5jdGlvbiB0byBmaWx0ZXIgbm90IG5lZWRlZCBkYXRhIGFuZCBkdXBsaWNhdGUgZGF0YS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZmlsdGVyRHVwbGljYXRlRGF0YUFuZEN1dChcclxuICAgICAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW10sIGN1dEJlZm9yZU1vbWVudDogbW9tZW50Lk1vbWVudCxcclxuICAgICAgICBkb05vdFNoaWZ0Rmlyc3RWYWx1ZT86IGJvb2xlYW4sIHRpbWV6b25lPzogc3RyaW5nKSB7XHJcbiAgICAgICAgY29uc3QgaWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgbGV0IG9iamVjdFRvQWRkVG9BcnJheTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM7XHJcbiAgICAgICAgbGV0IGZpcnN0SXNBZnRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBhcnJheUZpbHRlcihvOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykge1xyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50SXRlbU1vbWVudCA9IG1vbWVudC51dGMoby50KTtcclxuICAgICAgICAgICAgaWYgKGN1dEJlZm9yZU1vbWVudC5pc0FmdGVyKGN1cnJlbnRJdGVtTW9tZW50KSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFmaXJzdElzQWZ0ZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkgPSBfLmNsb25lKG8pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdCA9IGN1dEJlZm9yZU1vbWVudC5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheS50ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdCwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheS50ID0gY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBmaXJzdElzQWZ0ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpZHMuaW5kZXhPZihvLnQpICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlkcy5wdXNoKG8udCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBmaWx0ZXJlZEFycmF5ID0gdmFsdWVzLnJldmVyc2UoKS5maWx0ZXIoYXJyYXlGaWx0ZXIpO1xyXG4gICAgICAgIGlmICghZG9Ob3RTaGlmdEZpcnN0VmFsdWUgJiYgZmlyc3RJc0FmdGVyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxhc3RWYWx1ZSA9IF8ubGFzdChmaWx0ZXJlZEFycmF5KTtcclxuICAgICAgICAgICAgaWYgKCFsYXN0VmFsdWUgfHwgIW1vbWVudC51dGMobGFzdFZhbHVlLnQpLmlzU2FtZShtb21lbnQudXRjKG9iamVjdFRvQWRkVG9BcnJheS50KSkpIHtcclxuICAgICAgICAgICAgICAgIC8vIGl0IGlzIHJldmVyc2VkIGFycmF5IHNvIHB1c2ggdG8gaXRcclxuICAgICAgICAgICAgICAgIGZpbHRlcmVkQXJyYXkucHVzaChvYmplY3RUb0FkZFRvQXJyYXkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZEFycmF5LnJldmVyc2UoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdHMgcmVwZWF0ZWRseSBhbmQgcmV0dXJuIGFsbCBkYXRhIGluIGdpdmVuIHJlcXVlc3QgaW50ZXJ2YWwgKGJ5IGR1cmF0aW9uLCBzdGFydCBhbmQvb3IgZW5kIHRpbWUpLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBpbnRlcnZhbCBpbiBzZWNvbmRzXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcGVhdGVkbHlXaG9sZShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICBsZXQgbGFzdE1lcmdlZFJlc3BvbnNlOiBUaW1lc2VyaWVzUmVzcG9uc2U7XHJcbiAgICAgICAgY29uc3QgdHogPSB0aW1lem9uZTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwZWF0ZWRseU9icyA9IHRoaXMuX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0aW1lem9uZSlcclxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogVGltZXNlcmllc1Jlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobGFzdE1lcmdlZFJlc3BvbnNlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZSA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGN1dEJlZm9yZURhdGUuc3VidHJhY3QoTWF0aC5hYnMocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGVVVENGb3JtYXQgPSBjdXRCZWZvcmVEYXRlLmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwodHopKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKGN1dEJlZm9yZURhdGVVVENGb3JtYXQsIHR6KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID0gcmVzcG9uc2UudGltZVBlcmlvZC5lbmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBjdXRCZWZvcmVEYXRlVVRDRm9ybWF0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCkuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBfLmVhY2gobGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMsIChyZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3UmVzdWx0cyA9IF8uZmluZChyZXNwb25zZS5yZXN1bHRzLCB7IGZxbjogcmVzdWx0LmZxbiB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKG5ld1Jlc3VsdHMpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gcmVzdWx0LnZhbHVlcy5jb25jYXQobmV3UmVzdWx0cy52YWx1ZXMpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSBfLnNvcnRCeShyZXN1bHQudmFsdWVzLCBbKG86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1vbWVudC51dGMoby50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1dKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gdGhpcy5fZmlsdGVyRHVwbGljYXRlRGF0YUFuZEN1dChyZXN1bHQudmFsdWVzLCBjdXRCZWZvcmVEYXRlLCBmYWxzZSwgdHopO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gYWRkIGFueSBuZXcgZnFucyBkYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgXy5lYWNoKHJlc3BvbnNlLnJlc3VsdHMsIChuZXdSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmZpbmQobGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMsIHsgZnFuOiBuZXdSZXN1bHQuZnFuIH0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cy5wdXNoKG5ld1Jlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbGFzdE1lcmdlZFJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UgPSByZXNwb25zZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICByZXR1cm4gcmVwZWF0ZWRseU9icztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdHMgcmVwZWF0ZWRseSBhbmQgcmV0dXJuIGRhdGEgYXMgaW5jcmVtZW50cy5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgaW50ZXJ2YWwgaW4gc2Vjb25kc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhcclxuICAgICAgICByZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuXHJcbiAgICAgICAgbGV0IGxhc3RSZXNwb25zZURhdGE6IE1hcDxzdHJpbmcsIGFueT47XHJcbiAgICAgICAgbGV0IHJlcGVhdGVkSW50ZXJ2YWwgPSBjdXN0b21JbnRlcnZhbCB8fCB0aGlzLmNvbmZpZy5kZWZhdWx0UmVwZWF0ZWREYXRhSW50ZXJ2YWwgfHwgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMO1xyXG4gICAgICAgIHJlcGVhdGVkSW50ZXJ2YWwgPSByZXBlYXRlZEludGVydmFsICogMTAwMDtcclxuXHJcbiAgICAgICAgY29uc3QgbGFzdFJlcGVhdGVkUmVxdWVzdCA9IF8uY2xvbmUocmVxdWVzdCk7XHJcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxEdXJhdGlvbiA9IHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uO1xyXG4gICAgICAgIGxldCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50OiBtb21lbnQuTW9tZW50O1xyXG5cclxuICAgICAgICBjb25zdCByZXBlYXRlZERhdGFPYnNlcnZhYmxlID0gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQgPSB0aGlzLl9nZXRTdGFydEZvck5leHRSZXF1ZXN0KHJlc3BvbnNlLCBvcmlnaW5hbER1cmF0aW9uLCByZXBlYXRlZEludGVydmFsKTtcclxuICAgICAgICAgICAgLy8gd2UgcmVtZW1iZXIgbGFzdCB2YWx1ZSBiZWZvcmUgbmV4dFN0YXJ0IGluIGN1cnJlbnQgcmVxdWVzdCB0byBjaGVjayBpdHNcclxuICAgICAgICAgICAgLy8gcXVhbGl0eSB2cy4gbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgdmFsdWUgcXVhbGl0eSwgcG9zc2libHlcclxuICAgICAgICAgICAgLy8gdG8gb21pdCBzdGFydCB2YWx1ZVxyXG4gICAgICAgICAgICAvLyAtIGl0IG1heSBiZSBpbnRlcnBvbGF0ZWQgYmV0d2VlbiB0d28gZ29vZCBxdWFsaXR5IHZhbHVlc1xyXG4gICAgICAgICAgICBsYXN0UmVzcG9uc2VEYXRhID0gdGhpcy5fZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2UsIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHRpbWV6b25lKTtcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgY29uc3QgZXhwYW5kZWRPYnNlcnZhYmxlID0gcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZS5waXBlKFxyXG4gICAgICAgICAgICBleHBhbmQoKCkgPT4gdGltZXIocmVwZWF0ZWRJbnRlcnZhbCkucGlwZShjb25jYXRNYXAoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdFJlcGVhdGVkUmVxdWVzdC5zZXRUaW1lUGVyaW9kKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfLmV4dGVuZChsYXN0UmVwZWF0ZWRSZXF1ZXN0LmdldFRpbWVQZXJpb2QoKSwgeyBkdXJhdGlvbjogMCwgc3RhcnQ6IG5leHRSZXF1ZXN0U3RhcnRNb21lbnQudG9EYXRlKCkgfSkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChsYXN0UmVwZWF0ZWRSZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsYXN0UmVzcG9uc2VEYXRhLnNpemUgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdlIGNoZWNrIHByZXZpb3VzIHZhbHVlcyB0byBjdXJyZW50IHN0YXJ0aW5nIG9uZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gZmlsdGVyIG91dCBwb3NzaWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdGFydCBpbnRlcnBvbGF0ZWQgb25lcyBpZiB0aGV5IGFyZSBiZXR3ZWVuIGdvb2Qgb25lc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9maWx0ZXJTdGFydFJlc3BvbnNlRGF0YShyZXNwb25zZSwgbGFzdFJlc3BvbnNlRGF0YSwgcmVxdWVzdFRpbWVQZXJpb2QpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50ID0gdGhpcy5fZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChyZXNwb25zZSwgb3JpZ2luYWxEdXJhdGlvbiwgcmVwZWF0ZWRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gd2UgcmVtZW1iZXIgbGFzdCB2YWx1ZSBiZWZvcmUgbmV4dFN0YXJ0IGluIGN1cnJlbnQgcmVxdWVzdCB0byBjaGVjayBpdHNcclxuICAgICAgICAgICAgICAgICAgICAvLyBxdWFsaXR5IHZzLiBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSB2YWx1ZSBxdWFsaXR5LCBwb3NzaWJseVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRvIG9taXQgc3RhcnQgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAvLyAtIGl0IG1heSBiZSBpbnRlcnBvbGF0ZWQgYmV0d2VlbiB0d28gZ29vZCBxdWFsaXR5IHZhbHVlc1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RSZXNwb25zZURhdGEgPSB0aGlzLl9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZSwgbmV4dFJlcXVlc3RTdGFydE1vbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH0pKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIHJldHVybiBleHBhbmRlZE9ic2VydmFibGU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCByZXF1ZXN0IGZvciB0aW1lc2VyaWVzIGRhdGEgcmVwZWF0ZWRseS4gSXQgcmVwZWF0ZWRseSBzZW5kcyByZXF1ZXN0cyB0byBzZXJ2ZXIuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGN1c3RvbSBpbnRlcnZhbCBmb3IgcmVwZWF0ZWQgZGF0YSwgaW4gc2Vjb25kc1xyXG4gICAgICogQHBhcmFtIGZvcm1hdCAoT3B0aW9uYWwpIGZvcm1hdCBmb3IgcmVwZWF0ZWQgZGF0YSByZXNwb25zZVxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIChPcHRpb25hbCkgU2V0IHRoZSB0aW1lem9uZSB0byBhcHBseSB0byBkYXRldGltZSBzdHJpbmdzIGZvciB0aW1lc2VyaWVzIHJlc3BvbnNlIGRhdGEuXHJcbiAgICAgKiBSZXR1cm5lZCBkYXRlIHN0cmluZ3MgYXJlIGluIG1heGltdW0gamF2YXNjcmlwdCByZXNvbHV0aW9uIHBvc3NpYmxlXHJcbiAgICAgKiBzdXBwb3J0ZWQgYnkgdXNpbmcgbW9tZW50IGxpYnJhcnkgKEphdmFzY3JpcHQgZGF0ZSAtIG1pbGxpc2Vjb25kcykuXHJcbiAgICAgKiBSZXNvbHV0aW9uIGZvciB0aW1lIGFmdGVyIG1pbGxpc2Vjb25kcyB3aWxsIGJlIGxvc3QuXHJcbiAgICAgKiBJZiB3b3JraW5nIHdpdGggdGltZXpvbmUgaW4gZGF0ZXRpbWUgc3RyaW5nIGl0IGlzIHJlY29tbWVuZGVkIHRvIHVzZSBtb21lbnQucGFyc2Vab25lIHRvIHByZXNlcnZlIHRpbWV6b25lIGluZm9ybWF0aW9uLlxyXG4gICAgICogTW9tZW50IHRpbWV6b25lcyB0aGF0IHN0YXJ0IHdpdGggXCJFdGMvR01UXCIgdXNlIFBPU0lYLXN0eWxlIHNpZ25zIGluIHRoZSBab25lIG5hbWVzIGFuZCB0aGUgb3V0cHV0IGFiYnJldmlhdGlvbnMsXHJcbiAgICAgKiBldmVuIHRob3VnaCB0aGlzIGlzIHRoZSBvcHBvc2l0ZSBvZiB3aGF0IG1hbnkgcGVvcGxlIGV4cGVjdC5cclxuICAgICAqIFBPU0lYIGhhcyBwb3NpdGl2ZSBzaWducyB3ZXN0IG9mIEdyZWVud2ljaCwgYnV0IG1hbnkgcGVvcGxlIGV4cGVjdFxyXG4gICAgICogcG9zaXRpdmUgc2lnbnMgZWFzdCBvZiBHcmVlbndpY2guICBGb3IgZXhhbXBsZSwgVFo9J0V0Yy9HTVQrNCcgdXNlc1xyXG4gICAgICogdGhlIGFiYnJldmlhdGlvbiBcIkdNVCs0XCIgYW5kIGNvcnJlc3BvbmRzIHRvIDQgaG91cnMgYmVoaW5kIFVUXHJcbiAgICAgKiAoaS5lLiB3ZXN0IG9mIEdyZWVud2ljaCkgZXZlbiB0aG91Z2ggbWFueSBwZW9wbGUgd291bGQgZXhwZWN0IGl0IHRvXHJcbiAgICAgKiBtZWFuIDQgaG91cnMgYWhlYWQgb2YgVVQgKGkuZS4gZWFzdCBvZiBHcmVlbndpY2gpLlxyXG4gICAgICovXHJcbiAgICBnZXRSZXBlYXRlZGx5KHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgZm9ybWF0PzogVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdCwgdGltZXpvbmU/OiBzdHJpbmcpOlxyXG4gICAgICAgIE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHJlcXVlc3RUaW1lUGVyaW9kLnN0YXJ0KSkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0RXJyb3JPYnNlcnZhYmxlKCdUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZ2V0UmVwZWF0ZWRseTogQXJndW1lbnQgZXhjZXB0aW9uJ1xyXG4gICAgICAgICAgICAgICAgKyAnIC0gUmVxdWVzdCBzdGFydCB0aW1lIGNhbm5vdCBiZSBzZXQgZm9yIHJlcGVhdGVkIGRhdGEgKHJlcXVlc3Q6ICdcclxuICAgICAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkocmVxdWVzdCkgKyAnIGNhbm5vdCBiZSBwcm9jZXNzZWQuJyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChfLmlzTmlsKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSB8fCByZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEVycm9yT2JzZXJ2YWJsZSgnVGltZXNlcmllc0RhdGFTZXJ2aWNlIGdldFJlcGVhdGVkbHk6IEFyZ3VtZW50IGV4Y2VwdGlvbidcclxuICAgICAgICAgICAgICAgICsgJyAtIFJlcXVlc3QgZHVyYXRpb24gaGF2ZSB0byBiZSBuZWdhdGl2ZSAocmVxdWVzdDogJ1xyXG4gICAgICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KSArICcgY2Fubm90IGJlIHByb2Nlc3NlZC4nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB0ejogc3RyaW5nO1xyXG4gICAgICAgIGlmIChNb21lbnRIZWxwZXJTZXJ2aWNlLmlzVmFsaWRUaW1lem9uZSh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgdHogPSB0aW1lem9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF8uaXNOaWwoZm9ybWF0KSB8fCBmb3JtYXQgPT09IFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQud2hvbGVJbnRlcnZhbCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UmVwZWF0ZWRseVdob2xlKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0eik7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0eik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==