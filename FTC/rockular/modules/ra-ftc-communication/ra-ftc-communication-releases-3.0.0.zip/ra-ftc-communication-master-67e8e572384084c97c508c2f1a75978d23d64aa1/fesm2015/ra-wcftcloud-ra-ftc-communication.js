import { CommonModule } from '@angular/common';
import { Observable, Subject, timer } from 'rxjs';
import { utc, tz } from 'moment-timezone';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { InjectionToken, Inject, Injectable, NgModule } from '@angular/core';
import { map, expand, concatMap } from 'rxjs/operators';
import { isString, isNil, extend, isEmpty, clone, values, some, indexOf, each, filter, sumBy, last, first, find, sortBy } from 'lodash';

const DEFAULT_REPEATED_DATA_INTERVAL = 5;
const COMMUNICATION_CONFIG = new InjectionToken('COMMUNICATION_CONFIGURATION');

class BaseService {
    constructor(relativeApiEndpoint, config, http) {
        this.relativeApiEndpoint = relativeApiEndpoint;
        this.config = config;
        this.http = http;
    }
    get endpointUrl() {
        return this.config.baseUrl + this.relativeApiEndpoint;
    }
    _sendPostRequest(request) {
        return this.http.post(this.endpointUrl, request, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
    }
    _sendGetRequest(url, extraHttpOptions = {}) {
        const httpOptions = extend(extraHttpOptions, this.config.httpOptions);
        const endpointUrl = !isEmpty(url) ? url : this.endpointUrl;
        return this.http.get(endpointUrl, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, httpOptions));
    }
}

class InstanceService extends BaseService {
    constructor(config, http) {
        super('/api/1/instance/', config, http);
    }
    getInstances(instanceRequest) {
        return this._sendPostRequest(instanceRequest);
    }
}
InstanceService.decorators = [
    { type: Injectable }
];
InstanceService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];
class InstanceRequest {
    constructor(camelCasePropertyNames) {
        if (!isNil(camelCasePropertyNames)) {
            this.camelCasePropertyNames = camelCasePropertyNames;
        }
        else {
            this.camelCasePropertyNames = true;
        }
    }
    addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts) {
        instanceFqnItem.responseFormat = {};
        if (includeAccessControl) {
            instanceFqnItem.responseFormat.includeAcl = includeAccessControl;
        }
        if (!isNil(retrievalDepth) && retrievalDepth > 0) {
            instanceFqnItem.responseFormat.depth = retrievalDepth;
        }
        if (includeShortcuts) {
            instanceFqnItem.responseFormat.includeShortcuts = includeShortcuts;
        }
    }
    addItemFqn(fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceFqnItem = {
            fqn: fqn
        };
        ((this)).addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnItem);
        return ((this));
    }
    addItemFqnExcludeVolatile(fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceFqnItem = {
            fqn: fqn,
            excludeVolatileProperties: true
        };
        ((this)).addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnItem);
        return ((this));
    }
    addPropertyFqn(fqn, includeAccessControl, retrievalDepth, includeShortcuts, pageSize, page) {
        const instanceFqnPropertyItem = {
            propertyFqn: fqn,
            excludeVolatileProperties: true
        };
        ((this)).addResponseFormat(instanceFqnPropertyItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!isNil(pageSize)) {
            instanceFqnPropertyItem.pageSize = pageSize;
        }
        if (!isNil(page)) {
            instanceFqnPropertyItem.page = page;
        }
        if (!((this)).fqns) {
            ((this)).fqns = [];
        }
        ((this)).fqns.push(instanceFqnPropertyItem);
        return ((this));
    }
    addQuery(queryExpression, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceQueryItem = {
            query: queryExpression
        };
        ((this)).addResponseFormat(instanceQueryItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!((this)).queries) {
            ((this)).queries = [];
        }
        ((this)).queries.push(instanceQueryItem);
        return ((this));
    }
}

class LiveRequest {
    constructor(fqns) {
        this.fqns = fqns;
        this.fqns = clone(fqns);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
}
class LiveDataService extends BaseService {
    constructor(config, http) {
        super('/api/1/live/', config, http);
        this._fqns = new Map();
    }
    getOnce(request) {
        return this._sendPostRequest(request).pipe(map((response) => {
            const ret = [];
            each(response.fqnsResults, (oneResult) => {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    }
    _getInnerRepeatedObservable() {
        return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
            .pipe(map((response) => {
            const ret = [];
            each(response.fqnsResults, (oneResult) => {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    }
    _initializeRepeatedData() {
        if (!this._repeatedDataSubject) {
            this._repeatedDataSubject = new Subject();
        }
        if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
            let repeatedInterval = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval = repeatedInterval * 1000;
            this._repeatedDataObservable = this._getInnerRepeatedObservable();
            this._repeatedDataSubscription = this._repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => this._getInnerRepeatedObservable())))).subscribe((response) => {
                this._repeatedDataSubject.next(response);
            }, (err) => {
                this._repeatedDataSubscription.unsubscribe();
                this._reinitializeRepeatedObservable = true;
                this._repeatedDataSubject.error(err);
            }, () => {
                this._reinitializeRepeatedObservable = true;
                this._repeatedDataSubject.complete();
            });
            this._reinitializeRepeatedObservable = false;
        }
        return this._repeatedDataObservable;
    }
    getRepeatedly(request) {
        return new Observable((observer) => {
            each(request.fqns, (fqn) => {
                let newVal = 0;
                if (this._fqns.has(fqn)) {
                    newVal = this._fqns.get(fqn);
                }
                this._fqns.set(fqn, ++newVal);
            });
            this._initializeRepeatedData();
            const subscription = this._repeatedDataSubject.asObservable().pipe(map((currentResponse) => {
                return filter(currentResponse, (o) => {
                    return indexOf(request.fqns, o.fqn) > -1;
                });
            })).subscribe((response) => {
                observer.next(response);
            }, (error) => {
                observer.error(error);
            }, () => {
                observer.complete();
            });
            return () => {
                each(request.fqns, (fqn) => {
                    let newVal = 1;
                    if (this._fqns.has(fqn)) {
                        newVal = this._fqns.get(fqn);
                    }
                    if (newVal === 1) {
                        this._fqns.delete(fqn);
                    }
                    else {
                        this._fqns.set(fqn, --newVal);
                    }
                });
                subscription.unsubscribe();
                observer.unsubscribe();
                if (this._fqns.size === 0) {
                    if (this._repeatedDataSubscription) {
                        this._repeatedDataSubscription.unsubscribe();
                    }
                    this._repeatedDataSubject.complete();
                    delete this._repeatedDataSubject;
                    this._reinitializeRepeatedObservable = true;
                }
            };
        });
    }
}
LiveDataService.decorators = [
    { type: Injectable }
];
LiveDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];

class OpcQualityService {
    constructor() {
        this.opcDaQualityMask = 0xfffC;
        this.opcDaQualityMasterMask = 0x00C0;
        this.opcHdaQualityMask = 0xffff0000;
        this.opcDaQualityFieldMasks = {
            limitField: 0x0003,
            subStatusField: 0x003C,
            quality: 0x00C0
        };
        this.opcDaQualityMaster = {
            bad: 0x0000,
            uncertain: 0x0040,
            notDefined: 0x0080,
            good: 0x00C0
        };
        this.opcDaQualityStatus = {
            bad: 0x0000,
            configError: 0x0004,
            notConnected: 0x0008,
            deviceFailure: 0x000c,
            sensorFailure: 0x0010,
            lastKnown: 0x0014,
            commFailure: 0x0018,
            outOfService: 0x001c,
            initializing: 0x0020,
            uncertain: 0x0040,
            lastUsable: 0x0044,
            sensorNotAccurate: 0x0050,
            engUnitsExceeded: 0x0054,
            subNormal: 0x0058,
            good: 0x00C0,
            localOverride: 0x00D8
        };
        this.opcDaQualityLimit = {
            limitOk: 0x0000,
            limitLow: 0x0001,
            limitHigh: 0x0002,
            constant: 0x0003
        };
        this.opcHdaQuality = {
            extraData: 0x00010000,
            interpolated: 0x00020000,
            raw: 0x00040000,
            calculated: 0x00080000,
            noBound: 0x00100000,
            noData: 0x00200000,
            dataLost: 0x00400000,
            conversion: 0x00800000,
            partial: 0x01000000
        };
        this.overallMessages = {
            0x0000: 'Bad',
            0x0040: 'Uncertain',
            0x0080: 'Not defined',
            0x00C0: 'Good'
        };
        this.detailsMessages = {
            0x0000: 'Not limited',
            0x0001: 'Low limited',
            0x0002: 'High limited',
            0x0003: 'Constant',
            0x0004: 'Config error',
            0x0008: 'Not connected',
            0x000c: 'Device failure',
            0x0010: 'Sensor failure',
            0x0014: 'Last known',
            0x0018: 'Comm failure',
            0x001C: 'Out of service',
            0x0020: 'Initializing',
            0x0044: 'Last usable',
            0x0050: 'Sensors not accurate',
            0x0054: 'Engineering units exceeded',
            0x0058: 'Sub-Normal',
            0x00D8: 'Local override',
            0x00010000: 'Extra data',
            0x00020000: 'Interpolated',
            0x00040000: 'Raw',
            0x00080000: 'Calculated',
            0x00100000: 'No bound',
            0x00200000: 'No data',
            0x00400000: 'Data lost',
            0x00800000: 'Conversion',
            0x01000000: 'Partial'
        };
    }
    asObject(qualityAsInt) {
        let mask;
        const quality = (({}));
        mask = qualityAsInt & this.opcDaQualityMasterMask;
        quality.overall = this.overallMessages[mask];
        mask = qualityAsInt & this.opcDaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.da = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        if (mask && this.detailsMessages[mask]) {
            quality.limit = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcHdaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.hda = this.detailsMessages[mask];
        }
        return quality;
    }
    asString(qualityAsInt) {
        let hasDaQuality = false;
        const qObj = this.asObject(qualityAsInt);
        let qString;
        qString = qObj.overall;
        if (qObj.da) {
            qString = qString + ': ' + qObj.da;
            hasDaQuality = true;
        }
        if (qObj.limit) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.limit;
            hasDaQuality = true;
        }
        if (qObj.hda) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.hda;
        }
        return qString;
    }
    getOpcDaQuality(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMask;
    }
    getOpcLimitStatus(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
    }
    getSimpleQuality(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMasterMask;
    }
    getOpcHdaQuality(qualityAsInt) {
        return qualityAsInt & this.opcHdaQualityMask;
    }
    isGood(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
    }
    isUncertain(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
    }
    isBad(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
    }
    isDaConfigError(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
    }
    isDaNotConnected(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
    }
    isDaDeviceFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
    }
    isDaSensorFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
    }
    isDaLastKnown(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
    }
    isDaCommFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
    }
    isDaOutOfService(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
    }
    isDaInitializing(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
    }
    isDaLastUsable(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
    }
    isDaSensorNotAccurate(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
    }
    isDaEngUnitsExceeded(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
    }
    isDaSubNormal(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
    }
    isDaLocalOverride(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
    }
    isLimitOk(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
    }
    isLimitLow(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
    }
    isLimitHigh(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
    }
    isLimitConstant(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
    }
    isHdaExtraData(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
    }
    isHdaInterpolated(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
    }
    isHdaRaw(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
    }
    isHdaCalculated(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
    }
    isHdaNoBound(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
    }
    isHdaNoData(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
    }
    isHdaDataLost(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
    }
    isHdaConversion(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
    }
    isHdaPartial(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
    }
}
OpcQualityService.decorators = [
    { type: Injectable }
];

class MomentHelperService {
    static applyTimezone(datetime, timezone) {
        const mDate = utc(datetime);
        mDate.tz(timezone);
        return mDate.format(this.MOMENT_DATETIME_FORMAT_TZ_FULL);
    }
    static getAllTimezones() {
        return tz.names();
    }
    static isValidTimezone(timezone) {
        return timezone && tz.zone(timezone);
    }
}
MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL = 'YYYY-MM-DDTHH:mm:ss.SSS[Z]';
MomentHelperService.MOMENT_DATETIME_FORMAT_TZ_FULL = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
MomentHelperService.decorators = [
    { type: Injectable }
];

const TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = 'includeGood';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = 'includeBad';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = 'includeUncertain';
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = 'includeAll';
const TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
const SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
    PointsInTime: 'PointsInTime',
};
class TimeseriesRequest {
    constructor(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
    setFqns(fqns) {
        this.fqns = clone(fqns);
    }
    getFqns() {
        return clone(this.fqns);
    }
    setTimePeriod(timePeriod) {
        this.timePeriod = clone(timePeriod);
    }
    getTimePeriod() {
        return clone(this.timePeriod);
    }
    setSamplingDefinition(samplingDefinition) {
        this.samplingDefinition = clone(samplingDefinition);
    }
    getSamplingDefinition() {
        return clone(this.samplingDefinition);
    }
    setTimeDeadBand(timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    }
    getTimeDeadband() {
        return this.timeDeadBand;
    }
    setValueDeadBand(valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    }
    getValueDeadBand() {
        return this.valueDeadBand;
    }
    setQualityFilter(qualityFilter) {
        this.qualityFilter = qualityFilter;
    }
    getQualityFilter() {
        return this.qualityFilter;
    }
}
class TimeseriesDataService extends BaseService {
    constructor(config, http, opcQualitySvc) {
        super('/api/1/timeseries/', config, http);
        this.opcQualitySvc = opcQualitySvc;
    }
    getOnce(request, timezone) {
        let tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        return this._sendPostRequest(request).pipe(map((response) => this._transformTimeseriesInternalResponse(response, tz$$1)));
    }
    _getErrorObservable(errorString) {
        return new Observable((observer) => {
            observer.error(errorString);
            return () => {
                observer.unsubscribe();
            };
        });
    }
    _applyTimezoneToVqtData(vqtData, timezone) {
        each(vqtData, (vqt) => {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    }
    _getRequestDataNextStartValues(response, nextStartMoment) {
        const beforeNextRequestValues = new Map();
        let last$$1;
        each(response.fqnsResults, (el) => {
            if (!isNil(el) && el.values.length) {
                last$$1 = last(el.values);
                beforeNextRequestValues.set(el.fqn, last$$1);
            }
        });
        return beforeNextRequestValues;
    }
    _getStartForNextRequest(response, originalDuration, repeatedInterval) {
        const opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            const timeString = first(fqnResult.values).t;
            for (let i = fqnResult.values.length - 1; i >= 0; i--) {
                const val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        let result;
        const currentTimeMinusDuration = utc().subtract(Math.abs(originalDuration), 'seconds');
        each(response.fqnsResults, (fqnResult) => {
            if (isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            const lastValue = utc(getLastTimeToUse(fqnResult));
            if (isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (isNil(result)) {
            result = utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    }
    _filterStartResponseData(response, previousResponseLastData, requestTimePeriod) {
        let firstVqt;
        let firstVqtMoment;
        let secondVqt;
        const opcQualitySvc = this.opcQualitySvc;
        const cutBeforeDate = utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        each(response.fqnsResults, (el) => {
            if (!isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                const onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                const onePreviousResponseLastDataMoment = utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    }
    _transformTimeseriesInternalResponse(response, timezone) {
        let applyTimezone = false;
        if (!isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        const ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        each(response.fqnsResults, (oneResult) => {
            if (isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    }
    _filterDuplicateDataAndCut(values$$1, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        const ids = [];
        let objectToAddToArray;
        let firstIsAfter = false;
        function arrayFilter(o) {
            const currentItemMoment = utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = clone(o);
                    const cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        const filteredArray = values$$1.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            const lastValue = last(filteredArray);
            if (!lastValue || !utc(lastValue.t).isSame(utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    }
    _getRepeatedlyWhole(request, customInterval, timezone) {
        let lastMergedResponse;
        const tz$$1 = timezone;
        const repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map((response) => {
            if (!isNil(lastMergedResponse)) {
                const requestTimePeriod = request.getTimePeriod();
                const cutBeforeDate = utc(response.timePeriod.end);
                cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                const cutBeforeDateUTCFormat = cutBeforeDate.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!isNil(tz$$1)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz$$1);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                each(lastMergedResponse.results, (result) => {
                    const newResults = find(response.results, { fqn: result.fqn });
                    if (!isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = sortBy(result.values, [(o) => {
                                return utc(o.t);
                            }]);
                        result.values = this._filterDuplicateDataAndCut(result.values, cutBeforeDate, false, tz$$1);
                    }
                });
                each(response.results, (newResult) => {
                    if (!find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    }
    _getRepeatedlyIncrements(request, customInterval, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        let lastResponseData;
        let repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        const lastRepeatedRequest = clone(request);
        const originalDuration = requestTimePeriod.duration;
        let nextRequestStartMoment;
        const repeatedDataObservable = this._sendPostRequest(request).pipe(map((response) => {
            nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return this._transformTimeseriesInternalResponse(response, timezone);
        }));
        const expandedObservable = repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => {
            if (!isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return this._sendPostRequest(lastRepeatedRequest).pipe(map((response) => {
                if (lastResponseData.size > 0) {
                    this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return this._transformTimeseriesInternalResponse(response, timezone);
            }));
        }))));
        return expandedObservable;
    }
    getRepeatedly(request, customInterval, format, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        if (!isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        let tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        if (isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz$$1);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz$$1);
        }
    }
}
TimeseriesDataService.decorators = [
    { type: Injectable }
];
TimeseriesDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient },
    { type: OpcQualityService }
];

class OperationService extends BaseService {
    constructor(config, http) {
        super('/api/1/operation/', config, http);
    }
    getOperationData(operationReq) {
        return this._sendPostRequest(operationReq);
    }
}
OperationService.decorators = [
    { type: Injectable }
];
OperationService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];
class OperationRequest {
    constructor(target, operation, parameters) {
        this.target = target;
        this.operation = operation;
        this.parameters = parameters;
    }
}

class PersistenceService extends BaseService {
    constructor(config, http) {
        super('/api/1/persistence/', config, http);
    }
    commit(persistRequest) {
        return this._sendPostRequest(persistRequest);
    }
}
PersistenceService.decorators = [
    { type: Injectable }
];
PersistenceService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];
class PropNameValues {
    add(name, value) {
        if (name) {
            this[name] = value;
        }
    }
    remove(name) {
        if (!isNil(this[name])) {
            delete this[name];
        }
    }
    isEmpty() {
        return !some(this);
    }
}
class PersistRequest {
    createItem(parentPropertyFqn, itemType, propNameValues) {
        const createRequest = {
            parentPropertyFqn: parentPropertyFqn,
            itemType: itemType
        };
        if (propNameValues) {
            createRequest.props = propNameValues;
        }
        if (!this.newItems) {
            this.newItems = [];
        }
        this.newItems.push(createRequest);
        return this;
    }
    renameItem(itemFqn, newName) {
        this.renamedItem = {
            fqn: itemFqn,
            newName: newName
        };
        return this;
    }
    changeItem(itemFqn, propNameValues) {
        if (!propNameValues.isEmpty()) {
            const changeRequest = {
                FullyQualifiedName: itemFqn
            };
            extend(changeRequest, propNameValues);
            if (!this.changedItems) {
                this.changedItems = [];
            }
            this.changedItems.push(changeRequest);
        }
        return this;
    }
    deleteItem(itemFqn) {
        if (!this.deletedItems) {
            this.deletedItems = [];
        }
        this.deletedItems.push(itemFqn);
        return this;
    }
}

class NavigationService extends BaseService {
    constructor(config, http) {
        super('/api/1/navigation/', config, http);
    }
    getNavigationData(navigationRequest) {
        let request = navigationRequest;
        if (isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
            if (isNil(request.hideRules) && isNil(request.skipRules) && !isNil(this.config.defaultNavigationRules)) {
                const clonedRequest = clone(navigationRequest);
                if (this.config.defaultNavigationRules.skipRules) {
                    clonedRequest.skipRules = clone(this.config.defaultNavigationRules.skipRules);
                    request = clonedRequest;
                }
                if (this.config.defaultNavigationRules.hideRules) {
                    clonedRequest.hideRules = clone(this.config.defaultNavigationRules.hideRules);
                    request = clonedRequest;
                }
            }
        }
        return this._sendPostRequest(request);
    }
}
NavigationService.decorators = [
    { type: Injectable }
];
NavigationService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];
class NavigationRequest {
    constructor(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
        this.fqn = fqn;
        this.propNames = propNames;
        this.includeParents = includeParents;
        this.navHandlerFqn = navHandlerFqn;
        this.hideRules = hideRules;
        this.skipRules = skipRules;
    }
}

class SecurityContextService extends BaseService {
    constructor(config, http) {
        super('/api/1/securitycontext/', config, http);
    }
    getSecurityContextData() {
        return this._sendGetRequest();
    }
}
SecurityContextService.decorators = [
    { type: Injectable }
];
SecurityContextService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];

class MimeService extends BaseService {
    constructor(config, http) {
        super('/api/1/mime/', config, http);
    }
    getMimeItemPath(fqn) {
        return this.endpointUrl.concat(fqn);
    }
    getMimeProperty(fqn) {
        return this._sendGetRequest(this.getMimeItemPath(fqn), { responseType: 'text' });
    }
}
MimeService.decorators = [
    { type: Injectable }
];
MimeService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];

class NavigationHandlerService extends BaseService {
    constructor(config, http) {
        super('/api/1/navigationhandler/', config, http);
    }
    getNavigationHandlerData(navigationHandlerReq) {
        return this._sendPostRequest(navigationHandlerReq);
    }
}
NavigationHandlerService.decorators = [
    { type: Injectable }
];
NavigationHandlerService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] }] },
    { type: HttpClient }
];
class NavigationHandlerRequest {
    constructor(fqn, currentNavHandlerFqn, navHandlerProviderFqn) {
        this.fqn = fqn;
        this.currentNavHandlerFqn = currentNavHandlerFqn;
        this.navHandlerProviderFqn = navHandlerProviderFqn;
    }
}

class FqnService {
    getCombinedNameParts(anchorFqnParts, includedAnchorPartsCount, relativeFqnParts) {
        return anchorFqnParts.slice(0, includedAnchorPartsCount).concat(relativeFqnParts);
    }
    unescapeRawPart(rawPart) {
        let unescapedRawPart;
        if (rawPart.charAt(0) === FqnService.startPartChar) {
            if (rawPart.charAt(rawPart.length - 1) === FqnService.endPartChar) {
                unescapedRawPart = rawPart.substr(1, rawPart.length - 2);
            }
            else {
                unescapedRawPart = rawPart.substr(1);
            }
        }
        else if (rawPart.charAt(rawPart.length - 1) === FqnService.endPartChar) {
            unescapedRawPart = rawPart.substr(0, rawPart.length - 1);
        }
        if (unescapedRawPart) {
            const regex = new RegExp(FqnService.escapedEndPartChar, 'g');
            return unescapedRawPart.replace(regex, FqnService.endPartChar);
        }
        if (rawPart === FqnService.endPartChar || rawPart === FqnService.startPartChar) {
            return '';
        }
        return rawPart;
    }
    escape(part) {
        let escapedPart = FqnService.startPartChar;
        const regex = new RegExp(FqnService.endPartChar, 'g');
        escapedPart = escapedPart.concat(part.replace(regex, FqnService.escapedEndPartChar));
        return escapedPart.concat(FqnService.endPartChar);
    }
    requiresEscaping(part, checkWhitespace = false) {
        const charCount = (str, ch) => sumBy(str, (x) => x === ch ? 1 : 0);
        if (part[0] === FqnService.startPartChar && part[part.length - 1] === FqnService.endPartChar) {
            const unescapedPart = this.unescapeRawPart(part);
            if (charCount(unescapedPart, FqnService.startPartChar) === charCount(unescapedPart, FqnService.endPartChar)) {
                return false;
            }
            return true;
        }
        const basicAssumption = part.charAt(0) === FqnService.startPartChar || part.indexOf(FqnService.delimiterChar) >= 0;
        return checkWhitespace ? basicAssumption || part.indexOf(' ') >= 0 : basicAssumption;
    }
    relativeFqnDepth(relativeFqn) {
        if (relativeFqn[0] !== FqnService.delimiterChar) {
            return 0;
        }
        let depth = 0;
        while (depth < relativeFqn.length &&
            relativeFqn[depth] === FqnService.delimiterChar) {
            depth++;
        }
        return depth;
    }
    getLastPart(fqn) {
        if (this.areEqual(fqn, '')) {
            return '';
        }
        else {
            if (isString(fqn)) {
                const parts = this.splitFqn(fqn);
                return parts[parts.length - 1];
            }
            else {
                return '';
            }
        }
    }
    removeLastPart(fqn) {
        const parts = this.splitFqn(fqn);
        parts.splice(-1, 1);
        return this.buildFqn(parts);
    }
    areEqual(fqn1, fqn2) {
        if (fqn1 === fqn2) {
            return true;
        }
        if (isString(fqn1) && isString(fqn2)) {
            return fqn1.toLowerCase() === fqn2.toLowerCase();
        }
        return false;
    }
    splitFqn(fqn) {
        const parts = [];
        if (fqn && fqn.length > 0) {
            const rawParts = fqn.split(FqnService.delimiterChar);
            for (let i = 0; i < rawParts.length; i++) {
                if (rawParts[i].indexOf(FqnService.startPartChar) === 0) {
                    const partSequence = [];
                    for (; i < rawParts.length; i++) {
                        partSequence.push(this.unescapeRawPart(rawParts[i]));
                        const tmpString = rawParts[i].replace(new RegExp(FqnService.escapedEndPartChar, 'g'), '');
                        if (tmpString.charAt(tmpString.length - 1) === FqnService.endPartChar) {
                            break;
                        }
                    }
                    parts.push(partSequence.join(FqnService.delimiterChar));
                }
                else {
                    parts.push(rawParts[i]);
                }
            }
        }
        return parts;
    }
    buildFqn(parts) {
        const fqn = [];
        for (let i = 0; i < parts.length; i++) {
            if (this.requiresEscaping(parts[i])) {
                fqn.push(this.escape(parts[i]));
            }
            else {
                fqn.push(parts[i]);
            }
        }
        return fqn.join(FqnService.delimiterChar);
    }
    buildFqnWithEscaping(parts) {
        const fqn = [];
        for (let i = 0; i < parts.length; i++) {
            if (this.requiresEscaping(parts[i], true)) {
                fqn.push(this.escape(parts[i]));
            }
            else {
                fqn.push(parts[i]);
            }
        }
        return fqn.join(FqnService.delimiterChar);
    }
    appendNamePart(baseName, part) {
        return [baseName, this.buildFqn([part])].join(FqnService.delimiterChar);
    }
    appendNameParts(baseName, parts) {
        return [baseName, this.buildFqn(parts)].join(FqnService.delimiterChar);
    }
    isRelative(fqn) {
        return fqn[0] === FqnService.delimiterChar;
    }
    absoluteToRelative(anchorFqn, fqn) {
        if (!anchorFqn) {
            if (this.isRelative(fqn)) {
                return fqn;
            }
            else {
                return FqnService.delimiterChar + fqn;
            }
        }
        const anchorFqnParts = this.splitFqn(anchorFqn);
        const fqnParts = this.splitFqn(fqn);
        let commonCount = 0;
        let ii;
        for (ii = 0; ii < anchorFqnParts.length; ii++) {
            if (!this.areEqual(anchorFqnParts[ii], fqnParts[ii])) {
                break;
            }
            commonCount++;
        }
        const relativeFqnParts = fqnParts.slice(commonCount, fqnParts.length);
        let relativeFqn = this.buildFqn(relativeFqnParts);
        commonCount = (anchorFqnParts.length - commonCount) + 1;
        for (ii = 0; ii < commonCount; ii++) {
            relativeFqn = FqnService.delimiterChar + relativeFqn;
        }
        return relativeFqn;
    }
    relativeToAbsolute(anchorFqn, relativeFqn) {
        const trimmedAnchorFqn = anchorFqn.trim();
        const trimmedRelativeFqn = relativeFqn.trim();
        if (relativeFqn.length === 0) {
            return trimmedAnchorFqn;
        }
        let relativeDepth = this.relativeFqnDepth(trimmedRelativeFqn);
        const finalRelativeFqn = (relativeDepth < 1) ? trimmedRelativeFqn :
            trimmedRelativeFqn.slice(relativeDepth, trimmedRelativeFqn.length);
        const relativeFqnParts = this.splitFqn(finalRelativeFqn);
        const anchorFqnParts = this.splitFqn(trimmedAnchorFqn);
        if (relativeDepth > anchorFqnParts.length + 1) {
            return '';
        }
        if (relativeDepth > 0) {
            relativeDepth--;
        }
        const fullNameParts = this.getCombinedNameParts(anchorFqnParts, anchorFqnParts.length - relativeDepth, relativeFqnParts);
        return this.buildFqn(fullNameParts);
    }
}
FqnService.delimiterChar = '.';
FqnService.startPartChar = '[';
FqnService.endPartChar = ']';
FqnService.escapedEndPartChar = ']]';
FqnService.decorators = [
    { type: Injectable }
];

class ItemPermissions {
    get read() {
        return this._read;
    }
    set read(param) {
        this._read = isNil(param) ? false : param;
    }
    get write() {
        return this._write;
    }
    set write(param) {
        this._write = isNil(param) ? false : param;
    }
    get delete() {
        return this._delete;
    }
    set delete(param) {
        this._delete = isNil(param) ? false : param;
    }
    get execute() {
        return this._execute;
    }
    set execute(param) {
        this._execute = isNil(param) ? false : param;
    }
    static create(rwde) {
        if (rwde instanceof ItemPermissions) {
            return rwde;
        }
        const _rwde = isString(rwde) ? rwde.toLowerCase() : 'nnnn';
        return new ItemPermissions(_rwde[0] === 'y', _rwde[1] === 'y', _rwde[2] === 'y', _rwde[3] === 'y');
    }
    constructor(readPerm, writePerm, deletePerm, executePerm) {
        this._read = readPerm;
        this._write = writePerm;
        this._delete = deletePerm;
        this._execute = executePerm;
    }
    satisfiesRequired(requiredPermissions) {
        const requiredPermissionsLocal = ItemPermissions.create(requiredPermissions);
        if (requiredPermissionsLocal.read && !this.read) {
            return false;
        }
        if (requiredPermissionsLocal.write && !this.write) {
            return false;
        }
        if (requiredPermissionsLocal.delete && !this.delete) {
            return false;
        }
        if (requiredPermissionsLocal.execute && !this.execute) {
            return false;
        }
        return true;
    }
}

class PermissionsService {
    constructor(instanceSvc) {
        this.instanceSvc = instanceSvc;
    }
    checkItemsPermissions(fqns, requiredPermissions) {
        const checkPerm = ItemPermissions.create(requiredPermissions);
        const req = new InstanceRequest();
        const result = {};
        fqns.forEach((fqn) => {
            result[fqn] = false;
            req.addItemFqn(fqn, false, 0);
        });
        return this.instanceSvc.getInstances(req).pipe(map((response) => {
            for (let index = 0; index < response.fqnsResults.length; index++) {
                const itemData = response.fqnsResults[index];
                const item = itemData.item;
                if (!item || !item.fqn || isNil(result[item.fqn])) {
                    continue;
                }
                const itemPermissions = ItemPermissions.create(item.rwde);
                result[item.fqn] = itemPermissions.satisfiesRequired(checkPerm);
            }
            return values(result);
        }));
    }
}
PermissionsService.decorators = [
    { type: Injectable }
];
PermissionsService.ctorParameters = () => [
    { type: InstanceService }
];

function setupInstanceSvc(config, httpClient) {
    return new InstanceService(config, httpClient);
}
function setupLiveDataSvc(config, httpClient) {
    return new LiveDataService(config, httpClient);
}
function setupTimeseriesDataSvc(config, httpClient, qualitySvc) {
    return new TimeseriesDataService(config, httpClient, qualitySvc);
}
function setupOperationSvc(config, httpClient) {
    return new OperationService(config, httpClient);
}
function setupPersistenceSvc(config, httpClient) {
    return new PersistenceService(config, httpClient);
}
function setupNavigationSvc(config, httpClient) {
    return new NavigationService(config, httpClient);
}
function setupSecurityContextSvc(config, httpClient) {
    return new SecurityContextService(config, httpClient);
}
function setupMimeSvc(config, httpClient) {
    return new MimeService(config, httpClient);
}
function setupNavigationHandlerSvc(config, httpClient) {
    return new NavigationHandlerService(config, httpClient);
}
class RaFtcCommunicationModule {
    static forRoot(config) {
        return {
            ngModule: RaFtcCommunicationModule,
            providers: [
                {
                    provide: InstanceService,
                    useFactory: setupInstanceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: LiveDataService,
                    useFactory: setupLiveDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: TimeseriesDataService,
                    useFactory: setupTimeseriesDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient, OpcQualityService
                    ]
                },
                {
                    provide: OperationService,
                    useFactory: setupOperationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: PersistenceService,
                    useFactory: setupPersistenceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationService,
                    useFactory: setupNavigationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: SecurityContextService,
                    useFactory: setupSecurityContextSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: MimeService,
                    useFactory: setupMimeSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationHandlerService,
                    useFactory: setupNavigationHandlerSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                { provide: COMMUNICATION_CONFIG, useValue: config },
                OpcQualityService,
                FqnService,
                PermissionsService
            ]
        };
    }
}
RaFtcCommunicationModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    HttpClientModule
                ],
                providers: [OpcQualityService, FqnService],
                declarations: []
            },] }
];

export { setupInstanceSvc, setupLiveDataSvc, setupTimeseriesDataSvc, setupOperationSvc, setupPersistenceSvc, setupNavigationSvc, setupSecurityContextSvc, setupMimeSvc, setupNavigationHandlerSvc, RaFtcCommunicationModule, BaseService, InstanceService, InstanceRequest, LiveRequest, LiveDataService, NavigationService, NavigationRequest, OperationService, OperationRequest, PersistenceService, PropNameValues, PersistRequest, TimeseriesRequestQuality, TimeseriesRepeatedDataFormat, SamplingTypes, TimeseriesRequest, TimeseriesDataService, OpcQualityService, SecurityContextService, MomentHelperService, MimeService, NavigationHandlerService, NavigationHandlerRequest, FqnService, PermissionsService, DEFAULT_REPEATED_DATA_INTERVAL, COMMUNICATION_CONFIG, ItemPermissions };

//# sourceMappingURL=ra-wcftcloud-ra-ftc-communication.js.map