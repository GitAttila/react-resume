import { ItemPermissions } from './models/item-permissions';
import { InstanceService } from './instance.service';
import { Observable } from 'rxjs';
export declare class PermissionsService {
    private instanceSvc;
    constructor(instanceSvc: InstanceService);
    checkItemsPermissions(fqns: string[], requiredPermissions: string | ItemPermissions): Observable<any>;
}
