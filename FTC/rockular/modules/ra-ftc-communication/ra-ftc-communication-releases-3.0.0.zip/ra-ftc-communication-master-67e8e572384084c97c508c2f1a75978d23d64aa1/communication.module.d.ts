import { ModuleWithProviders } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { InstanceService } from './instance.service';
import { LiveDataService } from './live-data.service';
import { TimeseriesDataService } from './timeseries-data.service';
import { ICommunicationConfig } from './config';
import { OperationService } from './operation.service';
import { PersistenceService } from './persistence.service';
import { NavigationService } from './navigation.service';
import { OpcQualityService } from './opc-quality.service';
import { SecurityContextService } from './security-context.service';
import { MimeService } from './mime.service';
import { NavigationHandlerService } from './navigation-handler.service';
export declare function setupInstanceSvc(config: ICommunicationConfig, httpClient: HttpClient): InstanceService;
export declare function setupLiveDataSvc(config: ICommunicationConfig, httpClient: HttpClient): LiveDataService;
export declare function setupTimeseriesDataSvc(config: ICommunicationConfig, httpClient: HttpClient, qualitySvc: OpcQualityService): TimeseriesDataService;
export declare function setupOperationSvc(config: ICommunicationConfig, httpClient: HttpClient): OperationService;
export declare function setupPersistenceSvc(config: ICommunicationConfig, httpClient: HttpClient): PersistenceService;
export declare function setupNavigationSvc(config: ICommunicationConfig, httpClient: HttpClient): NavigationService;
export declare function setupSecurityContextSvc(config: ICommunicationConfig, httpClient: HttpClient): SecurityContextService;
export declare function setupMimeSvc(config: ICommunicationConfig, httpClient: HttpClient): MimeService;
export declare function setupNavigationHandlerSvc(config: ICommunicationConfig, httpClient: HttpClient): NavigationHandlerService;
export declare class RaFtcCommunicationModule {
    static forRoot(config: ICommunicationConfig): ModuleWithProviders;
}
