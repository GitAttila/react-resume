import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { Observable } from 'rxjs';
import { BaseService } from './base.service';
export interface INavigationHandlerResponse {
    navhandlerfqn: string | null;
}
export declare type NavigationHandlerResponse = INavigationHandlerResponse;
export declare class NavigationHandlerService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getNavigationHandlerData(navigationHandlerReq: NavigationHandlerRequest): Observable<NavigationHandlerResponse>;
}
export declare class NavigationHandlerRequest {
    fqn: string;
    currentNavHandlerFqn?: string;
    navHandlerProviderFqn?: string;
    constructor(fqn: string, currentNavHandlerFqn?: string, navHandlerProviderFqn?: string);
}
