import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { Observable } from 'rxjs';
import { BaseService } from './base.service';
export interface ISecurityContextResponse {
    username: string;
    roles: string[];
    identities: string[];
}
export declare type SecurityContextResponse = ISecurityContextResponse;
export declare class SecurityContextService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getSecurityContextData(): Observable<SecurityContextResponse>;
}
