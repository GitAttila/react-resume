import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { Observable } from 'rxjs';
import { BaseService } from './base.service';
export declare class OperationService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getOperationData(operationReq: OperationRequest): Observable<any>;
}
export declare class OperationRequest {
    target: string;
    operation: string;
    parameters: object;
    constructor(target: string, operation: string, parameters?: object);
}
