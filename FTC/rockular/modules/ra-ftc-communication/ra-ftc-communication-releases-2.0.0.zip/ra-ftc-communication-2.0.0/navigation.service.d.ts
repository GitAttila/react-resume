import { BaseService } from './base.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICommunicationConfig } from './config';
import { NavigationRules } from './shared';
export declare class NavigationService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getNavigationData(navigationRequest: NavigationRequest): Observable<any>;
}
export declare class NavigationRequest {
    fqn: string;
    propNames: string[];
    includeParents: boolean;
    navHandlerFqn: string;
    hideRules: NavigationRules;
    skipRules: NavigationRules;
    constructor(fqn: string, propNames?: string[], includeParents?: boolean, navHandlerFqn?: string, hideRules?: NavigationRules, skipRules?: NavigationRules);
}
