import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICommunicationConfig } from './config';
export declare class BaseService {
    protected endpointUrl: string;
    protected config: ICommunicationConfig;
    protected http: HttpClient;
    constructor(endpointUrl: string, config: ICommunicationConfig, http: HttpClient);
    protected _sendPostRequest(request: any): Observable<any>;
    protected _sendGetRequest(): Observable<any>;
}
