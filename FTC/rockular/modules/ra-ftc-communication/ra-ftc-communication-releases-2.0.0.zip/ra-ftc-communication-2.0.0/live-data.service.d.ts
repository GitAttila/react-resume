import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICommunicationConfig } from './config';
import { identifier, IResponse } from './shared';
import { BaseService } from './base.service';
export interface ILiveResponseProxyValue {
    fqn: string;
    name: string;
    type: string;
    createdOn?: string;
    createdOnOffset?: number;
    modifiedOn?: string;
    modifiedOnOffset?: number;
}
export interface ILiveResponse extends IResponse {
    v: string | number | boolean | ILiveResponseProxyValue[];
    q: number;
    t: string;
}
export declare type LiveResponse = ILiveResponse[];
export declare class LiveRequest {
    readonly fqns: identifier[];
    constructor(fqns: identifier[]);
    addFqn(fqn: identifier): void;
    removeFqn(fqn: identifier): void;
}
export declare class LiveDataService extends BaseService {
    private _fqns;
    private _repeatedDataObservable;
    private _repeatedDataSubscription;
    private _repeatedDataSubject;
    private _reinitializeRepeatedObservable;
    constructor(config: ICommunicationConfig, http: HttpClient);
    getOnce(request: LiveRequest): Observable<LiveResponse>;
    private _getInnerRepeatedObservable();
    private _initializeRepeatedData();
    getRepeatedly(request: LiveRequest): Observable<LiveResponse>;
}
