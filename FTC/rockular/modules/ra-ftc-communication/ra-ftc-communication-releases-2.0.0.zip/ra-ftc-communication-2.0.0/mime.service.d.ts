import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { BaseService } from './base.service';
export declare class MimeService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getMimeItemPath(fqn: string): string;
}
