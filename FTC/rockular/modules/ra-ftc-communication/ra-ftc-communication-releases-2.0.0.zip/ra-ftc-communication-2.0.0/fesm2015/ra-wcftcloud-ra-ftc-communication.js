import { InjectionToken, Inject, Injectable, NgModule } from '@angular/core';
import { extend, isNil, clone, indexOf, each, filter, some, last, first, find, sortBy } from 'lodash';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable, Subject, timer } from 'rxjs';
import { map, expand, concatMap } from 'rxjs/operators';
import { utc, tz } from 'moment-timezone';
import { CommonModule } from '@angular/common';

const DEFAULT_REPEATED_DATA_INTERVAL = 5;
const COMMUNICATION_CONFIG = new InjectionToken('COMMUNICATION_CONFIGURATION');

class BaseService {
    constructor(endpointUrl, config, http) {
        this.endpointUrl = endpointUrl;
        this.config = config;
        this.http = http;
    }
    _sendPostRequest(request) {
        return this.http.post(this.endpointUrl, request, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
    }
    _sendGetRequest() {
        return this.http.get(this.endpointUrl, extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
    }
}

class InstanceService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/instance/', config, http);
    }
    getInstances(instanceRequest) {
        return this._sendPostRequest(instanceRequest);
    }
}
InstanceService.decorators = [
    { type: Injectable },
];
InstanceService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
class InstanceRequest {
    constructor(camelCasePropertyNames) {
        if (!isNil(camelCasePropertyNames)) {
            this.camelCasePropertyNames = camelCasePropertyNames;
        }
        else {
            this.camelCasePropertyNames = true;
        }
    }
    addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts) {
        instanceFqnItem.responseFormat = {};
        if (includeAccessControl) {
            instanceFqnItem.responseFormat.includeAcl = includeAccessControl;
        }
        if (!isNil(retrievalDepth) && retrievalDepth > 0) {
            instanceFqnItem.responseFormat.depth = retrievalDepth;
        }
        if (includeShortcuts) {
            instanceFqnItem.responseFormat.includeShortcuts = includeShortcuts;
        }
    }
    addItemFqn(fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceFqnItem = {
            fqn: fqn
        };
        this.addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!this.fqns) {
            this.fqns = [];
        }
        this.fqns.push(instanceFqnItem);
        return this;
    }
    addItemFqnExcludeVolatile(fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceFqnItem = {
            fqn: fqn,
            excludeVolatileProperties: true
        };
        this.addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!this.fqns) {
            this.fqns = [];
        }
        this.fqns.push(instanceFqnItem);
        return this;
    }
    addPropertyFqn(fqn, includeAccessControl, retrievalDepth, includeShortcuts, pageSize, page) {
        const instanceFqnPropertyItem = {
            propertyFqn: fqn,
            excludeVolatileProperties: true
        };
        this.addResponseFormat(instanceFqnPropertyItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!isNil(pageSize)) {
            instanceFqnPropertyItem.pageSize = pageSize;
        }
        if (!isNil(page)) {
            instanceFqnPropertyItem.page = page;
        }
        if (!this.fqns) {
            this.fqns = [];
        }
        this.fqns.push(instanceFqnPropertyItem);
        return this;
    }
    addQuery(queryExpression, includeAccessControl, retrievalDepth, includeShortcuts) {
        const instanceQueryItem = {
            query: queryExpression
        };
        this.addResponseFormat(instanceQueryItem, includeAccessControl, retrievalDepth, includeShortcuts);
        if (!this.queries) {
            this.queries = [];
        }
        this.queries.push(instanceQueryItem);
        return this;
    }
}

class LiveRequest {
    constructor(fqns) {
        this.fqns = fqns;
        this.fqns = clone(fqns);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
}
class LiveDataService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/live/', config, http);
        this._fqns = new Map();
    }
    getOnce(request) {
        return this._sendPostRequest(request).pipe(map((response) => {
            const ret = [];
            each(response.fqnsResults, (oneResult) => {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    }
    _getInnerRepeatedObservable() {
        return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
            .pipe(map((response) => {
            const ret = [];
            each(response.fqnsResults, (oneResult) => {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    }
    _initializeRepeatedData() {
        if (!this._repeatedDataSubject) {
            this._repeatedDataSubject = new Subject();
        }
        if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
            let repeatedInterval = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval = repeatedInterval * 1000;
            this._repeatedDataObservable = this._getInnerRepeatedObservable();
            this._repeatedDataSubscription = this._repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => this._getInnerRepeatedObservable())))).subscribe((response) => {
                this._repeatedDataSubject.next(response);
            }, (err) => {
                this._repeatedDataSubscription.unsubscribe();
                this._reinitializeRepeatedObservable = true;
                this._repeatedDataSubject.error(err);
            }, () => {
                this._reinitializeRepeatedObservable = true;
                this._repeatedDataSubject.complete();
            });
            this._reinitializeRepeatedObservable = false;
        }
        return this._repeatedDataObservable;
    }
    getRepeatedly(request) {
        return new Observable((observer) => {
            each(request.fqns, (fqn) => {
                let newVal = 0;
                if (this._fqns.has(fqn)) {
                    newVal = this._fqns.get(fqn);
                }
                this._fqns.set(fqn, ++newVal);
            });
            this._initializeRepeatedData();
            const subscription = this._repeatedDataSubject.asObservable().pipe(map((currentResponse) => {
                return filter(currentResponse, (o) => {
                    return indexOf(request.fqns, o.fqn) > -1;
                });
            })).subscribe((response) => {
                observer.next(response);
            }, (error) => {
                observer.error(error);
            }, () => {
                observer.complete();
            });
            return () => {
                each(request.fqns, (fqn) => {
                    let newVal = 1;
                    if (this._fqns.has(fqn)) {
                        newVal = this._fqns.get(fqn);
                    }
                    if (newVal === 1) {
                        this._fqns.delete(fqn);
                    }
                    else {
                        this._fqns.set(fqn, --newVal);
                    }
                });
                subscription.unsubscribe();
                observer.unsubscribe();
                if (this._fqns.size === 0) {
                    if (this._repeatedDataSubscription) {
                        this._repeatedDataSubscription.unsubscribe();
                    }
                    this._repeatedDataSubject.complete();
                    delete this._repeatedDataSubject;
                    this._reinitializeRepeatedObservable = true;
                }
            };
        });
    }
}
LiveDataService.decorators = [
    { type: Injectable },
];
LiveDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];

class OpcQualityService {
    constructor() {
        this.opcDaQualityMask = 0xfffC;
        this.opcDaQualityMasterMask = 0x00C0;
        this.opcHdaQualityMask = 0xffff0000;
        this.opcDaQualityFieldMasks = {
            limitField: 0x0003,
            subStatusField: 0x003C,
            quality: 0x00C0
        };
        this.opcDaQualityMaster = {
            bad: 0x0000,
            uncertain: 0x0040,
            notDefined: 0x0080,
            good: 0x00C0
        };
        this.opcDaQualityStatus = {
            bad: 0x0000,
            configError: 0x0004,
            notConnected: 0x0008,
            deviceFailure: 0x000c,
            sensorFailure: 0x0010,
            lastKnown: 0x0014,
            commFailure: 0x0018,
            outOfService: 0x001c,
            initializing: 0x0020,
            uncertain: 0x0040,
            lastUsable: 0x0044,
            sensorNotAccurate: 0x0050,
            engUnitsExceeded: 0x0054,
            subNormal: 0x0058,
            good: 0x00C0,
            localOverride: 0x00D8
        };
        this.opcDaQualityLimit = {
            limitOk: 0x0000,
            limitLow: 0x0001,
            limitHigh: 0x0002,
            constant: 0x0003
        };
        this.opcHdaQuality = {
            extraData: 0x00010000,
            interpolated: 0x00020000,
            raw: 0x00040000,
            calculated: 0x00080000,
            noBound: 0x00100000,
            noData: 0x00200000,
            dataLost: 0x00400000,
            conversion: 0x00800000,
            partial: 0x01000000
        };
        this.overallMessages = {
            0x0000: 'Bad',
            0x0040: 'Uncertain',
            0x0080: 'Not defined',
            0x00C0: 'Good'
        };
        this.detailsMessages = {
            0x0000: 'Not limited',
            0x0001: 'Low limited',
            0x0002: 'High limited',
            0x0003: 'Constant',
            0x0004: 'Config error',
            0x0008: 'Not connected',
            0x000c: 'Device failure',
            0x0010: 'Sensor failure',
            0x0014: 'Last known',
            0x0018: 'Comm failure',
            0x001C: 'Out of service',
            0x0020: 'Initializing',
            0x0044: 'Last usable',
            0x0050: 'Sensors not accurate',
            0x0054: 'Engineering units exceeded',
            0x0058: 'Sub-Normal',
            0x00D8: 'Local override',
            0x00010000: 'Extra data',
            0x00020000: 'Interpolated',
            0x00040000: 'Raw',
            0x00080000: 'Calculated',
            0x00100000: 'No bound',
            0x00200000: 'No data',
            0x00400000: 'Data lost',
            0x00800000: 'Conversion',
            0x01000000: 'Partial'
        };
    }
    asObject(qualityAsInt) {
        let mask;
        const quality = ({});
        mask = qualityAsInt & this.opcDaQualityMasterMask;
        quality.overall = this.overallMessages[mask];
        mask = qualityAsInt & this.opcDaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.da = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        if (mask && this.detailsMessages[mask]) {
            quality.limit = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcHdaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.hda = this.detailsMessages[mask];
        }
        return quality;
    }
    asString(qualityAsInt) {
        let hasDaQuality = false;
        const qObj = this.asObject(qualityAsInt);
        let qString;
        qString = qObj.overall;
        if (qObj.da) {
            qString = qString + ': ' + qObj.da;
            hasDaQuality = true;
        }
        if (qObj.limit) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.limit;
            hasDaQuality = true;
        }
        if (qObj.hda) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.hda;
        }
        return qString;
    }
    getOpcDaQuality(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMask;
    }
    getOpcLimitStatus(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
    }
    getSimpleQuality(qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMasterMask;
    }
    getOpcHdaQuality(qualityAsInt) {
        return qualityAsInt & this.opcHdaQualityMask;
    }
    isGood(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
    }
    isUncertain(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
    }
    isBad(qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
    }
    isDaConfigError(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
    }
    isDaNotConnected(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
    }
    isDaDeviceFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
    }
    isDaSensorFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
    }
    isDaLastKnown(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
    }
    isDaCommFailure(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
    }
    isDaOutOfService(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
    }
    isDaInitializing(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
    }
    isDaLastUsable(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
    }
    isDaSensorNotAccurate(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
    }
    isDaEngUnitsExceeded(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
    }
    isDaSubNormal(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
    }
    isDaLocalOverride(qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
    }
    isLimitOk(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
    }
    isLimitLow(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
    }
    isLimitHigh(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
    }
    isLimitConstant(qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
    }
    isHdaExtraData(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
    }
    isHdaInterpolated(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
    }
    isHdaRaw(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
    }
    isHdaCalculated(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
    }
    isHdaNoBound(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
    }
    isHdaNoData(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
    }
    isHdaDataLost(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
    }
    isHdaConversion(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
    }
    isHdaPartial(qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
    }
}
OpcQualityService.decorators = [
    { type: Injectable },
];

class MomentHelperService {
    static applyTimezone(datetime, timezone) {
        const mDate = utc(datetime);
        mDate.tz(timezone);
        return mDate.format(this.MOMENT_DATETIME_FORMAT_TZ_FULL);
    }
    static getAllTimezones() {
        return tz.names();
    }
    static isValidTimezone(timezone) {
        return timezone && tz.zone(timezone);
    }
}
MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL = 'YYYY-MM-DDTHH:mm:ss.SSS[Z]';
MomentHelperService.MOMENT_DATETIME_FORMAT_TZ_FULL = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
MomentHelperService.decorators = [
    { type: Injectable },
];

const TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = "includeGood";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = "includeBad";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = "includeUncertain";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = "includeAll";
const TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
const SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
};
class TimeseriesRequest {
    constructor(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
    setFqns(fqns) {
        this.fqns = clone(fqns);
    }
    getFqns() {
        return clone(this.fqns);
    }
    setTimePeriod(timePeriod) {
        this.timePeriod = clone(timePeriod);
    }
    getTimePeriod() {
        return clone(this.timePeriod);
    }
    setSamplingDefinition(samplingDefinition) {
        this.samplingDefinition = clone(samplingDefinition);
    }
    getSamplingDefinition() {
        return clone(this.samplingDefinition);
    }
    setTimeDeadBand(timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    }
    getTimeDeadband() {
        return this.timeDeadBand;
    }
    setValueDeadBand(valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    }
    getValueDeadBand() {
        return this.valueDeadBand;
    }
    setQualityFilter(qualityFilter) {
        this.qualityFilter = qualityFilter;
    }
    getQualityFilter() {
        return this.qualityFilter;
    }
}
class TimeseriesDataService extends BaseService {
    constructor(config, http, opcQualitySvc) {
        super(config.baseUrl + '/api/1/timeseries/', config, http);
        this.opcQualitySvc = opcQualitySvc;
    }
    getOnce(request, timezone) {
        let tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        return this._sendPostRequest(request).pipe(map((response) => this._transformTimeseriesInternalResponse(response, tz$$1)));
    }
    _getErrorObservable(errorString) {
        return new Observable((observer) => {
            observer.error(errorString);
            return () => {
                observer.unsubscribe();
            };
        });
    }
    _applyTimezoneToVqtData(vqtData, timezone) {
        each(vqtData, (vqt) => {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    }
    _getRequestDataNextStartValues(response, nextStartMoment) {
        const beforeNextRequestValues = new Map();
        let last$$1;
        each(response.fqnsResults, (el) => {
            if (!isNil(el) && el.values.length) {
                last$$1 = last(el.values);
                beforeNextRequestValues.set(el.fqn, last$$1);
            }
        });
        return beforeNextRequestValues;
    }
    _getStartForNextRequest(response, originalDuration, repeatedInterval) {
        const opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            const timeString = first(fqnResult.values).t;
            for (let i = fqnResult.values.length - 1; i >= 0; i--) {
                const val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        let result;
        const currentTimeMinusDuration = utc().subtract(Math.abs(originalDuration), 'seconds');
        each(response.fqnsResults, (fqnResult) => {
            if (isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            const lastValue = utc(getLastTimeToUse(fqnResult));
            if (isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (isNil(result)) {
            result = utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    }
    _filterStartResponseData(response, previousResponseLastData, requestTimePeriod) {
        let firstVqt;
        let firstVqtMoment;
        let secondVqt;
        const opcQualitySvc = this.opcQualitySvc;
        const cutBeforeDate = utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        each(response.fqnsResults, (el) => {
            if (!isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                const onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                const onePreviousResponseLastDataMoment = utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    }
    _transformTimeseriesInternalResponse(response, timezone) {
        let applyTimezone = false;
        if (!isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        const ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        each(response.fqnsResults, (oneResult) => {
            if (isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    }
    _filterDuplicateDataAndCut(values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        const ids = [];
        let objectToAddToArray;
        let firstIsAfter = false;
        function arrayFilter(o) {
            const currentItemMoment = utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = clone(o);
                    const cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        const filteredArray = values.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            const lastValue = last(filteredArray);
            if (!lastValue || !utc(lastValue.t).isSame(utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    }
    _getRepeatedlyWhole(request, customInterval, timezone) {
        let lastMergedResponse;
        const tz$$1 = timezone;
        const repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map((response) => {
            if (!isNil(lastMergedResponse)) {
                const requestTimePeriod = request.getTimePeriod();
                const cutBeforeDate = utc(response.timePeriod.end);
                cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                const cutBeforeDateUTCFormat = cutBeforeDate.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!isNil(tz$$1)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz$$1);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                each(lastMergedResponse.results, (result) => {
                    const newResults = find(response.results, { fqn: result.fqn });
                    if (!isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = sortBy(result.values, [(o) => {
                                return utc(o.t);
                            }]);
                        result.values = this._filterDuplicateDataAndCut(result.values, cutBeforeDate, false, tz$$1);
                    }
                });
                each(response.results, (newResult) => {
                    if (!find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    }
    _getRepeatedlyIncrements(request, customInterval, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        let lastResponseData;
        let repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        const lastRepeatedRequest = clone(request);
        const originalDuration = requestTimePeriod.duration;
        let nextRequestStartMoment;
        const repeatedDataObservable = this._sendPostRequest(request).pipe(map((response) => {
            nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return this._transformTimeseriesInternalResponse(response, timezone);
        }));
        const expandedObservable = repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => {
            if (!isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return this._sendPostRequest(lastRepeatedRequest).pipe(map((response) => {
                if (lastResponseData.size > 0) {
                    this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return this._transformTimeseriesInternalResponse(response, timezone);
            }));
        }))));
        return expandedObservable;
    }
    getRepeatedly(request, customInterval, format, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        if (!isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        let tz$$1;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz$$1 = timezone;
        }
        if (isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz$$1);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz$$1);
        }
    }
}
TimeseriesDataService.decorators = [
    { type: Injectable },
];
TimeseriesDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
    { type: OpcQualityService, },
];

class OperationService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/operation/', config, http);
    }
    getOperationData(operationReq) {
        return this._sendPostRequest(operationReq);
    }
}
OperationService.decorators = [
    { type: Injectable },
];
OperationService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
class OperationRequest {
    constructor(target, operation, parameters) {
        this.target = target;
        this.operation = operation;
        this.parameters = parameters;
    }
}

class PersistenceService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/persistence/', config, http);
    }
    commit(persistRequest) {
        return this._sendPostRequest(persistRequest);
    }
}
PersistenceService.decorators = [
    { type: Injectable },
];
PersistenceService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
class PropNameValues {
    add(name, value) {
        if (name) {
            this[name] = value;
        }
    }
    remove(name) {
        if (!isNil(this[name])) {
            delete this[name];
        }
    }
    isEmpty() {
        return !some(this);
    }
}
class PersistRequest {
    createItem(parentPropertyFqn, itemType, propNameValues) {
        const createRequest = {
            parentPropertyFqn: parentPropertyFqn,
            itemType: itemType
        };
        if (propNameValues) {
            createRequest.props = propNameValues;
        }
        if (!this.newItems) {
            this.newItems = [];
        }
        this.newItems.push(createRequest);
        return this;
    }
    renameItem(itemFqn, newName) {
        this.renamedItem = {
            fqn: itemFqn,
            newName: newName
        };
        return this;
    }
    changeItem(itemFqn, propNameValues) {
        if (!propNameValues.isEmpty()) {
            const changeRequest = {
                FullyQualifiedName: itemFqn
            };
            extend(changeRequest, propNameValues);
            if (!this.changedItems) {
                this.changedItems = [];
            }
            this.changedItems.push(changeRequest);
        }
        return this;
    }
    deleteItem(itemFqn) {
        if (!this.deletedItems) {
            this.deletedItems = [];
        }
        this.deletedItems.push(itemFqn);
        return this;
    }
}

class NavigationService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/navigation/', config, http);
    }
    getNavigationData(navigationRequest) {
        let request = navigationRequest;
        if (isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
            if (isNil(request.hideRules) && isNil(request.skipRules)) {
                request = clone(navigationRequest);
                request.skipRules = clone(this.config.defaultNavigationRules.skipRules);
                request.hideRules = clone(this.config.defaultNavigationRules.hideRules);
            }
        }
        return this._sendPostRequest(request);
    }
}
NavigationService.decorators = [
    { type: Injectable },
];
NavigationService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
class NavigationRequest {
    constructor(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
        this.fqn = fqn;
        this.propNames = propNames;
        this.includeParents = includeParents;
        this.navHandlerFqn = navHandlerFqn;
        this.hideRules = hideRules;
        this.skipRules = skipRules;
    }
}

class SecurityContextService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/securitycontext/', config, http);
    }
    getSecurityContextData() {
        return this._sendGetRequest();
    }
}
SecurityContextService.decorators = [
    { type: Injectable },
];
SecurityContextService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];

class MimeService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/mime/', config, http);
    }
    getMimeItemPath(fqn) {
        return this.endpointUrl.concat(fqn);
    }
}
MimeService.decorators = [
    { type: Injectable },
];
MimeService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];

class NavigationHandlerService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/navigationhandler/', config, http);
    }
    getNavigationHandlerData(navigationHandlerReq) {
        return this._sendPostRequest(navigationHandlerReq);
    }
}
NavigationHandlerService.decorators = [
    { type: Injectable },
];
NavigationHandlerService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
class NavigationHandlerRequest {
    constructor(fqn, currentNavHandlerFqn, navHandlerProviderFqn) {
        this.fqn = fqn;
        this.currentNavHandlerFqn = currentNavHandlerFqn;
        this.navHandlerProviderFqn = navHandlerProviderFqn;
    }
}

function setupInstanceSvc(config, httpClient) {
    return new InstanceService(config, httpClient);
}
function setupLiveDataSvc(config, httpClient) {
    return new LiveDataService(config, httpClient);
}
function setupTimeseriesDataSvc(config, httpClient, qualitySvc) {
    return new TimeseriesDataService(config, httpClient, qualitySvc);
}
function setupOperationSvc(config, httpClient) {
    return new OperationService(config, httpClient);
}
function setupPersistenceSvc(config, httpClient) {
    return new PersistenceService(config, httpClient);
}
function setupNavigationSvc(config, httpClient) {
    return new NavigationService(config, httpClient);
}
function setupSecurityContextSvc(config, httpClient) {
    return new SecurityContextService(config, httpClient);
}
function setupMimeSvc(config, httpClient) {
    return new MimeService(config, httpClient);
}
function setupNavigationHandlerSvc(config, httpClient) {
    return new NavigationHandlerService(config, httpClient);
}
class RaFtcCommunicationModule {
    static forRoot(config) {
        return {
            ngModule: RaFtcCommunicationModule,
            providers: [
                {
                    provide: InstanceService,
                    useFactory: setupInstanceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: LiveDataService,
                    useFactory: setupLiveDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: TimeseriesDataService,
                    useFactory: setupTimeseriesDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient, OpcQualityService
                    ]
                },
                {
                    provide: OperationService,
                    useFactory: setupOperationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: PersistenceService,
                    useFactory: setupPersistenceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationService,
                    useFactory: setupNavigationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: SecurityContextService,
                    useFactory: setupSecurityContextSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: MimeService,
                    useFactory: setupMimeSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationHandlerService,
                    useFactory: setupNavigationHandlerSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                { provide: COMMUNICATION_CONFIG, useValue: config }
            ]
        };
    }
}
RaFtcCommunicationModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    HttpClientModule
                ],
                providers: [OpcQualityService],
                declarations: []
            },] },
];

export { setupInstanceSvc, setupLiveDataSvc, setupTimeseriesDataSvc, setupOperationSvc, setupPersistenceSvc, setupNavigationSvc, setupSecurityContextSvc, setupMimeSvc, setupNavigationHandlerSvc, RaFtcCommunicationModule, BaseService, InstanceService, InstanceRequest, LiveRequest, LiveDataService, NavigationService, NavigationRequest, OperationService, OperationRequest, PersistenceService, PropNameValues, PersistRequest, TimeseriesRequestQuality, TimeseriesRepeatedDataFormat, SamplingTypes, TimeseriesRequest, TimeseriesDataService, OpcQualityService, SecurityContextService, MomentHelperService, MimeService, NavigationHandlerService, NavigationHandlerRequest, DEFAULT_REPEATED_DATA_INTERVAL, COMMUNICATION_CONFIG };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmEtd2NmdGNsb3VkLXJhLWZ0Yy1jb21tdW5pY2F0aW9uLmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL2NvbmZpZy50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9iYXNlLnNlcnZpY2UudHMiLCJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vaW5zdGFuY2Uuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9saXZlLWRhdGEuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9vcGMtcXVhbGl0eS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL21vbWVudC1oZWxwZXIuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi90aW1lc2VyaWVzLWRhdGEuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9vcGVyYXRpb24uc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9wZXJzaXN0ZW5jZS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL25hdmlnYXRpb24uc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9zZWN1cml0eS1jb250ZXh0LnNlcnZpY2UudHMiLCJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vbWltZS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL25hdmlnYXRpb24taGFuZGxlci5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL2NvbW11bmljYXRpb24ubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SW5qZWN0aW9uVG9rZW59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge05hdmlnYXRpb25SdWxlc30gZnJvbSAnLi9zaGFyZWQnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJQ29tbW9uSHR0cENvbmZpZyB7XHJcbiAgICB3aXRoQ3JlZGVudGlhbHM6IGJvb2xlYW47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU5hdmlnYXRpb25SdWxlcyB7XHJcbiAgICBoaWRlUnVsZXM/OiBOYXZpZ2F0aW9uUnVsZXM7XHJcbiAgICBza2lwUnVsZXM/OiBOYXZpZ2F0aW9uUnVsZXM7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUwgPSA1O1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJQ29tbXVuaWNhdGlvbkNvbmZpZyB7XHJcbiAgICBiYXNlVXJsOiBzdHJpbmc7XHJcbiAgICBkZWZhdWx0UmVwZWF0ZWREYXRhSW50ZXJ2YWw/OiBudW1iZXI7XHJcbiAgICBkZWZhdWx0TmF2aWdhdGlvblJ1bGVzPzogSU5hdmlnYXRpb25SdWxlcztcclxuICAgIGh0dHBPcHRpb25zPzogSUNvbW1vbkh0dHBDb25maWc7XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIENPTkZJR19UWVBFID0gSUNvbW11bmljYXRpb25Db25maWc7XHJcblxyXG5leHBvcnQgY29uc3QgQ09NTVVOSUNBVElPTl9DT05GSUcgPSBuZXcgSW5qZWN0aW9uVG9rZW48SUNvbW11bmljYXRpb25Db25maWc+KCdDT01NVU5JQ0FUSU9OX0NPTkZJR1VSQVRJT04nKTtcclxuIiwiaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuXHJcbmV4cG9ydCBjbGFzcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJvdGVjdGVkIGVuZHBvaW50VXJsOiBzdHJpbmcsXHJcbiAgICAgICAgcHJvdGVjdGVkIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsXHJcbiAgICAgICAgcHJvdGVjdGVkIGh0dHA6IEh0dHBDbGllbnQpIHsgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3Q6IGFueSk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KHRoaXMuZW5kcG9pbnRVcmwsIHJlcXVlc3QsXHJcbiAgICAgICAgICAgIF8uZXh0ZW5kKHsgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcgfSB9LCB0aGlzLmNvbmZpZy5odHRwT3B0aW9ucykpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBfc2VuZEdldFJlcXVlc3QoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldCh0aGlzLmVuZHBvaW50VXJsLFxyXG4gICAgICAgICAgICBfLmV4dGVuZCh7IGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnIH0gfSwgdGhpcy5jb25maWcuaHR0cE9wdGlvbnMpKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5cclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHJlc3BvbnNlIGZvcm1hdCBvZiBmcW4gaXRlbS4gICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUZxbkl0ZW1SZXNwb25zZUZvcm1hdCB7XHJcbiAgICAvKiogRGVwdGggb2YgcmVzcG9uc2Ugb2JqZWN0ICovXHJcbiAgICBkZXB0aD86IG51bWJlcjtcclxuICAgIC8qKiBXaGV0aGVyIHRvIGluY2x1ZGUgc2hvcnRjdXRzIGluIHJlc3BvbnNlIG9iamVjdCBvciBub3QgKi9cclxuICAgIGluY2x1ZGVTaG9ydGN1dHM/OiBib29sZWFuO1xyXG4gICAgLyoqIFdoZXRoZXIgdG8gaW5jbHVkZSBhY2Nlc3MgY29udHJvbCBpbmZvcm1hdGlvbiBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90ICovXHJcbiAgICBpbmNsdWRlQWNsPzogYm9vbGVhbjtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGZxbiBpdGVtLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElGcW5JdGVtIHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgZXhjbHVkZVZvbGF0aWxlUHJvcGVydGllcz86IGJvb2xlYW47XHJcbiAgICAvKiogU2l6ZSBvZiBwYWdlIChkZWZhdWx0IDAgLSBkbyBub3QgdXNlIHBhZ2luZykgKi9cclxuICAgIHBhZ2VTaXplPzogbnVtYmVyO1xyXG4gICAgLyoqIEluZGV4IG9mIHBhZ2UgKGRlZmF1bHQgMCkgKi9cclxuICAgIHBhZ2U/OiBudW1iZXI7XHJcbiAgICByZXNwb25zZUZvcm1hdD86IElGcW5JdGVtUmVzcG9uc2VGb3JtYXQ7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBmcW4gcHJvcGVydHkgaXRlbS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJRnFuUHJvcGVydHlJdGVtIHtcclxuICAgIHByb3BlcnR5RnFuOiBzdHJpbmc7XHJcbiAgICAvKiogU2l6ZSBvZiBwYWdlIChkZWZhdWx0IDAgLSBkbyBub3QgdXNlIHBhZ2luZykgKi9cclxuICAgIHBhZ2VTaXplPzogbnVtYmVyO1xyXG4gICAgLyoqIEluZGV4IG9mIHBhZ2UgKGRlZmF1bHQgMCkgKi9cclxuICAgIHBhZ2U/OiBudW1iZXI7XHJcbiAgICByZXNwb25zZUZvcm1hdD86IElGcW5JdGVtUmVzcG9uc2VGb3JtYXQ7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBxdWVyeSBpdGVtLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElRdWVyeUl0ZW0ge1xyXG4gICAgLyoqIFF1ZXJ5IEV4cHJlc3Npb24gKi9cclxuICAgIHF1ZXJ5OiBzdHJpbmc7XHJcbiAgICByZXNwb25zZUZvcm1hdD86IElGcW5JdGVtUmVzcG9uc2VGb3JtYXQ7XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEluc3RhbmNlRnFuSXRlbSA9IElGcW5JdGVtIHwgSUZxblByb3BlcnR5SXRlbTtcclxuZXhwb3J0IHR5cGUgSW5zdGFuY2VRdWVyeUl0ZW0gPSBJUXVlcnlJdGVtO1xyXG5cclxuLyoqXHJcbiAqIFRoZSBJbnN0YW5jZSBTZXJ2aWNlIHJldHJpZXZlcyBpdGVtIChpbnN0YW5jZSkgZGF0YSBmcm9tIHRoZSBtb2RlbC4gSXRlbXMgY2FuIGJlIHJlcXVlc3RlZCBlaXRoZXIgYnkgdXNpbmcgYSBsaXN0IG9mXHJcbiAqIGZ1bGx5IHF1YWxpZmllZCBuYW1lcyAoRlFOKSBvciBhIHF1ZXJ5IGV4cHJlc3Npb24uIEEgc2luZ2xlIHJlcXVlc3QgY2FuIGluY2x1ZGUgbXVsdHBsZSBGUU4gbGlzdHMgYW5kIG11bHRpcGxlIHF1ZXJ5XHJcbiAqIGV4cHJlc3Npb25zLlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgSW5zdGFuY2VTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvaW5zdGFuY2UvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ha2VzIGEgcmVxdWVzdCB0byB0aGUgSlNPTiBJbnN0YW5jZSBzZXJ2aWNlIG9uIHRoZSBzZXJ2ZXIuXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRJbnN0YW5jZXMoaW5zdGFuY2VSZXF1ZXN0OiBJbnN0YW5jZVJlcXVlc3QpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QoaW5zdGFuY2VSZXF1ZXN0KTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEluc3RhbmNlUmVxdWVzdCB7XHJcbiAgICBwcml2YXRlIHF1ZXJpZXM6IEluc3RhbmNlUXVlcnlJdGVtW107XHJcbiAgICBwcml2YXRlIGZxbnM6IEluc3RhbmNlRnFuSXRlbVtdO1xyXG4gICAgcHVibGljIGNhbWVsQ2FzZVByb3BlcnR5TmFtZXM6IGJvb2xlYW47XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBJbnN0YW5jZSByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gY2FtZWxDYXNlUHJvcGVydHlOYW1lcyAtIHRydWUgaWYgcHJvcGVydHkgbmFtZXMgYXJlIGNhbWVsQ2FzZS4gRGVmYXVsdCBpcyB0cnVlLlxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihjYW1lbENhc2VQcm9wZXJ0eU5hbWVzPzogYm9vbGVhbikge1xyXG4gICAgICAgIGlmICghXy5pc05pbChjYW1lbENhc2VQcm9wZXJ0eU5hbWVzKSkge1xyXG4gICAgICAgICAgICB0aGlzLmNhbWVsQ2FzZVByb3BlcnR5TmFtZXMgPSBjYW1lbENhc2VQcm9wZXJ0eU5hbWVzO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2FtZWxDYXNlUHJvcGVydHlOYW1lcyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIFJlc3BvbnNlIEZvcm1hdCB0byBJbnN0YW5jZSBSZXF1ZXN0IE9iamVjdFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGFkZFJlc3BvbnNlRm9ybWF0KFxyXG4gICAgICAgIGluc3RhbmNlRnFuSXRlbTogSW5zdGFuY2VGcW5JdGVtIHwgSW5zdGFuY2VRdWVyeUl0ZW0sIGluY2x1ZGVBY2Nlc3NDb250cm9sOiBib29sZWFuLFxyXG4gICAgICAgIHJldHJpZXZhbERlcHRoOiBudW1iZXIsIGluY2x1ZGVTaG9ydGN1dHM6IGJvb2xlYW4pIHtcclxuXHJcbiAgICAgICAgaW5zdGFuY2VGcW5JdGVtLnJlc3BvbnNlRm9ybWF0ID0ge307XHJcbiAgICAgICAgaWYgKGluY2x1ZGVBY2Nlc3NDb250cm9sKSB7XHJcbiAgICAgICAgICAgIGluc3RhbmNlRnFuSXRlbS5yZXNwb25zZUZvcm1hdC5pbmNsdWRlQWNsID0gaW5jbHVkZUFjY2Vzc0NvbnRyb2w7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghXy5pc05pbChyZXRyaWV2YWxEZXB0aCkgJiYgcmV0cmlldmFsRGVwdGggPiAwKSB7XHJcbiAgICAgICAgICAgIGluc3RhbmNlRnFuSXRlbS5yZXNwb25zZUZvcm1hdC5kZXB0aCA9IHJldHJpZXZhbERlcHRoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoaW5jbHVkZVNob3J0Y3V0cykge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUZxbkl0ZW0ucmVzcG9uc2VGb3JtYXQuaW5jbHVkZVNob3J0Y3V0cyA9IGluY2x1ZGVTaG9ydGN1dHM7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIEl0ZW0gRlFOIHRvIEluc3RhbmNlIFJlcXVlc3QgT2JqZWN0XHJcbiAgICAgKiBAcGFyYW0gZnFuIC0gRlFOIHRvIGFkZCB0byB0aGUgcmVxdWVzdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVBY2Nlc3NDb250cm9sIC0gV2hldGhlciB0byBpbmNsdWRlIEFDTCBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKiBAcGFyYW0gcmV0cmlldmFsRGVwdGggLSBEZXB0aCBvZiByZXNwb25zZSBvYmplY3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlU2hvcnRjdXRzIC0gV2hldGhlciB0byBpbmNsdWRlIHNob3J0Y3V0cyBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBhZGRJdGVtRnFuKGZxbjogc3RyaW5nLCBpbmNsdWRlQWNjZXNzQ29udHJvbD86IGJvb2xlYW4sIHJldHJpZXZhbERlcHRoPzogbnVtYmVyLCBpbmNsdWRlU2hvcnRjdXRzPzogYm9vbGVhbikge1xyXG4gICAgICAgIGNvbnN0IGluc3RhbmNlRnFuSXRlbTogSW5zdGFuY2VGcW5JdGVtID0ge1xyXG4gICAgICAgICAgICBmcW46IGZxblxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hZGRSZXNwb25zZUZvcm1hdChpbnN0YW5jZUZxbkl0ZW0sIGluY2x1ZGVBY2Nlc3NDb250cm9sLCByZXRyaWV2YWxEZXB0aCwgaW5jbHVkZVNob3J0Y3V0cyk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmZxbnMpIHtcclxuICAgICAgICAgICAgdGhpcy5mcW5zID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZnFucy5wdXNoKGluc3RhbmNlRnFuSXRlbSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBZGQgSXRlbSBGUU4gdG8gSW5zdGFuY2UgUmVxdWVzdCBPYmplY3QgLSBFeGNsdWRlIFZvbGF0aWxlIFByb3BlcnRpZXNcclxuICAgICAqIEBwYXJhbSBmcW4gLSBGUU4gdG8gYWRkIHRvIHRoZSByZXF1ZXN0XHJcbiAgICAgKiBAcGFyYW0gaW5jbHVkZUFjY2Vzc0NvbnRyb2wgLSBXaGV0aGVyIHRvIGluY2x1ZGUgQUNMIGluIHJlc3BvbnNlIG9iamVjdCBvciBub3RcclxuICAgICAqIEBwYXJhbSByZXRyaWV2YWxEZXB0aCAtIERlcHRoIG9mIHJlc3BvbnNlIG9iamVjdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVTaG9ydGN1dHMgLSBXaGV0aGVyIHRvIGluY2x1ZGUgc2hvcnRjdXRzIGluIHJlc3BvbnNlIG9iamVjdCBvciBub3RcclxuICAgICAqL1xyXG4gICAgcHVibGljIGFkZEl0ZW1GcW5FeGNsdWRlVm9sYXRpbGUoXHJcbiAgICAgICAgZnFuOiBzdHJpbmcsXHJcbiAgICAgICAgaW5jbHVkZUFjY2Vzc0NvbnRyb2w6IGJvb2xlYW4sXHJcbiAgICAgICAgcmV0cmlldmFsRGVwdGg6IG51bWJlcixcclxuICAgICAgICBpbmNsdWRlU2hvcnRjdXRzOiBib29sZWFuKSB7XHJcblxyXG4gICAgICAgIGNvbnN0IGluc3RhbmNlRnFuSXRlbTogSW5zdGFuY2VGcW5JdGVtID0ge1xyXG4gICAgICAgICAgICBmcW46IGZxbixcclxuICAgICAgICAgICAgZXhjbHVkZVZvbGF0aWxlUHJvcGVydGllczogdHJ1ZVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hZGRSZXNwb25zZUZvcm1hdChpbnN0YW5jZUZxbkl0ZW0sIGluY2x1ZGVBY2Nlc3NDb250cm9sLCByZXRyaWV2YWxEZXB0aCwgaW5jbHVkZVNob3J0Y3V0cyk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmZxbnMpIHtcclxuICAgICAgICAgICAgdGhpcy5mcW5zID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZnFucy5wdXNoKGluc3RhbmNlRnFuSXRlbSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBZGQgUHJvcGVydHkgRlFOIHRvIEluc3RhbmNlIFJlcXVlc3QgT2JqZWN0XHJcbiAgICAgKiBAcGFyYW0gZnFuIC0gRlFOIHRvIGFkZCB0byB0aGUgcmVxdWVzdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVBY2Nlc3NDb250cm9sIC0gV2hldGhlciB0byBpbmNsdWRlIEFDTCBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKiBAcGFyYW0gcmV0cmlldmFsRGVwdGggLSBEZXB0aCBvZiByZXNwb25zZSBvYmplY3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlU2hvcnRjdXRzIC0gV2hldGhlciB0byBpbmNsdWRlIHNob3J0Y3V0cyBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKiBAcGFyYW0gcGFnZVNpemUgLSBTaXplIG9mIHJldHVybmVkIHBhZ2UgKGRlZmF1bHQgMCAtIGRvIG5vdCB1c2UgcGFnaW5nKVxyXG4gICAgICogQHBhcmFtIHBhZ2UgLSBJbmRleCBvZiByZXR1cm5lZCBwYWdlIChkZWZhdWx0IDApXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBhZGRQcm9wZXJ0eUZxbihcclxuICAgICAgICBmcW46IHN0cmluZywgaW5jbHVkZUFjY2Vzc0NvbnRyb2w/OiBib29sZWFuLCByZXRyaWV2YWxEZXB0aD86IG51bWJlcixcclxuICAgICAgICBpbmNsdWRlU2hvcnRjdXRzPzogYm9vbGVhbiwgcGFnZVNpemU/OiBudW1iZXIsIHBhZ2U/OiBudW1iZXIpIHtcclxuXHJcbiAgICAgICAgY29uc3QgaW5zdGFuY2VGcW5Qcm9wZXJ0eUl0ZW06IEluc3RhbmNlRnFuSXRlbSA9IHtcclxuICAgICAgICAgICAgcHJvcGVydHlGcW46IGZxbixcclxuICAgICAgICAgICAgZXhjbHVkZVZvbGF0aWxlUHJvcGVydGllczogdHJ1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYWRkUmVzcG9uc2VGb3JtYXQoaW5zdGFuY2VGcW5Qcm9wZXJ0eUl0ZW0sIGluY2x1ZGVBY2Nlc3NDb250cm9sLCByZXRyaWV2YWxEZXB0aCwgaW5jbHVkZVNob3J0Y3V0cyk7XHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHBhZ2VTaXplKSkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUZxblByb3BlcnR5SXRlbS5wYWdlU2l6ZSA9IHBhZ2VTaXplO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIV8uaXNOaWwocGFnZSkpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2VGcW5Qcm9wZXJ0eUl0ZW0ucGFnZSA9IHBhZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghdGhpcy5mcW5zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucyA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmZxbnMucHVzaChpbnN0YW5jZUZxblByb3BlcnR5SXRlbSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBZGQgUXVlcnkgRXhwcmVzc2lvbiB0byBJbnN0YW5jZSBSZXF1ZXN0IE9iamVjdFxyXG4gICAgICogQHBhcmFtIHF1ZXJ5RXhwcmVzc2lvbiAtIFF1ZXJ5IEV4cHJlc3Npb24gdG8gYWRkIHRvIHRoZSByZXF1ZXN0XHJcbiAgICAgKiBAcGFyYW0gaW5jbHVkZUFjY2Vzc0NvbnRyb2wgLSBXaGV0aGVyIHRvIGluY2x1ZGUgQUNMIGluIHJlc3BvbnNlIG9iamVjdCBvciBub3RcclxuICAgICAqIEBwYXJhbSByZXRyaWV2YWxEZXB0aCAtIERlcHRoIG9mIHJlc3BvbnNlIG9iamVjdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVTaG9ydGN1dHMgLSBXaGV0aGVyIHRvIGluY2x1ZGUgc2hvcnRjdXRzIGluIHJlc3BvbnNlIG9iamVjdCBvciBub3RcclxuICAgICAqL1xyXG4gICAgcHVibGljIGFkZFF1ZXJ5KFxyXG4gICAgICAgIHF1ZXJ5RXhwcmVzc2lvbjogc3RyaW5nLCBpbmNsdWRlQWNjZXNzQ29udHJvbD86IGJvb2xlYW4sXHJcbiAgICAgICAgcmV0cmlldmFsRGVwdGg/OiBudW1iZXIsIGluY2x1ZGVTaG9ydGN1dHM/OiBib29sZWFuKSB7XHJcblxyXG4gICAgICAgIGNvbnN0IGluc3RhbmNlUXVlcnlJdGVtOiBJbnN0YW5jZVF1ZXJ5SXRlbSA9IHtcclxuICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5RXhwcmVzc2lvblxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hZGRSZXNwb25zZUZvcm1hdChpbnN0YW5jZVF1ZXJ5SXRlbSwgaW5jbHVkZUFjY2Vzc0NvbnRyb2wsIHJldHJpZXZhbERlcHRoLCBpbmNsdWRlU2hvcnRjdXRzKTtcclxuICAgICAgICBpZiAoIXRoaXMucXVlcmllcykge1xyXG4gICAgICAgICAgICB0aGlzLnF1ZXJpZXMgPSBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5xdWVyaWVzLnB1c2goaW5zdGFuY2VRdWVyeUl0ZW0pO1xyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YnNjcmlwdGlvbiwgU3ViamVjdCwgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgbWFwLCBleHBhbmQsIGNvbmNhdE1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnLCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUwgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IGlkZW50aWZpZXIsIElSZXNwb25zZSB9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHByb3h5IHZhbHVlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJTGl2ZVJlc3BvbnNlUHJveHlWYWx1ZSB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIHR5cGU6IHN0cmluZztcclxuICAgIGNyZWF0ZWRPbj86IHN0cmluZztcclxuICAgIGNyZWF0ZWRPbk9mZnNldD86IG51bWJlcjtcclxuICAgIG1vZGlmaWVkT24/OiBzdHJpbmc7XHJcbiAgICBtb2RpZmllZE9uT2Zmc2V0PzogbnVtYmVyO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHJlc3BvbnNlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJTGl2ZVJlc3BvbnNlIGV4dGVuZHMgSVJlc3BvbnNlIHtcclxuICAgIHY6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBJTGl2ZVJlc3BvbnNlUHJveHlWYWx1ZVtdO1xyXG4gICAgcTogbnVtYmVyO1xyXG4gICAgdDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBMaXZlUmVzcG9uc2UgPSBJTGl2ZVJlc3BvbnNlW107XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHZxdCBpbnRlcm5hbCBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxWcXRPYmplY3Qge1xyXG4gICAgdjogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbiB8IElMaXZlUmVzcG9uc2VQcm94eVZhbHVlW107XHJcbiAgICBxOiBudW1iZXI7XHJcbiAgICB0OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcmVzcG9uc2Ugb2JqZWN0IGludGVybmFsIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElMaXZlUmVzcG9uc2VJbnRlcm5hbE9iamVjdCB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU/OiBzdHJpbmc7XHJcbiAgICBlbmdpbmVlcmluZ1VuaXQ/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZVR5cGU/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZTogSUxpdmVSZXNwb25zZUludGVybmFsVnF0T2JqZWN0O1xyXG59XHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcmVzcG9uc2UgaW50ZXJuYWwgKHJhdykgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSUxpdmVSZXNwb25zZUludGVybmFsIHtcclxuICAgIGZxbnNSZXN1bHRzPzogSUxpdmVSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbiAgICBxdWVyeVJlc3VsdHM/OiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIExpdmVSZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogTGl2ZSByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFucyBMaXN0IG9mIGZxbnMgKGlkZW50aWZpY2F0b3JzKSB0byBiZSB1c2VkIGZvciByZXF1ZXN0XHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKHJlYWRvbmx5IGZxbnM6IGlkZW50aWZpZXJbXVxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zID0gXy5jbG9uZShmcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBvbmUgZnFuIHRvIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIGFkZFxyXG4gICAgICovXHJcbiAgICBhZGRGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zLnB1c2goZnFuKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbW92ZSBvbmUgZnFuIGZyb20gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IF8uaW5kZXhPZih0aGlzLmZxbnMsIGZxbik7XHJcbiAgICAgICAgaWYgKGluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmZxbnMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIHNlcnZpY2UgcHJvdmlkZXMgYSBzZXQgb2YgbWV0aG9kcyBmb3Igc2VuZGluZyByZXF1ZXN0cyB0byBvYnRhaW4gbGl2ZSBkYXRhLlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgTGl2ZURhdGFTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG4gICAgLyoqIEBpbnRlcm5hbCBhY3R1YWwgcmVwZWF0ZWQgbGl2ZSByZXF1ZXN0IGZxbnMgKi9cclxuICAgIHByaXZhdGUgX2ZxbnM6IE1hcDxzdHJpbmcsIG51bWJlcj4gPSBuZXcgTWFwKCk7XHJcbiAgICBwcml2YXRlIF9yZXBlYXRlZERhdGFPYnNlcnZhYmxlOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT47XHJcbiAgICBwcml2YXRlIF9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3JlcGVhdGVkRGF0YVN1YmplY3Q6IFN1YmplY3Q8TGl2ZVJlc3BvbnNlPjtcclxuICAgIHByaXZhdGUgX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZTogYm9vbGVhbjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL2xpdmUvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIGxpdmUgcmVxdWVzdCB0byBzZXJ2ZXIsIGJ1dCBvbmx5IG9uY2UuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBsaXZlIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICovXHJcbiAgICBnZXRPbmNlKHJlcXVlc3Q6IExpdmVSZXF1ZXN0KTogT2JzZXJ2YWJsZTxMaXZlUmVzcG9uc2U+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpLnBpcGUoXHJcbiAgICAgICAgICAgIG1hcCgocmVzcG9uc2U6IElMaXZlUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmV0OiBMaXZlUmVzcG9uc2UgPSBbXTtcclxuICAgICAgICAgICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKG9uZVJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldC5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogb25lUmVzdWx0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZxbjogb25lUmVzdWx0LmZxbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiBvbmVSZXN1bHQudmFsdWVUeXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmdpbmVlcmluZ1VuaXQ6IG9uZVJlc3VsdC5lbmdpbmVlcmluZ1VuaXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHY6IG9uZVJlc3VsdC52YWx1ZS52LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBxOiBvbmVSZXN1bHQudmFsdWUucSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdDogb25lUmVzdWx0LnZhbHVlLnRcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJldDtcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldElubmVyUmVwZWF0ZWRPYnNlcnZhYmxlKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QoeyBmcW5zOiBBcnJheS5mcm9tKHRoaXMuX2ZxbnMua2V5cygpKSB9KVxyXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlc3BvbnNlOiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldDogTGl2ZVJlc3BvbnNlID0gW107XHJcbiAgICAgICAgICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChvbmVSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IG9uZVJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcW46IG9uZVJlc3VsdC5mcW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogb25lUmVzdWx0LnZhbHVlVHlwZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5naW5lZXJpbmdVbml0OiBvbmVSZXN1bHQuZW5naW5lZXJpbmdVbml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2OiBvbmVSZXN1bHQudmFsdWUudixcclxuICAgICAgICAgICAgICAgICAgICAgICAgcTogb25lUmVzdWx0LnZhbHVlLnEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQ6IG9uZVJlc3VsdC52YWx1ZS50XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXQ7XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0aWFsaXplUmVwZWF0ZWREYXRhKCk6IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPiB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QgPSBuZXcgU3ViamVjdDxMaXZlUmVzcG9uc2U+KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX3JlcGVhdGVkRGF0YU9ic2VydmFibGUgfHwgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlKSB7XHJcbiAgICAgICAgICAgIGxldCByZXBlYXRlZEludGVydmFsID0gdGhpcy5jb25maWcuZGVmYXVsdFJlcGVhdGVkRGF0YUludGVydmFsIHx8IERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTDtcclxuICAgICAgICAgICAgcmVwZWF0ZWRJbnRlcnZhbCA9IHJlcGVhdGVkSW50ZXJ2YWwgKiAxMDAwO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZSA9IHRoaXMuX2dldElubmVyUmVwZWF0ZWRPYnNlcnZhYmxlKCk7XHJcbiAgICAgICAgICAgIC8vIEV4cGFuZCBjdXJyZW50IG9ic2VydmFibGUgc2VxdWVuY2UgYnkgcmVjdXJzaXZlbHkgaW52b2tpbmcgc2VsZWN0b3IgLVxyXG4gICAgICAgICAgICAvLyBhIHRpbWVyIGJhc2VkIG9uIGludGVydmFsLCB3aGljaCB3aWxsIHJlcGVhdCByZXF1ZXN0IGFuZCBwcm9jZXNzIHJlc3BvbnNlLlxyXG4gICAgICAgICAgICAvLyBPYnNlcnZhYmxlIHRpbWVyOlxyXG4gICAgICAgICAgICAvLyBSZXR1cm5zIGFuIG9ic2VydmFibGUgc2VxdWVuY2UgdGhhdCBwcm9kdWNlcyBhIHZhbHVlIGFmdGVyIGR1ZVRpbWUgaGFzIGVsYXBzZWQgYW5kIHRoZW4gYWZ0ZXIgZWFjaCBwZXJpb2QuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbiA9IHRoaXMuX3JlcGVhdGVkRGF0YU9ic2VydmFibGUucGlwZShcclxuICAgICAgICAgICAgICAgIGV4cGFuZCgoKSA9PiB0aW1lcihyZXBlYXRlZEludGVydmFsKS5waXBlKGNvbmNhdE1hcCgoKSA9PiB0aGlzLl9nZXRJbm5lclJlcGVhdGVkT2JzZXJ2YWJsZSgpKSkpXHJcbiAgICAgICAgICAgICkuc3Vic2NyaWJlKChyZXNwb25zZTogTGl2ZVJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0Lm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9LCAoZXJyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0LmVycm9yKGVycik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0LmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgcmVxdWVzdCBmb3IgbGl2ZSBkYXRhIHJlcGVhdGVkbHkuIEl0IHJlcGVhdGVkbHkgc2VuZHMgcmVxdWVzdHMgdG8gc2VydmVyLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgbGl2ZSByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqL1xyXG4gICAgZ2V0UmVwZWF0ZWRseShyZXF1ZXN0OiBMaXZlUmVxdWVzdCk6IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPiB7XHJcblxyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxMaXZlUmVzcG9uc2U+KChvYnNlcnZlcikgPT4ge1xyXG4gICAgICAgICAgICAvLyB3ZSByZWdpc3RlciBuZXcgaWRlbnRpZmljYXRvcnMgZm9yIHBlcmlvZGljIGxpdmUgdXBkYXRlc1xyXG4gICAgICAgICAgICBfLmVhY2gocmVxdWVzdC5mcW5zLCAoZnFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgbmV3VmFsID0gMDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mcW5zLmhhcyhmcW4pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VmFsID0gdGhpcy5fZnFucy5nZXQoZnFuKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2ZxbnMuc2V0KGZxbiwgKytuZXdWYWwpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5faW5pdGlhbGl6ZVJlcGVhdGVkRGF0YSgpO1xyXG4gICAgICAgICAgICBjb25zdCBzdWJzY3JpcHRpb24gPSB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpLnBpcGUobWFwKChjdXJyZW50UmVzcG9uc2U6IExpdmVSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF8uZmlsdGVyKGN1cnJlbnRSZXNwb25zZSwgKG8pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXy5pbmRleE9mKHJlcXVlc3QuZnFucywgby5mcW4pID4gLTE7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSkpLnN1YnNjcmliZSgocmVzcG9uc2U6IExpdmVSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH0sIChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyB3ZSB1bnJlZ2lzdGVyIGlkZW50aWZpY2F0b3JzIGZvciBwZXJpb2RpYyBsaXZlIHVwZGF0ZXNcclxuICAgICAgICAgICAgICAgIF8uZWFjaChyZXF1ZXN0LmZxbnMsIChmcW4pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbmV3VmFsID0gMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fZnFucy5oYXMoZnFuKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdWYWwgPSB0aGlzLl9mcW5zLmdldChmcW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAobmV3VmFsID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZxbnMuZGVsZXRlKGZxbik7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZnFucy5zZXQoZnFuLCAtLW5ld1ZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2ZxbnMuc2l6ZSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiIsIi8qIHRzbGludDpkaXNhYmxlOm5vLWJpdHdpc2UgKi9cclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRoZSBxdWFsaXR5LiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElRdWFsaXR5IHtcclxuICAvKiogZ29vZCwgYmFkLCB1bmNlcnRhaW4gb3Igbm90IGRlZmluZWQgcXVhbGl0eSB2YWx1ZSAqL1xyXG4gIG92ZXJhbGw6IHN0cmluZztcclxuICAvKiogT1BDIERBIHF1YWxpdHkgKi9cclxuICBkYT86IHN0cmluZztcclxuICAvKiogT1BDIGxpbWl0IHN0YXR1cyAqL1xyXG4gIGxpbWl0Pzogc3RyaW5nO1xyXG4gIC8qKiBPUEMgSERBIHF1YWxpdHkgKi9cclxuICBoZGE/OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIHNlcnZpY2UgcHJvdmlkZXMgYSBzZXQgb2YgbWV0aG9kcyBmb3IgZXZhbHVhdGluZyBPUEMgREEgcXVhbGl0eSwgT1BDIGxpbWl0XHJcbiAqIHN0YXR1cyBvciBPUEMgSERBIHF1YWxpdHkgYnkgcGFzc2VkIGFyZ3VtZW50LlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgT3BjUXVhbGl0eVNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eU1hc2sgPSAweGZmZkM7XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlNYXN0ZXJNYXNrID0gMHgwMEMwO1xyXG4gIHByaXZhdGUgb3BjSGRhUXVhbGl0eU1hc2sgPSAweGZmZmYwMDAwO1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5RmllbGRNYXNrcyA9IHtcclxuICAgIGxpbWl0RmllbGQ6IDB4MDAwMyxcclxuICAgIHN1YlN0YXR1c0ZpZWxkOiAweDAwM0MsXHJcbiAgICBxdWFsaXR5OiAweDAwQzBcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5TWFzdGVyID0ge1xyXG4gICAgYmFkOiAweDAwMDAsXHJcbiAgICB1bmNlcnRhaW46IDB4MDA0MCxcclxuICAgIG5vdERlZmluZWQ6IDB4MDA4MCxcclxuICAgIGdvb2Q6IDB4MDBDMFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlTdGF0dXMgPSB7XHJcbiAgICBiYWQ6IDB4MDAwMCxcclxuICAgIGNvbmZpZ0Vycm9yOiAweDAwMDQsXHJcbiAgICBub3RDb25uZWN0ZWQ6IDB4MDAwOCxcclxuICAgIGRldmljZUZhaWx1cmU6IDB4MDAwYyxcclxuICAgIHNlbnNvckZhaWx1cmU6IDB4MDAxMCxcclxuICAgIGxhc3RLbm93bjogMHgwMDE0LFxyXG4gICAgY29tbUZhaWx1cmU6IDB4MDAxOCxcclxuICAgIG91dE9mU2VydmljZTogMHgwMDFjLFxyXG4gICAgaW5pdGlhbGl6aW5nOiAweDAwMjAsXHJcbiAgICB1bmNlcnRhaW46IDB4MDA0MCxcclxuICAgIGxhc3RVc2FibGU6IDB4MDA0NCxcclxuICAgIHNlbnNvck5vdEFjY3VyYXRlOiAweDAwNTAsXHJcbiAgICBlbmdVbml0c0V4Y2VlZGVkOiAweDAwNTQsXHJcbiAgICBzdWJOb3JtYWw6IDB4MDA1OCxcclxuICAgIGdvb2Q6IDB4MDBDMCxcclxuICAgIGxvY2FsT3ZlcnJpZGU6IDB4MDBEOFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlMaW1pdCA9IHtcclxuICAgIGxpbWl0T2s6IDB4MDAwMCxcclxuICAgIGxpbWl0TG93OiAweDAwMDEsXHJcbiAgICBsaW1pdEhpZ2g6IDB4MDAwMixcclxuICAgIGNvbnN0YW50OiAweDAwMDNcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjSGRhUXVhbGl0eSA9IHtcclxuICAgIGV4dHJhRGF0YTogMHgwMDAxMDAwMCxcclxuICAgIGludGVycG9sYXRlZDogMHgwMDAyMDAwMCxcclxuICAgIHJhdzogMHgwMDA0MDAwMCxcclxuICAgIGNhbGN1bGF0ZWQ6IDB4MDAwODAwMDAsXHJcbiAgICBub0JvdW5kOiAweDAwMTAwMDAwLFxyXG4gICAgbm9EYXRhOiAweDAwMjAwMDAwLFxyXG4gICAgZGF0YUxvc3Q6IDB4MDA0MDAwMDAsXHJcbiAgICBjb252ZXJzaW9uOiAweDAwODAwMDAwLFxyXG4gICAgcGFydGlhbDogMHgwMTAwMDAwMFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvdmVyYWxsTWVzc2FnZXMgPSB7XHJcbiAgICAweDAwMDA6ICdCYWQnLFxyXG4gICAgMHgwMDQwOiAnVW5jZXJ0YWluJyxcclxuICAgIDB4MDA4MDogJ05vdCBkZWZpbmVkJyxcclxuICAgIDB4MDBDMDogJ0dvb2QnXHJcbiAgfTtcclxuXHJcbiAgcHJpdmF0ZSBkZXRhaWxzTWVzc2FnZXMgPSB7XHJcbiAgICAvLyBMaW1pdCBzdGF0dXNcclxuICAgIDB4MDAwMDogJ05vdCBsaW1pdGVkJyxcclxuICAgIDB4MDAwMTogJ0xvdyBsaW1pdGVkJyxcclxuICAgIDB4MDAwMjogJ0hpZ2ggbGltaXRlZCcsXHJcbiAgICAweDAwMDM6ICdDb25zdGFudCcsXHJcbiAgICAvLyBCYWRcclxuICAgIDB4MDAwNDogJ0NvbmZpZyBlcnJvcicsXHJcbiAgICAweDAwMDg6ICdOb3QgY29ubmVjdGVkJyxcclxuICAgIDB4MDAwYzogJ0RldmljZSBmYWlsdXJlJyxcclxuICAgIDB4MDAxMDogJ1NlbnNvciBmYWlsdXJlJyxcclxuICAgIDB4MDAxNDogJ0xhc3Qga25vd24nLFxyXG4gICAgMHgwMDE4OiAnQ29tbSBmYWlsdXJlJyxcclxuICAgIDB4MDAxQzogJ091dCBvZiBzZXJ2aWNlJyxcclxuICAgIDB4MDAyMDogJ0luaXRpYWxpemluZycsXHJcbiAgICAvLyBVbmNlcnRhaW5cclxuICAgIDB4MDA0NDogJ0xhc3QgdXNhYmxlJyxcclxuICAgIDB4MDA1MDogJ1NlbnNvcnMgbm90IGFjY3VyYXRlJyxcclxuICAgIDB4MDA1NDogJ0VuZ2luZWVyaW5nIHVuaXRzIGV4Y2VlZGVkJyxcclxuICAgIDB4MDA1ODogJ1N1Yi1Ob3JtYWwnLFxyXG4gICAgLy8gR29vZFxyXG4gICAgMHgwMEQ4OiAnTG9jYWwgb3ZlcnJpZGUnLFxyXG4gICAgLy8gSGRhIGZsYWdzXHJcbiAgICAweDAwMDEwMDAwOiAnRXh0cmEgZGF0YScsXHJcbiAgICAweDAwMDIwMDAwOiAnSW50ZXJwb2xhdGVkJyxcclxuICAgIDB4MDAwNDAwMDA6ICdSYXcnLFxyXG4gICAgMHgwMDA4MDAwMDogJ0NhbGN1bGF0ZWQnLFxyXG4gICAgMHgwMDEwMDAwMDogJ05vIGJvdW5kJyxcclxuICAgIDB4MDAyMDAwMDA6ICdObyBkYXRhJyxcclxuICAgIDB4MDA0MDAwMDA6ICdEYXRhIGxvc3QnLFxyXG4gICAgMHgwMDgwMDAwMDogJ0NvbnZlcnNpb24nLFxyXG4gICAgMHgwMTAwMDAwMDogJ1BhcnRpYWwnXHJcbiAgfTtcclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24gb2YgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc09iamVjdChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IElRdWFsaXR5IHtcclxuICAgIGxldCBtYXNrOiBudW1iZXI7XHJcbiAgICBjb25zdCBxdWFsaXR5ID0ge30gYXMgSVF1YWxpdHk7XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyTWFzaztcclxuICAgIHF1YWxpdHkub3ZlcmFsbCA9IHRoaXMub3ZlcmFsbE1lc3NhZ2VzW21hc2tdO1xyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eU1hc2s7XHJcbiAgICBpZiAobWFzayAmJiB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXSkge1xyXG4gICAgICBxdWFsaXR5LmRhID0gdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza107XHJcbiAgICB9XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5saW1pdEZpZWxkO1xyXG4gICAgaWYgKG1hc2sgJiYgdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza10pIHtcclxuICAgICAgcXVhbGl0eS5saW1pdCA9IHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdO1xyXG4gICAgfVxyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0hkYVF1YWxpdHlNYXNrO1xyXG4gICAgaWYgKG1hc2sgJiYgdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza10pIHtcclxuICAgICAgcXVhbGl0eS5oZGEgPSB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXTtcclxuICAgIH1cclxuICAgIHJldHVybiBxdWFsaXR5O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhIHN0cmluZyB3aGljaCBpcyBhIHdyaXR0ZW4gcmVwcmVzZW50YXRpb24gb2YgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc1N0cmluZyhxdWFsaXR5QXNJbnQ6IG51bWJlcikge1xyXG4gICAgbGV0IGhhc0RhUXVhbGl0eSA9IGZhbHNlO1xyXG4gICAgY29uc3QgcU9iaiA9IHRoaXMuYXNPYmplY3QocXVhbGl0eUFzSW50KTtcclxuICAgIGxldCBxU3RyaW5nOiBzdHJpbmc7XHJcblxyXG4gICAgcVN0cmluZyA9IHFPYmoub3ZlcmFsbDtcclxuICAgIGlmIChxT2JqLmRhKSB7XHJcbiAgICAgIHFTdHJpbmcgPSBxU3RyaW5nICsgJzogJyArIHFPYmouZGE7XHJcbiAgICAgIGhhc0RhUXVhbGl0eSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAocU9iai5saW1pdCkge1xyXG4gICAgICBxU3RyaW5nID0gcVN0cmluZyArXHJcbiAgICAgICAgKGhhc0RhUXVhbGl0eSA/ICcsICcgOiAnOiAnKSArIHFPYmoubGltaXQ7XHJcbiAgICAgIGhhc0RhUXVhbGl0eSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBpZiAocU9iai5oZGEpIHtcclxuICAgICAgcVN0cmluZyA9IHFTdHJpbmcgK1xyXG4gICAgICAgIChoYXNEYVF1YWxpdHkgPyAnLCAnIDogJzogJykgKyBxT2JqLmhkYTtcclxuICAgIH1cclxuICAgIHJldHVybiBxU3RyaW5nO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgT1BDIERBIHF1YWxpdHkgcG9ydGlvbiAobG93ZXIgMTYgYml0cykuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzaztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBsaW1pdCBzdGF0dXMgcG9ydGlvbi4gKG5vdCBsaW1pdGVkLCBsb3cgbGltaXRlZCwgaGlnaCBsaW1pdGVkIG9yIGNvbnN0YW50KS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MubGltaXRGaWVsZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBEQSBNYXN0ZXIgcXVhbGl0eSBwb3J0aW9uIChnb29kLCB1bmNlcnRhaW4sIGJhZCwgb3IgdW5kZWZpbmVkKS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGdldFNpbXBsZVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyTWFzaztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBIREEgcXVhbGl0eSBwb3J0aW9uICh1cHBlciAxNiBiaXRzKS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50XHJcbiAgICovXHJcbiAgcHVibGljIGdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjSGRhUXVhbGl0eU1hc2s7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBIG1ldGhvZCBmb3IgY2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBpcyBvZiBnb29kIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0dvb2QocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAocXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLnF1YWxpdHkpID09PSB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlci5nb29kO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQSBtZXRob2QgZm9yIGNoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaXMgb2YgdW5jZXJ0YWluIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc1VuY2VydGFpbihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIChxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MucXVhbGl0eSkgPT09IHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyLnVuY2VydGFpbjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEEgbWV0aG9kIGZvciBjaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGlzIG9mIGJhZCBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNCYWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAocXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLnF1YWxpdHkpID09PSB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlci5iYWQ7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUNvbmZpZ0Vycm9yKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb25maWdFcnJvcikgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbmZpZ0Vycm9yO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYU5vdENvbm5lY3RlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubm90Q29ubmVjdGVkKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubm90Q29ubmVjdGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYURldmljZUZhaWx1cmUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmRldmljZUZhaWx1cmUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5kZXZpY2VGYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVNlbnNvckZhaWx1cmUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvckZhaWx1cmUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JGYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxhc3RLbm93bihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdEtub3duKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdEtub3duO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUNvbW1GYWlsdXJlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb21tRmFpbHVyZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbW1GYWlsdXJlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYU91dE9mU2VydmljZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMub3V0T2ZTZXJ2aWNlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMub3V0T2ZTZXJ2aWNlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUluaXRpYWxpemluZyhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuaW5pdGlhbGl6aW5nKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuaW5pdGlhbGl6aW5nO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxhc3RVc2FibGUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxhc3RVc2FibGUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sYXN0VXNhYmxlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVNlbnNvck5vdEFjY3VyYXRlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JOb3RBY2N1cmF0ZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvck5vdEFjY3VyYXRlO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUVuZ1VuaXRzRXhjZWVkZWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmVuZ1VuaXRzRXhjZWVkZWQpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5lbmdVbml0c0V4Y2VlZGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYVN1Yk5vcm1hbChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc3ViTm9ybWFsKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc3ViTm9ybWFsO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgREEgcXVhbGl0eSAoZ29vZCwgYmFkLCB1bmNlcnRhaW4pIHdpdGggYXBwcm9wcmlhdGUgc3Vic3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNEYUxvY2FsT3ZlcnJpZGUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxvY2FsT3ZlcnJpZGUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sb2NhbE92ZXJyaWRlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRPayhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0T2spID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0T2s7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBsaW1pdCBzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0xpbWl0TG93KHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRMb3cpID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0TG93O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgbGltaXQgc3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNMaW1pdEhpZ2gocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdEhpZ2gpID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0SGlnaDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRDb25zdGFudChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmNvbnN0YW50KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5jb25zdGFudDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhRXh0cmFEYXRhKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmV4dHJhRGF0YSkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5leHRyYURhdGE7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUludGVycG9sYXRlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5pbnRlcnBvbGF0ZWQpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuaW50ZXJwb2xhdGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFSYXcocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkucmF3KSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LnJhdztcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhQ2FsY3VsYXRlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5jYWxjdWxhdGVkKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmNhbGN1bGF0ZWQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYU5vQm91bmQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkubm9Cb3VuZCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5ub0JvdW5kO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFOb0RhdGEocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkubm9EYXRhKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5Lm5vRGF0YTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhRGF0YUxvc3QocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuZGF0YUxvc3QpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuZGF0YUxvc3Q7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUNvbnZlcnNpb24ocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuY29udmVyc2lvbikgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5jb252ZXJzaW9uO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFQYXJ0aWFsKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LnBhcnRpYWwpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkucGFydGlhbDtcclxuICB9XHJcbn1cclxuXHJcbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0ICogYXMgbW9tZW50IGZyb20gJ21vbWVudC10aW1lem9uZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBNb21lbnRIZWxwZXJTZXJ2aWNlIHtcclxuICAgIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCA9ICdZWVlZLU1NLUREVEhIOm1tOnNzLlNTU1taXSc7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVFpfRlVMTCA9ICdZWVlZLU1NLUREVEhIOm1tOnNzLlNTU1onO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIGFwcGx5IHRpbWV6b25lIHRvIFVUQyBzdHJpbmcuXHJcbiAgICAgKiBSZXR1cm5zIGRhdGUgc3RyaW5nIGluIG1heGltdW0gamF2YXNjcmlwdCByZXNvbHV0aW9uIHBvc3NpYmxlLCBzdXBwb3J0ZWQgYnkgdXNpbmcgbW9tZW50IGxpYnJhcnkgKEphdmFzY3JpcHQgZGF0ZSAtIG1pbGxpc2Vjb25kcykuXHJcbiAgICAgKiBSZXNvbHV0aW9uIGZvciB0aW1lIGFmdGVyIG1pbGxpc2Vjb25kcyB3aWxsIGJlIGxvc3QuXHJcbiAgICAgKiBAcGFyYW0gZGF0ZXRpbWUgZGF0ZXRpbWUgc3RyaW5nIGluIFVUQyBmb3JtYXRcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSB0aW1lem9uZSB0byBhcHBseVxyXG4gICAgICogSWYgd29ya2luZyB3aXRoIHRpbWV6b25lIGluIGRhdGV0aW1lIHN0cmluZyBpdCBpcyByZWNvbW1lbmRlZCB0byB1c2UgbW9tZW50LnBhcnNlWm9uZSB0byBwcmVzZXJ2ZSB0aW1lem9uZSBpbmZvcm1hdGlvbi5cclxuICAgICAqL1xyXG4gICAgcHVibGljIHN0YXRpYyBhcHBseVRpbWV6b25lKGRhdGV0aW1lOiBzdHJpbmcsIHRpbWV6b25lOiBzdHJpbmcpIHtcclxuICAgICAgY29uc3QgbURhdGUgPSBtb21lbnQudXRjKGRhdGV0aW1lKTtcclxuICAgICAgbURhdGUudHoodGltZXpvbmUpO1xyXG4gICAgICByZXR1cm4gbURhdGUuZm9ybWF0KHRoaXMuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9UWl9GVUxMKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIGdldEFsbFRpbWV6b25lcygpIHtcclxuICAgICAgICByZXR1cm4gbW9tZW50LnR6Lm5hbWVzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBpc1ZhbGlkVGltZXpvbmUodGltZXpvbmUpIHtcclxuICAgICAgcmV0dXJuIHRpbWV6b25lICYmIG1vbWVudC50ei56b25lKHRpbWV6b25lKTtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgKiBhcyBtb21lbnQgZnJvbSAnbW9tZW50LXRpbWV6b25lJztcclxuaW1wb3J0IHsgT3BjUXVhbGl0eVNlcnZpY2UgfSBmcm9tICcuL29wYy1xdWFsaXR5LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAsIGNvbmNhdE1hcCwgZXhwYW5kIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcsIERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTCB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgaWRlbnRpZmllciwgSVJlc3BvbnNlIH0gZnJvbSAnLi9zaGFyZWQnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTW9tZW50SGVscGVyU2VydmljZSB9IGZyb20gJy4vbW9tZW50LWhlbHBlci5zZXJ2aWNlJztcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHZxdCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMge1xyXG4gICAgdjogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbjtcclxuICAgIHE6IG51bWJlcjtcclxuICAgIHQ6IHN0cmluZztcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdnF0IGxpc3Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2UgZXh0ZW5kcyBJUmVzcG9uc2Uge1xyXG4gICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNSZXNwb25zZSB7XHJcbiAgICB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZFJlc3BvbnNlO1xyXG4gICAgcmVzdWx0czogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVtdO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBUaW1lc2VyaWVzUmVzcG9uc2UgPSBJVGltZXNlcmllc1Jlc3BvbnNlO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgaW50ZXJuYWwgb2JqZWN0IHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdCB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU/OiBzdHJpbmc7XHJcbiAgICBlbmdpbmVlcmluZ1VuaXQ/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZVR5cGU/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHRpbWUgcGVyaW9kIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZVBlcmlvZFJlc3BvbnNlIHtcclxuICAgIHN0YXJ0OiBzdHJpbmc7XHJcbiAgICBlbmQ6IHN0cmluZztcclxuICAgIGR1cmF0aW9uOiBudW1iZXI7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIGludGVybmFsIChyYXcpIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCB7XHJcbiAgICB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZFJlc3BvbnNlO1xyXG4gICAgZnFuc1Jlc3VsdHM/OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxuICAgIHF1ZXJ5UmVzdWx0cz86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXF1ZXN0IHRpbWUgcGVyaW9kIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZVBlcmlvZCB7XHJcbiAgICBzdGFydD86IERhdGUgfCBtb21lbnQuTW9tZW50O1xyXG4gICAgZW5kPzogRGF0ZSB8IG1vbWVudC5Nb21lbnQ7XHJcbiAgICBkdXJhdGlvbj86IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGVudW0gVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHtcclxuICAgIGluY2x1ZGVHb29kID0gMSxcclxuICAgIGluY2x1ZGVCYWQgPSAyLFxyXG4gICAgaW5jbHVkZVVuY2VydGFpbiA9IDQsXHJcbiAgICBpbmNsdWRlQWxsID0gN1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0IHtcclxuICAgIHdob2xlSW50ZXJ2YWwgPSAnd2hvbGVJbnRlcnZhbCcsXHJcbiAgICBpbmNyZW1lbnRzID0gJ2luY3JlbWVudHMnXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFNhbXBsaW5nVHlwZXMge1xyXG4gICAgSW50ZXJwb2xhdGl2ZSA9ICdJbnRlcnBvbGF0aXZlJyxcclxuICAgIFNhbXBsZUFuZEhvbGQgPSAnU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBMaW5lYXIgPSAnTGluZWFyJyxcclxuICAgIFRvdGFsID0gJ1RvdGFsJyxcclxuICAgIFN1bSA9ICdTdW0nLFxyXG4gICAgQXZlcmFnZSA9ICdBdmVyYWdlJyxcclxuICAgIFRpbWVBdmVyYWdlID0gJ1RpbWVBdmVyYWdlJyxcclxuICAgIENvdW50ID0gJ0NvdW50JyxcclxuICAgIFN0YW5kYXJkRGV2aWF0aW9uID0gJ1N0YW5kYXJkRGV2aWF0aW9uJyxcclxuICAgIE1pbmltdW1BY3R1YWxUaW1lID0gJ01pbmltdW1BY3R1YWxUaW1lJyxcclxuICAgIE1heGltdW0gPSAnTWF4aW11bScsXHJcbiAgICBTdGFydCA9ICdTdGFydCcsXHJcbiAgICBFbmQgPSAnRW5kJyxcclxuICAgIERlbHRhID0gJ0RlbHRhJyxcclxuICAgIFZhcmlhbmNlID0gJ1ZhcmlhbmNlJyxcclxuICAgIFJhbmdlID0gJ1JhbmdlJyxcclxuICAgIER1cmF0aW9uR29vZCA9ICdEdXJhdGlvbkdvb2QnLFxyXG4gICAgRHVyYXRpb25CYWQgPSAnRHVyYXRpb25CYWQnLFxyXG4gICAgUGVyY2VudEdvb2QgPSAnUGVyY2VudEdvb2QnLFxyXG4gICAgUGVyY2VudEJhZCA9ICdQZXJjZW50QmFkJyxcclxuICAgIFdvcnN0UXVhbGl0eSA9ICdXb3JzdFF1YWxpdHknLFxyXG4gICAgVGltZUF2ZXJhZ2VTYW1wbGVBbmRIb2xkID0gJ1RpbWVBdmVyYWdlU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBUb3RhbFNhbXBsZUFuZEhvbGQgPSAnVG90YWxTYW1wbGVBbmRIb2xkJyxcclxuICAgIE1pblNhbXBsZUFuZEhvbGQgPSAnTWluU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBNYXhTYW1wbGVBbmRIb2xkID0gJ01heFNhbXBsZUFuZEhvbGQnLFxyXG4gICAgQ3VtdWxhdGl2ZVRvdGFsID0gJ0N1bXVsYXRpdmVUb3RhbCdcclxufVxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyBzYW1wbGluZyBkZWZpbml0aW9uLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElTYW1wbGluZ0RlZmluaXRpb24ge1xyXG4gICAgLyoqIFRoZSBudW1iZXIgb2YgdGhlIHNsaWNlcyB0aGF0IHRoZSBwcm92aWRlZCB0aW1lIHBlcmlvZCBzaG91bGQgYmUgY3V0IGludG8uXHJcbiAgICAgKiBJZiB6ZXJvIHRoZW4gYSBub24temVybyBEZWx0YVQgdmFsdWUgbmVlZHMgdG8gYmUgcHJvdmlkZWQuICovXHJcbiAgICBzbGljZUNvdW50PzogbnVtYmVyO1xyXG4gICAgLyoqIElmIHRoZSBzbGljZSBjb3VudCBpcyB6ZXJvLCB0aGVuIGEgbm9uLXplcm8gdmFsdWUgcmVwcmVzZW50aW5nIHRoZSB3aWR0aCBvZiBhIHRpbWUgc2xpY2UgaW4gc2Vjb25kc1xyXG4gICAgICogbXVzdCBiZSBwcm92aWRlZC4gQSBwb3NpdGl2ZSB2YWx1ZSBtZWFucyB0aGUgc2xpY2VzIGFyZSBhbmNob3JlZCBhdCB0aGUgc3RhcnQgdGltZSBvZiB0aGUgcmVxdWVzdGVkIHRpbWUgcGVyaW9kLlxyXG4gICAgICogQSBuZWdhdGl2ZSB2YWx1ZSBpbmRpY2F0ZXMgYW5jaG9yaW5nIGF0IHRoZSBlbmQgb2YgdGhlIHRpbWUgcGVyaW9kLiAqL1xyXG4gICAgZGVsdGFUPzogbnVtYmVyO1xyXG4gICAgLyoqIE9uZSBvZiB0aGUgc2FtcGxpbmcgdHlwZXMgc3VwcG9ydGVkIGJ5IHRoZSB0aW1lc2VyaWVzLiBTZWUgU2FtcGxpbmdUeXBlcyBlbnVtLiAqL1xyXG4gICAgc2FtcGxpbmdUeXBlOiBTYW1wbGluZ1R5cGVzO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgVGltZXNlcmllc1JlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBUaW1lc2VyaWVzIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSBmcW5zIExpc3Qgb2YgZnFucyAoaWRlbnRpZmljYXRvcnMpIHRvIGJlIHVzZWQgZm9yIHJlcXVlc3RcclxuICAgICAqIEBwYXJhbSB0aW1lUGVyaW9kIFNldHRpbmdzIGZvciB0aW1lIHBlcmlvZCBvZiB0aW1lc2VyaWVzIHJlcXVlc3QsIGUuZy4gc3RhcnQgdGltZSwgZW5kIHRpbWUgYW5kIGR1cmF0aW9uXHJcbiAgICAgKiBAcGFyYW0gc2FtcGxpbmdEZWZpbml0aW9uIChPcHRpb25hbCkgZGVmaW5pdGlvbiBmb3IgdGltZXNlcmllcyB0byBzZXQgaG93IHRvIHByb2Nlc3MgZGF0YSwgd2hpY2ggU2FtcGxpbmcgdHlwZSB0byB1c2VcclxuICAgICAqIEBwYXJhbSB0aW1lRGVhZEJhbmQgKE9wdGlvbmFsKSBTZXR0aW5ncyBmb3IgdGltZSBkZWFkYmFuZCAtIHBvc3NpYmxlIHN0cnVjdHVyZSBbd3NdWy1dIGQgfCBkLmhoOm1tWzpzc1suZmZdXSB8IGhoOm1tWzpzc1suZmZdXSBbd3NdXHJcbiAgICAgKiBAcGFyYW0gdmFsdWVEZWFkQmFuZCAoT3B0aW9uYWwpIFNwZWNpZmllcyB0aGUgdmFsdWUgZGVhZCBiYW5kLCBjYW4gYmUgYW55IGZsb2F0IG51bWJlci5cclxuICAgICAqIEBwYXJhbSBxdWFsaXR5RmlsdGVyIChPcHRpb25hbCkgVGhpcyBpcyBhIGJpdCBmbGFnIHZhbHVlIHdpdGggdGhlIGZvbGxvd2luZyBvcHRpb25zOlxyXG4gICAgICogSW5jbHVkZUdvb2QgOiAxXHJcbiAgICAgKiBJbmNsdWRlQmFkIDogMlxyXG4gICAgICogSW5jbHVkZVVuY2VydGFpbiA6IDRcclxuICAgICAqIEluY2x1ZGVBbGwgOiA3XHJcbiAgICAgKiBVc2UgYSB2YWx1ZSBmcm9tIHByZWRlZmluZWQgZW51bSBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgb3Igc3BlY2lmeSBhIHZhbGx1ZS5cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBmcW5zOiBpZGVudGlmaWVyW10sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZCxcclxuICAgICAgICBwcml2YXRlIHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lRGVhZEJhbmQ/OiBzdHJpbmcsXHJcbiAgICAgICAgcHJpdmF0ZSB2YWx1ZURlYWRCYW5kPzogbnVtYmVyLFxyXG4gICAgICAgIHByaXZhdGUgcXVhbGl0eUZpbHRlcj86IFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB8IG51bWJlclxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5zZXRGcW5zKGZxbnMpO1xyXG4gICAgICAgIHRoaXMuc2V0VGltZVBlcmlvZCh0aW1lUGVyaW9kKTtcclxuICAgICAgICB0aGlzLnNldFNhbXBsaW5nRGVmaW5pdGlvbihzYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIG9uZSBmcW4gdG8gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gYWRkXHJcbiAgICAgKi9cclxuICAgIGFkZEZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICB0aGlzLmZxbnMucHVzaChmcW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmVtb3ZlIG9uZSBmcW4gZnJvbSByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byByZW1vdmVcclxuICAgICAqL1xyXG4gICAgcmVtb3ZlRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIGNvbnN0IGluZGV4ID0gXy5pbmRleE9mKHRoaXMuZnFucywgZnFuKTtcclxuICAgICAgICBpZiAoaW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlcGxhY2UgY3VycmVudCBmcW5zIGluIHJlcXVlc3QgdG8gbmV3IG9uZXMuXHJcbiAgICAgKiBAcGFyYW0gZnFucyBsaXN0IG9mIGZxbiBpZGVudGlmaWNhdG9ycyB0byBzZXRcclxuICAgICAqL1xyXG4gICAgc2V0RnFucyhmcW5zOiBpZGVudGlmaWVyW10pIHtcclxuICAgICAgICB0aGlzLmZxbnMgPSBfLmNsb25lKGZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IGZxbiBpZGVudGlmaWNhdG9ycy5cclxuICAgICAqL1xyXG4gICAgZ2V0RnFucygpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLmZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHJlcXVlc3QgdGltZSBwZXJpb2QuXHJcbiAgICAgKiBAcGFyYW0gdGltZVBlcmlvZFxyXG4gICAgICovXHJcbiAgICBzZXRUaW1lUGVyaW9kKHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kKSB7XHJcbiAgICAgICAgdGhpcy50aW1lUGVyaW9kID0gXy5jbG9uZSh0aW1lUGVyaW9kKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCByZXF1ZXN0IHRpbWUgcGVyaW9kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lUGVyaW9kKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMudGltZVBlcmlvZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgc2FtcGxpbmcgZGVmaW5pdGlvbi5cclxuICAgICAqIEBwYXJhbSBzYW1wbGluZ0RlZmluaXRpb25cclxuICAgICAqL1xyXG4gICAgc2V0U2FtcGxpbmdEZWZpbml0aW9uKHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24pIHtcclxuICAgICAgICB0aGlzLnNhbXBsaW5nRGVmaW5pdGlvbiA9IF8uY2xvbmUoc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBzYW1wbGluZyBkZWZpbml0aW9uLlxyXG4gICAgICovXHJcbiAgICBnZXRTYW1wbGluZ0RlZmluaXRpb24oKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy5zYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHRpbWUgZGVhZGJhbmQuXHJcbiAgICAgKiBAcGFyYW0gdGltZURlYWRCYW5kXHJcbiAgICAgKi9cclxuICAgIHNldFRpbWVEZWFkQmFuZCh0aW1lRGVhZEJhbmQ/OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLnRpbWVEZWFkQmFuZCA9IHRpbWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB0aW1lIGRlYWRiYW5kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lRGVhZGJhbmQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudGltZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHZhbHVlIGRlYWRiYW5kLlxyXG4gICAgICogQHBhcmFtIHZhbHVlRGVhZEJhbmRcclxuICAgICAqL1xyXG4gICAgc2V0VmFsdWVEZWFkQmFuZCh2YWx1ZURlYWRCYW5kPzogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy52YWx1ZURlYWRCYW5kID0gdmFsdWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB2YWx1ZSBkZWFkYmFuZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VmFsdWVEZWFkQmFuZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy52YWx1ZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHF1YWxpdHkgZmlsdGVyLlxyXG4gICAgICogQHBhcmFtIHF1YWxpdHlGaWx0ZXJcclxuICAgICAqL1xyXG4gICAgc2V0UXVhbGl0eUZpbHRlcihxdWFsaXR5RmlsdGVyPzogVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHwgbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5xdWFsaXR5RmlsdGVyID0gcXVhbGl0eUZpbHRlcjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBxdWFsaXR5IGZpbHRlci5cclxuICAgICAqL1xyXG4gICAgZ2V0UXVhbGl0eUZpbHRlcigpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5xdWFsaXR5RmlsdGVyO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogVGhpcyBzZXJ2aWNlIHByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgZm9yIHNlbmRpbmcgcmVxdWVzdHMgdG8gb2J0YWluIHRpbWVzZXJpZXMgZGF0YS5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFRpbWVzZXJpZXNEYXRhU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLFxyXG4gICAgICAgIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgb3BjUXVhbGl0eVN2YzogT3BjUXVhbGl0eVNlcnZpY2UpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvdGltZXNlcmllcy8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0IHRvIHNlcnZlciwgYnV0IG9ubHkgb25jZS5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgdGltZXpvbmUgdG8gYXBwbHkgdG8gdGltZXNlcmllcyByZXNwb25zZSBkYXRhLCBvbmx5IG1vbWVudCB0aW1lem9uZXMgYXJlIHN1cHBvcnRlZFxyXG4gICAgICogSWYgd29ya2luZyB3aXRoIHRpbWV6b25lIGluIGRhdGV0aW1lIHN0cmluZyBpdCBpcyByZWNvbW1lbmRlZCB0byB1c2UgbW9tZW50LnBhcnNlWm9uZSB0byBwcmVzZXJ2ZSB0aW1lem9uZSBpbmZvcm1hdGlvbi5cclxuICAgICAqIE1vbWVudCB0aW1lem9uZXMgdGhhdCBzdGFydCB3aXRoIFwiRXRjL0dNVFwiIHVzZSBQT1NJWC1zdHlsZSBzaWducyBpbiB0aGUgWm9uZSBuYW1lcyBhbmQgdGhlIG91dHB1dCBhYmJyZXZpYXRpb25zLFxyXG4gICAgICogZXZlbiB0aG91Z2ggdGhpcyBpcyB0aGUgb3Bwb3NpdGUgb2Ygd2hhdCBtYW55IHBlb3BsZSBleHBlY3QuXHJcbiAgICAgKiBQT1NJWCBoYXMgcG9zaXRpdmUgc2lnbnMgd2VzdCBvZiBHcmVlbndpY2gsIGJ1dCBtYW55IHBlb3BsZSBleHBlY3RcclxuICAgICAqIHBvc2l0aXZlIHNpZ25zIGVhc3Qgb2YgR3JlZW53aWNoLiAgRm9yIGV4YW1wbGUsIFRaPSdFdGMvR01UKzQnIHVzZXNcclxuICAgICAqIHRoZSBhYmJyZXZpYXRpb24gXCJHTVQrNFwiIGFuZCBjb3JyZXNwb25kcyB0byA0IGhvdXJzIGJlaGluZCBVVFxyXG4gICAgICogKGkuZS4gd2VzdCBvZiBHcmVlbndpY2gpIGV2ZW4gdGhvdWdoIG1hbnkgcGVvcGxlIHdvdWxkIGV4cGVjdCBpdCB0b1xyXG4gICAgICogbWVhbiA0IGhvdXJzIGFoZWFkIG9mIFVUIChpLmUuIGVhc3Qgb2YgR3JlZW53aWNoKS5cclxuICAgICAqL1xyXG4gICAgZ2V0T25jZShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIGxldCB0ejogc3RyaW5nO1xyXG4gICAgICAgIGlmIChNb21lbnRIZWxwZXJTZXJ2aWNlLmlzVmFsaWRUaW1lem9uZSh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgdHogPSB0aW1lem9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT5cclxuICAgICAgICAgICAgdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHR6KSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHJldHVybiBhbiBvYnNlcnZhYmxlIHdoaWNoIGltbWVkaWF0ZWxseSBlcnJvcnMgb3V0IHdpdGggZ2l2ZW4gZXJyb3Igc3RyaW5nLlxyXG4gICAgICogQHBhcmFtIGVycm9yU3RyaW5nXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldEVycm9yT2JzZXJ2YWJsZShlcnJvclN0cmluZzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPigob2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICAgICAgb2JzZXJ2ZXIuZXJyb3IoZXJyb3JTdHJpbmcpO1xyXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBhcHBseSB0aW1lem9uZSB0byB3aG9sZVxyXG4gICAgICogQHBhcmFtIHZxdERhdGEgbGlzdCBvZiBWUVQgZGF0YVxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIHRpbWV6b25lIHN0cmluZ1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9hcHBseVRpbWV6b25lVG9WcXREYXRhKHZxdERhdGE6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW10sIHRpbWV6b25lKSB7XHJcbiAgICAgICAgXy5lYWNoKHZxdERhdGEsICh2cXQ6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSA9PiB7XHJcbiAgICAgICAgICAgIHZxdC50ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHZxdC50LCB0aW1lem9uZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHZxdERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gZ2V0IGZpcnN0IHZhbHVlIGJlZm9yZSBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSBpbiBjdXJyZW50IGRhdGEuXHJcbiAgICAgKlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCBuZXh0U3RhcnRNb21lbnQ6IG1vbWVudC5Nb21lbnQpOlxyXG4gICAgICAgIE1hcDxzdHJpbmcsIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzPiB7XHJcbiAgICAgICAgY29uc3QgYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXM6IE1hcDxzdHJpbmcsIGFueT4gPSBuZXcgTWFwKCk7XHJcbiAgICAgICAgbGV0IGxhc3Q6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzO1xyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGVsKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghXy5pc05pbChlbCkgJiYgZWwudmFsdWVzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgbGFzdCA9IF8ubGFzdChlbC52YWx1ZXMpO1xyXG4gICAgICAgICAgICAgICAgYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXMuc2V0KGVsLmZxbiwgbGFzdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0cyBzdGFydCB0aW1lIGZvciBuZXh0IHJlcXVlc3Qgd2hlbiBnZXR0aW5nIGRhdGEgcmVwZWF0ZWRseS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChcclxuICAgICAgICByZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCBvcmlnaW5hbER1cmF0aW9uOiBudW1iZXIsIHJlcGVhdGVkSW50ZXJ2YWw6IG51bWJlcik6IG1vbWVudC5Nb21lbnQge1xyXG4gICAgICAgIGNvbnN0IG9wY1F1YWxpdHlTdmMgPSB0aGlzLm9wY1F1YWxpdHlTdmM7XHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0TGFzdFRpbWVUb1VzZShmcW5SZXN1bHQ6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdCk6IHN0cmluZyB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRpbWVTdHJpbmcgPSBfLmZpcnN0KGZxblJlc3VsdC52YWx1ZXMpLnQ7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gZnFuUmVzdWx0LnZhbHVlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZnFuUmVzdWx0LnZhbHVlc1tpXTtcclxuICAgICAgICAgICAgICAgIGlmICghb3BjUXVhbGl0eVN2Yy5pc0hkYUludGVycG9sYXRlZCh2YWwucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsLnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB0aW1lU3RyaW5nO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHJlc3VsdDogbW9tZW50Lk1vbWVudDtcclxuICAgICAgICBjb25zdCBjdXJyZW50VGltZU1pbnVzRHVyYXRpb24gPSBtb21lbnQudXRjKCkuc3VidHJhY3QoTWF0aC5hYnMob3JpZ2luYWxEdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcblxyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGZxblJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChmcW5SZXN1bHQpIHx8IGZxblJlc3VsdC52YWx1ZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBubyB0aW1lc2VyaWVzIGRhdGFcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBsYXN0VmFsdWUgPSBtb21lbnQudXRjKGdldExhc3RUaW1lVG9Vc2UoZnFuUmVzdWx0KSk7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKHJlc3VsdCkgfHwgcmVzdWx0LmlzQWZ0ZXIobGFzdFZhbHVlKSkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gbGFzdFZhbHVlLmNsb25lKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKF8uaXNOaWwocmVzdWx0KSkge1xyXG4gICAgICAgICAgICAvLyBubyBnb29kIHF1YWxpdHkgLSBhZGQgcGVyaW9kIHRvIHJlc3BvbnNlIHN0YXJ0IHRpbWUgLSBhcyBkZWZhdWx0IGZvciBuZXh0IHJlcXVlc3RcclxuICAgICAgICAgICAgcmVzdWx0ID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0KS5hZGQocmVwZWF0ZWRJbnRlcnZhbCwgJ21pbGxpc2Vjb25kcycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbi5pc0FmdGVyKHJlc3VsdCkpIHtcclxuICAgICAgICAgICAgcmVzdWx0ID0gY3VycmVudFRpbWVNaW51c0R1cmF0aW9uLmNsb25lKCkuYWRkKHJlcGVhdGVkSW50ZXJ2YWwsICdtaWxsaXNlY29uZHMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAqIEZ1bmN0aW9uIHRvIG9wdGlvbmFsbHkgZmlsdGVyIGZpcnN0IHZhbHVlIGluIHJlcGVhdGVkIHJlcXVlc3Qgd2hlbiBpdCBpcyBpbnRlcnBvbGF0ZWQgYmV0d2VlblxyXG4gICAgKiB0d28gZ29vZC9iYWQgb25lcy4gRGlyZWN0bHkgbW9kaWZpZXMgcmVzcG9uc2UgaW5wdXQgcGFyYW1ldGVyLlxyXG4gICAgKi9cclxuICAgIHByaXZhdGUgX2ZpbHRlclN0YXJ0UmVzcG9uc2VEYXRhKFxyXG4gICAgICAgIHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsXHJcbiAgICAgICAgcHJldmlvdXNSZXNwb25zZUxhc3REYXRhOiBNYXA8c3RyaW5nLCBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cz4sIHJlcXVlc3RUaW1lUGVyaW9kOiBJVGltZVBlcmlvZCkge1xyXG4gICAgICAgIGxldCBmaXJzdFZxdDtcclxuICAgICAgICBsZXQgZmlyc3RWcXRNb21lbnQ7XHJcbiAgICAgICAgbGV0IHNlY29uZFZxdDtcclxuICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcclxuICAgICAgICBjb25zdCBvcGNRdWFsaXR5U3ZjID0gdGhpcy5vcGNRdWFsaXR5U3ZjO1xyXG4gICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGUgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKTtcclxuICAgICAgICBjdXRCZWZvcmVEYXRlLnN1YnRyYWN0KE1hdGguYWJzKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChlbCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIV8uaXNOaWwoZWwpICYmIHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5oYXMoZWwuZnFuKSAmJiBlbC52YWx1ZXMubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhID0gcHJldmlvdXNSZXNwb25zZUxhc3REYXRhLmdldChlbC5mcW4pO1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhTW9tZW50ID0gbW9tZW50LnV0YyhvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEudCk7XHJcbiAgICAgICAgICAgICAgICBmaXJzdFZxdCA9IGVsLnZhbHVlcy5zbGljZSgwLCAxKVswXTtcclxuICAgICAgICAgICAgICAgIGZpcnN0VnF0TW9tZW50ID0gbW9tZW50LnV0YyhmaXJzdFZxdC50KTtcclxuICAgICAgICAgICAgICAgIGlmIChvcGNRdWFsaXR5U3ZjLmlzSGRhSW50ZXJwb2xhdGVkKGZpcnN0VnF0LnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vjb25kVnF0ID0gZWwudmFsdWVzLnNsaWNlKDEsIDIpWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZxdE1vbWVudCA+IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YU1vbWVudCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaXJzdFZxdE1vbWVudCA8IG1vbWVudC51dGMoc2Vjb25kVnF0LnQpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wY1F1YWxpdHlTdmMuaXNHb29kKG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5xKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGNRdWFsaXR5U3ZjLmlzR29vZChzZWNvbmRWcXQucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWwudmFsdWVzLnNwbGljZSgwLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCB0aW1lem9uZT86IHN0cmluZyk6IFRpbWVzZXJpZXNSZXNwb25zZSB7XHJcbiAgICAgICAgbGV0IGFwcGx5VGltZXpvbmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICAvLyB3ZSBkbyBoYXZlIHRpbWV6b25lXHJcbiAgICAgICAgICAgIGFwcGx5VGltZXpvbmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAvLyBhcHBseSB0aW1lem9uZSBhbHNvIHRvIHJlc3BvbnNlIHRpbWUgcGVyaW9kIHRvIG1hdGNoIGRhdGFcclxuICAgICAgICAgICAgcmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShyZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0LCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kLCB0aW1lem9uZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZXQ6IFRpbWVzZXJpZXNSZXNwb25zZSA9IHtcclxuICAgICAgICAgICAgdGltZVBlcmlvZDogcmVzcG9uc2UudGltZVBlcmlvZCxcclxuICAgICAgICAgICAgcmVzdWx0czogW11cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChvbmVSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwob25lUmVzdWx0KSkge1xyXG4gICAgICAgICAgICAgICAgLy8gbm8gdGltZXNlcmllcyBkYXRhXHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhcHBseVRpbWV6b25lKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hcHBseVRpbWV6b25lVG9WcXREYXRhKG9uZVJlc3VsdC52YWx1ZXMsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0LnJlc3VsdHMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiBvbmVSZXN1bHQubmFtZSxcclxuICAgICAgICAgICAgICAgIGZxbjogb25lUmVzdWx0LmZxbixcclxuICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogb25lUmVzdWx0LnZhbHVlVHlwZSxcclxuICAgICAgICAgICAgICAgIGVuZ2luZWVyaW5nVW5pdDogb25lUmVzdWx0LmVuZ2luZWVyaW5nVW5pdCxcclxuICAgICAgICAgICAgICAgIHZhbHVlczogb25lUmVzdWx0LnZhbHVlc1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gcmV0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogRnVuY3Rpb24gdG8gZmlsdGVyIG5vdCBuZWVkZWQgZGF0YSBhbmQgZHVwbGljYXRlIGRhdGEuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2ZpbHRlckR1cGxpY2F0ZURhdGFBbmRDdXQoXHJcbiAgICAgICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdLCBjdXRCZWZvcmVNb21lbnQ6IG1vbWVudC5Nb21lbnQsXHJcbiAgICAgICAgZG9Ob3RTaGlmdEZpcnN0VmFsdWU/OiBib29sZWFuLCB0aW1lem9uZT86IHN0cmluZykge1xyXG4gICAgICAgIGNvbnN0IGlkczogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIGxldCBvYmplY3RUb0FkZFRvQXJyYXk6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzO1xyXG4gICAgICAgIGxldCBmaXJzdElzQWZ0ZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gYXJyYXlGaWx0ZXIobzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpIHtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudEl0ZW1Nb21lbnQgPSBtb21lbnQudXRjKG8udCk7XHJcbiAgICAgICAgICAgIGlmIChjdXRCZWZvcmVNb21lbnQuaXNBZnRlcihjdXJyZW50SXRlbU1vbWVudCkpIHtcclxuICAgICAgICAgICAgICAgIGlmICghZmlyc3RJc0FmdGVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5ID0gXy5jbG9uZShvKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQgPSBjdXRCZWZvcmVNb21lbnQuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkudCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkudCA9IGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3RJc0FmdGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaWRzLmluZGV4T2Yoby50KSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZHMucHVzaChvLnQpO1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZmlsdGVyZWRBcnJheSA9IHZhbHVlcy5yZXZlcnNlKCkuZmlsdGVyKGFycmF5RmlsdGVyKTtcclxuICAgICAgICBpZiAoIWRvTm90U2hpZnRGaXJzdFZhbHVlICYmIGZpcnN0SXNBZnRlcikge1xyXG4gICAgICAgICAgICBjb25zdCBsYXN0VmFsdWUgPSBfLmxhc3QoZmlsdGVyZWRBcnJheSk7XHJcbiAgICAgICAgICAgIGlmICghbGFzdFZhbHVlIHx8ICFtb21lbnQudXRjKGxhc3RWYWx1ZS50KS5pc1NhbWUobW9tZW50LnV0YyhvYmplY3RUb0FkZFRvQXJyYXkudCkpKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBpdCBpcyByZXZlcnNlZCBhcnJheSBzbyBwdXNoIHRvIGl0XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZEFycmF5LnB1c2gob2JqZWN0VG9BZGRUb0FycmF5KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRBcnJheS5yZXZlcnNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3RzIHJlcGVhdGVkbHkgYW5kIHJldHVybiBhbGwgZGF0YSBpbiBnaXZlbiByZXF1ZXN0IGludGVydmFsIChieSBkdXJhdGlvbiwgc3RhcnQgYW5kL29yIGVuZCB0aW1lKS5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgaW50ZXJ2YWwgaW4gc2Vjb25kc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXBlYXRlZGx5V2hvbGUocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgbGV0IGxhc3RNZXJnZWRSZXNwb25zZTogVGltZXNlcmllc1Jlc3BvbnNlO1xyXG4gICAgICAgIGNvbnN0IHR6ID0gdGltZXpvbmU7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcGVhdGVkbHlPYnMgPSB0aGlzLl9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdGltZXpvbmUpXHJcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzcG9uc2U6IFRpbWVzZXJpZXNSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGxhc3RNZXJnZWRSZXNwb25zZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGUgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKTtcclxuICAgICAgICAgICAgICAgICAgICBjdXRCZWZvcmVEYXRlLnN1YnRyYWN0KE1hdGguYWJzKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlVVRDRm9ybWF0ID0gY3V0QmVmb3JlRGF0ZS5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKHR6KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShjdXRCZWZvcmVEYXRlVVRDRm9ybWF0LCB0eik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9IHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpLmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXy5lYWNoKGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLCAocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld1Jlc3VsdHMgPSBfLmZpbmQocmVzcG9uc2UucmVzdWx0cywgeyBmcW46IHJlc3VsdC5mcW4gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChuZXdSZXN1bHRzKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IHJlc3VsdC52YWx1ZXMuY29uY2F0KG5ld1Jlc3VsdHMudmFsdWVzKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gXy5zb3J0QnkocmVzdWx0LnZhbHVlcywgWyhvOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBtb21lbnQudXRjKG8udCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IHRoaXMuX2ZpbHRlckR1cGxpY2F0ZURhdGFBbmRDdXQocmVzdWx0LnZhbHVlcywgY3V0QmVmb3JlRGF0ZSwgZmFsc2UsIHR6KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGFkZCBhbnkgbmV3IGZxbnMgZGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIF8uZWFjaChyZXNwb25zZS5yZXN1bHRzLCAobmV3UmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5maW5kKGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLCB7IGZxbjogbmV3UmVzdWx0LmZxbiB9KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMucHVzaChuZXdSZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGxhc3RNZXJnZWRSZXNwb25zZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlID0gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgcmV0dXJuIHJlcGVhdGVkbHlPYnM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3RzIHJlcGVhdGVkbHkgYW5kIHJldHVybiBkYXRhIGFzIGluY3JlbWVudHMuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGludGVydmFsIGluIHNlY29uZHNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMoXHJcbiAgICAgICAgcmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcblxyXG4gICAgICAgIGxldCBsYXN0UmVzcG9uc2VEYXRhOiBNYXA8c3RyaW5nLCBhbnk+O1xyXG4gICAgICAgIGxldCByZXBlYXRlZEludGVydmFsID0gY3VzdG9tSW50ZXJ2YWwgfHwgdGhpcy5jb25maWcuZGVmYXVsdFJlcGVhdGVkRGF0YUludGVydmFsIHx8IERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTDtcclxuICAgICAgICByZXBlYXRlZEludGVydmFsID0gcmVwZWF0ZWRJbnRlcnZhbCAqIDEwMDA7XHJcblxyXG4gICAgICAgIGNvbnN0IGxhc3RSZXBlYXRlZFJlcXVlc3QgPSBfLmNsb25lKHJlcXVlc3QpO1xyXG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRHVyYXRpb24gPSByZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbjtcclxuICAgICAgICBsZXQgbmV4dFJlcXVlc3RTdGFydE1vbWVudDogbW9tZW50Lk1vbWVudDtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZSA9IHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50ID0gdGhpcy5fZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChyZXNwb25zZSwgb3JpZ2luYWxEdXJhdGlvbiwgcmVwZWF0ZWRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgIC8vIHdlIHJlbWVtYmVyIGxhc3QgdmFsdWUgYmVmb3JlIG5leHRTdGFydCBpbiBjdXJyZW50IHJlcXVlc3QgdG8gY2hlY2sgaXRzXHJcbiAgICAgICAgICAgIC8vIHF1YWxpdHkgdnMuIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIHZhbHVlIHF1YWxpdHksIHBvc3NpYmx5XHJcbiAgICAgICAgICAgIC8vIHRvIG9taXQgc3RhcnQgdmFsdWVcclxuICAgICAgICAgICAgLy8gLSBpdCBtYXkgYmUgaW50ZXJwb2xhdGVkIGJldHdlZW4gdHdvIGdvb2QgcXVhbGl0eSB2YWx1ZXNcclxuICAgICAgICAgICAgbGFzdFJlc3BvbnNlRGF0YSA9IHRoaXMuX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlLCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0aW1lem9uZSk7XHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIGNvbnN0IGV4cGFuZGVkT2JzZXJ2YWJsZSA9IHJlcGVhdGVkRGF0YU9ic2VydmFibGUucGlwZShcclxuICAgICAgICAgICAgZXhwYW5kKCgpID0+IHRpbWVyKHJlcGVhdGVkSW50ZXJ2YWwpLnBpcGUoY29uY2F0TWFwKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RSZXBlYXRlZFJlcXVlc3Quc2V0VGltZVBlcmlvZChcclxuICAgICAgICAgICAgICAgICAgICAgICAgXy5leHRlbmQobGFzdFJlcGVhdGVkUmVxdWVzdC5nZXRUaW1lUGVyaW9kKCksIHsgZHVyYXRpb246IDAsIHN0YXJ0OiBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50LnRvRGF0ZSgpIH0pKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QobGFzdFJlcGVhdGVkUmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobGFzdFJlc3BvbnNlRGF0YS5zaXplID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3ZSBjaGVjayBwcmV2aW91cyB2YWx1ZXMgdG8gY3VycmVudCBzdGFydGluZyBvbmVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGZpbHRlciBvdXQgcG9zc2libGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RhcnQgaW50ZXJwb2xhdGVkIG9uZXMgaWYgdGhleSBhcmUgYmV0d2VlbiBnb29kIG9uZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZmlsdGVyU3RhcnRSZXNwb25zZURhdGEocmVzcG9uc2UsIGxhc3RSZXNwb25zZURhdGEsIHJlcXVlc3RUaW1lUGVyaW9kKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmV4dFJlcXVlc3RTdGFydE1vbWVudCA9IHRoaXMuX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QocmVzcG9uc2UsIG9yaWdpbmFsRHVyYXRpb24sIHJlcGVhdGVkSW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHdlIHJlbWVtYmVyIGxhc3QgdmFsdWUgYmVmb3JlIG5leHRTdGFydCBpbiBjdXJyZW50IHJlcXVlc3QgdG8gY2hlY2sgaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gcXVhbGl0eSB2cy4gbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgdmFsdWUgcXVhbGl0eSwgcG9zc2libHlcclxuICAgICAgICAgICAgICAgICAgICAvLyB0byBvbWl0IHN0YXJ0IHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gLSBpdCBtYXkgYmUgaW50ZXJwb2xhdGVkIGJldHdlZW4gdHdvIGdvb2QgcXVhbGl0eSB2YWx1ZXNcclxuICAgICAgICAgICAgICAgICAgICBsYXN0UmVzcG9uc2VEYXRhID0gdGhpcy5fZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2UsIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9KSkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICByZXR1cm4gZXhwYW5kZWRPYnNlcnZhYmxlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgcmVxdWVzdCBmb3IgdGltZXNlcmllcyBkYXRhIHJlcGVhdGVkbHkuIEl0IHJlcGVhdGVkbHkgc2VuZHMgcmVxdWVzdHMgdG8gc2VydmVyLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBjdXN0b20gaW50ZXJ2YWwgZm9yIHJlcGVhdGVkIGRhdGEsIGluIHNlY29uZHNcclxuICAgICAqIEBwYXJhbSBmb3JtYXQgKE9wdGlvbmFsKSBmb3JtYXQgZm9yIHJlcGVhdGVkIGRhdGEgcmVzcG9uc2VcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSAoT3B0aW9uYWwpIFNldCB0aGUgdGltZXpvbmUgdG8gYXBwbHkgdG8gZGF0ZXRpbWUgc3RyaW5ncyBmb3IgdGltZXNlcmllcyByZXNwb25zZSBkYXRhLlxyXG4gICAgICogUmV0dXJuZWQgZGF0ZSBzdHJpbmdzIGFyZSBpbiBtYXhpbXVtIGphdmFzY3JpcHQgcmVzb2x1dGlvbiBwb3NzaWJsZVxyXG4gICAgICogc3VwcG9ydGVkIGJ5IHVzaW5nIG1vbWVudCBsaWJyYXJ5IChKYXZhc2NyaXB0IGRhdGUgLSBtaWxsaXNlY29uZHMpLlxyXG4gICAgICogUmVzb2x1dGlvbiBmb3IgdGltZSBhZnRlciBtaWxsaXNlY29uZHMgd2lsbCBiZSBsb3N0LlxyXG4gICAgICogSWYgd29ya2luZyB3aXRoIHRpbWV6b25lIGluIGRhdGV0aW1lIHN0cmluZyBpdCBpcyByZWNvbW1lbmRlZCB0byB1c2UgbW9tZW50LnBhcnNlWm9uZSB0byBwcmVzZXJ2ZSB0aW1lem9uZSBpbmZvcm1hdGlvbi5cclxuICAgICAqIE1vbWVudCB0aW1lem9uZXMgdGhhdCBzdGFydCB3aXRoIFwiRXRjL0dNVFwiIHVzZSBQT1NJWC1zdHlsZSBzaWducyBpbiB0aGUgWm9uZSBuYW1lcyBhbmQgdGhlIG91dHB1dCBhYmJyZXZpYXRpb25zLFxyXG4gICAgICogZXZlbiB0aG91Z2ggdGhpcyBpcyB0aGUgb3Bwb3NpdGUgb2Ygd2hhdCBtYW55IHBlb3BsZSBleHBlY3QuXHJcbiAgICAgKiBQT1NJWCBoYXMgcG9zaXRpdmUgc2lnbnMgd2VzdCBvZiBHcmVlbndpY2gsIGJ1dCBtYW55IHBlb3BsZSBleHBlY3RcclxuICAgICAqIHBvc2l0aXZlIHNpZ25zIGVhc3Qgb2YgR3JlZW53aWNoLiAgRm9yIGV4YW1wbGUsIFRaPSdFdGMvR01UKzQnIHVzZXNcclxuICAgICAqIHRoZSBhYmJyZXZpYXRpb24gXCJHTVQrNFwiIGFuZCBjb3JyZXNwb25kcyB0byA0IGhvdXJzIGJlaGluZCBVVFxyXG4gICAgICogKGkuZS4gd2VzdCBvZiBHcmVlbndpY2gpIGV2ZW4gdGhvdWdoIG1hbnkgcGVvcGxlIHdvdWxkIGV4cGVjdCBpdCB0b1xyXG4gICAgICogbWVhbiA0IGhvdXJzIGFoZWFkIG9mIFVUIChpLmUuIGVhc3Qgb2YgR3JlZW53aWNoKS5cclxuICAgICAqL1xyXG4gICAgZ2V0UmVwZWF0ZWRseShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIGZvcm1hdD86IFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQsIHRpbWV6b25lPzogc3RyaW5nKTpcclxuICAgICAgICBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG4gICAgICAgIGlmICghXy5pc05pbChyZXF1ZXN0VGltZVBlcmlvZC5zdGFydCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEVycm9yT2JzZXJ2YWJsZSgnVGltZXNlcmllc0RhdGFTZXJ2aWNlIGdldFJlcGVhdGVkbHk6IEFyZ3VtZW50IGV4Y2VwdGlvbidcclxuICAgICAgICAgICAgICAgICsgJyAtIFJlcXVlc3Qgc3RhcnQgdGltZSBjYW5ub3QgYmUgc2V0IGZvciByZXBlYXRlZCBkYXRhIChyZXF1ZXN0OiAnXHJcbiAgICAgICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpICsgJyBjYW5ub3QgYmUgcHJvY2Vzc2VkLicpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoXy5pc05pbChyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbikgfHwgcmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24gPiAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRFcnJvck9ic2VydmFibGUoJ1RpbWVzZXJpZXNEYXRhU2VydmljZSBnZXRSZXBlYXRlZGx5OiBBcmd1bWVudCBleGNlcHRpb24nXHJcbiAgICAgICAgICAgICAgICArICcgLSBSZXF1ZXN0IGR1cmF0aW9uIGhhdmUgdG8gYmUgbmVnYXRpdmUgKHJlcXVlc3Q6ICdcclxuICAgICAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkocmVxdWVzdCkgKyAnIGNhbm5vdCBiZSBwcm9jZXNzZWQuJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdHo6IHN0cmluZztcclxuICAgICAgICBpZiAoTW9tZW50SGVscGVyU2VydmljZS5pc1ZhbGlkVGltZXpvbmUodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIHR6ID0gdGltZXpvbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfLmlzTmlsKGZvcm1hdCkgfHwgZm9ybWF0ID09PSBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0Lndob2xlSW50ZXJ2YWwpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJlcGVhdGVkbHlXaG9sZShyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdHopO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdHopO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQge0luamVjdCwgSW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7SHR0cENsaWVudH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQge0NPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZ30gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge0Jhc2VTZXJ2aWNlfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBPcGVyYXRpb25TZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvb3BlcmF0aW9uLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gSlNPTiBPcGVyYXRpb24gc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0T3BlcmF0aW9uRGF0YShvcGVyYXRpb25SZXE6IE9wZXJhdGlvblJlcXVlc3QpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3Qob3BlcmF0aW9uUmVxKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE9wZXJhdGlvblJlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBPcGVyYXRpb24gcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIHRhcmdldCAtIFRoZSBGUU4gb2YgdGFyZ2V0IGl0ZW1cclxuICAgICAqIEBwYXJhbSBvcGVyYXRpb24gLSBUaGUgbmFtZSBvZiB0aGUgb3BlcmF0aW9uXHJcbiAgICAgKiBAcGFyYW0gcGFyYW1ldGVycyAtIFRoZSBwYXJhbWV0ZXJzIGZvciB0aGUgcmVxdWVzdFxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgdGFyZ2V0OiBzdHJpbmcsIHB1YmxpYyBvcGVyYXRpb246IHN0cmluZywgcHVibGljIHBhcmFtZXRlcnM/OiBvYmplY3QpIHtcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQge0luamVjdCwgSW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7QmFzZVNlcnZpY2V9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7aWRlbnRpZmllcn0gZnJvbSAnLi9zaGFyZWQnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElOZXdJdGVtIHtcclxuICAgIHBhcmVudFByb3BlcnR5RnFuOiBzdHJpbmc7XHJcbiAgICBpdGVtVHlwZTogc3RyaW5nO1xyXG4gICAgcHJvcHM/OiBQcm9wTmFtZVZhbHVlcztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUmVuYW1lZEl0ZW0ge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuZXdOYW1lOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNoYW5nZWRJdGVtIHtcclxuICAgIEZ1bGx5UXVhbGlmaWVkTmFtZTogc3RyaW5nO1xyXG4gICAgW2tleTogc3RyaW5nXTogYW55O1xyXG59XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBQZXJzaXN0ZW5jZVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS9wZXJzaXN0ZW5jZS8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAvKipcclxuICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gSlNPTiBQZXJzaXN0ZW5jZSBzZXJ2aWNlIG9uIHRoZSBzZXJ2ZXIuXHJcbiAgICovXHJcbiAgICBjb21taXQocGVyc2lzdFJlcXVlc3Q6IFBlcnNpc3RSZXF1ZXN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHBlcnNpc3RSZXF1ZXN0KTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFByb3BOYW1lVmFsdWVzIHtcclxuXHJcbiAgLyoqXHJcbiAgICogQWRkcyBwcm9wZXJ0eSBOYW1lIFZhbHVlIFBhaXIgZm9yIE5ldyBJdGVtIENyZWF0aW9uXHJcbiAgICogQHBhcmFtIG5hbWUgLSBOYW1lIG9mIHRoZSBwcm9wZXJ0eSB0byBhZGRcclxuICAgKiBAcGFyYW0gdmFsdWUgLSBWYWx1ZSB0byBhZGQgYXQgTmFtZSBwcm9wZXJ0eSBuYW1lXHJcbiAgICovXHJcbiAgICBhZGQobmFtZTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgaWYgKG5hbWUpIHtcclxuICAgICAgICAgICAgdGhpc1tuYW1lXSA9IHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbW92ZXMgcHJvcGVydHkgTmFtZVxyXG4gICAgICogQHBhcmFtIG5hbWUgLSBOYW1lIG9mIHRoZSBwcm9wZXJ0eSB0byByZW1vdmVcclxuICAgICAqL1xyXG4gICAgcmVtb3ZlKG5hbWU6IHN0cmluZykge1xyXG4gICAgICAgIGlmICghXy5pc05pbCh0aGlzW25hbWVdKSkge1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpc1tuYW1lXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaXNFbXB0eSgpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gIV8uc29tZSh0aGlzKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgIC8qKiBMaXN0IG9mIG5ldyBpdGVtcyB0byBwZXJzaXN0ICovXHJcbiAgICBuZXdJdGVtczogSU5ld0l0ZW1bXTtcclxuICAgIC8qKiBMaXN0IG9mIGl0ZW1zIHRvIHJlbmFtZSAqL1xyXG4gICAgcmVuYW1lZEl0ZW06IElSZW5hbWVkSXRlbTtcclxuICAgIC8qKiBMaXN0IG9mIGNoYW5nZWQgaXRlbXMgdG8gcGVyc2lzdCAqL1xyXG4gICAgY2hhbmdlZEl0ZW1zOiBJQ2hhbmdlZEl0ZW1bXTtcclxuICAgIC8qKiBMaXN0IG9mIGl0ZW1zIHRvIGRlbGV0ZSAqL1xyXG4gICAgZGVsZXRlZEl0ZW1zOiBpZGVudGlmaWVyW107XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDcmVhdGUgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIHBhcmVudFByb3BlcnR5RnFuIC0gRlFOIG9mIFBhcmVudCBQcm9wZXJ0eVxyXG4gICAgICogQHBhcmFtIGl0ZW1UeXBlIC0gSXRlbSBUeXBlXHJcbiAgICAgKiBAcGFyYW0gcHJvcE5hbWVWYWx1ZXMgLSBQcm9wZXJ0eSBOYW1lIFZhbHVlIFBhaXJzXHJcbiAgICAgKi9cclxuICAgIGNyZWF0ZUl0ZW0ocGFyZW50UHJvcGVydHlGcW46IHN0cmluZywgaXRlbVR5cGU6IHN0cmluZywgcHJvcE5hbWVWYWx1ZXM/OiBQcm9wTmFtZVZhbHVlcyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBjb25zdCBjcmVhdGVSZXF1ZXN0OiBJTmV3SXRlbSA9IHtcclxuICAgICAgICAgICAgcGFyZW50UHJvcGVydHlGcW46IHBhcmVudFByb3BlcnR5RnFuLFxyXG4gICAgICAgICAgICBpdGVtVHlwZTogaXRlbVR5cGVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAocHJvcE5hbWVWYWx1ZXMpIHtcclxuICAgICAgICAgICAgY3JlYXRlUmVxdWVzdC5wcm9wcyA9IHByb3BOYW1lVmFsdWVzO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLm5ld0l0ZW1zKSB7XHJcbiAgICAgICAgICAgIHRoaXMubmV3SXRlbXMgPSBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubmV3SXRlbXMucHVzaChjcmVhdGVSZXF1ZXN0KTtcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbmFtZSBJdGVtIHZpYSBQZXJzaXN0ZW5jZSBTZXJ2aWNlXHJcbiAgICAgKiBAcGFyYW0gaXRlbUZxbiAtIEZRTiBvZiBJdGVtXHJcbiAgICAgKiBAcGFyYW0gbmV3TmFtZSAtIE5ldyBOYW1lIG9mIEl0ZW1cclxuICAgICAqL1xyXG4gICAgcmVuYW1lSXRlbShpdGVtRnFuOiBzdHJpbmcsIG5ld05hbWU6IHN0cmluZyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICB0aGlzLnJlbmFtZWRJdGVtID0ge1xyXG4gICAgICAgICAgICBmcW46IGl0ZW1GcW4sXHJcbiAgICAgICAgICAgIG5ld05hbWU6IG5ld05hbWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIENoYW5nZSBJdGVtIHZpYSBQZXJzaXN0ZW5jZSBTZXJ2aWNlXHJcbiAgICAgKiBAcGFyYW0gaXRlbUZxbiAtIEZRTiBvZiBJdGVtXHJcbiAgICAgKiBAcGFyYW0gcHJvcE5hbWVWYWx1ZXMgLSBQcm9wZXJ0aWVzIHRvIGNoYW5nZVxyXG4gICAgICovXHJcbiAgICBjaGFuZ2VJdGVtKGl0ZW1GcW46IHN0cmluZywgcHJvcE5hbWVWYWx1ZXM6IFByb3BOYW1lVmFsdWVzKTogUGVyc2lzdFJlcXVlc3Qge1xyXG4gICAgICAgIGlmICghcHJvcE5hbWVWYWx1ZXMuaXNFbXB0eSgpKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNoYW5nZVJlcXVlc3Q6IElDaGFuZ2VkSXRlbSA9IHtcclxuICAgICAgICAgICAgICAgIEZ1bGx5UXVhbGlmaWVkTmFtZTogaXRlbUZxblxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBfLmV4dGVuZChjaGFuZ2VSZXF1ZXN0LCBwcm9wTmFtZVZhbHVlcyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuY2hhbmdlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZWRJdGVtcyA9IFtdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuY2hhbmdlZEl0ZW1zLnB1c2goY2hhbmdlUmVxdWVzdCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogRGVsZXRlIEl0ZW0gdmlhIFBlcnNpc3RlbmNlIFNlcnZpY2VcclxuICAgICAqIEBwYXJhbSBpdGVtRnFuIC0gRlFOIG9mIEl0ZW0gdG8gZGVsZXRlXHJcbiAgICAgKi9cclxuICAgIGRlbGV0ZUl0ZW0oaXRlbUZxbjogc3RyaW5nKTogUGVyc2lzdFJlcXVlc3Qge1xyXG4gICAgICAgIGlmICghdGhpcy5kZWxldGVkSXRlbXMpIHtcclxuICAgICAgICAgICAgdGhpcy5kZWxldGVkSXRlbXMgPSBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5kZWxldGVkSXRlbXMucHVzaChpdGVtRnFuKTtcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IE5hdmlnYXRpb25SdWxlcyB9IGZyb20gJy4vc2hhcmVkJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE5hdmlnYXRpb25TZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbmF2aWdhdGlvbi8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gTmF2aWdhdGlvbiBzZXJ2aWNlIG9uIHRoZSBzZXJ2ZXIuXHJcbiAgICAgKi9cclxuICAgIGdldE5hdmlnYXRpb25EYXRhKG5hdmlnYXRpb25SZXF1ZXN0OiBOYXZpZ2F0aW9uUmVxdWVzdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgbGV0IHJlcXVlc3QgPSBuYXZpZ2F0aW9uUmVxdWVzdDtcclxuICAgICAgICBpZiAoXy5pc05pbChuYXZpZ2F0aW9uUmVxdWVzdC5uYXZIYW5kbGVyRnFuKSB8fCBuYXZpZ2F0aW9uUmVxdWVzdC5uYXZIYW5kbGVyRnFuID09PSAnJykge1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChyZXF1ZXN0LmhpZGVSdWxlcykgJiYgXy5pc05pbChyZXF1ZXN0LnNraXBSdWxlcykpIHtcclxuICAgICAgICAgICAgICAgIHJlcXVlc3QgPSBfLmNsb25lKG5hdmlnYXRpb25SZXF1ZXN0KTtcclxuICAgICAgICAgICAgICAgIHJlcXVlc3Quc2tpcFJ1bGVzID0gXy5jbG9uZSh0aGlzLmNvbmZpZy5kZWZhdWx0TmF2aWdhdGlvblJ1bGVzLnNraXBSdWxlcyk7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmhpZGVSdWxlcyA9IF8uY2xvbmUodGhpcy5jb25maWcuZGVmYXVsdE5hdmlnYXRpb25SdWxlcy5oaWRlUnVsZXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0aW9uUmVxdWVzdCB7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBOYXZpZ2F0aW9uIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSBmcW4gLSBUaGUgRlFOIG9mIE5hdmlnYXRpb25SZXF1ZXN0XHJcbiAgICAgKiBAcGFyYW0gcHJvcE5hbWVzIC0gVGhlIFByb3BlcnR5IE5hbWVzXHJcbiAgICAgKiBAcGFyYW0gaW5jbHVkZVBhcmVudHMgLSBXaGV0aGVyIHRvIGluY2x1ZGUgcGFyZW50cyBpbiByZXN1bHRzXHJcbiAgICAgKiBAcGFyYW0gbmF2SGFuZGxlckZxbiAtIFRoZSBGUU4gb2YgTmF2aWdhdGlvbiBIYW5kbGVyIEl0ZW1cclxuICAgICAqIEBwYXJhbSBoaWRlUnVsZXMgLSBUaGUgSGlkZSBSdWxlcyBmb3IgTmF2aWdhdGlvblxyXG4gICAgICogQHBhcmFtIHNraXBSdWxlcyAtIFRoZSBTa2lwIFJ1bGVzIGZvciBOYXZpZ2F0aW9uXHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHB1YmxpYyBmcW46IHN0cmluZywgcHVibGljIHByb3BOYW1lcz86IHN0cmluZ1tdLCBwdWJsaWMgaW5jbHVkZVBhcmVudHM/OiBib29sZWFuLFxyXG4gICAgICAgIHB1YmxpYyBuYXZIYW5kbGVyRnFuPzogc3RyaW5nLCBwdWJsaWMgaGlkZVJ1bGVzPzogTmF2aWdhdGlvblJ1bGVzLCBwdWJsaWMgc2tpcFJ1bGVzPzogTmF2aWdhdGlvblJ1bGVzKSB7XHJcbiAgICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7SW5qZWN0LCBJbmplY3RhYmxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7Q09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7QmFzZVNlcnZpY2V9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbi8qKlxyXG4gKiBOYXZpZ2F0aW9uIHJlc3BvbnNlIGludGVyZmFjZVxyXG4gKiBAcGFyYW0gdXNlcm5hbWUgLSBpZGVudGl0eSBwcm92aWRlciAoZW1haWwpXHJcbiAqIEBwYXJhbSByb2xlcyAtIGxpc3Qgb2YgdXNlciByb2xlc1xyXG4gKiBAcGFyYW0gaWRlbnRpdGllcyAtIGxpc3Qgb2YgaWRlbnRpdGllcyBwcm92aWRlcnNcclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVNlY3VyaXR5Q29udGV4dFJlc3BvbnNlIHtcclxuICB1c2VybmFtZTogc3RyaW5nO1xyXG4gIHJvbGVzOiBzdHJpbmdbXTtcclxuICBpZGVudGl0aWVzOiBzdHJpbmdbXTtcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgU2VjdXJpdHlDb250ZXh0UmVzcG9uc2UgPSBJU2VjdXJpdHlDb250ZXh0UmVzcG9uc2U7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBTZWN1cml0eUNvbnRleHRTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvc2VjdXJpdHljb250ZXh0LycsIGNvbmZpZywgaHR0cCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gSlNPTiBTZWN1cml0eSBDb250ZXh0IHNlcnZpY2Ugb24gdGhlIHNlcnZlci5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0U2VjdXJpdHlDb250ZXh0RGF0YSgpOiBPYnNlcnZhYmxlPFNlY3VyaXR5Q29udGV4dFJlc3BvbnNlPiB7XHJcbiAgICByZXR1cm4gdGhpcy5fc2VuZEdldFJlcXVlc3QoKTtcclxuICB9XHJcbn1cclxuXHJcbiIsImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgTWltZVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS9taW1lLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0TWltZUl0ZW1QYXRoKGZxbjogc3RyaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZW5kcG9pbnRVcmwuY29uY2F0KGZxbik7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0h0dHBDbGllbnR9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtCYXNlU2VydmljZX0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuLyoqXHJcbiAqIE5hdmlnYXRpb24gaGFuZGxlciByZXNwb25zZSBpbnRlcmZhY2VcclxuICogQHBhcmFtIHVzZXJuYW1lIC0gaWRlbnRpdHkgcHJvdmlkZXIgKGVtYWlsKVxyXG4gKiBAcGFyYW0gcm9sZXMgLSBsaXN0IG9mIHVzZXIgcm9sZXNcclxuICogQHBhcmFtIGlkZW50aXRpZXMgLSBsaXN0IG9mIGlkZW50aXRpZXMgcHJvdmlkZXJzXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElOYXZpZ2F0aW9uSGFuZGxlclJlc3BvbnNlIHtcclxuICBuYXZoYW5kbGVyZnFuOiBzdHJpbmcgfCBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBOYXZpZ2F0aW9uSGFuZGxlclJlc3BvbnNlID0gSU5hdmlnYXRpb25IYW5kbGVyUmVzcG9uc2U7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0aW9uSGFuZGxlclNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS9uYXZpZ2F0aW9uaGFuZGxlci8nLCBjb25maWcsIGh0dHApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gTmF2aWdhdGlvbkhhbmRsZXIgc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXROYXZpZ2F0aW9uSGFuZGxlckRhdGEobmF2aWdhdGlvbkhhbmRsZXJSZXE6IE5hdmlnYXRpb25IYW5kbGVyUmVxdWVzdCk6IE9ic2VydmFibGU8TmF2aWdhdGlvbkhhbmRsZXJSZXNwb25zZT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChuYXZpZ2F0aW9uSGFuZGxlclJlcSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTmF2aWdhdGlvbkhhbmRsZXJSZXF1ZXN0IHtcclxuICAvKipcclxuICAgKiBOYXZpZ2F0aW9uSGFuZGxlciByZXF1ZXN0IGNvbnN0cnVjdG9yLlxyXG4gICAqIEF0IGxlYXN0IG9uZSBvZiBvcHRpb25hbCBwYXJhbWV0ZXJzIG11c3QgYmUgdXNlZFxyXG4gICAqIEBwYXJhbSBmcW4gVGhlIEZRTiBvZiBOYXZpZ2F0aW9uSGFuZGxlclJlcXVlc3RcclxuICAgKiBAcGFyYW0gY3VycmVudE5hdkhhbmRsZXJGcW4gVGhlIEZRTiBvZiBjdXJyZW50IE5hdmlnYXRpb24gaGFuZGxlclxyXG4gICAqIEBwYXJhbSBuYXZIYW5kbGVyUHJvdmlkZXJGcW4gVGhlIEZRTiBvZiBOYXZpZ2F0aW9uIEhhbmRsZXIgUHJvdmlkZXJcclxuICAgKi9cclxuICBjb25zdHJ1Y3RvcihwdWJsaWMgZnFuOiBzdHJpbmcsIHB1YmxpYyBjdXJyZW50TmF2SGFuZGxlckZxbj86IHN0cmluZyxcclxuICAgICAgICAgICAgICBwdWJsaWMgbmF2SGFuZGxlclByb3ZpZGVyRnFuPzogc3RyaW5nKSB7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE5nTW9kdWxlLCBNb2R1bGVXaXRoUHJvdmlkZXJzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IEh0dHBDbGllbnRNb2R1bGUsIEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IEluc3RhbmNlU2VydmljZSB9IGZyb20gJy4vaW5zdGFuY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IExpdmVEYXRhU2VydmljZSB9IGZyb20gJy4vbGl2ZS1kYXRhLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBUaW1lc2VyaWVzRGF0YVNlcnZpY2UgfSBmcm9tICcuL3RpbWVzZXJpZXMtZGF0YS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBPcGVyYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9vcGVyYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IFBlcnNpc3RlbmNlU2VydmljZSB9IGZyb20gJy4vcGVyc2lzdGVuY2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdmlnYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9uYXZpZ2F0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPcGNRdWFsaXR5U2VydmljZSB9IGZyb20gJy4vb3BjLXF1YWxpdHkuc2VydmljZSc7XHJcbmltcG9ydCB7IFNlY3VyaXR5Q29udGV4dFNlcnZpY2UgfSBmcm9tICcuL3NlY3VyaXR5LWNvbnRleHQuc2VydmljZSc7XHJcbmltcG9ydCB7IE1pbWVTZXJ2aWNlIH0gZnJvbSAnLi9taW1lLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uSGFuZGxlclNlcnZpY2UgfSBmcm9tICcuL25hdmlnYXRpb24taGFuZGxlci5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cEluc3RhbmNlU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBJbnN0YW5jZVNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBMaXZlRGF0YVN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgTGl2ZURhdGFTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwVGltZXNlcmllc0RhdGFTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50LCBxdWFsaXR5U3ZjOiBPcGNRdWFsaXR5U2VydmljZSkge1xyXG4gICAgcmV0dXJuIG5ldyBUaW1lc2VyaWVzRGF0YVNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50LCBxdWFsaXR5U3ZjKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwT3BlcmF0aW9uU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBPcGVyYXRpb25TZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwUGVyc2lzdGVuY2VTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IFBlcnNpc3RlbmNlU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cE5hdmlnYXRpb25TdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IE5hdmlnYXRpb25TZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwU2VjdXJpdHlDb250ZXh0U3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBTZWN1cml0eUNvbnRleHRTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwTWltZVN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgTWltZVNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBOYXZpZ2F0aW9uSGFuZGxlclN2YyhcclxuICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgcmV0dXJuIG5ldyBOYXZpZ2F0aW9uSGFuZGxlclNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5cclxuQE5nTW9kdWxlKHtcclxuICAgIGltcG9ydHM6IFtcclxuICAgICAgICBDb21tb25Nb2R1bGUsXHJcbiAgICAgICAgSHR0cENsaWVudE1vZHVsZVxyXG4gICAgXSxcclxuICAgIHByb3ZpZGVyczogW09wY1F1YWxpdHlTZXJ2aWNlXSxcclxuICAgIGRlY2xhcmF0aW9uczogW11cclxufSlcclxuZXhwb3J0IGNsYXNzIFJhRnRjQ29tbXVuaWNhdGlvbk1vZHVsZSB7XHJcbiAgICBzdGF0aWMgZm9yUm9vdChjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnKTogTW9kdWxlV2l0aFByb3ZpZGVycyB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgbmdNb2R1bGU6IFJhRnRjQ29tbXVuaWNhdGlvbk1vZHVsZSxcclxuICAgICAgICAgICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogSW5zdGFuY2VTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwSW5zdGFuY2VTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogTGl2ZURhdGFTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwTGl2ZURhdGFTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogVGltZXNlcmllc0RhdGFTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwVGltZXNlcmllc0RhdGFTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudCwgT3BjUXVhbGl0eVNlcnZpY2VcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IE9wZXJhdGlvblNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBPcGVyYXRpb25TdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogUGVyc2lzdGVuY2VTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwUGVyc2lzdGVuY2VTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogTmF2aWdhdGlvblNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBOYXZpZ2F0aW9uU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IFNlY3VyaXR5Q29udGV4dFNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBTZWN1cml0eUNvbnRleHRTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogTWltZVNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBNaW1lU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IE5hdmlnYXRpb25IYW5kbGVyU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cE5hdmlnYXRpb25IYW5kbGVyU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHsgcHJvdmlkZTogQ09NTVVOSUNBVElPTl9DT05GSUcsIHVzZVZhbHVlOiBjb25maWcgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufVxyXG4iXSwibmFtZXMiOlsiXy5leHRlbmQiLCJfLmlzTmlsIiwiXy5jbG9uZSIsIl8uaW5kZXhPZiIsIl8uZWFjaCIsIl8uZmlsdGVyIiwibW9tZW50LnV0YyIsIm1vbWVudC50eiIsInR6IiwibGFzdCIsIl8ubGFzdCIsIl8uZmlyc3QiLCJfLmZpbmQiLCJfLnNvcnRCeSIsIl8uc29tZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7TUFZYSw4QkFBOEIsR0FBRyxDQUFDLENBQUM7TUFXbkMsb0JBQW9CLEdBQUcsSUFBSSxjQUFjLENBQXVCLDZCQUE2QixDQUFDOzs7SUNoQnZHLFlBQ2MsV0FBbUIsRUFDbkIsTUFBNEIsRUFDNUIsSUFBZ0I7UUFGaEIsZ0JBQVcsR0FBWCxXQUFXLENBQVE7UUFDbkIsV0FBTSxHQUFOLE1BQU0sQ0FBc0I7UUFDNUIsU0FBSSxHQUFKLElBQUksQ0FBWTtLQUFLO0lBRXpCLGdCQUFnQixDQUFDLE9BQVk7UUFDbkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sRUFDM0NBLE1BQVEsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxtQ0FBbUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0tBQ2hIO0lBRVMsZUFBZTtRQUNyQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQ2pDQSxNQUFRLENBQUMsRUFBRSxPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsbUNBQW1DLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztLQUNoSDtDQUNKOztxQkNrQzRCLFNBQVEsV0FBVztJQUU1QyxZQUEwQyxRQUE4QixJQUFnQjtRQUNwRixLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDNUQ7SUFLTSxZQUFZLENBQUMsZUFBZ0M7UUFDaEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLENBQUM7Ozs7WUFYckQsVUFBVTs7OzRDQUdNLE1BQU0sU0FBQyxvQkFBb0I7WUF4RG5DLFVBQVU7OztJQTZFZixZQUFZLHNCQUFnQztRQUN4QyxJQUFJLENBQUNDLEtBQU8sQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxzQkFBc0IsQ0FBQztTQUN4RDthQUFNO1lBQ0gsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztTQUN0QztLQUNKO0lBS08saUJBQWlCLENBQ3JCLGVBQW9ELEVBQUUsb0JBQTZCLEVBQ25GLGNBQXNCLEVBQUUsZ0JBQXlCO1FBRWpELGVBQWUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3BDLElBQUksb0JBQW9CLEVBQUU7WUFDdEIsZUFBZSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEdBQUcsb0JBQW9CLENBQUM7U0FDcEU7UUFDRCxJQUFJLENBQUNBLEtBQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxjQUFjLEdBQUcsQ0FBQyxFQUFFO1lBQ2hELGVBQWUsQ0FBQyxjQUFjLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQztTQUN6RDtRQUNELElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsZUFBZSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQztTQUN0RTs7SUFVRSxVQUFVLENBQUMsR0FBVyxFQUFFLG9CQUE4QixFQUFFLGNBQXVCLEVBQUUsZ0JBQTBCO1FBQzlHLE1BQU0sZUFBZSxHQUFvQjtZQUNyQyxHQUFHLEVBQUUsR0FBRztTQUNYLENBQUM7UUFDRixJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxFQUFFLG9CQUFvQixFQUFFLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2hHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1osSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7U0FDbEI7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNoQyxPQUFPLElBQUksQ0FBQzs7SUFVVCx5QkFBeUIsQ0FDNUIsR0FBVyxFQUNYLG9CQUE2QixFQUM3QixjQUFzQixFQUN0QixnQkFBeUI7UUFFekIsTUFBTSxlQUFlLEdBQW9CO1lBQ3JDLEdBQUcsRUFBRSxHQUFHO1lBQ1IseUJBQXlCLEVBQUUsSUFBSTtTQUNsQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsRUFBRSxvQkFBb0IsRUFBRSxjQUFjLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUNoRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNaLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDaEMsT0FBTyxJQUFJLENBQUM7O0lBWVQsY0FBYyxDQUNqQixHQUFXLEVBQUUsb0JBQThCLEVBQUUsY0FBdUIsRUFDcEUsZ0JBQTBCLEVBQUUsUUFBaUIsRUFBRSxJQUFhO1FBRTVELE1BQU0sdUJBQXVCLEdBQW9CO1lBQzdDLFdBQVcsRUFBRSxHQUFHO1lBQ2hCLHlCQUF5QixFQUFFLElBQUk7U0FDbEMsQ0FBQztRQUVGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsRUFBRSxvQkFBb0IsRUFBRSxjQUFjLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUN4RyxJQUFJLENBQUNBLEtBQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUNwQix1QkFBdUIsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO1NBQy9DO1FBQ0QsSUFBSSxDQUFDQSxLQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDaEIsdUJBQXVCLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztTQUN2QztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1osSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7U0FDbEI7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ3hDLE9BQU8sSUFBSSxDQUFDOztJQVVULFFBQVEsQ0FDWCxlQUF1QixFQUFFLG9CQUE4QixFQUN2RCxjQUF1QixFQUFFLGdCQUEwQjtRQUVuRCxNQUFNLGlCQUFpQixHQUFzQjtZQUN6QyxLQUFLLEVBQUUsZUFBZTtTQUN6QixDQUFDO1FBQ0YsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixFQUFFLG9CQUFvQixFQUFFLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2xHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDckI7UUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sSUFBSSxDQUFDOztDQUVuQjs7O0lDbkpHLFlBQXFCLElBQWtCO1FBQWxCLFNBQUksR0FBSixJQUFJLENBQWM7UUFFbkMsSUFBSSxDQUFDLElBQUksR0FBR0MsS0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzdCO0lBTUQsTUFBTSxDQUFDLEdBQWU7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdkI7SUFNRCxTQUFTLENBQUMsR0FBZTtRQUNyQixNQUFNLEtBQUssR0FBR0MsT0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDeEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQzlCO0tBQ0o7Q0FDSjtxQkFNNEIsU0FBUSxXQUFXO0lBUTVDLFlBQTBDLFFBQThCLElBQWdCO1FBQ3BGLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBUHBCLElBQUksR0FBRyxFQUFFO0tBUTdDO0lBTUQsT0FBTyxDQUFDLE9BQW9CO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FDdEMsR0FBRyxDQUFDLENBQUMsUUFBK0I7WUFDaEMsTUFBTSxHQUFHLEdBQWlCLEVBQUUsQ0FBQztZQUM3QkMsSUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTO2dCQUNuQyxHQUFHLENBQUMsSUFBSSxDQUFDO29CQUNMLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTtvQkFDcEIsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHO29CQUNsQixTQUFTLEVBQUUsU0FBUyxDQUFDLFNBQVM7b0JBQzlCLGVBQWUsRUFBRSxTQUFTLENBQUMsZUFBZTtvQkFDMUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDcEIsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDcEIsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDdkIsQ0FBQyxDQUFDO2FBQ04sQ0FBQyxDQUFDO1lBQ0gsT0FBTyxHQUFHLENBQUM7U0FDZCxDQUFDLENBQUMsQ0FBQztLQUNYO0lBRU8sMkJBQTJCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDaEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQStCO1lBQ3RDLE1BQU0sR0FBRyxHQUFpQixFQUFFLENBQUM7WUFDN0JBLElBQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUztnQkFDbkMsR0FBRyxDQUFDLElBQUksQ0FBQztvQkFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUk7b0JBQ3BCLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRztvQkFDbEIsU0FBUyxFQUFFLFNBQVMsQ0FBQyxTQUFTO29CQUM5QixlQUFlLEVBQUUsU0FBUyxDQUFDLGVBQWU7b0JBQzFDLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3ZCLENBQUMsQ0FBQzthQUNOLENBQUMsQ0FBQztZQUNILE9BQU8sR0FBRyxDQUFDO1NBQ2QsQ0FBQyxDQUFDLENBQUM7O0lBR0osdUJBQXVCO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7WUFDNUIsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDO1NBQzNEO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsSUFBSSxJQUFJLENBQUMsK0JBQStCLEVBQUU7WUFDdkUsSUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDJCQUEyQixJQUFJLDhCQUE4QixDQUFDO1lBQ2pHLGdCQUFnQixHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUUzQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFLbEUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQzlELE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FDbEcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFzQjtnQkFDL0IsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM1QyxFQUFFLENBQUMsR0FBRztnQkFDSCxJQUFJLENBQUMseUJBQXlCLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzdDLElBQUksQ0FBQywrQkFBK0IsR0FBRyxJQUFJLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDeEMsRUFBRTtnQkFDQyxJQUFJLENBQUMsK0JBQStCLEdBQUcsSUFBSSxDQUFDO2dCQUM1QyxJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDeEMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLCtCQUErQixHQUFHLEtBQUssQ0FBQztTQUNoRDtRQUVELE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDOztJQU94QyxhQUFhLENBQUMsT0FBb0I7UUFFOUIsT0FBTyxJQUFJLFVBQVUsQ0FBZSxDQUFDLFFBQVE7WUFFekNBLElBQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRztnQkFDckIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3JCLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDaEM7Z0JBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDakMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxlQUE2QjtnQkFDakcsT0FBT0MsTUFBUSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7b0JBQy9CLE9BQU9GLE9BQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDOUMsQ0FBQyxDQUFDO2FBQ04sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBc0I7Z0JBQ2pDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDM0IsRUFBRSxDQUFDLEtBQUs7Z0JBQ0wsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN6QixFQUFFO2dCQUNDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUN2QixDQUFDLENBQUM7WUFFSCxPQUFPO2dCQUVIQyxJQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUc7b0JBQ3JCLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFDZixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNyQixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ2hDO29CQUNELElBQUksTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDZCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDMUI7eUJBQU07d0JBQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7cUJBQ2pDO2lCQUNKLENBQUMsQ0FBQztnQkFFSCxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzNCLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLEVBQUU7b0JBQ3ZCLElBQUksSUFBSSxDQUFDLHlCQUF5QixFQUFFO3dCQUNoQyxJQUFJLENBQUMseUJBQXlCLENBQUMsV0FBVyxFQUFFLENBQUM7cUJBQ2hEO29CQUNELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDckMsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUM7b0JBQ2pDLElBQUksQ0FBQywrQkFBK0IsR0FBRyxJQUFJLENBQUM7aUJBQy9DO2FBQ0osQ0FBQztTQUNMLENBQUMsQ0FBQztLQUNOOzs7WUE3SUosVUFBVTs7OzRDQVNNLE1BQU0sU0FBQyxvQkFBb0I7WUEzRm5DLFVBQVU7Ozs7O2dDQ3FCVSxNQUFNO3NDQUNBLE1BQU07aUNBQ1gsVUFBVTtzQ0FDTDtZQUMvQixVQUFVLEVBQUUsTUFBTTtZQUNsQixjQUFjLEVBQUUsTUFBTTtZQUN0QixPQUFPLEVBQUUsTUFBTTtTQUNoQjtrQ0FDNEI7WUFDM0IsR0FBRyxFQUFFLE1BQU07WUFDWCxTQUFTLEVBQUUsTUFBTTtZQUNqQixVQUFVLEVBQUUsTUFBTTtZQUNsQixJQUFJLEVBQUUsTUFBTTtTQUNiO2tDQUM0QjtZQUMzQixHQUFHLEVBQUUsTUFBTTtZQUNYLFdBQVcsRUFBRSxNQUFNO1lBQ25CLFlBQVksRUFBRSxNQUFNO1lBQ3BCLGFBQWEsRUFBRSxNQUFNO1lBQ3JCLGFBQWEsRUFBRSxNQUFNO1lBQ3JCLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLFdBQVcsRUFBRSxNQUFNO1lBQ25CLFlBQVksRUFBRSxNQUFNO1lBQ3BCLFlBQVksRUFBRSxNQUFNO1lBQ3BCLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLFVBQVUsRUFBRSxNQUFNO1lBQ2xCLGlCQUFpQixFQUFFLE1BQU07WUFDekIsZ0JBQWdCLEVBQUUsTUFBTTtZQUN4QixTQUFTLEVBQUUsTUFBTTtZQUNqQixJQUFJLEVBQUUsTUFBTTtZQUNaLGFBQWEsRUFBRSxNQUFNO1NBQ3RCO2lDQUMyQjtZQUMxQixPQUFPLEVBQUUsTUFBTTtZQUNmLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLFFBQVEsRUFBRSxNQUFNO1NBQ2pCOzZCQUN1QjtZQUN0QixTQUFTLEVBQUUsVUFBVTtZQUNyQixZQUFZLEVBQUUsVUFBVTtZQUN4QixHQUFHLEVBQUUsVUFBVTtZQUNmLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLE9BQU8sRUFBRSxVQUFVO1lBQ25CLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLE9BQU8sRUFBRSxVQUFVO1NBQ3BCOytCQUN5QjtZQUN4QixNQUFNLEVBQUUsS0FBSztZQUNiLE1BQU0sRUFBRSxXQUFXO1lBQ25CLE1BQU0sRUFBRSxhQUFhO1lBQ3JCLE1BQU0sRUFBRSxNQUFNO1NBQ2Y7K0JBRXlCO1lBRXhCLE1BQU0sRUFBRSxhQUFhO1lBQ3JCLE1BQU0sRUFBRSxhQUFhO1lBQ3JCLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLE1BQU0sRUFBRSxVQUFVO1lBRWxCLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLE1BQU0sRUFBRSxlQUFlO1lBQ3ZCLE1BQU0sRUFBRSxnQkFBZ0I7WUFDeEIsTUFBTSxFQUFFLGdCQUFnQjtZQUN4QixNQUFNLEVBQUUsWUFBWTtZQUNwQixNQUFNLEVBQUUsY0FBYztZQUN0QixNQUFNLEVBQUUsZ0JBQWdCO1lBQ3hCLE1BQU0sRUFBRSxjQUFjO1lBRXRCLE1BQU0sRUFBRSxhQUFhO1lBQ3JCLE1BQU0sRUFBRSxzQkFBc0I7WUFDOUIsTUFBTSxFQUFFLDRCQUE0QjtZQUNwQyxNQUFNLEVBQUUsWUFBWTtZQUVwQixNQUFNLEVBQUUsZ0JBQWdCO1lBRXhCLFVBQVUsRUFBRSxZQUFZO1lBQ3hCLFVBQVUsRUFBRSxjQUFjO1lBQzFCLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLFVBQVUsRUFBRSxZQUFZO1lBQ3hCLFVBQVUsRUFBRSxVQUFVO1lBQ3RCLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFVBQVUsRUFBRSxXQUFXO1lBQ3ZCLFVBQVUsRUFBRSxZQUFZO1lBQ3hCLFVBQVUsRUFBRSxTQUFTO1NBQ3RCOztJQU1NLFFBQVEsQ0FBQyxZQUFvQjtRQUNsQyxJQUFJLElBQVksQ0FBQztRQUNqQixNQUFNLE9BQU8sSUFBRyxFQUFjLENBQUEsQ0FBQztRQUUvQixJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztRQUNsRCxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFN0MsSUFBSSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDNUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN0QyxPQUFPLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDekM7UUFFRCxJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUM7UUFDN0QsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN0QyxPQUFPLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUM7UUFFRCxJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUM3QyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQztRQUNELE9BQU8sT0FBTyxDQUFDOztJQU9WLFFBQVEsQ0FBQyxZQUFvQjtRQUNsQyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDekIsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN6QyxJQUFJLE9BQWUsQ0FBQztRQUVwQixPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN2QixJQUFJLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDWCxPQUFPLEdBQUcsT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ25DLFlBQVksR0FBRyxJQUFJLENBQUM7U0FDckI7UUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDZCxPQUFPLEdBQUcsT0FBTztpQkFDZCxZQUFZLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDNUMsWUFBWSxHQUFHLElBQUksQ0FBQztTQUNyQjtRQUNELElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNaLE9BQU8sR0FBRyxPQUFPO2lCQUNkLFlBQVksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUMzQztRQUNELE9BQU8sT0FBTyxDQUFDOztJQU9WLGVBQWUsQ0FBQyxZQUFvQjtRQUN6QyxPQUFPLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7O0lBT3ZDLGlCQUFpQixDQUFDLFlBQW9CO1FBQzNDLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUM7O0lBT3hELGdCQUFnQixDQUFDLFlBQW9CO1FBQzFDLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQzs7SUFPN0MsZ0JBQWdCLENBQUMsWUFBb0I7UUFDMUMsT0FBTyxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDOztJQU94QyxNQUFNLENBQUMsWUFBb0I7UUFDaEMsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7O0lBT3hGLFdBQVcsQ0FBQyxZQUFvQjtRQUNyQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7SUFPN0YsS0FBSyxDQUFDLFlBQW9CO1FBQy9CLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDOztJQU92RixlQUFlLENBQUMsWUFBb0I7UUFDekMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQzs7SUFNMUUsZ0JBQWdCLENBQUMsWUFBb0I7UUFDMUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQzs7SUFNNUUsaUJBQWlCLENBQUMsWUFBb0I7UUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQzs7SUFNOUUsaUJBQWlCLENBQUMsWUFBb0I7UUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQzs7SUFNOUUsYUFBYSxDQUFDLFlBQW9CO1FBQ3ZDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7O0lBTXRFLGVBQWUsQ0FBQyxZQUFvQjtRQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDOztJQU0xRSxnQkFBZ0IsQ0FBQyxZQUFvQjtRQUMxQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDOztJQU01RSxnQkFBZ0IsQ0FBQyxZQUFvQjtRQUMxQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDOztJQU01RSxjQUFjLENBQUMsWUFBb0I7UUFDeEMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQzs7SUFNeEUscUJBQXFCLENBQUMsWUFBb0I7UUFDL0MsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUM7O0lBTXRGLG9CQUFvQixDQUFDLFlBQW9CO1FBQzlDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDOztJQU1wRixhQUFhLENBQUMsWUFBb0I7UUFDdkMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7SUFNdEUsaUJBQWlCLENBQUMsWUFBb0I7UUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQzs7SUFPOUUsU0FBUyxDQUFDLFlBQW9CO1FBQ25DLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7SUFNaEUsVUFBVSxDQUFDLFlBQW9CO1FBQ3BDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQzs7SUFNbEUsV0FBVyxDQUFDLFlBQW9CO1FBQ3JDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQzs7SUFNcEUsZUFBZSxDQUFDLFlBQW9CO1FBQ3pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQzs7SUFNbEUsY0FBYyxDQUFDLFlBQW9CO1FBQ3hDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDOztJQU01RCxpQkFBaUIsQ0FBQyxZQUFvQjtRQUMzQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQzs7SUFNbEUsUUFBUSxDQUFDLFlBQW9CO1FBQ2xDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDOztJQU1oRCxlQUFlLENBQUMsWUFBb0I7UUFDekMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUM7O0lBTTlELFlBQVksQ0FBQyxZQUFvQjtRQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQzs7SUFNeEQsV0FBVyxDQUFDLFlBQW9CO1FBQ3JDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDOztJQU10RCxhQUFhLENBQUMsWUFBb0I7UUFDdkMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7O0lBTTFELGVBQWUsQ0FBQyxZQUFvQjtRQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQzs7SUFNOUQsWUFBWSxDQUFDLFlBQW9CO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDOzs7O1lBMVpoRSxVQUFVOzs7O0lDSEEsT0FBTyxhQUFhLENBQUMsUUFBZ0IsRUFBRSxRQUFnQjtRQUM1RCxNQUFNLEtBQUssR0FBR0UsR0FBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ25DLEtBQUssQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbkIsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDOztJQUdwRCxPQUFPLGVBQWU7UUFDekIsT0FBT0MsRUFBUyxDQUFDLEtBQUssRUFBRSxDQUFDOztJQUd0QixPQUFPLGVBQWUsQ0FBQyxRQUFRO1FBQ3BDLE9BQU8sUUFBUSxJQUFJQSxFQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzs7c0RBdEJXLDRCQUE0QjtxREFDN0IsMEJBQTBCOztZQUhyRixVQUFVOzs7Ozs7Ozs7Ozs7OzttQkNtRVMsZUFBZTtnQkFDbEIsWUFBWTs7O21CQUlULGVBQWU7bUJBQ2YsZUFBZTtZQUN0QixRQUFRO1dBQ1QsT0FBTztTQUNULEtBQUs7YUFDRCxTQUFTO2lCQUNMLGFBQWE7V0FDbkIsT0FBTzt1QkFDSyxtQkFBbUI7dUJBQ25CLG1CQUFtQjthQUM3QixTQUFTO1dBQ1gsT0FBTztTQUNULEtBQUs7V0FDSCxPQUFPO2NBQ0osVUFBVTtXQUNiLE9BQU87a0JBQ0EsY0FBYztpQkFDZixhQUFhO2lCQUNiLGFBQWE7Z0JBQ2QsWUFBWTtrQkFDVixjQUFjOzhCQUNGLDBCQUEwQjt3QkFDaEMsb0JBQW9CO3NCQUN0QixrQkFBa0I7c0JBQ2xCLGtCQUFrQjtxQkFDbkIsaUJBQWlCOzs7SUE4Qm5DLFlBQ1ksTUFDQSxZQUNBLG9CQUNBLGNBQ0EsZUFDQTtRQUxBLFNBQUksR0FBSixJQUFJO1FBQ0osZUFBVSxHQUFWLFVBQVU7UUFDVix1QkFBa0IsR0FBbEIsa0JBQWtCO1FBQ2xCLGlCQUFZLEdBQVosWUFBWTtRQUNaLGtCQUFhLEdBQWIsYUFBYTtRQUNiLGtCQUFhLEdBQWIsYUFBYTtRQUVyQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDbEQ7SUFNRCxNQUFNLENBQUMsR0FBZTtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUN2QjtJQU1ELFNBQVMsQ0FBQyxHQUFlO1FBQ3JCLE1BQU0sS0FBSyxHQUFHSixPQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN4QyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUU7WUFDWCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDOUI7S0FDSjtJQU1ELE9BQU8sQ0FBQyxJQUFrQjtRQUN0QixJQUFJLENBQUMsSUFBSSxHQUFHRCxLQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDN0I7SUFLRCxPQUFPO1FBQ0gsT0FBT0EsS0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUM3QjtJQU1ELGFBQWEsQ0FBQyxVQUF1QjtRQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHQSxLQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDekM7SUFLRCxhQUFhO1FBQ1QsT0FBT0EsS0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUNuQztJQU1ELHFCQUFxQixDQUFDLGtCQUF3QztRQUMxRCxJQUFJLENBQUMsa0JBQWtCLEdBQUdBLEtBQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0tBQ3pEO0lBS0QscUJBQXFCO1FBQ2pCLE9BQU9BLEtBQU8sQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztLQUMzQztJQU1ELGVBQWUsQ0FBQyxZQUFxQjtRQUNqQyxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztLQUNwQztJQUtELGVBQWU7UUFDWCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7S0FDNUI7SUFNRCxnQkFBZ0IsQ0FBQyxhQUFzQjtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztLQUN0QztJQUtELGdCQUFnQjtRQUNaLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztLQUM3QjtJQU1ELGdCQUFnQixDQUFDLGFBQWlEO1FBQzlELElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO0tBQ3RDO0lBS0QsZ0JBQWdCO1FBQ1osT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0tBQzdCO0NBQ0o7MkJBTWtDLFNBQVEsV0FBVztJQUVsRCxZQUNrQyxRQUM5QixJQUFnQixFQUFVLGFBQWdDO1FBQzFELEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQURqQyxrQkFBYSxHQUFiLGFBQWEsQ0FBbUI7S0FFN0Q7SUFlRCxPQUFPLENBQUMsT0FBMEIsRUFBRSxRQUFpQjtRQUNqRCxJQUFJTSxLQUFVLENBQUM7UUFDZixJQUFJLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUMvQ0EsS0FBRSxHQUFHLFFBQVEsQ0FBQztTQUNqQjtRQUNELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUEyQyxLQUN2RixJQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFQSxLQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDakU7SUFNTyxtQkFBbUIsQ0FBQyxXQUFtQjtRQUMzQyxPQUFPLElBQUksVUFBVSxDQUFxQixDQUFDLFFBQVE7WUFDL0MsUUFBUSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM1QixPQUFPO2dCQUNILFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUMxQixDQUFDO1NBQ0wsQ0FBQyxDQUFDOztJQVFDLHVCQUF1QixDQUFDLE9BQXdDLEVBQUUsUUFBUTtRQUM5RUosSUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLEdBQWtDO1lBQy9DLEdBQUcsQ0FBQyxDQUFDLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDOUQsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxPQUFPLENBQUM7O0lBT1gsOEJBQThCLENBQUMsUUFBMkMsRUFBRSxlQUE4QjtRQUU5RyxNQUFNLHVCQUF1QixHQUFxQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzVELElBQUlLLE9BQW1DLENBQUM7UUFDeENMLElBQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRTtZQUM1QixJQUFJLENBQUNILEtBQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDbENRLE9BQUksR0FBR0MsSUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDekIsdUJBQXVCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUVELE9BQUksQ0FBQyxDQUFDO2FBQzdDO1NBQ0osQ0FBQyxDQUFDO1FBRUgsT0FBTyx1QkFBdUIsQ0FBQzs7SUFNM0IsdUJBQXVCLENBQzNCLFFBQTJDLEVBQUUsZ0JBQXdCLEVBQUUsZ0JBQXdCO1FBQy9GLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDekMsMEJBQTBCLFNBQWtEO1lBQ3hFLE1BQU0sVUFBVSxHQUFHRSxLQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUUvQyxLQUFLLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNuRCxNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDekMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNoQjthQUNKO1lBRUQsT0FBTyxVQUFVLENBQUM7U0FDckI7UUFFRCxJQUFJLE1BQXFCLENBQUM7UUFDMUIsTUFBTSx3QkFBd0IsR0FBR0wsR0FBVSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUU5RkYsSUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTO1lBQ25DLElBQUlILEtBQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBRXJELE9BQU87YUFDVjtZQUNELE1BQU0sU0FBUyxHQUFHSyxHQUFVLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUMxRCxJQUFJTCxLQUFPLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDOUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUM5QjtTQUNKLENBQUMsQ0FBQztRQUVILElBQUlBLEtBQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUVqQixNQUFNLEdBQUdLLEdBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUN4RjtRQUVELElBQUksd0JBQXdCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzFDLE1BQU0sR0FBRyx3QkFBd0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDbkY7UUFFRCxPQUFPLE1BQU0sQ0FBQzs7SUFPVix3QkFBd0IsQ0FDNUIsUUFBMkMsRUFDM0Msd0JBQW9FLEVBQUUsaUJBQThCO1FBQ3BHLElBQUksUUFBUSxDQUFDO1FBQ2IsSUFBSSxjQUFjLENBQUM7UUFDbkIsSUFBSSxTQUFTLENBQUM7UUFFZCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3pDLE1BQU0sYUFBYSxHQUFHQSxHQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxRCxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDeEVGLElBQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRTtZQUM1QixJQUFJLENBQUNILEtBQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDOUUsTUFBTSwyQkFBMkIsR0FBRyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN6RSxNQUFNLGlDQUFpQyxHQUFHSyxHQUFVLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BGLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLGNBQWMsR0FBR0EsR0FBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxhQUFhLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUM3QyxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLGNBQWMsR0FBRyxpQ0FBaUM7d0JBQ2xELGNBQWMsR0FBR0EsR0FBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hDLGFBQWEsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDO3dCQUNuRCxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDbkMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3FCQUMxQjtpQkFDSjthQUNKO1NBQ0osQ0FBQyxDQUFDOztJQUdDLG9DQUFvQyxDQUFDLFFBQTJDLEVBQUUsUUFBaUI7UUFDdkcsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBRTFCLElBQUksQ0FBQ0wsS0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBRXBCLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFFckIsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ25HLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztTQUNsRztRQUVELE1BQU0sR0FBRyxHQUF1QjtZQUM1QixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVU7WUFDL0IsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDO1FBRUZHLElBQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUztZQUNuQyxJQUFJSCxLQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBRXBCLE9BQU87YUFDVjtZQUVELElBQUksYUFBYSxFQUFFO2dCQUNmLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQzVEO1lBRUQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO2dCQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7Z0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztnQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO2dCQUMxQyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU07YUFDM0IsQ0FBQyxDQUFDO1NBQ04sQ0FBQyxDQUFDO1FBQ0gsT0FBTyxHQUFHLENBQUM7O0lBTVAsMEJBQTBCLENBQzlCLE1BQXVDLEVBQUUsZUFBOEIsRUFDdkUsb0JBQThCLEVBQUUsUUFBaUI7UUFDakQsTUFBTSxHQUFHLEdBQWtCLEVBQUUsQ0FBQztRQUM5QixJQUFJLGtCQUFpRCxDQUFDO1FBQ3RELElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQztRQUV6QixxQkFBcUIsQ0FBZ0M7WUFDakQsTUFBTSxpQkFBaUIsR0FBR0ssR0FBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxJQUFJLGVBQWUsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLFlBQVksRUFBRTtvQkFDZixrQkFBa0IsR0FBR0osS0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxNQUFNLHdCQUF3QixHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsK0JBQStCLENBQUMsQ0FBQztvQkFDN0csSUFBSSxDQUFDRCxLQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3BCLGtCQUFrQixDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ2hHO3lCQUFNO3dCQUNILGtCQUFrQixDQUFDLENBQUMsR0FBRyx3QkFBd0IsQ0FBQztxQkFDbkQ7b0JBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQztpQkFDdkI7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDaEI7WUFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN6QixPQUFPLEtBQUssQ0FBQzthQUNoQjtZQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2QsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELE1BQU0sYUFBYSxHQUFHLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLG9CQUFvQixJQUFJLFlBQVksRUFBRTtZQUN2QyxNQUFNLFNBQVMsR0FBR1MsSUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQ0osR0FBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUNBLEdBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUVqRixhQUFhLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7YUFDMUM7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDOztJQVEzQixtQkFBbUIsQ0FBQyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsUUFBaUI7UUFDOUYsSUFBSSxrQkFBc0MsQ0FBQztRQUMzQyxNQUFNRSxLQUFFLEdBQUcsUUFBUSxDQUFDO1FBRXBCLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLFFBQVEsQ0FBQzthQUNqRixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBNEI7WUFDbkMsSUFBSSxDQUFDUCxLQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDOUIsTUFBTSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ2xELE1BQU0sYUFBYSxHQUFHSyxHQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDMUQsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN4RSxNQUFNLHNCQUFzQixHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsK0JBQStCLENBQUMsQ0FBQztnQkFFekcsSUFBSSxDQUFDTCxLQUFPLENBQUNPLEtBQUUsQ0FBQyxFQUFFO29CQUNkLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLHNCQUFzQixFQUFFQSxLQUFFLENBQUMsQ0FBQztvQkFDcEcsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztpQkFDL0Q7cUJBQU07b0JBQ0gsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxzQkFBc0IsQ0FBQztvQkFDN0Qsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEdBQUc7d0JBQzdCRixHQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsK0JBQStCLENBQUMsQ0FBQztpQkFDdkc7Z0JBRURGLElBQU0sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNO29CQUN0QyxNQUFNLFVBQVUsR0FBR1EsSUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7b0JBQ2pFLElBQUksQ0FBQ1gsS0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO3dCQUN0QixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFFeEQsTUFBTSxDQUFDLE1BQU0sR0FBR1ksTUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQWdDO2dDQUN0RSxPQUFPUCxHQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzZCQUMxQixDQUFDLENBQUMsQ0FBQzt3QkFFSixNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUVFLEtBQUUsQ0FBQyxDQUFDO3FCQUM1RjtpQkFDSixDQUFDLENBQUM7Z0JBRUhKLElBQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsU0FBUztvQkFDL0IsSUFBSSxDQUFDUSxJQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFO3dCQUM3RCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM5QztpQkFDSixDQUFDLENBQUM7Z0JBQ0gsT0FBTyxrQkFBa0IsQ0FBQzthQUM3QjtpQkFBTTtnQkFDSCxrQkFBa0IsR0FBRyxRQUFRLENBQUM7Z0JBQzlCLE9BQU8sUUFBUSxDQUFDO2FBQ25CO1NBQ0osQ0FBQyxDQUFDLENBQUM7UUFDUixPQUFPLGFBQWEsQ0FBQzs7SUFRakIsd0JBQXdCLENBQzVCLE9BQTBCLEVBQUUsY0FBdUIsRUFBRSxRQUFpQjtRQUV0RSxNQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVsRCxJQUFJLGdCQUFrQyxDQUFDO1FBQ3ZDLElBQUksZ0JBQWdCLEdBQUcsY0FBYyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsMkJBQTJCLElBQUksOEJBQThCLENBQUM7UUFDbkgsZ0JBQWdCLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBRTNDLE1BQU0sbUJBQW1CLEdBQUdWLEtBQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3QyxNQUFNLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztRQUNwRCxJQUFJLHNCQUFxQyxDQUFDO1FBRTFDLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUEyQztZQUMvRyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFLcEcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3pGLE9BQU8sSUFBSSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztTQUN4RSxDQUFDLENBQUMsQ0FBQztRQUNKLE1BQU0sa0JBQWtCLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxDQUNsRCxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2hELElBQUksQ0FBQ0QsS0FBTyxDQUFDLHNCQUFzQixDQUFDLEVBQUU7Z0JBQ2xDLG1CQUFtQixDQUFDLGFBQWEsQ0FDN0JELE1BQVEsQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLHNCQUFzQixDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQy9HO1lBQ0QsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBMkM7Z0JBQ25HLElBQUksZ0JBQWdCLENBQUMsSUFBSSxHQUFHLENBQUMsRUFBRTtvQkFJM0IsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO2lCQUNoRjtnQkFDRCxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBS3BHLGdCQUFnQixHQUFHLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztnQkFDekYsT0FBTyxJQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ3hFLENBQUMsQ0FBQyxDQUFDO1NBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FDUCxDQUFDO1FBQ0YsT0FBTyxrQkFBa0IsQ0FBQzs7SUFxQjlCLGFBQWEsQ0FBQyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsTUFBcUMsRUFBRSxRQUFpQjtRQUd2SCxNQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsRCxJQUFJLENBQUNDLEtBQU8sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNuQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyx5REFBeUQ7a0JBQ25GLGtFQUFrRTtrQkFDbEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO1NBQzVEO2FBQU0sSUFBSUEsS0FBTyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUU7WUFDOUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixvREFBb0Q7a0JBQ3BELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtRQUVELElBQUlPLEtBQVUsQ0FBQztRQUNmLElBQUksbUJBQW1CLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQy9DQSxLQUFFLEdBQUcsUUFBUSxDQUFDO1NBQ2pCO1FBQ0QsSUFBSVAsS0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sS0FBSyw0QkFBNEIsQ0FBQyxhQUFhLEVBQUU7WUFDMUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRU8sS0FBRSxDQUFDLENBQUM7U0FDaEU7YUFBTTtZQUNILE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUVBLEtBQUUsQ0FBQyxDQUFDO1NBQ3JFO0tBQ0o7OztZQTFYSixVQUFVOzs7NENBSUYsTUFBTSxTQUFDLG9CQUFvQjtZQW5RM0IsVUFBVTtZQUdWLGlCQUFpQjs7O3NCQ0dJLFNBQVEsV0FBVztJQUU3QyxZQUEwQyxRQUE4QixJQUFnQjtRQUNwRixLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDN0Q7SUFLTSxnQkFBZ0IsQ0FBQyxZQUE4QjtRQUNsRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7OztZQVhsRCxVQUFVOzs7NENBR00sTUFBTSxTQUFDLG9CQUFvQjtZQVJwQyxVQUFVOzs7SUEyQmQsWUFBbUIsTUFBYyxFQUFTLFNBQWlCLEVBQVMsVUFBbUI7UUFBcEUsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFTLGNBQVMsR0FBVCxTQUFTLENBQVE7UUFBUyxlQUFVLEdBQVYsVUFBVSxDQUFTO0tBQ3RGO0NBQ0o7O3dCQ0wrQixTQUFRLFdBQVc7SUFFL0MsWUFBMEMsUUFBOEIsSUFBZ0I7UUFDcEYsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcscUJBQXFCLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQy9EO0lBS0QsTUFBTSxDQUFDLGNBQThCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0tBQ2hEOzs7WUFaSixVQUFVOzs7NENBR00sTUFBTSxTQUFDLG9CQUFvQjtZQXhCcEMsVUFBVTs7O0lBMkNkLEdBQUcsQ0FBQyxJQUFZLEVBQUUsS0FBYTtRQUMzQixJQUFJLElBQUksRUFBRTtZQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUM7U0FDdEI7S0FDSjtJQU1ELE1BQU0sQ0FBQyxJQUFZO1FBQ2YsSUFBSSxDQUFDUCxLQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDckI7S0FDSjtJQUVELE9BQU87UUFDSCxPQUFPLENBQUNhLElBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN4QjtDQUNKO0FBRUQ7SUFnQkksVUFBVSxDQUFDLGlCQUF5QixFQUFFLFFBQWdCLEVBQUUsY0FBK0I7UUFDbkYsTUFBTSxhQUFhLEdBQWE7WUFDNUIsaUJBQWlCLEVBQUUsaUJBQWlCO1lBQ3BDLFFBQVEsRUFBRSxRQUFRO1NBQ3JCLENBQUM7UUFFRixJQUFJLGNBQWMsRUFBRTtZQUNoQixhQUFhLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQztTQUN4QztRQUVELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1NBQ3RCO1FBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUM7S0FDZjtJQU9ELFVBQVUsQ0FBQyxPQUFlLEVBQUUsT0FBZTtRQUN2QyxJQUFJLENBQUMsV0FBVyxHQUFHO1lBQ2YsR0FBRyxFQUFFLE9BQU87WUFDWixPQUFPLEVBQUUsT0FBTztTQUNuQixDQUFDO1FBRUYsT0FBTyxJQUFJLENBQUM7S0FDZjtJQU9ELFVBQVUsQ0FBQyxPQUFlLEVBQUUsY0FBOEI7UUFDdEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUMzQixNQUFNLGFBQWEsR0FBaUI7Z0JBQ2hDLGtCQUFrQixFQUFFLE9BQU87YUFDOUIsQ0FBQztZQUNGZCxNQUFRLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBRXhDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUNwQixJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzthQUMxQjtZQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3pDO1FBQ0QsT0FBTyxJQUFJLENBQUM7S0FDZjtJQU1ELFVBQVUsQ0FBQyxPQUFlO1FBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDaEMsT0FBTyxJQUFJLENBQUM7S0FDZjtDQUNKOzt1QkN6SThCLFNBQVEsV0FBVztJQUU5QyxZQUEwQyxRQUE4QixJQUFnQjtRQUNwRixLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDOUQ7SUFLRCxpQkFBaUIsQ0FBQyxpQkFBb0M7UUFDbEQsSUFBSSxPQUFPLEdBQUcsaUJBQWlCLENBQUM7UUFDaEMsSUFBSUMsS0FBTyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLGFBQWEsS0FBSyxFQUFFLEVBQUU7WUFDcEYsSUFBSUEsS0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSUEsS0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDMUQsT0FBTyxHQUFHQyxLQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFDckMsT0FBTyxDQUFDLFNBQVMsR0FBR0EsS0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzFFLE9BQU8sQ0FBQyxTQUFTLEdBQUdBLEtBQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQzdFO1NBQ0o7UUFDRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN6Qzs7O1lBcEJKLFVBQVU7Ozs0Q0FHTSxNQUFNLFNBQUMsb0JBQW9CO1lBVG5DLFVBQVU7OztJQXdDZixZQUNXLEtBQW9CLFNBQW9CLEVBQVMsY0FBd0IsRUFDekUsZUFBK0IsU0FBMkIsRUFBUyxTQUEyQjtRQUQ5RixRQUFHLEdBQUgsR0FBRztRQUFpQixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQVMsbUJBQWMsR0FBZCxjQUFjLENBQVU7UUFDekUsa0JBQWEsR0FBYixhQUFhO1FBQWtCLGNBQVMsR0FBVCxTQUFTLENBQWtCO1FBQVMsY0FBUyxHQUFULFNBQVMsQ0FBa0I7S0FDeEc7Q0FFSjs7NEJDMUJtQyxTQUFRLFdBQVc7SUFFckQsWUFBMEMsUUFBOEIsSUFBZ0I7UUFDdEYsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcseUJBQXlCLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ2pFO0lBS00sc0JBQXNCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDOzs7O1lBWGpDLFVBQVU7Ozs0Q0FHSSxNQUFNLFNBQUMsb0JBQW9CO1lBdEJsQyxVQUFVOzs7aUJDS08sU0FBUSxXQUFXO0lBRXhDLFlBQTBDLFFBQThCLElBQWdCO1FBQ3BGLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDeEQ7SUFFRCxlQUFlLENBQUMsR0FBVztRQUN2QixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ3ZDOzs7WUFUSixVQUFVOzs7NENBR00sTUFBTSxTQUFDLG9CQUFvQjtZQVBuQyxVQUFVOzs7OEJDa0JtQixTQUFRLFdBQVc7SUFFdkQsWUFBMEMsUUFBOEIsSUFBZ0I7UUFDdEYsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsMkJBQTJCLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ25FO0lBS00sd0JBQXdCLENBQUMsb0JBQThDO1FBQzVFLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLG9CQUFvQixDQUFDLENBQUM7Ozs7WUFYdEQsVUFBVTs7OzRDQUdJLE1BQU0sU0FBQyxvQkFBb0I7WUFwQmxDLFVBQVU7OztJQXdDaEIsWUFBbUIsR0FBVyxFQUFTLG9CQUE2QixFQUNqRDtRQURBLFFBQUcsR0FBSCxHQUFHLENBQVE7UUFBUyx5QkFBb0IsR0FBcEIsb0JBQW9CLENBQVM7UUFDakQsMEJBQXFCLEdBQXJCLHFCQUFxQjtLQUN2QztDQUNGOzswQkM1QkcsTUFBNEIsRUFBRSxVQUFzQjtJQUNwRCxPQUFPLElBQUksZUFBZSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztDQUNsRDtBQUNELDBCQUNJLE1BQTRCLEVBQUUsVUFBc0I7SUFDcEQsT0FBTyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDbEQ7QUFDRCxnQ0FDSSxNQUE0QixFQUFFLFVBQXNCLEVBQUUsVUFBNkI7SUFDbkYsT0FBTyxJQUFJLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDcEU7QUFFRCwyQkFDSSxNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDbkQ7QUFDRCw2QkFDSSxNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDckQ7QUFDRCw0QkFDSSxNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE9BQU8sSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDcEQ7QUFDRCxpQ0FDSSxNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE9BQU8sSUFBSSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDekQ7QUFDRCxzQkFDSSxNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE9BQU8sSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQzlDO0FBQ0QsbUNBQ0UsTUFBNEIsRUFBRSxVQUFzQjtJQUNwRCxPQUFPLElBQUksd0JBQXdCLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQ3pEO0FBVUQ7SUFDSSxPQUFPLE9BQU8sQ0FBQyxNQUE0QjtRQUN2QyxPQUFPO1lBQ0gsUUFBUSxFQUFFLHdCQUF3QjtZQUNsQyxTQUFTLEVBQUU7Z0JBQ1A7b0JBQ0ksT0FBTyxFQUFFLGVBQWU7b0JBQ3hCLFVBQVUsRUFBRSxnQkFBZ0I7b0JBQzVCLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVO3FCQUNuQztpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsZUFBZTtvQkFDeEIsVUFBVSxFQUFFLGdCQUFnQjtvQkFDNUIsSUFBSSxFQUFFO3dCQUNGLG9CQUFvQixFQUFFLFVBQVU7cUJBQ25DO2lCQUNKO2dCQUNEO29CQUNJLE9BQU8sRUFBRSxxQkFBcUI7b0JBQzlCLFVBQVUsRUFBRSxzQkFBc0I7b0JBQ2xDLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVLEVBQUUsaUJBQWlCO3FCQUN0RDtpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsZ0JBQWdCO29CQUN6QixVQUFVLEVBQUUsaUJBQWlCO29CQUM3QixJQUFJLEVBQUU7d0JBQ0Ysb0JBQW9CLEVBQUUsVUFBVTtxQkFDbkM7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksT0FBTyxFQUFFLGtCQUFrQjtvQkFDM0IsVUFBVSxFQUFFLG1CQUFtQjtvQkFDL0IsSUFBSSxFQUFFO3dCQUNGLG9CQUFvQixFQUFFLFVBQVU7cUJBQ25DO2lCQUNKO2dCQUNEO29CQUNJLE9BQU8sRUFBRSxpQkFBaUI7b0JBQzFCLFVBQVUsRUFBRSxrQkFBa0I7b0JBQzlCLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVO3FCQUNuQztpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsc0JBQXNCO29CQUMvQixVQUFVLEVBQUUsdUJBQXVCO29CQUNuQyxJQUFJLEVBQUU7d0JBQ0Ysb0JBQW9CLEVBQUUsVUFBVTtxQkFDbkM7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksT0FBTyxFQUFFLFdBQVc7b0JBQ3BCLFVBQVUsRUFBRSxZQUFZO29CQUN4QixJQUFJLEVBQUU7d0JBQ0Ysb0JBQW9CLEVBQUUsVUFBVTtxQkFDbkM7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksT0FBTyxFQUFFLHdCQUF3QjtvQkFDakMsVUFBVSxFQUFFLHlCQUF5QjtvQkFDckMsSUFBSSxFQUFFO3dCQUNKLG9CQUFvQixFQUFFLFVBQVU7cUJBQ2pDO2lCQUNKO2dCQUNELEVBQUUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUU7YUFDdEQ7U0FDSixDQUFDO0tBQ0w7OztZQS9FSixRQUFRLFNBQUM7Z0JBQ04sT0FBTyxFQUFFO29CQUNMLFlBQVk7b0JBQ1osZ0JBQWdCO2lCQUNuQjtnQkFDRCxTQUFTLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztnQkFDOUIsWUFBWSxFQUFFLEVBQUU7YUFDbkI7Ozs7OyJ9