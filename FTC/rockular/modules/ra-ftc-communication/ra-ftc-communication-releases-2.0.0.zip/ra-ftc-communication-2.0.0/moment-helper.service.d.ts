import * as moment from 'moment-timezone';
export declare class MomentHelperService {
    static readonly MOMENT_DATETIME_FORMAT_UTC_FULL: string;
    static readonly MOMENT_DATETIME_FORMAT_TZ_FULL: string;
    static applyTimezone(datetime: string, timezone: string): string;
    static getAllTimezones(): string[];
    static isValidTimezone(timezone: any): moment.MomentZone;
}
