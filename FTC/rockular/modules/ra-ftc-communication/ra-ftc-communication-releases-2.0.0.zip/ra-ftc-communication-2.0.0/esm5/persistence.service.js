import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { COMMUNICATION_CONFIG } from './config';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
export function INewItem() { }
function INewItem_tsickle_Closure_declarations() {
    INewItem.prototype.parentPropertyFqn;
    INewItem.prototype.itemType;
    INewItem.prototype.props;
}
export function IRenamedItem() { }
function IRenamedItem_tsickle_Closure_declarations() {
    IRenamedItem.prototype.fqn;
    IRenamedItem.prototype.newName;
}
export function IChangedItem() { }
function IChangedItem_tsickle_Closure_declarations() {
    IChangedItem.prototype.FullyQualifiedName;
}
var PersistenceService = (function (_super) {
    tslib_1.__extends(PersistenceService, _super);
    function PersistenceService(config, http) {
        return _super.call(this, config.baseUrl + '/api/1/persistence/', config, http) || this;
    }
    PersistenceService.prototype.commit = function (persistRequest) {
        return this._sendPostRequest(persistRequest);
    };
    PersistenceService.decorators = [
        { type: Injectable },
    ];
    PersistenceService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return PersistenceService;
}(BaseService));
export { PersistenceService };
function PersistenceService_tsickle_Closure_declarations() {
    PersistenceService.decorators;
    PersistenceService.ctorParameters;
}
var PropNameValues = (function () {
    function PropNameValues() {
    }
    PropNameValues.prototype.add = function (name, value) {
        if (name) {
            this[name] = value;
        }
    };
    PropNameValues.prototype.remove = function (name) {
        if (!_.isNil(this[name])) {
            delete this[name];
        }
    };
    PropNameValues.prototype.isEmpty = function () {
        return !_.some(this);
    };
    return PropNameValues;
}());
export { PropNameValues };
var PersistRequest = (function () {
    function PersistRequest() {
    }
    PersistRequest.prototype.createItem = function (parentPropertyFqn, itemType, propNameValues) {
        var createRequest = {
            parentPropertyFqn: parentPropertyFqn,
            itemType: itemType
        };
        if (propNameValues) {
            createRequest.props = propNameValues;
        }
        if (!this.newItems) {
            this.newItems = [];
        }
        this.newItems.push(createRequest);
        return this;
    };
    PersistRequest.prototype.renameItem = function (itemFqn, newName) {
        this.renamedItem = {
            fqn: itemFqn,
            newName: newName
        };
        return this;
    };
    PersistRequest.prototype.changeItem = function (itemFqn, propNameValues) {
        if (!propNameValues.isEmpty()) {
            var changeRequest = {
                FullyQualifiedName: itemFqn
            };
            _.extend(changeRequest, propNameValues);
            if (!this.changedItems) {
                this.changedItems = [];
            }
            this.changedItems.push(changeRequest);
        }
        return this;
    };
    PersistRequest.prototype.deleteItem = function (itemFqn) {
        if (!this.deletedItems) {
            this.deletedItems = [];
        }
        this.deletedItems.push(itemFqn);
        return this;
    };
    return PersistRequest;
}());
export { PersistRequest };
function PersistRequest_tsickle_Closure_declarations() {
    PersistRequest.prototype.newItems;
    PersistRequest.prototype.renamedItem;
    PersistRequest.prototype.changedItems;
    PersistRequest.prototype.deletedItems;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyc2lzdGVuY2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJwZXJzaXN0ZW5jZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUMsTUFBTSxFQUFFLFVBQVUsRUFBQyxNQUFNLGVBQWUsQ0FBQztBQUNqRCxPQUFPLEVBQUMsV0FBVyxFQUFDLE1BQU0sZ0JBQWdCLENBQUM7QUFDM0MsT0FBTyxFQUFDLG9CQUFvQixFQUF1QixNQUFNLFVBQVUsQ0FBQztBQUNwRSxPQUFPLEVBQUMsVUFBVSxFQUFDLE1BQU0sc0JBQXNCLENBQUM7QUFHaEQsT0FBTyxLQUFLLENBQUMsTUFBTSxRQUFRLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBbUJZLDhDQUFXO0lBRS9DLDRCQUEwQyxRQUE4QixJQUFnQjtlQUNwRixrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLHFCQUFxQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUM7S0FDOUQ7SUFLRCxtQ0FBTSxHQUFOLFVBQU8sY0FBOEI7UUFDakMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUNoRDs7Z0JBWkosVUFBVTs7O2dEQUdNLE1BQU0sU0FBQyxvQkFBb0I7Z0JBeEJwQyxVQUFVOzs2QkFIbEI7RUF5QndDLFdBQVc7U0FBdEMsa0JBQWtCOzs7OztBQWMvQixJQUFBOzs7SUFPSSw0QkFBRyxHQUFILFVBQUksSUFBWSxFQUFFLEtBQWE7UUFDM0IsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUM7U0FDdEI7S0FDSjtJQU1ELCtCQUFNLEdBQU4sVUFBTyxJQUFZO1FBQ2YsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNyQjtLQUNKO0lBRUQsZ0NBQU8sR0FBUDtRQUNJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDeEI7eUJBaEVMO0lBaUVDLENBQUE7QUExQkQsMEJBMEJDO0FBRUQsSUFBQTs7O0lBZ0JJLG1DQUFVLEdBQVYsVUFBVyxpQkFBeUIsRUFBRSxRQUFnQixFQUFFLGNBQStCO1FBQ25GLElBQU0sYUFBYSxHQUFhO1lBQzVCLGlCQUFpQixFQUFFLGlCQUFpQjtZQUNwQyxRQUFRLEVBQUUsUUFBUTtTQUNyQixDQUFDO1FBRUYsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztZQUNqQixhQUFhLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQztTQUN4QztRQUVELEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7U0FDdEI7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNsQyxNQUFNLENBQUMsSUFBSSxDQUFDO0tBQ2Y7SUFPRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZSxFQUFFLE9BQWU7UUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRztZQUNmLEdBQUcsRUFBRSxPQUFPO1lBQ1osT0FBTyxFQUFFLE9BQU87U0FDbkIsQ0FBQztRQUVGLE1BQU0sQ0FBQyxJQUFJLENBQUM7S0FDZjtJQU9ELG1DQUFVLEdBQVYsVUFBVyxPQUFlLEVBQUUsY0FBOEI7UUFDdEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzVCLElBQU0sYUFBYSxHQUFpQjtnQkFDaEMsa0JBQWtCLEVBQUUsT0FBTzthQUM5QixDQUFDO1lBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsY0FBYyxDQUFDLENBQUM7WUFFeEMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7YUFDMUI7WUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUN6QztRQUNELE1BQU0sQ0FBQyxJQUFJLENBQUM7S0FDZjtJQU1ELG1DQUFVLEdBQVYsVUFBVyxPQUFlO1FBQ3RCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7U0FDMUI7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNoQyxNQUFNLENBQUMsSUFBSSxDQUFDO0tBQ2Y7eUJBakpMO0lBa0pDLENBQUE7QUEvRUQsMEJBK0VDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Jhc2VTZXJ2aWNlfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7Q09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7SHR0cENsaWVudH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge2lkZW50aWZpZXJ9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJTmV3SXRlbSB7XHJcbiAgICBwYXJlbnRQcm9wZXJ0eUZxbjogc3RyaW5nO1xyXG4gICAgaXRlbVR5cGU6IHN0cmluZztcclxuICAgIHByb3BzPzogUHJvcE5hbWVWYWx1ZXM7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVJlbmFtZWRJdGVtIHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmV3TmFtZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElDaGFuZ2VkSXRlbSB7XHJcbiAgICBGdWxseVF1YWxpZmllZE5hbWU6IHN0cmluZztcclxuICAgIFtrZXk6IHN0cmluZ106IGFueTtcclxufVxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgUGVyc2lzdGVuY2VTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvcGVyc2lzdGVuY2UvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gUGVyc2lzdGVuY2Ugc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAqL1xyXG4gICAgY29tbWl0KHBlcnNpc3RSZXF1ZXN0OiBQZXJzaXN0UmVxdWVzdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChwZXJzaXN0UmVxdWVzdCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQcm9wTmFtZVZhbHVlcyB7XHJcblxyXG4gIC8qKlxyXG4gICAqIEFkZHMgcHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyIGZvciBOZXcgSXRlbSBDcmVhdGlvblxyXG4gICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gYWRkXHJcbiAgICogQHBhcmFtIHZhbHVlIC0gVmFsdWUgdG8gYWRkIGF0IE5hbWUgcHJvcGVydHkgbmFtZVxyXG4gICAqL1xyXG4gICAgYWRkKG5hbWU6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xyXG4gICAgICAgIGlmIChuYW1lKSB7XHJcbiAgICAgICAgICAgIHRoaXNbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmVzIHByb3BlcnR5IE5hbWVcclxuICAgICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZShuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoIV8uaXNOaWwodGhpc1tuYW1lXSkpIHtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXNbbmFtZV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlzRW1wdHkoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICFfLnNvbWUodGhpcyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAvKiogTGlzdCBvZiBuZXcgaXRlbXMgdG8gcGVyc2lzdCAqL1xyXG4gICAgbmV3SXRlbXM6IElOZXdJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byByZW5hbWUgKi9cclxuICAgIHJlbmFtZWRJdGVtOiBJUmVuYW1lZEl0ZW07XHJcbiAgICAvKiogTGlzdCBvZiBjaGFuZ2VkIGl0ZW1zIHRvIHBlcnNpc3QgKi9cclxuICAgIGNoYW5nZWRJdGVtczogSUNoYW5nZWRJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byBkZWxldGUgKi9cclxuICAgIGRlbGV0ZWRJdGVtczogaWRlbnRpZmllcltdO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ3JlYXRlIEl0ZW0gdmlhIFBlcnNpc3RlbmNlIFNlcnZpY2VcclxuICAgICAqIEBwYXJhbSBwYXJlbnRQcm9wZXJ0eUZxbiAtIEZRTiBvZiBQYXJlbnQgUHJvcGVydHlcclxuICAgICAqIEBwYXJhbSBpdGVtVHlwZSAtIEl0ZW0gVHlwZVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyc1xyXG4gICAgICovXHJcbiAgICBjcmVhdGVJdGVtKHBhcmVudFByb3BlcnR5RnFuOiBzdHJpbmcsIGl0ZW1UeXBlOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzPzogUHJvcE5hbWVWYWx1ZXMpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgY29uc3QgY3JlYXRlUmVxdWVzdDogSU5ld0l0ZW0gPSB7XHJcbiAgICAgICAgICAgIHBhcmVudFByb3BlcnR5RnFuOiBwYXJlbnRQcm9wZXJ0eUZxbixcclxuICAgICAgICAgICAgaXRlbVR5cGU6IGl0ZW1UeXBlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKHByb3BOYW1lVmFsdWVzKSB7XHJcbiAgICAgICAgICAgIGNyZWF0ZVJlcXVlc3QucHJvcHMgPSBwcm9wTmFtZVZhbHVlcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5uZXdJdGVtcykge1xyXG4gICAgICAgICAgICB0aGlzLm5ld0l0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5ld0l0ZW1zLnB1c2goY3JlYXRlUmVxdWVzdCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW5hbWUgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIG5ld05hbWUgLSBOZXcgTmFtZSBvZiBJdGVtXHJcbiAgICAgKi9cclxuICAgIHJlbmFtZUl0ZW0oaXRlbUZxbjogc3RyaW5nLCBuZXdOYW1lOiBzdHJpbmcpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgdGhpcy5yZW5hbWVkSXRlbSA9IHtcclxuICAgICAgICAgICAgZnFuOiBpdGVtRnFuLFxyXG4gICAgICAgICAgICBuZXdOYW1lOiBuZXdOYW1lXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDaGFuZ2UgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydGllcyB0byBjaGFuZ2VcclxuICAgICAqL1xyXG4gICAgY2hhbmdlSXRlbShpdGVtRnFuOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzOiBQcm9wTmFtZVZhbHVlcyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXByb3BOYW1lVmFsdWVzLmlzRW1wdHkoKSkge1xyXG4gICAgICAgICAgICBjb25zdCBjaGFuZ2VSZXF1ZXN0OiBJQ2hhbmdlZEl0ZW0gPSB7XHJcbiAgICAgICAgICAgICAgICBGdWxseVF1YWxpZmllZE5hbWU6IGl0ZW1GcW5cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgXy5leHRlbmQoY2hhbmdlUmVxdWVzdCwgcHJvcE5hbWVWYWx1ZXMpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNoYW5nZWRJdGVtcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VkSXRlbXMgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmNoYW5nZWRJdGVtcy5wdXNoKGNoYW5nZVJlcXVlc3QpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIERlbGV0ZSBJdGVtIHZpYSBQZXJzaXN0ZW5jZSBTZXJ2aWNlXHJcbiAgICAgKiBAcGFyYW0gaXRlbUZxbiAtIEZRTiBvZiBJdGVtIHRvIGRlbGV0ZVxyXG4gICAgICovXHJcbiAgICBkZWxldGVJdGVtKGl0ZW1GcW46IHN0cmluZyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXRoaXMuZGVsZXRlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zLnB1c2goaXRlbUZxbik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcbn1cclxuIl19