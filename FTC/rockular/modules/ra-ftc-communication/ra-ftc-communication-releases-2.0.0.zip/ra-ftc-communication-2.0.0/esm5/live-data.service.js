import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import { Observable, Subject, timer } from 'rxjs';
import { map, expand, concatMap } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
export function ILiveResponseProxyValue() { }
function ILiveResponseProxyValue_tsickle_Closure_declarations() {
    ILiveResponseProxyValue.prototype.fqn;
    ILiveResponseProxyValue.prototype.name;
    ILiveResponseProxyValue.prototype.type;
    ILiveResponseProxyValue.prototype.createdOn;
    ILiveResponseProxyValue.prototype.createdOnOffset;
    ILiveResponseProxyValue.prototype.modifiedOn;
    ILiveResponseProxyValue.prototype.modifiedOnOffset;
}
export function ILiveResponse() { }
function ILiveResponse_tsickle_Closure_declarations() {
    ILiveResponse.prototype.v;
    ILiveResponse.prototype.q;
    ILiveResponse.prototype.t;
}
function ILiveResponseInternalVqtObject() { }
function ILiveResponseInternalVqtObject_tsickle_Closure_declarations() {
    ILiveResponseInternalVqtObject.prototype.v;
    ILiveResponseInternalVqtObject.prototype.q;
    ILiveResponseInternalVqtObject.prototype.t;
}
function ILiveResponseInternalObject() { }
function ILiveResponseInternalObject_tsickle_Closure_declarations() {
    ILiveResponseInternalObject.prototype.fqn;
    ILiveResponseInternalObject.prototype.name;
    ILiveResponseInternalObject.prototype.engineeringUnit;
    ILiveResponseInternalObject.prototype.valueType;
    ILiveResponseInternalObject.prototype.value;
}
function ILiveResponseInternal() { }
function ILiveResponseInternal_tsickle_Closure_declarations() {
    ILiveResponseInternal.prototype.fqnsResults;
    ILiveResponseInternal.prototype.queryResults;
}
var LiveRequest = (function () {
    function LiveRequest(fqns) {
        this.fqns = fqns;
        this.fqns = _.clone(fqns);
    }
    LiveRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    LiveRequest.prototype.removeFqn = function (fqn) {
        var index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    return LiveRequest;
}());
export { LiveRequest };
function LiveRequest_tsickle_Closure_declarations() {
    LiveRequest.prototype.fqns;
}
var LiveDataService = (function (_super) {
    tslib_1.__extends(LiveDataService, _super);
    function LiveDataService(config, http) {
        var _this = _super.call(this, config.baseUrl + '/api/1/live/', config, http) || this;
        _this._fqns = new Map();
        return _this;
    }
    LiveDataService.prototype.getOnce = function (request) {
        return this._sendPostRequest(request).pipe(map(function (response) {
            var ret = [];
            _.each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._getInnerRepeatedObservable = function () {
        return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
            .pipe(map(function (response) {
            var ret = [];
            _.each(response.fqnsResults, function (oneResult) {
                ret.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    v: oneResult.value.v,
                    q: oneResult.value.q,
                    t: oneResult.value.t
                });
            });
            return ret;
        }));
    };
    LiveDataService.prototype._initializeRepeatedData = function () {
        var _this = this;
        if (!this._repeatedDataSubject) {
            this._repeatedDataSubject = new Subject();
        }
        if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
            var repeatedInterval_1 = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval_1 = repeatedInterval_1 * 1000;
            this._repeatedDataObservable = this._getInnerRepeatedObservable();
            this._repeatedDataSubscription = this._repeatedDataObservable.pipe(expand(function () { return timer(repeatedInterval_1).pipe(concatMap(function () { return _this._getInnerRepeatedObservable(); })); })).subscribe(function (response) {
                _this._repeatedDataSubject.next(response);
            }, function (err) {
                _this._repeatedDataSubscription.unsubscribe();
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.error(err);
            }, function () {
                _this._reinitializeRepeatedObservable = true;
                _this._repeatedDataSubject.complete();
            });
            this._reinitializeRepeatedObservable = false;
        }
        return this._repeatedDataObservable;
    };
    LiveDataService.prototype.getRepeatedly = function (request) {
        var _this = this;
        return new Observable(function (observer) {
            _.each(request.fqns, function (fqn) {
                var newVal = 0;
                if (_this._fqns.has(fqn)) {
                    newVal = _this._fqns.get(fqn);
                }
                _this._fqns.set(fqn, ++newVal);
            });
            _this._initializeRepeatedData();
            var subscription = _this._repeatedDataSubject.asObservable().pipe(map(function (currentResponse) {
                return _.filter(currentResponse, function (o) {
                    return _.indexOf(request.fqns, o.fqn) > -1;
                });
            })).subscribe(function (response) {
                observer.next(response);
            }, function (error) {
                observer.error(error);
            }, function () {
                observer.complete();
            });
            return function () {
                _.each(request.fqns, function (fqn) {
                    var newVal = 1;
                    if (_this._fqns.has(fqn)) {
                        newVal = _this._fqns.get(fqn);
                    }
                    if (newVal === 1) {
                        _this._fqns.delete(fqn);
                    }
                    else {
                        _this._fqns.set(fqn, --newVal);
                    }
                });
                subscription.unsubscribe();
                observer.unsubscribe();
                if (_this._fqns.size === 0) {
                    if (_this._repeatedDataSubscription) {
                        _this._repeatedDataSubscription.unsubscribe();
                    }
                    _this._repeatedDataSubject.complete();
                    delete _this._repeatedDataSubject;
                    _this._reinitializeRepeatedObservable = true;
                }
            };
        });
    };
    LiveDataService.decorators = [
        { type: Injectable },
    ];
    LiveDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return LiveDataService;
}(BaseService));
export { LiveDataService };
function LiveDataService_tsickle_Closure_declarations() {
    LiveDataService.decorators;
    LiveDataService.ctorParameters;
    LiveDataService.prototype._fqns;
    LiveDataService.prototype._repeatedDataObservable;
    LiveDataService.prototype._repeatedDataSubscription;
    LiveDataService.prototype._repeatedDataSubject;
    LiveDataService.prototype._reinitializeRepeatedObservable;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGl2ZS1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsibGl2ZS1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLEVBQUUsVUFBVSxFQUFnQixPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ2hFLE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsOEJBQThCLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFFdEcsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEyQzdDLElBQUE7SUFLSSxxQkFBcUIsSUFBa0I7UUFBbEIsU0FBSSxHQUFKLElBQUksQ0FBYztRQUVuQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDN0I7SUFNRCw0QkFBTSxHQUFOLFVBQU8sR0FBZTtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUN2QjtJQU1ELCtCQUFTLEdBQVQsVUFBVSxHQUFlO1FBQ3JCLElBQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN4QyxFQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztTQUM5QjtLQUNKO3NCQTdFTDtJQThFQyxDQUFBO0FBNUJELHVCQTRCQzs7Ozs7SUFNb0MsMkNBQVc7SUFRNUMseUJBQTBDLFFBQThCLElBQWdCO1FBQXhGLFlBQ0ksa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUN2RDtzQkFSb0MsSUFBSSxHQUFHLEVBQUU7O0tBUTdDO0lBTUQsaUNBQU8sR0FBUCxVQUFRLE9BQW9CO1FBQ3hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUN0QyxHQUFHLENBQUMsVUFBQyxRQUErQjtZQUNoQyxJQUFNLEdBQUcsR0FBaUIsRUFBRSxDQUFDO1lBQzdCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7Z0JBQ25DLEdBQUcsQ0FBQyxJQUFJLENBQUM7b0JBQ0wsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO29CQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7b0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztvQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO29CQUMxQyxDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixDQUFDLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN2QixDQUFDLENBQUM7YUFDTixDQUFDLENBQUM7WUFDSCxNQUFNLENBQUMsR0FBRyxDQUFDO1NBQ2QsQ0FBQyxDQUFDLENBQUM7S0FDWDtJQUVPLHFEQUEyQjtRQUMvQixNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDaEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLFFBQStCO1lBQ3RDLElBQU0sR0FBRyxHQUFpQixFQUFFLENBQUM7WUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQUMsU0FBUztnQkFDbkMsR0FBRyxDQUFDLElBQUksQ0FBQztvQkFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUk7b0JBQ3BCLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRztvQkFDbEIsU0FBUyxFQUFFLFNBQVMsQ0FBQyxTQUFTO29CQUM5QixlQUFlLEVBQUUsU0FBUyxDQUFDLGVBQWU7b0JBQzFDLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3ZCLENBQUMsQ0FBQzthQUNOLENBQUMsQ0FBQztZQUNILE1BQU0sQ0FBQyxHQUFHLENBQUM7U0FDZCxDQUFDLENBQUMsQ0FBQzs7SUFHSixpREFBdUI7O1FBQzNCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxPQUFPLEVBQWdCLENBQUM7U0FDM0Q7UUFFRCxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsSUFBSSxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDO1lBQ3hFLElBQUksa0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSw4QkFBOEIsQ0FBQztZQUNqRyxrQkFBZ0IsR0FBRyxrQkFBZ0IsR0FBRyxJQUFJLENBQUM7WUFFM0MsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1lBS2xFLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUM5RCxNQUFNLENBQUMsY0FBTSxPQUFBLEtBQUssQ0FBQyxrQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQywyQkFBMkIsRUFBRSxFQUFsQyxDQUFrQyxDQUFDLENBQUMsRUFBakYsQ0FBaUYsQ0FBQyxDQUNsRyxDQUFDLFNBQVMsQ0FBQyxVQUFDLFFBQXNCO2dCQUMvQixLQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzVDLEVBQUUsVUFBQyxHQUFHO2dCQUNILEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDN0MsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztnQkFDNUMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUN4QyxFQUFFO2dCQUNDLEtBQUksQ0FBQywrQkFBK0IsR0FBRyxJQUFJLENBQUM7Z0JBQzVDLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUN4QyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsK0JBQStCLEdBQUcsS0FBSyxDQUFDO1NBQ2hEO1FBRUQsTUFBTSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQzs7SUFPeEMsdUNBQWEsR0FBYixVQUFjLE9BQW9CO1FBQWxDLGlCQWtEQztRQWhERyxNQUFNLENBQUMsSUFBSSxVQUFVLENBQWUsVUFBQyxRQUFRO1lBRXpDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxVQUFDLEdBQUc7Z0JBQ3JCLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDZixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3RCLE1BQU0sR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDaEM7Z0JBQ0QsS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDakMsQ0FBQyxDQUFDO1lBQ0gsS0FBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDL0IsSUFBTSxZQUFZLEdBQUcsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxlQUE2QjtnQkFDakcsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLFVBQUMsQ0FBQztvQkFDL0IsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQzlDLENBQUMsQ0FBQzthQUNOLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFDLFFBQXNCO2dCQUNqQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzNCLEVBQUUsVUFBQyxLQUFLO2dCQUNMLFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDekIsRUFBRTtnQkFDQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDdkIsQ0FBQyxDQUFDO1lBRUgsTUFBTSxDQUFDO2dCQUVILENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxVQUFDLEdBQUc7b0JBQ3JCLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFDZixFQUFFLENBQUMsQ0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RCLE1BQU0sR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDaEM7b0JBQ0QsRUFBRSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2YsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQzFCO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLEtBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO3FCQUNqQztpQkFDSixDQUFDLENBQUM7Z0JBRUgsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMzQixRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3ZCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hCLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7d0JBQ2pDLEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztxQkFDaEQ7b0JBQ0QsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNyQyxPQUFPLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQztvQkFDakMsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztpQkFDL0M7YUFDSixDQUFDO1NBQ0wsQ0FBQyxDQUFDO0tBQ047O2dCQTdJSixVQUFVOzs7Z0RBU00sTUFBTSxTQUFDLG9CQUFvQjtnQkEzRm5DLFVBQVU7OzBCQURuQjtFQW9GcUMsV0FBVztTQUFuQyxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCAqIGFzIF8gZnJvbSAnbG9kYXNoJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3Vic2NyaXB0aW9uLCBTdWJqZWN0LCB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAsIGV4cGFuZCwgY29uY2F0TWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcsIERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTCB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgaWRlbnRpZmllciwgSVJlc3BvbnNlIH0gZnJvbSAnLi9zaGFyZWQnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcHJveHkgdmFsdWUgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElMaXZlUmVzcG9uc2VQcm94eVZhbHVlIHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmFtZTogc3RyaW5nO1xyXG4gICAgdHlwZTogc3RyaW5nO1xyXG4gICAgY3JlYXRlZE9uPzogc3RyaW5nO1xyXG4gICAgY3JlYXRlZE9uT2Zmc2V0PzogbnVtYmVyO1xyXG4gICAgbW9kaWZpZWRPbj86IHN0cmluZztcclxuICAgIG1vZGlmaWVkT25PZmZzZXQ/OiBudW1iZXI7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgcmVzcG9uc2Ugc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElMaXZlUmVzcG9uc2UgZXh0ZW5kcyBJUmVzcG9uc2Uge1xyXG4gICAgdjogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbiB8IElMaXZlUmVzcG9uc2VQcm94eVZhbHVlW107XHJcbiAgICBxOiBudW1iZXI7XHJcbiAgICB0OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIExpdmVSZXNwb25zZSA9IElMaXZlUmVzcG9uc2VbXTtcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBsaXZlIGRhdGEgdnF0IGludGVybmFsIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElMaXZlUmVzcG9uc2VJbnRlcm5hbFZxdE9iamVjdCB7XHJcbiAgICB2OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgSUxpdmVSZXNwb25zZVByb3h5VmFsdWVbXTtcclxuICAgIHE6IG51bWJlcjtcclxuICAgIHQ6IHN0cmluZztcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGxpdmUgZGF0YSByZXNwb25zZSBvYmplY3QgaW50ZXJuYWwgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSUxpdmVSZXNwb25zZUludGVybmFsT2JqZWN0IHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmFtZT86IHN0cmluZztcclxuICAgIGVuZ2luZWVyaW5nVW5pdD86IHN0cmluZztcclxuICAgIHZhbHVlVHlwZT86IHN0cmluZztcclxuICAgIHZhbHVlOiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxWcXRPYmplY3Q7XHJcbn1cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGxpdmUgZGF0YSByZXNwb25zZSBpbnRlcm5hbCAocmF3KSBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJTGl2ZVJlc3BvbnNlSW50ZXJuYWwge1xyXG4gICAgZnFuc1Jlc3VsdHM/OiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxuICAgIHF1ZXJ5UmVzdWx0cz86IElMaXZlUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTGl2ZVJlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBMaXZlIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSBmcW5zIExpc3Qgb2YgZnFucyAoaWRlbnRpZmljYXRvcnMpIHRvIGJlIHVzZWQgZm9yIHJlcXVlc3RcclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IocmVhZG9ubHkgZnFuczogaWRlbnRpZmllcltdXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLmZxbnMgPSBfLmNsb25lKGZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIG9uZSBmcW4gdG8gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gYWRkXHJcbiAgICAgKi9cclxuICAgIGFkZEZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICB0aGlzLmZxbnMucHVzaChmcW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmVtb3ZlIG9uZSBmcW4gZnJvbSByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byByZW1vdmVcclxuICAgICAqL1xyXG4gICAgcmVtb3ZlRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIGNvbnN0IGluZGV4ID0gXy5pbmRleE9mKHRoaXMuZnFucywgZnFuKTtcclxuICAgICAgICBpZiAoaW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFRoaXMgc2VydmljZSBwcm92aWRlcyBhIHNldCBvZiBtZXRob2RzIGZvciBzZW5kaW5nIHJlcXVlc3RzIHRvIG9idGFpbiBsaXZlIGRhdGEuXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBMaXZlRGF0YVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcbiAgICAvKiogQGludGVybmFsIGFjdHVhbCByZXBlYXRlZCBsaXZlIHJlcXVlc3QgZnFucyAqL1xyXG4gICAgcHJpdmF0ZSBfZnFuczogTWFwPHN0cmluZywgbnVtYmVyPiA9IG5ldyBNYXAoKTtcclxuICAgIHByaXZhdGUgX3JlcGVhdGVkRGF0YU9ic2VydmFibGU6IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPjtcclxuICAgIHByaXZhdGUgX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfcmVwZWF0ZWREYXRhU3ViamVjdDogU3ViamVjdDxMaXZlUmVzcG9uc2U+O1xyXG4gICAgcHJpdmF0ZSBfcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlOiBib29sZWFuO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbGl2ZS8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgbGl2ZSByZXF1ZXN0IHRvIHNlcnZlciwgYnV0IG9ubHkgb25jZS5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IGxpdmUgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKi9cclxuICAgIGdldE9uY2UocmVxdWVzdDogTGl2ZVJlcXVlc3QpOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCkucGlwZShcclxuICAgICAgICAgICAgbWFwKChyZXNwb25zZTogSUxpdmVSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXQ6IExpdmVSZXNwb25zZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAob25lUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBvbmVSZXN1bHQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnFuOiBvbmVSZXN1bHQuZnFuLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6IG9uZVJlc3VsdC52YWx1ZVR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZ2luZWVyaW5nVW5pdDogb25lUmVzdWx0LmVuZ2luZWVyaW5nVW5pdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdjogb25lUmVzdWx0LnZhbHVlLnYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHE6IG9uZVJlc3VsdC52YWx1ZS5xLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0OiBvbmVSZXN1bHQudmFsdWUudFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmV0O1xyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0SW5uZXJSZXBlYXRlZE9ic2VydmFibGUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdCh7IGZxbnM6IEFycmF5LmZyb20odGhpcy5fZnFucy5rZXlzKCkpIH0pXHJcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzcG9uc2U6IElMaXZlUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmV0OiBMaXZlUmVzcG9uc2UgPSBbXTtcclxuICAgICAgICAgICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKG9uZVJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldC5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogb25lUmVzdWx0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZxbjogb25lUmVzdWx0LmZxbixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUeXBlOiBvbmVSZXN1bHQudmFsdWVUeXBlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmdpbmVlcmluZ1VuaXQ6IG9uZVJlc3VsdC5lbmdpbmVlcmluZ1VuaXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHY6IG9uZVJlc3VsdC52YWx1ZS52LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBxOiBvbmVSZXN1bHQudmFsdWUucSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdDogb25lUmVzdWx0LnZhbHVlLnRcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJldDtcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRpYWxpemVSZXBlYXRlZERhdGEoKTogT2JzZXJ2YWJsZTxMaXZlUmVzcG9uc2U+IHtcclxuICAgICAgICBpZiAoIXRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdCA9IG5ldyBTdWJqZWN0PExpdmVSZXNwb25zZT4oKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5fcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZSB8fCB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUpIHtcclxuICAgICAgICAgICAgbGV0IHJlcGVhdGVkSW50ZXJ2YWwgPSB0aGlzLmNvbmZpZy5kZWZhdWx0UmVwZWF0ZWREYXRhSW50ZXJ2YWwgfHwgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMO1xyXG4gICAgICAgICAgICByZXBlYXRlZEludGVydmFsID0gcmVwZWF0ZWRJbnRlcnZhbCAqIDEwMDA7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlID0gdGhpcy5fZ2V0SW5uZXJSZXBlYXRlZE9ic2VydmFibGUoKTtcclxuICAgICAgICAgICAgLy8gRXhwYW5kIGN1cnJlbnQgb2JzZXJ2YWJsZSBzZXF1ZW5jZSBieSByZWN1cnNpdmVseSBpbnZva2luZyBzZWxlY3RvciAtXHJcbiAgICAgICAgICAgIC8vIGEgdGltZXIgYmFzZWQgb24gaW50ZXJ2YWwsIHdoaWNoIHdpbGwgcmVwZWF0IHJlcXVlc3QgYW5kIHByb2Nlc3MgcmVzcG9uc2UuXHJcbiAgICAgICAgICAgIC8vIE9ic2VydmFibGUgdGltZXI6XHJcbiAgICAgICAgICAgIC8vIFJldHVybnMgYW4gb2JzZXJ2YWJsZSBzZXF1ZW5jZSB0aGF0IHByb2R1Y2VzIGEgdmFsdWUgYWZ0ZXIgZHVlVGltZSBoYXMgZWxhcHNlZCBhbmQgdGhlbiBhZnRlciBlYWNoIHBlcmlvZC5cclxuICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uID0gdGhpcy5fcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZS5waXBlKFxyXG4gICAgICAgICAgICAgICAgZXhwYW5kKCgpID0+IHRpbWVyKHJlcGVhdGVkSW50ZXJ2YWwpLnBpcGUoY29uY2F0TWFwKCgpID0+IHRoaXMuX2dldElubmVyUmVwZWF0ZWRPYnNlcnZhYmxlKCkpKSlcclxuICAgICAgICAgICAgKS5zdWJzY3JpYmUoKHJlc3BvbnNlOiBMaXZlUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QubmV4dChyZXNwb25zZSk7XHJcbiAgICAgICAgICAgIH0sIChlcnIpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QuZXJyb3IoZXJyKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3JlcGVhdGVkRGF0YU9ic2VydmFibGU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCByZXF1ZXN0IGZvciBsaXZlIGRhdGEgcmVwZWF0ZWRseS4gSXQgcmVwZWF0ZWRseSBzZW5kcyByZXF1ZXN0cyB0byBzZXJ2ZXIuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCBsaXZlIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICovXHJcbiAgICBnZXRSZXBlYXRlZGx5KHJlcXVlc3Q6IExpdmVSZXF1ZXN0KTogT2JzZXJ2YWJsZTxMaXZlUmVzcG9uc2U+IHtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4oKG9ic2VydmVyKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIHdlIHJlZ2lzdGVyIG5ldyBpZGVudGlmaWNhdG9ycyBmb3IgcGVyaW9kaWMgbGl2ZSB1cGRhdGVzXHJcbiAgICAgICAgICAgIF8uZWFjaChyZXF1ZXN0LmZxbnMsIChmcW4pID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdWYWwgPSAwO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2ZxbnMuaGFzKGZxbikpIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWwgPSB0aGlzLl9mcW5zLmdldChmcW4pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZnFucy5zZXQoZnFuLCArK25ld1ZhbCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLl9pbml0aWFsaXplUmVwZWF0ZWREYXRhKCk7XHJcbiAgICAgICAgICAgIGNvbnN0IHN1YnNjcmlwdGlvbiA9IHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3QuYXNPYnNlcnZhYmxlKCkucGlwZShtYXAoKGN1cnJlbnRSZXNwb25zZTogTGl2ZVJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gXy5maWx0ZXIoY3VycmVudFJlc3BvbnNlLCAobykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBfLmluZGV4T2YocmVxdWVzdC5mcW5zLCBvLmZxbikgPiAtMTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KSkuc3Vic2NyaWJlKChyZXNwb25zZTogTGl2ZVJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfSwgKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgICAgIH0sICgpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIHdlIHVucmVnaXN0ZXIgaWRlbnRpZmljYXRvcnMgZm9yIHBlcmlvZGljIGxpdmUgdXBkYXRlc1xyXG4gICAgICAgICAgICAgICAgXy5lYWNoKHJlcXVlc3QuZnFucywgKGZxbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuZXdWYWwgPSAxO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mcW5zLmhhcyhmcW4pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld1ZhbCA9IHRoaXMuX2ZxbnMuZ2V0KGZxbik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXdWYWwgPT09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZnFucy5kZWxldGUoZnFuKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9mcW5zLnNldChmcW4sIC0tbmV3VmFsKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBzdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZnFucy5zaXplID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19