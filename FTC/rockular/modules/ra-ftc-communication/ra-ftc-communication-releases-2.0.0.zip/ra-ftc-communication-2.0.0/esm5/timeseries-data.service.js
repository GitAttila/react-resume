import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { OpcQualityService } from './opc-quality.service';
import { Observable, timer } from 'rxjs';
import { map, concatMap, expand } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
import { MomentHelperService } from './moment-helper.service';
export function ITimeseriesValuesResponseVqts() { }
function ITimeseriesValuesResponseVqts_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseVqts.prototype.v;
    ITimeseriesValuesResponseVqts.prototype.q;
    ITimeseriesValuesResponseVqts.prototype.t;
}
export function ITimeseriesValuesResponse() { }
function ITimeseriesValuesResponse_tsickle_Closure_declarations() {
    ITimeseriesValuesResponse.prototype.values;
}
export function ITimeseriesResponse() { }
function ITimeseriesResponse_tsickle_Closure_declarations() {
    ITimeseriesResponse.prototype.timePeriod;
    ITimeseriesResponse.prototype.results;
}
function ITimeseriesValuesResponseInternalObject() { }
function ITimeseriesValuesResponseInternalObject_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseInternalObject.prototype.fqn;
    ITimeseriesValuesResponseInternalObject.prototype.name;
    ITimeseriesValuesResponseInternalObject.prototype.engineeringUnit;
    ITimeseriesValuesResponseInternalObject.prototype.valueType;
    ITimeseriesValuesResponseInternalObject.prototype.values;
}
export function ITimePeriodResponse() { }
function ITimePeriodResponse_tsickle_Closure_declarations() {
    ITimePeriodResponse.prototype.start;
    ITimePeriodResponse.prototype.end;
    ITimePeriodResponse.prototype.duration;
}
function ITimeseriesValuesResponseInternal() { }
function ITimeseriesValuesResponseInternal_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseInternal.prototype.timePeriod;
    ITimeseriesValuesResponseInternal.prototype.fqnsResults;
    ITimeseriesValuesResponseInternal.prototype.queryResults;
}
export function ITimePeriod() { }
function ITimePeriod_tsickle_Closure_declarations() {
    ITimePeriod.prototype.start;
    ITimePeriod.prototype.end;
    ITimePeriod.prototype.duration;
}
var TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
export { TimeseriesRequestQuality };
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = "includeGood";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = "includeBad";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = "includeUncertain";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = "includeAll";
var TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
export { TimeseriesRepeatedDataFormat };
var SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
};
export { SamplingTypes };
export function ISamplingDefinition() { }
function ISamplingDefinition_tsickle_Closure_declarations() {
    ISamplingDefinition.prototype.sliceCount;
    ISamplingDefinition.prototype.deltaT;
    ISamplingDefinition.prototype.samplingType;
}
var TimeseriesRequest = (function () {
    function TimeseriesRequest(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    TimeseriesRequest.prototype.addFqn = function (fqn) {
        this.fqns.push(fqn);
    };
    TimeseriesRequest.prototype.removeFqn = function (fqn) {
        var index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    };
    TimeseriesRequest.prototype.setFqns = function (fqns) {
        this.fqns = _.clone(fqns);
    };
    TimeseriesRequest.prototype.getFqns = function () {
        return _.clone(this.fqns);
    };
    TimeseriesRequest.prototype.setTimePeriod = function (timePeriod) {
        this.timePeriod = _.clone(timePeriod);
    };
    TimeseriesRequest.prototype.getTimePeriod = function () {
        return _.clone(this.timePeriod);
    };
    TimeseriesRequest.prototype.setSamplingDefinition = function (samplingDefinition) {
        this.samplingDefinition = _.clone(samplingDefinition);
    };
    TimeseriesRequest.prototype.getSamplingDefinition = function () {
        return _.clone(this.samplingDefinition);
    };
    TimeseriesRequest.prototype.setTimeDeadBand = function (timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    };
    TimeseriesRequest.prototype.getTimeDeadband = function () {
        return this.timeDeadBand;
    };
    TimeseriesRequest.prototype.setValueDeadBand = function (valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    };
    TimeseriesRequest.prototype.getValueDeadBand = function () {
        return this.valueDeadBand;
    };
    TimeseriesRequest.prototype.setQualityFilter = function (qualityFilter) {
        this.qualityFilter = qualityFilter;
    };
    TimeseriesRequest.prototype.getQualityFilter = function () {
        return this.qualityFilter;
    };
    return TimeseriesRequest;
}());
export { TimeseriesRequest };
function TimeseriesRequest_tsickle_Closure_declarations() {
    TimeseriesRequest.prototype.fqns;
    TimeseriesRequest.prototype.timePeriod;
    TimeseriesRequest.prototype.samplingDefinition;
    TimeseriesRequest.prototype.timeDeadBand;
    TimeseriesRequest.prototype.valueDeadBand;
    TimeseriesRequest.prototype.qualityFilter;
}
var TimeseriesDataService = (function (_super) {
    tslib_1.__extends(TimeseriesDataService, _super);
    function TimeseriesDataService(config, http, opcQualitySvc) {
        var _this = _super.call(this, config.baseUrl + '/api/1/timeseries/', config, http) || this;
        _this.opcQualitySvc = opcQualitySvc;
        return _this;
    }
    TimeseriesDataService.prototype.getOnce = function (request, timezone) {
        var _this = this;
        var tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        return this._sendPostRequest(request).pipe(map(function (response) {
            return _this._transformTimeseriesInternalResponse(response, tz);
        }));
    };
    TimeseriesDataService.prototype._getErrorObservable = function (errorString) {
        return new Observable(function (observer) {
            observer.error(errorString);
            return function () {
                observer.unsubscribe();
            };
        });
    };
    TimeseriesDataService.prototype._applyTimezoneToVqtData = function (vqtData, timezone) {
        _.each(vqtData, function (vqt) {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    };
    TimeseriesDataService.prototype._getRequestDataNextStartValues = function (response, nextStartMoment) {
        var beforeNextRequestValues = new Map();
        var last;
        _.each(response.fqnsResults, function (el) {
            if (!_.isNil(el) && el.values.length) {
                last = _.last(el.values);
                beforeNextRequestValues.set(el.fqn, last);
            }
        });
        return beforeNextRequestValues;
    };
    TimeseriesDataService.prototype._getStartForNextRequest = function (response, originalDuration, repeatedInterval) {
        var opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            var timeString = _.first(fqnResult.values).t;
            for (var i = fqnResult.values.length - 1; i >= 0; i--) {
                var val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        var result;
        var currentTimeMinusDuration = moment.utc().subtract(Math.abs(originalDuration), 'seconds');
        _.each(response.fqnsResults, function (fqnResult) {
            if (_.isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            var lastValue = moment.utc(getLastTimeToUse(fqnResult));
            if (_.isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (_.isNil(result)) {
            result = moment.utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    };
    TimeseriesDataService.prototype._filterStartResponseData = function (response, previousResponseLastData, requestTimePeriod) {
        var firstVqt;
        var firstVqtMoment;
        var secondVqt;
        var self = this;
        var opcQualitySvc = this.opcQualitySvc;
        var cutBeforeDate = moment.utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        _.each(response.fqnsResults, function (el) {
            if (!_.isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                var onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                var onePreviousResponseLastDataMoment = moment.utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = moment.utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < moment.utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    };
    TimeseriesDataService.prototype._transformTimeseriesInternalResponse = function (response, timezone) {
        var _this = this;
        var applyTimezone = false;
        if (!_.isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        var ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        _.each(response.fqnsResults, function (oneResult) {
            if (_.isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                _this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    };
    TimeseriesDataService.prototype._filterDuplicateDataAndCut = function (values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        var ids = [];
        var objectToAddToArray;
        var firstIsAfter = false;
        function arrayFilter(o) {
            var currentItemMoment = moment.utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = _.clone(o);
                    var cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!_.isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        var filteredArray = values.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            var lastValue = _.last(filteredArray);
            if (!lastValue || !moment.utc(lastValue.t).isSame(moment.utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    };
    TimeseriesDataService.prototype._getRepeatedlyWhole = function (request, customInterval, timezone) {
        var _this = this;
        var lastMergedResponse;
        var tz = timezone;
        var repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map(function (response) {
            if (!_.isNil(lastMergedResponse)) {
                var requestTimePeriod = request.getTimePeriod();
                var cutBeforeDate_1 = moment.utc(response.timePeriod.end);
                cutBeforeDate_1.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                var cutBeforeDateUTCFormat = cutBeforeDate_1.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!_.isNil(tz)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        moment.utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                _.each(lastMergedResponse.results, function (result) {
                    var newResults = _.find(response.results, { fqn: result.fqn });
                    if (!_.isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = _.sortBy(result.values, [function (o) {
                                return moment.utc(o.t);
                            }]);
                        result.values = _this._filterDuplicateDataAndCut(result.values, cutBeforeDate_1, false, tz);
                    }
                });
                _.each(response.results, function (newResult) {
                    if (!_.find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    };
    TimeseriesDataService.prototype._getRepeatedlyIncrements = function (request, customInterval, timezone) {
        var _this = this;
        var requestTimePeriod = request.getTimePeriod();
        var lastResponseData;
        var repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        var lastRepeatedRequest = _.clone(request);
        var originalDuration = requestTimePeriod.duration;
        var nextRequestStartMoment;
        var repeatedDataObservable = this._sendPostRequest(request).pipe(map(function (response) {
            nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return _this._transformTimeseriesInternalResponse(response, timezone);
        }));
        var expandedObservable = repeatedDataObservable.pipe(expand(function () {
            return timer(repeatedInterval).pipe(concatMap(function () {
                if (!_.isNil(nextRequestStartMoment)) {
                    lastRepeatedRequest.setTimePeriod(_.extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
                }
                return _this._sendPostRequest(lastRepeatedRequest).pipe(map(function (response) {
                    if (lastResponseData.size > 0) {
                        _this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                    }
                    nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                    lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                    return _this._transformTimeseriesInternalResponse(response, timezone);
                }));
            }));
        }));
        return expandedObservable;
    };
    TimeseriesDataService.prototype.getRepeatedly = function (request, customInterval, format, timezone) {
        var requestTimePeriod = request.getTimePeriod();
        if (!_.isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (_.isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        var tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        if (_.isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz);
        }
    };
    TimeseriesDataService.decorators = [
        { type: Injectable },
    ];
    TimeseriesDataService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
        { type: OpcQualityService, },
    ]; };
    return TimeseriesDataService;
}(BaseService));
export { TimeseriesDataService };
function TimeseriesDataService_tsickle_Closure_declarations() {
    TimeseriesDataService.decorators;
    TimeseriesDataService.ctorParameters;
    TimeseriesDataService.prototype.opcQualitySvc;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXNlcmllcy1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsidGltZXNlcmllcy1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsQ0FBQztBQUM1QixPQUFPLEtBQUssTUFBTSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzFELE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxHQUFHLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsOEJBQThCLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFFdEcsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHlCQUF5QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bUJBNEQxQyxlQUFlO2dCQUNsQixZQUFZOzs7O21CQUlULGVBQWU7bUJBQ2YsZUFBZTtZQUN0QixRQUFRO1dBQ1QsT0FBTztTQUNULEtBQUs7YUFDRCxTQUFTO2lCQUNMLGFBQWE7V0FDbkIsT0FBTzt1QkFDSyxtQkFBbUI7dUJBQ25CLG1CQUFtQjthQUM3QixTQUFTO1dBQ1gsT0FBTztTQUNULEtBQUs7V0FDSCxPQUFPO2NBQ0osVUFBVTtXQUNiLE9BQU87a0JBQ0EsY0FBYztpQkFDZixhQUFhO2lCQUNiLGFBQWE7Z0JBQ2QsWUFBWTtrQkFDVixjQUFjOzhCQUNGLDBCQUEwQjt3QkFDaEMsb0JBQW9CO3NCQUN0QixrQkFBa0I7c0JBQ2xCLGtCQUFrQjtxQkFDbkIsaUJBQWlCOzs7Ozs7Ozs7QUFldkMsSUFBQTtJQWVJLDJCQUNZLE1BQ0EsWUFDQSxvQkFDQSxjQUNBLGVBQ0E7UUFMQSxTQUFJLEdBQUosSUFBSTtRQUNKLGVBQVUsR0FBVixVQUFVO1FBQ1YsdUJBQWtCLEdBQWxCLGtCQUFrQjtRQUNsQixpQkFBWSxHQUFaLFlBQVk7UUFDWixrQkFBYSxHQUFiLGFBQWE7UUFDYixrQkFBYSxHQUFiLGFBQWE7UUFFckIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0tBQ2xEO0lBTUQsa0NBQU0sR0FBTixVQUFPLEdBQWU7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdkI7SUFNRCxxQ0FBUyxHQUFULFVBQVUsR0FBZTtRQUNyQixJQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDeEMsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDOUI7S0FDSjtJQU1ELG1DQUFPLEdBQVAsVUFBUSxJQUFrQjtRQUN0QixJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDN0I7SUFLRCxtQ0FBTyxHQUFQO1FBQ0ksTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzdCO0lBTUQseUNBQWEsR0FBYixVQUFjLFVBQXVCO1FBQ2pDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztLQUN6QztJQUtELHlDQUFhLEdBQWI7UUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDbkM7SUFNRCxpREFBcUIsR0FBckIsVUFBc0Isa0JBQXdDO1FBQzFELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDekQ7SUFLRCxpREFBcUIsR0FBckI7UUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztLQUMzQztJQU1ELDJDQUFlLEdBQWYsVUFBZ0IsWUFBcUI7UUFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7S0FDcEM7SUFLRCwyQ0FBZSxHQUFmO1FBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7S0FDNUI7SUFNRCw0Q0FBZ0IsR0FBaEIsVUFBaUIsYUFBc0I7UUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7S0FDdEM7SUFLRCw0Q0FBZ0IsR0FBaEI7UUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztLQUM3QjtJQU1ELDRDQUFnQixHQUFoQixVQUFpQixhQUFpRDtRQUM5RCxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztLQUN0QztJQUtELDRDQUFnQixHQUFoQjtRQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO0tBQzdCOzRCQTFQTDtJQTJQQyxDQUFBO0FBeElELDZCQXdJQzs7Ozs7Ozs7OztJQU0wQyxpREFBVztJQUVsRCwrQkFDa0MsUUFDOUIsSUFBZ0IsRUFBVSxhQUFnQztRQUY5RCxZQUdJLGtCQUFNLE1BQU0sQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUM3RDtRQUY2QixtQkFBYSxHQUFiLGFBQWEsQ0FBbUI7O0tBRTdEO0lBZUQsdUNBQU8sR0FBUCxVQUFRLE9BQTBCLEVBQUUsUUFBaUI7UUFBckQsaUJBT0M7UUFORyxJQUFJLEVBQVUsQ0FBQztRQUNmLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEQsRUFBRSxHQUFHLFFBQVEsQ0FBQztTQUNqQjtRQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLFFBQTJDO1lBQ3ZGLE9BQUEsS0FBSSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7UUFBdkQsQ0FBdUQsQ0FBQyxDQUFDLENBQUM7S0FDakU7SUFNTyxtREFBbUIsYUFBQyxXQUFtQjtRQUMzQyxNQUFNLENBQUMsSUFBSSxVQUFVLENBQXFCLFVBQUMsUUFBUTtZQUMvQyxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzVCLE1BQU0sQ0FBQztnQkFDSCxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDMUIsQ0FBQztTQUNMLENBQUMsQ0FBQzs7SUFRQyx1REFBdUIsYUFBQyxPQUF3QyxFQUFFLFFBQVE7UUFDOUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQyxHQUFrQztZQUMvQyxHQUFHLENBQUMsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQzlELENBQUMsQ0FBQztRQUNILE1BQU0sQ0FBQyxPQUFPLENBQUM7O0lBT1gsOERBQThCLGFBQUMsUUFBMkMsRUFBRSxlQUE4QjtRQUU5RyxJQUFNLHVCQUF1QixHQUFxQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzVELElBQUksSUFBbUMsQ0FBQztRQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBQyxFQUFFO1lBQzVCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDekIsdUJBQXVCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDN0M7U0FDSixDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsdUJBQXVCLENBQUM7O0lBTTNCLHVEQUF1QixhQUMzQixRQUEyQyxFQUFFLGdCQUF3QixFQUFFLGdCQUF3QjtRQUMvRixJQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ3pDLDBCQUEwQixTQUFrRDtZQUN4RSxJQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFL0MsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDcEQsSUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ2hCO2FBQ0o7WUFFRCxNQUFNLENBQUMsVUFBVSxDQUFDO1NBQ3JCO1FBRUQsSUFBSSxNQUFxQixDQUFDO1FBQzFCLElBQU0sd0JBQXdCLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFOUYsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQUMsU0FBUztZQUNuQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXRELE1BQU0sQ0FBQzthQUNWO1lBQ0QsSUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQzFELEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9DLE1BQU0sR0FBRyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDOUI7U0FDSixDQUFDLENBQUM7UUFFSCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVsQixNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUN4RjtRQUVELEVBQUUsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0MsTUFBTSxHQUFHLHdCQUF3QixDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUNuRjtRQUVELE1BQU0sQ0FBQyxNQUFNLENBQUM7O0lBT1Ysd0RBQXdCLGFBQzVCLFFBQTJDLEVBQzNDLHdCQUFvRSxFQUFFLGlCQUE4QjtRQUNwRyxJQUFJLFFBQVEsQ0FBQztRQUNiLElBQUksY0FBYyxDQUFDO1FBQ25CLElBQUksU0FBUyxDQUFDO1FBQ2QsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLElBQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDekMsSUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFELGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN4RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBQyxFQUFFO1lBQzVCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9FLElBQU0sMkJBQTJCLEdBQUcsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDekUsSUFBTSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRixRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxjQUFjLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM5QyxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxFQUFFLENBQUMsQ0FBQyxjQUFjLEdBQUcsaUNBQWlDO3dCQUNsRCxjQUFjLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUN4QyxhQUFhLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQzt3QkFDbkQsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQzFCO2lCQUNKO2FBQ0o7U0FDSixDQUFDLENBQUM7O0lBR0Msb0VBQW9DLGFBQUMsUUFBMkMsRUFBRSxRQUFpQjs7UUFDdkcsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBRTFCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFckIsYUFBYSxHQUFHLElBQUksQ0FBQztZQUVyQixRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQ2xHO1FBRUQsSUFBTSxHQUFHLEdBQXVCO1lBQzVCLFVBQVUsRUFBRSxRQUFRLENBQUMsVUFBVTtZQUMvQixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7UUFFRixDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBQyxTQUFTO1lBQ25DLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVyQixNQUFNLENBQUM7YUFDVjtZQUVELEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLEtBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQzVEO1lBRUQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO2dCQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7Z0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztnQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO2dCQUMxQyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU07YUFDM0IsQ0FBQyxDQUFDO1NBQ04sQ0FBQyxDQUFDO1FBQ0gsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7SUFNUCwwREFBMEIsYUFDOUIsTUFBdUMsRUFBRSxlQUE4QixFQUN2RSxvQkFBOEIsRUFBRSxRQUFpQjtRQUNqRCxJQUFNLEdBQUcsR0FBa0IsRUFBRSxDQUFDO1FBQzlCLElBQUksa0JBQWlELENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBRXpCLHFCQUFxQixDQUFnQztZQUNqRCxJQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFDaEIsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsSUFBTSx3QkFBd0IsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7b0JBQzdHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JCLGtCQUFrQixDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ2hHO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLGtCQUFrQixDQUFDLENBQUMsR0FBRyx3QkFBd0IsQ0FBQztxQkFDbkQ7b0JBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQztpQkFDdkI7Z0JBQ0QsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNoQjtZQUNELEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUIsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNoQjtZQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNmO1FBQ0QsSUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzRCxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDeEMsSUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN4QyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVsRixhQUFhLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7YUFDMUM7U0FDSjtRQUNELE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7O0lBUTNCLG1EQUFtQixhQUFDLE9BQTBCLEVBQUUsY0FBdUIsRUFBRSxRQUFpQjs7UUFDOUYsSUFBSSxrQkFBc0MsQ0FBQztRQUMzQyxJQUFNLEVBQUUsR0FBRyxRQUFRLENBQUM7UUFFcEIsSUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDO2FBQ2pGLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUE0QjtZQUNuQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLElBQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNsRCxJQUFNLGVBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzFELGVBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDeEUsSUFBTSxzQkFBc0IsR0FBRyxlQUFhLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7Z0JBRXpHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2Ysa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3BHLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7aUJBQy9EO2dCQUFDLElBQUksQ0FBQyxDQUFDO29CQUNKLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsc0JBQXNCLENBQUM7b0JBQzdELGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHO3dCQUM3QixNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7aUJBQ3ZHO2dCQUVELENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFVBQUMsTUFBTTtvQkFDdEMsSUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUNqRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFFeEQsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxVQUFDLENBQWdDO2dDQUN0RSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NkJBQzFCLENBQUMsQ0FBQyxDQUFDO3dCQUVKLE1BQU0sQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsZUFBYSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztxQkFDNUY7aUJBQ0osQ0FBQyxDQUFDO2dCQUVILENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFNBQVM7b0JBQy9CLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5RCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM5QztpQkFDSixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxDQUFDLGtCQUFrQixDQUFDO2FBQzdCO1lBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCLEdBQUcsUUFBUSxDQUFDO2dCQUM5QixNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ25CO1NBQ0osQ0FBQyxDQUFDLENBQUM7UUFDUixNQUFNLENBQUMsYUFBYSxDQUFDOztJQVFqQix3REFBd0IsYUFDNUIsT0FBMEIsRUFBRSxjQUF1QixFQUFFLFFBQWlCOztRQUV0RSxJQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVsRCxJQUFJLGdCQUFrQyxDQUFDO1FBQ3ZDLElBQUksZ0JBQWdCLEdBQUcsY0FBYyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsMkJBQTJCLElBQUksOEJBQThCLENBQUM7UUFDbkgsZ0JBQWdCLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBRTNDLElBQU0sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3QyxJQUFNLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDLFFBQVEsQ0FBQztRQUNwRCxJQUFJLHNCQUFxQyxDQUFDO1FBRTFDLElBQU0sc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUEyQztZQUMvRyxzQkFBc0IsR0FBRyxLQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFLcEcsZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3pGLE1BQU0sQ0FBQyxLQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQ3hFLENBQUMsQ0FBQyxDQUFDO1FBQ0osSUFBTSxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQ2xELE1BQU0sQ0FBQztZQUFNLE9BQUEsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDaEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNuQyxtQkFBbUIsQ0FBQyxhQUFhLENBQzdCLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDL0c7Z0JBQ0QsTUFBTSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUEyQztvQkFDbkcsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBSTVCLEtBQUksQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztxQkFDaEY7b0JBQ0Qsc0JBQXNCLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO29CQUtwRyxnQkFBZ0IsR0FBRyxLQUFJLENBQUMsOEJBQThCLENBQUMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLENBQUM7b0JBQ3pGLE1BQU0sQ0FBQyxLQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2lCQUN4RSxDQUFDLENBQUMsQ0FBQzthQUNQLENBQUMsQ0FBQztRQXBCVSxDQW9CVixDQUFDLENBQ1AsQ0FBQztRQUNGLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQzs7SUFxQjlCLDZDQUFhLEdBQWIsVUFBYyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsTUFBcUMsRUFBRSxRQUFpQjtRQUd2SCxJQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixrRUFBa0U7a0JBQ2xFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtRQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9FLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixvREFBb0Q7a0JBQ3BELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtRQUVELElBQUksRUFBVSxDQUFDO1FBQ2YsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoRCxFQUFFLEdBQUcsUUFBUSxDQUFDO1NBQ2pCO1FBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLEtBQUssNEJBQTRCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztZQUMzRSxNQUFNLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDaEU7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNKLE1BQU0sQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNyRTtLQUNKOztnQkExWEosVUFBVTs7O2dEQUlGLE1BQU0sU0FBQyxvQkFBb0I7Z0JBblEzQixVQUFVO2dCQUdWLGlCQUFpQjs7Z0NBSjFCO0VBaVEyQyxXQUFXO1NBQXpDLHFCQUFxQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgKiBhcyBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCAqIGFzIG1vbWVudCBmcm9tICdtb21lbnQtdGltZXpvbmUnO1xyXG5pbXBvcnQgeyBPcGNRdWFsaXR5U2VydmljZSB9IGZyb20gJy4vb3BjLXF1YWxpdHkuc2VydmljZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCwgY29uY2F0TWFwLCBleHBhbmQgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZywgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBpZGVudGlmaWVyLCBJUmVzcG9uc2UgfSBmcm9tICcuL3NoYXJlZCc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBNb21lbnRIZWxwZXJTZXJ2aWNlIH0gZnJvbSAnLi9tb21lbnQtaGVscGVyLnNlcnZpY2UnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdnF0IHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cyB7XHJcbiAgICB2OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuO1xyXG4gICAgcTogbnVtYmVyO1xyXG4gICAgdDogc3RyaW5nO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB2cXQgbGlzdCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZSBleHRlbmRzIElSZXNwb25zZSB7XHJcbiAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1Jlc3BvbnNlIHtcclxuICAgIHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kUmVzcG9uc2U7XHJcbiAgICByZXN1bHRzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlW107XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIFRpbWVzZXJpZXNSZXNwb25zZSA9IElUaW1lc2VyaWVzUmVzcG9uc2U7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBpbnRlcm5hbCBvYmplY3Qgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0IHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmFtZT86IHN0cmluZztcclxuICAgIGVuZ2luZWVyaW5nVW5pdD86IHN0cmluZztcclxuICAgIHZhbHVlVHlwZT86IHN0cmluZztcclxuICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdGltZSBwZXJpb2Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lUGVyaW9kUmVzcG9uc2Uge1xyXG4gICAgc3RhcnQ6IHN0cmluZztcclxuICAgIGVuZDogc3RyaW5nO1xyXG4gICAgZHVyYXRpb246IG51bWJlcjtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgaW50ZXJuYWwgKHJhdykgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsIHtcclxuICAgIHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kUmVzcG9uc2U7XHJcbiAgICBmcW5zUmVzdWx0cz86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG4gICAgcXVlcnlSZXN1bHRzPzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlcXVlc3QgdGltZSBwZXJpb2Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lUGVyaW9kIHtcclxuICAgIHN0YXJ0PzogRGF0ZSB8IG1vbWVudC5Nb21lbnQ7XHJcbiAgICBlbmQ/OiBEYXRlIHwgbW9tZW50Lk1vbWVudDtcclxuICAgIGR1cmF0aW9uPzogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkge1xyXG4gICAgaW5jbHVkZUdvb2QgPSAxLFxyXG4gICAgaW5jbHVkZUJhZCA9IDIsXHJcbiAgICBpbmNsdWRlVW5jZXJ0YWluID0gNCxcclxuICAgIGluY2x1ZGVBbGwgPSA3XHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQge1xyXG4gICAgd2hvbGVJbnRlcnZhbCA9ICd3aG9sZUludGVydmFsJyxcclxuICAgIGluY3JlbWVudHMgPSAnaW5jcmVtZW50cydcclxufVxyXG5cclxuZXhwb3J0IGVudW0gU2FtcGxpbmdUeXBlcyB7XHJcbiAgICBJbnRlcnBvbGF0aXZlID0gJ0ludGVycG9sYXRpdmUnLFxyXG4gICAgU2FtcGxlQW5kSG9sZCA9ICdTYW1wbGVBbmRIb2xkJyxcclxuICAgIExpbmVhciA9ICdMaW5lYXInLFxyXG4gICAgVG90YWwgPSAnVG90YWwnLFxyXG4gICAgU3VtID0gJ1N1bScsXHJcbiAgICBBdmVyYWdlID0gJ0F2ZXJhZ2UnLFxyXG4gICAgVGltZUF2ZXJhZ2UgPSAnVGltZUF2ZXJhZ2UnLFxyXG4gICAgQ291bnQgPSAnQ291bnQnLFxyXG4gICAgU3RhbmRhcmREZXZpYXRpb24gPSAnU3RhbmRhcmREZXZpYXRpb24nLFxyXG4gICAgTWluaW11bUFjdHVhbFRpbWUgPSAnTWluaW11bUFjdHVhbFRpbWUnLFxyXG4gICAgTWF4aW11bSA9ICdNYXhpbXVtJyxcclxuICAgIFN0YXJ0ID0gJ1N0YXJ0JyxcclxuICAgIEVuZCA9ICdFbmQnLFxyXG4gICAgRGVsdGEgPSAnRGVsdGEnLFxyXG4gICAgVmFyaWFuY2UgPSAnVmFyaWFuY2UnLFxyXG4gICAgUmFuZ2UgPSAnUmFuZ2UnLFxyXG4gICAgRHVyYXRpb25Hb29kID0gJ0R1cmF0aW9uR29vZCcsXHJcbiAgICBEdXJhdGlvbkJhZCA9ICdEdXJhdGlvbkJhZCcsXHJcbiAgICBQZXJjZW50R29vZCA9ICdQZXJjZW50R29vZCcsXHJcbiAgICBQZXJjZW50QmFkID0gJ1BlcmNlbnRCYWQnLFxyXG4gICAgV29yc3RRdWFsaXR5ID0gJ1dvcnN0UXVhbGl0eScsXHJcbiAgICBUaW1lQXZlcmFnZVNhbXBsZUFuZEhvbGQgPSAnVGltZUF2ZXJhZ2VTYW1wbGVBbmRIb2xkJyxcclxuICAgIFRvdGFsU2FtcGxlQW5kSG9sZCA9ICdUb3RhbFNhbXBsZUFuZEhvbGQnLFxyXG4gICAgTWluU2FtcGxlQW5kSG9sZCA9ICdNaW5TYW1wbGVBbmRIb2xkJyxcclxuICAgIE1heFNhbXBsZUFuZEhvbGQgPSAnTWF4U2FtcGxlQW5kSG9sZCcsXHJcbiAgICBDdW11bGF0aXZlVG90YWwgPSAnQ3VtdWxhdGl2ZVRvdGFsJ1xyXG59XHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHNhbXBsaW5nIGRlZmluaXRpb24uICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVNhbXBsaW5nRGVmaW5pdGlvbiB7XHJcbiAgICAvKiogVGhlIG51bWJlciBvZiB0aGUgc2xpY2VzIHRoYXQgdGhlIHByb3ZpZGVkIHRpbWUgcGVyaW9kIHNob3VsZCBiZSBjdXQgaW50by5cclxuICAgICAqIElmIHplcm8gdGhlbiBhIG5vbi16ZXJvIERlbHRhVCB2YWx1ZSBuZWVkcyB0byBiZSBwcm92aWRlZC4gKi9cclxuICAgIHNsaWNlQ291bnQ/OiBudW1iZXI7XHJcbiAgICAvKiogSWYgdGhlIHNsaWNlIGNvdW50IGlzIHplcm8sIHRoZW4gYSBub24temVybyB2YWx1ZSByZXByZXNlbnRpbmcgdGhlIHdpZHRoIG9mIGEgdGltZSBzbGljZSBpbiBzZWNvbmRzXHJcbiAgICAgKiBtdXN0IGJlIHByb3ZpZGVkLiBBIHBvc2l0aXZlIHZhbHVlIG1lYW5zIHRoZSBzbGljZXMgYXJlIGFuY2hvcmVkIGF0IHRoZSBzdGFydCB0aW1lIG9mIHRoZSByZXF1ZXN0ZWQgdGltZSBwZXJpb2QuXHJcbiAgICAgKiBBIG5lZ2F0aXZlIHZhbHVlIGluZGljYXRlcyBhbmNob3JpbmcgYXQgdGhlIGVuZCBvZiB0aGUgdGltZSBwZXJpb2QuICovXHJcbiAgICBkZWx0YVQ/OiBudW1iZXI7XHJcbiAgICAvKiogT25lIG9mIHRoZSBzYW1wbGluZyB0eXBlcyBzdXBwb3J0ZWQgYnkgdGhlIHRpbWVzZXJpZXMuIFNlZSBTYW1wbGluZ1R5cGVzIGVudW0uICovXHJcbiAgICBzYW1wbGluZ1R5cGU6IFNhbXBsaW5nVHlwZXM7XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBUaW1lc2VyaWVzUmVxdWVzdCB7XHJcbiAgICAvKipcclxuICAgICAqIFRpbWVzZXJpZXMgcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIGZxbnMgTGlzdCBvZiBmcW5zIChpZGVudGlmaWNhdG9ycykgdG8gYmUgdXNlZCBmb3IgcmVxdWVzdFxyXG4gICAgICogQHBhcmFtIHRpbWVQZXJpb2QgU2V0dGluZ3MgZm9yIHRpbWUgcGVyaW9kIG9mIHRpbWVzZXJpZXMgcmVxdWVzdCwgZS5nLiBzdGFydCB0aW1lLCBlbmQgdGltZSBhbmQgZHVyYXRpb25cclxuICAgICAqIEBwYXJhbSBzYW1wbGluZ0RlZmluaXRpb24gKE9wdGlvbmFsKSBkZWZpbml0aW9uIGZvciB0aW1lc2VyaWVzIHRvIHNldCBob3cgdG8gcHJvY2VzcyBkYXRhLCB3aGljaCBTYW1wbGluZyB0eXBlIHRvIHVzZVxyXG4gICAgICogQHBhcmFtIHRpbWVEZWFkQmFuZCAoT3B0aW9uYWwpIFNldHRpbmdzIGZvciB0aW1lIGRlYWRiYW5kIC0gcG9zc2libGUgc3RydWN0dXJlIFt3c11bLV0gZCB8IGQuaGg6bW1bOnNzWy5mZl1dIHwgaGg6bW1bOnNzWy5mZl1dIFt3c11cclxuICAgICAqIEBwYXJhbSB2YWx1ZURlYWRCYW5kIChPcHRpb25hbCkgU3BlY2lmaWVzIHRoZSB2YWx1ZSBkZWFkIGJhbmQsIGNhbiBiZSBhbnkgZmxvYXQgbnVtYmVyLlxyXG4gICAgICogQHBhcmFtIHF1YWxpdHlGaWx0ZXIgKE9wdGlvbmFsKSBUaGlzIGlzIGEgYml0IGZsYWcgdmFsdWUgd2l0aCB0aGUgZm9sbG93aW5nIG9wdGlvbnM6XHJcbiAgICAgKiBJbmNsdWRlR29vZCA6IDFcclxuICAgICAqIEluY2x1ZGVCYWQgOiAyXHJcbiAgICAgKiBJbmNsdWRlVW5jZXJ0YWluIDogNFxyXG4gICAgICogSW5jbHVkZUFsbCA6IDdcclxuICAgICAqIFVzZSBhIHZhbHVlIGZyb20gcHJlZGVmaW5lZCBlbnVtIFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSBvciBzcGVjaWZ5IGEgdmFsbHVlLlxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIGZxbnM6IGlkZW50aWZpZXJbXSxcclxuICAgICAgICBwcml2YXRlIHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kLFxyXG4gICAgICAgIHByaXZhdGUgc2FtcGxpbmdEZWZpbml0aW9uPzogSVNhbXBsaW5nRGVmaW5pdGlvbixcclxuICAgICAgICBwcml2YXRlIHRpbWVEZWFkQmFuZD86IHN0cmluZyxcclxuICAgICAgICBwcml2YXRlIHZhbHVlRGVhZEJhbmQ/OiBudW1iZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBxdWFsaXR5RmlsdGVyPzogVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHwgbnVtYmVyXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLnNldEZxbnMoZnFucyk7XHJcbiAgICAgICAgdGhpcy5zZXRUaW1lUGVyaW9kKHRpbWVQZXJpb2QpO1xyXG4gICAgICAgIHRoaXMuc2V0U2FtcGxpbmdEZWZpbml0aW9uKHNhbXBsaW5nRGVmaW5pdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBZGQgb25lIGZxbiB0byByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byBhZGRcclxuICAgICAqL1xyXG4gICAgYWRkRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIHRoaXMuZnFucy5wdXNoKGZxbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmUgb25lIGZxbiBmcm9tIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIHJlbW92ZVxyXG4gICAgICovXHJcbiAgICByZW1vdmVGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgY29uc3QgaW5kZXggPSBfLmluZGV4T2YodGhpcy5mcW5zLCBmcW4pO1xyXG4gICAgICAgIGlmIChpbmRleCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5mcW5zLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmVwbGFjZSBjdXJyZW50IGZxbnMgaW4gcmVxdWVzdCB0byBuZXcgb25lcy5cclxuICAgICAqIEBwYXJhbSBmcW5zIGxpc3Qgb2YgZnFuIGlkZW50aWZpY2F0b3JzIHRvIHNldFxyXG4gICAgICovXHJcbiAgICBzZXRGcW5zKGZxbnM6IGlkZW50aWZpZXJbXSkge1xyXG4gICAgICAgIHRoaXMuZnFucyA9IF8uY2xvbmUoZnFucyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgZnFuIGlkZW50aWZpY2F0b3JzLlxyXG4gICAgICovXHJcbiAgICBnZXRGcW5zKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMuZnFucyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgcmVxdWVzdCB0aW1lIHBlcmlvZC5cclxuICAgICAqIEBwYXJhbSB0aW1lUGVyaW9kXHJcbiAgICAgKi9cclxuICAgIHNldFRpbWVQZXJpb2QodGltZVBlcmlvZDogSVRpbWVQZXJpb2QpIHtcclxuICAgICAgICB0aGlzLnRpbWVQZXJpb2QgPSBfLmNsb25lKHRpbWVQZXJpb2QpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IHJlcXVlc3QgdGltZSBwZXJpb2QuXHJcbiAgICAgKi9cclxuICAgIGdldFRpbWVQZXJpb2QoKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy50aW1lUGVyaW9kKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCBzYW1wbGluZyBkZWZpbml0aW9uLlxyXG4gICAgICogQHBhcmFtIHNhbXBsaW5nRGVmaW5pdGlvblxyXG4gICAgICovXHJcbiAgICBzZXRTYW1wbGluZ0RlZmluaXRpb24oc2FtcGxpbmdEZWZpbml0aW9uPzogSVNhbXBsaW5nRGVmaW5pdGlvbikge1xyXG4gICAgICAgIHRoaXMuc2FtcGxpbmdEZWZpbml0aW9uID0gXy5jbG9uZShzYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IHNhbXBsaW5nIGRlZmluaXRpb24uXHJcbiAgICAgKi9cclxuICAgIGdldFNhbXBsaW5nRGVmaW5pdGlvbigpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLnNhbXBsaW5nRGVmaW5pdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgdGltZSBkZWFkYmFuZC5cclxuICAgICAqIEBwYXJhbSB0aW1lRGVhZEJhbmRcclxuICAgICAqL1xyXG4gICAgc2V0VGltZURlYWRCYW5kKHRpbWVEZWFkQmFuZD86IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMudGltZURlYWRCYW5kID0gdGltZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IHRpbWUgZGVhZGJhbmQuXHJcbiAgICAgKi9cclxuICAgIGdldFRpbWVEZWFkYmFuZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy50aW1lRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgdmFsdWUgZGVhZGJhbmQuXHJcbiAgICAgKiBAcGFyYW0gdmFsdWVEZWFkQmFuZFxyXG4gICAgICovXHJcbiAgICBzZXRWYWx1ZURlYWRCYW5kKHZhbHVlRGVhZEJhbmQ/OiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLnZhbHVlRGVhZEJhbmQgPSB2YWx1ZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IHZhbHVlIGRlYWRiYW5kLlxyXG4gICAgICovXHJcbiAgICBnZXRWYWx1ZURlYWRCYW5kKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnZhbHVlRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgcXVhbGl0eSBmaWx0ZXIuXHJcbiAgICAgKiBAcGFyYW0gcXVhbGl0eUZpbHRlclxyXG4gICAgICovXHJcbiAgICBzZXRRdWFsaXR5RmlsdGVyKHF1YWxpdHlGaWx0ZXI/OiBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgfCBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLnF1YWxpdHlGaWx0ZXIgPSBxdWFsaXR5RmlsdGVyO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IHF1YWxpdHkgZmlsdGVyLlxyXG4gICAgICovXHJcbiAgICBnZXRRdWFsaXR5RmlsdGVyKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnF1YWxpdHlGaWx0ZXI7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGlzIHNlcnZpY2UgcHJvdmlkZXMgYSBzZXQgb2YgbWV0aG9kcyBmb3Igc2VuZGluZyByZXF1ZXN0cyB0byBvYnRhaW4gdGltZXNlcmllcyBkYXRhLlxyXG4gKi9cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgVGltZXNlcmllc0RhdGFTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsXHJcbiAgICAgICAgaHR0cDogSHR0cENsaWVudCwgcHJpdmF0ZSBvcGNRdWFsaXR5U3ZjOiBPcGNRdWFsaXR5U2VydmljZSkge1xyXG4gICAgICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS90aW1lc2VyaWVzLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gc2VydmVyLCBidXQgb25seSBvbmNlLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSB0aW1lem9uZSB0byBhcHBseSB0byB0aW1lc2VyaWVzIHJlc3BvbnNlIGRhdGEsIG9ubHkgbW9tZW50IHRpbWV6b25lcyBhcmUgc3VwcG9ydGVkXHJcbiAgICAgKiBJZiB3b3JraW5nIHdpdGggdGltZXpvbmUgaW4gZGF0ZXRpbWUgc3RyaW5nIGl0IGlzIHJlY29tbWVuZGVkIHRvIHVzZSBtb21lbnQucGFyc2Vab25lIHRvIHByZXNlcnZlIHRpbWV6b25lIGluZm9ybWF0aW9uLlxyXG4gICAgICogTW9tZW50IHRpbWV6b25lcyB0aGF0IHN0YXJ0IHdpdGggXCJFdGMvR01UXCIgdXNlIFBPU0lYLXN0eWxlIHNpZ25zIGluIHRoZSBab25lIG5hbWVzIGFuZCB0aGUgb3V0cHV0IGFiYnJldmlhdGlvbnMsXHJcbiAgICAgKiBldmVuIHRob3VnaCB0aGlzIGlzIHRoZSBvcHBvc2l0ZSBvZiB3aGF0IG1hbnkgcGVvcGxlIGV4cGVjdC5cclxuICAgICAqIFBPU0lYIGhhcyBwb3NpdGl2ZSBzaWducyB3ZXN0IG9mIEdyZWVud2ljaCwgYnV0IG1hbnkgcGVvcGxlIGV4cGVjdFxyXG4gICAgICogcG9zaXRpdmUgc2lnbnMgZWFzdCBvZiBHcmVlbndpY2guICBGb3IgZXhhbXBsZSwgVFo9J0V0Yy9HTVQrNCcgdXNlc1xyXG4gICAgICogdGhlIGFiYnJldmlhdGlvbiBcIkdNVCs0XCIgYW5kIGNvcnJlc3BvbmRzIHRvIDQgaG91cnMgYmVoaW5kIFVUXHJcbiAgICAgKiAoaS5lLiB3ZXN0IG9mIEdyZWVud2ljaCkgZXZlbiB0aG91Z2ggbWFueSBwZW9wbGUgd291bGQgZXhwZWN0IGl0IHRvXHJcbiAgICAgKiBtZWFuIDQgaG91cnMgYWhlYWQgb2YgVVQgKGkuZS4gZWFzdCBvZiBHcmVlbndpY2gpLlxyXG4gICAgICovXHJcbiAgICBnZXRPbmNlKHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgbGV0IHR6OiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKE1vbWVudEhlbHBlclNlcnZpY2UuaXNWYWxpZFRpbWV6b25lKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICB0eiA9IHRpbWV6b25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PlxyXG4gICAgICAgICAgICB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdHopKSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gcmV0dXJuIGFuIG9ic2VydmFibGUgd2hpY2ggaW1tZWRpYXRlbGx5IGVycm9ycyBvdXQgd2l0aCBnaXZlbiBlcnJvciBzdHJpbmcuXHJcbiAgICAgKiBAcGFyYW0gZXJyb3JTdHJpbmdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0RXJyb3JPYnNlcnZhYmxlKGVycm9yU3RyaW5nOiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+KChvYnNlcnZlcikgPT4ge1xyXG4gICAgICAgICAgICBvYnNlcnZlci5lcnJvcihlcnJvclN0cmluZyk7XHJcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYnNlcnZlci51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIGFwcGx5IHRpbWV6b25lIHRvIHdob2xlXHJcbiAgICAgKiBAcGFyYW0gdnF0RGF0YSBsaXN0IG9mIFZRVCBkYXRhXHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgdGltZXpvbmUgc3RyaW5nXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2FwcGx5VGltZXpvbmVUb1ZxdERhdGEodnF0RGF0YTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXSwgdGltZXpvbmUpIHtcclxuICAgICAgICBfLmVhY2godnF0RGF0YSwgKHZxdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpID0+IHtcclxuICAgICAgICAgICAgdnF0LnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUodnF0LnQsIHRpbWV6b25lKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gdnF0RGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBnZXQgZmlyc3QgdmFsdWUgYmVmb3JlIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIGluIGN1cnJlbnQgZGF0YS5cclxuICAgICAqXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIG5leHRTdGFydE1vbWVudDogbW9tZW50Lk1vbWVudCk6XHJcbiAgICAgICAgTWFwPHN0cmluZywgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM+IHtcclxuICAgICAgICBjb25zdCBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlczogTWFwPHN0cmluZywgYW55PiA9IG5ldyBNYXAoKTtcclxuICAgICAgICBsZXQgbGFzdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM7XHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZWwpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGVsKSAmJiBlbC52YWx1ZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBsYXN0ID0gXy5sYXN0KGVsLnZhbHVlcyk7XHJcbiAgICAgICAgICAgICAgICBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlcy5zZXQoZWwuZnFuLCBsYXN0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXRzIHN0YXJ0IHRpbWUgZm9yIG5leHQgcmVxdWVzdCB3aGVuIGdldHRpbmcgZGF0YSByZXBlYXRlZGx5LlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRTdGFydEZvck5leHRSZXF1ZXN0KFxyXG4gICAgICAgIHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIG9yaWdpbmFsRHVyYXRpb246IG51bWJlciwgcmVwZWF0ZWRJbnRlcnZhbDogbnVtYmVyKTogbW9tZW50Lk1vbWVudCB7XHJcbiAgICAgICAgY29uc3Qgb3BjUXVhbGl0eVN2YyA9IHRoaXMub3BjUXVhbGl0eVN2YztcclxuICAgICAgICBmdW5jdGlvbiBnZXRMYXN0VGltZVRvVXNlKGZxblJlc3VsdDogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0KTogc3RyaW5nIHtcclxuICAgICAgICAgICAgY29uc3QgdGltZVN0cmluZyA9IF8uZmlyc3QoZnFuUmVzdWx0LnZhbHVlcykudDtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSBmcW5SZXN1bHQudmFsdWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBmcW5SZXN1bHQudmFsdWVzW2ldO1xyXG4gICAgICAgICAgICAgICAgaWYgKCFvcGNRdWFsaXR5U3ZjLmlzSGRhSW50ZXJwb2xhdGVkKHZhbC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWwudDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHRpbWVTdHJpbmc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcmVzdWx0OiBtb21lbnQuTW9tZW50O1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbiA9IG1vbWVudC51dGMoKS5zdWJ0cmFjdChNYXRoLmFicyhvcmlnaW5hbER1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuXHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZnFuUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKGZxblJlc3VsdCkgfHwgZnFuUmVzdWx0LnZhbHVlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIC8vIG5vIHRpbWVzZXJpZXMgZGF0YVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IGxhc3RWYWx1ZSA9IG1vbWVudC51dGMoZ2V0TGFzdFRpbWVUb1VzZShmcW5SZXN1bHQpKTtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwocmVzdWx0KSB8fCByZXN1bHQuaXNBZnRlcihsYXN0VmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBsYXN0VmFsdWUuY2xvbmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoXy5pc05pbChyZXN1bHQpKSB7XHJcbiAgICAgICAgICAgIC8vIG5vIGdvb2QgcXVhbGl0eSAtIGFkZCBwZXJpb2QgdG8gcmVzcG9uc2Ugc3RhcnQgdGltZSAtIGFzIGRlZmF1bHQgZm9yIG5leHQgcmVxdWVzdFxyXG4gICAgICAgICAgICByZXN1bHQgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQpLmFkZChyZXBlYXRlZEludGVydmFsLCAnbWlsbGlzZWNvbmRzJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoY3VycmVudFRpbWVNaW51c0R1cmF0aW9uLmlzQWZ0ZXIocmVzdWx0KSkge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBjdXJyZW50VGltZU1pbnVzRHVyYXRpb24uY2xvbmUoKS5hZGQocmVwZWF0ZWRJbnRlcnZhbCwgJ21pbGxpc2Vjb25kcycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICogRnVuY3Rpb24gdG8gb3B0aW9uYWxseSBmaWx0ZXIgZmlyc3QgdmFsdWUgaW4gcmVwZWF0ZWQgcmVxdWVzdCB3aGVuIGl0IGlzIGludGVycG9sYXRlZCBiZXR3ZWVuXHJcbiAgICAqIHR3byBnb29kL2JhZCBvbmVzLiBEaXJlY3RseSBtb2RpZmllcyByZXNwb25zZSBpbnB1dCBwYXJhbWV0ZXIuXHJcbiAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZmlsdGVyU3RhcnRSZXNwb25zZURhdGEoXHJcbiAgICAgICAgcmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCxcclxuICAgICAgICBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGE6IE1hcDxzdHJpbmcsIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzPiwgcmVxdWVzdFRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kKSB7XHJcbiAgICAgICAgbGV0IGZpcnN0VnF0O1xyXG4gICAgICAgIGxldCBmaXJzdFZxdE1vbWVudDtcclxuICAgICAgICBsZXQgc2Vjb25kVnF0O1xyXG4gICAgICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGNvbnN0IG9wY1F1YWxpdHlTdmMgPSB0aGlzLm9wY1F1YWxpdHlTdmM7XHJcbiAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZSA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpO1xyXG4gICAgICAgIGN1dEJlZm9yZURhdGUuc3VidHJhY3QoTWF0aC5hYnMocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGVsKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghXy5pc05pbChlbCkgJiYgcHJldmlvdXNSZXNwb25zZUxhc3REYXRhLmhhcyhlbC5mcW4pICYmIGVsLnZhbHVlcy5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEgPSBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEuZ2V0KGVsLmZxbik7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGFNb21lbnQgPSBtb21lbnQudXRjKG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS50KTtcclxuICAgICAgICAgICAgICAgIGZpcnN0VnF0ID0gZWwudmFsdWVzLnNsaWNlKDAsIDEpWzBdO1xyXG4gICAgICAgICAgICAgICAgZmlyc3RWcXRNb21lbnQgPSBtb21lbnQudXRjKGZpcnN0VnF0LnQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKG9wY1F1YWxpdHlTdmMuaXNIZGFJbnRlcnBvbGF0ZWQoZmlyc3RWcXQucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZWNvbmRWcXQgPSBlbC52YWx1ZXMuc2xpY2UoMSwgMilbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpcnN0VnF0TW9tZW50ID4gb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhTW9tZW50ICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpcnN0VnF0TW9tZW50IDwgbW9tZW50LnV0YyhzZWNvbmRWcXQudCkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3BjUXVhbGl0eVN2Yy5pc0dvb2Qob25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhLnEpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wY1F1YWxpdHlTdmMuaXNHb29kKHNlY29uZFZxdC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbC52YWx1ZXMuc3BsaWNlKDAsIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsIHRpbWV6b25lPzogc3RyaW5nKTogVGltZXNlcmllc1Jlc3BvbnNlIHtcclxuICAgICAgICBsZXQgYXBwbHlUaW1lem9uZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICBpZiAoIV8uaXNOaWwodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIC8vIHdlIGRvIGhhdmUgdGltZXpvbmVcclxuICAgICAgICAgICAgYXBwbHlUaW1lem9uZSA9IHRydWU7XHJcbiAgICAgICAgICAgIC8vIGFwcGx5IHRpbWV6b25lIGFsc28gdG8gcmVzcG9uc2UgdGltZSBwZXJpb2QgdG8gbWF0Y2ggZGF0YVxyXG4gICAgICAgICAgICByZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgcmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUocmVzcG9uc2UudGltZVBlcmlvZC5lbmQsIHRpbWV6b25lKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJldDogVGltZXNlcmllc1Jlc3BvbnNlID0ge1xyXG4gICAgICAgICAgICB0aW1lUGVyaW9kOiByZXNwb25zZS50aW1lUGVyaW9kLFxyXG4gICAgICAgICAgICByZXN1bHRzOiBbXVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKG9uZVJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChvbmVSZXN1bHQpKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBubyB0aW1lc2VyaWVzIGRhdGFcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFwcGx5VGltZXpvbmUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FwcGx5VGltZXpvbmVUb1ZxdERhdGEob25lUmVzdWx0LnZhbHVlcywgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXQucmVzdWx0cy5wdXNoKHtcclxuICAgICAgICAgICAgICAgIG5hbWU6IG9uZVJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgZnFuOiBvbmVSZXN1bHQuZnFuLFxyXG4gICAgICAgICAgICAgICAgdmFsdWVUeXBlOiBvbmVSZXN1bHQudmFsdWVUeXBlLFxyXG4gICAgICAgICAgICAgICAgZW5naW5lZXJpbmdVbml0OiBvbmVSZXN1bHQuZW5naW5lZXJpbmdVbml0LFxyXG4gICAgICAgICAgICAgICAgdmFsdWVzOiBvbmVSZXN1bHQudmFsdWVzXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiByZXQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBGdW5jdGlvbiB0byBmaWx0ZXIgbm90IG5lZWRlZCBkYXRhIGFuZCBkdXBsaWNhdGUgZGF0YS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZmlsdGVyRHVwbGljYXRlRGF0YUFuZEN1dChcclxuICAgICAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW10sIGN1dEJlZm9yZU1vbWVudDogbW9tZW50Lk1vbWVudCxcclxuICAgICAgICBkb05vdFNoaWZ0Rmlyc3RWYWx1ZT86IGJvb2xlYW4sIHRpbWV6b25lPzogc3RyaW5nKSB7XHJcbiAgICAgICAgY29uc3QgaWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgbGV0IG9iamVjdFRvQWRkVG9BcnJheTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM7XHJcbiAgICAgICAgbGV0IGZpcnN0SXNBZnRlciA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBhcnJheUZpbHRlcihvOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykge1xyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50SXRlbU1vbWVudCA9IG1vbWVudC51dGMoby50KTtcclxuICAgICAgICAgICAgaWYgKGN1dEJlZm9yZU1vbWVudC5pc0FmdGVyKGN1cnJlbnRJdGVtTW9tZW50KSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFmaXJzdElzQWZ0ZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkgPSBfLmNsb25lKG8pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdCA9IGN1dEJlZm9yZU1vbWVudC5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheS50ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdCwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheS50ID0gY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBmaXJzdElzQWZ0ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpZHMuaW5kZXhPZihvLnQpICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlkcy5wdXNoKG8udCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBmaWx0ZXJlZEFycmF5ID0gdmFsdWVzLnJldmVyc2UoKS5maWx0ZXIoYXJyYXlGaWx0ZXIpO1xyXG4gICAgICAgIGlmICghZG9Ob3RTaGlmdEZpcnN0VmFsdWUgJiYgZmlyc3RJc0FmdGVyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxhc3RWYWx1ZSA9IF8ubGFzdChmaWx0ZXJlZEFycmF5KTtcclxuICAgICAgICAgICAgaWYgKCFsYXN0VmFsdWUgfHwgIW1vbWVudC51dGMobGFzdFZhbHVlLnQpLmlzU2FtZShtb21lbnQudXRjKG9iamVjdFRvQWRkVG9BcnJheS50KSkpIHtcclxuICAgICAgICAgICAgICAgIC8vIGl0IGlzIHJldmVyc2VkIGFycmF5IHNvIHB1c2ggdG8gaXRcclxuICAgICAgICAgICAgICAgIGZpbHRlcmVkQXJyYXkucHVzaChvYmplY3RUb0FkZFRvQXJyYXkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZEFycmF5LnJldmVyc2UoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdHMgcmVwZWF0ZWRseSBhbmQgcmV0dXJuIGFsbCBkYXRhIGluIGdpdmVuIHJlcXVlc3QgaW50ZXJ2YWwgKGJ5IGR1cmF0aW9uLCBzdGFydCBhbmQvb3IgZW5kIHRpbWUpLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBpbnRlcnZhbCBpbiBzZWNvbmRzXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcGVhdGVkbHlXaG9sZShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICBsZXQgbGFzdE1lcmdlZFJlc3BvbnNlOiBUaW1lc2VyaWVzUmVzcG9uc2U7XHJcbiAgICAgICAgY29uc3QgdHogPSB0aW1lem9uZTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwZWF0ZWRseU9icyA9IHRoaXMuX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0aW1lem9uZSlcclxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogVGltZXNlcmllc1Jlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobGFzdE1lcmdlZFJlc3BvbnNlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZSA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGN1dEJlZm9yZURhdGUuc3VidHJhY3QoTWF0aC5hYnMocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGVVVENGb3JtYXQgPSBjdXRCZWZvcmVEYXRlLmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwodHopKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKGN1dEJlZm9yZURhdGVVVENGb3JtYXQsIHR6KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID0gcmVzcG9uc2UudGltZVBlcmlvZC5lbmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBjdXRCZWZvcmVEYXRlVVRDRm9ybWF0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCkuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBfLmVhY2gobGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMsIChyZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3UmVzdWx0cyA9IF8uZmluZChyZXNwb25zZS5yZXN1bHRzLCB7IGZxbjogcmVzdWx0LmZxbiB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKG5ld1Jlc3VsdHMpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gcmVzdWx0LnZhbHVlcy5jb25jYXQobmV3UmVzdWx0cy52YWx1ZXMpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSBfLnNvcnRCeShyZXN1bHQudmFsdWVzLCBbKG86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1vbWVudC51dGMoby50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1dKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gdGhpcy5fZmlsdGVyRHVwbGljYXRlRGF0YUFuZEN1dChyZXN1bHQudmFsdWVzLCBjdXRCZWZvcmVEYXRlLCBmYWxzZSwgdHopO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gYWRkIGFueSBuZXcgZnFucyBkYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgXy5lYWNoKHJlc3BvbnNlLnJlc3VsdHMsIChuZXdSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmZpbmQobGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMsIHsgZnFuOiBuZXdSZXN1bHQuZnFuIH0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cy5wdXNoKG5ld1Jlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbGFzdE1lcmdlZFJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UgPSByZXNwb25zZTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICByZXR1cm4gcmVwZWF0ZWRseU9icztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdHMgcmVwZWF0ZWRseSBhbmQgcmV0dXJuIGRhdGEgYXMgaW5jcmVtZW50cy5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgaW50ZXJ2YWwgaW4gc2Vjb25kc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhcclxuICAgICAgICByZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuXHJcbiAgICAgICAgbGV0IGxhc3RSZXNwb25zZURhdGE6IE1hcDxzdHJpbmcsIGFueT47XHJcbiAgICAgICAgbGV0IHJlcGVhdGVkSW50ZXJ2YWwgPSBjdXN0b21JbnRlcnZhbCB8fCB0aGlzLmNvbmZpZy5kZWZhdWx0UmVwZWF0ZWREYXRhSW50ZXJ2YWwgfHwgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMO1xyXG4gICAgICAgIHJlcGVhdGVkSW50ZXJ2YWwgPSByZXBlYXRlZEludGVydmFsICogMTAwMDtcclxuXHJcbiAgICAgICAgY29uc3QgbGFzdFJlcGVhdGVkUmVxdWVzdCA9IF8uY2xvbmUocmVxdWVzdCk7XHJcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxEdXJhdGlvbiA9IHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uO1xyXG4gICAgICAgIGxldCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50OiBtb21lbnQuTW9tZW50O1xyXG5cclxuICAgICAgICBjb25zdCByZXBlYXRlZERhdGFPYnNlcnZhYmxlID0gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQgPSB0aGlzLl9nZXRTdGFydEZvck5leHRSZXF1ZXN0KHJlc3BvbnNlLCBvcmlnaW5hbER1cmF0aW9uLCByZXBlYXRlZEludGVydmFsKTtcclxuICAgICAgICAgICAgLy8gd2UgcmVtZW1iZXIgbGFzdCB2YWx1ZSBiZWZvcmUgbmV4dFN0YXJ0IGluIGN1cnJlbnQgcmVxdWVzdCB0byBjaGVjayBpdHNcclxuICAgICAgICAgICAgLy8gcXVhbGl0eSB2cy4gbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgdmFsdWUgcXVhbGl0eSwgcG9zc2libHlcclxuICAgICAgICAgICAgLy8gdG8gb21pdCBzdGFydCB2YWx1ZVxyXG4gICAgICAgICAgICAvLyAtIGl0IG1heSBiZSBpbnRlcnBvbGF0ZWQgYmV0d2VlbiB0d28gZ29vZCBxdWFsaXR5IHZhbHVlc1xyXG4gICAgICAgICAgICBsYXN0UmVzcG9uc2VEYXRhID0gdGhpcy5fZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2UsIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHRpbWV6b25lKTtcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgY29uc3QgZXhwYW5kZWRPYnNlcnZhYmxlID0gcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZS5waXBlKFxyXG4gICAgICAgICAgICBleHBhbmQoKCkgPT4gdGltZXIocmVwZWF0ZWRJbnRlcnZhbCkucGlwZShjb25jYXRNYXAoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdFJlcGVhdGVkUmVxdWVzdC5zZXRUaW1lUGVyaW9kKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfLmV4dGVuZChsYXN0UmVwZWF0ZWRSZXF1ZXN0LmdldFRpbWVQZXJpb2QoKSwgeyBkdXJhdGlvbjogMCwgc3RhcnQ6IG5leHRSZXF1ZXN0U3RhcnRNb21lbnQudG9EYXRlKCkgfSkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChsYXN0UmVwZWF0ZWRSZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsYXN0UmVzcG9uc2VEYXRhLnNpemUgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdlIGNoZWNrIHByZXZpb3VzIHZhbHVlcyB0byBjdXJyZW50IHN0YXJ0aW5nIG9uZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gZmlsdGVyIG91dCBwb3NzaWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdGFydCBpbnRlcnBvbGF0ZWQgb25lcyBpZiB0aGV5IGFyZSBiZXR3ZWVuIGdvb2Qgb25lc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9maWx0ZXJTdGFydFJlc3BvbnNlRGF0YShyZXNwb25zZSwgbGFzdFJlc3BvbnNlRGF0YSwgcmVxdWVzdFRpbWVQZXJpb2QpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50ID0gdGhpcy5fZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChyZXNwb25zZSwgb3JpZ2luYWxEdXJhdGlvbiwgcmVwZWF0ZWRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gd2UgcmVtZW1iZXIgbGFzdCB2YWx1ZSBiZWZvcmUgbmV4dFN0YXJ0IGluIGN1cnJlbnQgcmVxdWVzdCB0byBjaGVjayBpdHNcclxuICAgICAgICAgICAgICAgICAgICAvLyBxdWFsaXR5IHZzLiBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSB2YWx1ZSBxdWFsaXR5LCBwb3NzaWJseVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRvIG9taXQgc3RhcnQgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAvLyAtIGl0IG1heSBiZSBpbnRlcnBvbGF0ZWQgYmV0d2VlbiB0d28gZ29vZCBxdWFsaXR5IHZhbHVlc1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RSZXNwb25zZURhdGEgPSB0aGlzLl9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZSwgbmV4dFJlcXVlc3RTdGFydE1vbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH0pKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIHJldHVybiBleHBhbmRlZE9ic2VydmFibGU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCByZXF1ZXN0IGZvciB0aW1lc2VyaWVzIGRhdGEgcmVwZWF0ZWRseS4gSXQgcmVwZWF0ZWRseSBzZW5kcyByZXF1ZXN0cyB0byBzZXJ2ZXIuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGN1c3RvbSBpbnRlcnZhbCBmb3IgcmVwZWF0ZWQgZGF0YSwgaW4gc2Vjb25kc1xyXG4gICAgICogQHBhcmFtIGZvcm1hdCAoT3B0aW9uYWwpIGZvcm1hdCBmb3IgcmVwZWF0ZWQgZGF0YSByZXNwb25zZVxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIChPcHRpb25hbCkgU2V0IHRoZSB0aW1lem9uZSB0byBhcHBseSB0byBkYXRldGltZSBzdHJpbmdzIGZvciB0aW1lc2VyaWVzIHJlc3BvbnNlIGRhdGEuXHJcbiAgICAgKiBSZXR1cm5lZCBkYXRlIHN0cmluZ3MgYXJlIGluIG1heGltdW0gamF2YXNjcmlwdCByZXNvbHV0aW9uIHBvc3NpYmxlXHJcbiAgICAgKiBzdXBwb3J0ZWQgYnkgdXNpbmcgbW9tZW50IGxpYnJhcnkgKEphdmFzY3JpcHQgZGF0ZSAtIG1pbGxpc2Vjb25kcykuXHJcbiAgICAgKiBSZXNvbHV0aW9uIGZvciB0aW1lIGFmdGVyIG1pbGxpc2Vjb25kcyB3aWxsIGJlIGxvc3QuXHJcbiAgICAgKiBJZiB3b3JraW5nIHdpdGggdGltZXpvbmUgaW4gZGF0ZXRpbWUgc3RyaW5nIGl0IGlzIHJlY29tbWVuZGVkIHRvIHVzZSBtb21lbnQucGFyc2Vab25lIHRvIHByZXNlcnZlIHRpbWV6b25lIGluZm9ybWF0aW9uLlxyXG4gICAgICogTW9tZW50IHRpbWV6b25lcyB0aGF0IHN0YXJ0IHdpdGggXCJFdGMvR01UXCIgdXNlIFBPU0lYLXN0eWxlIHNpZ25zIGluIHRoZSBab25lIG5hbWVzIGFuZCB0aGUgb3V0cHV0IGFiYnJldmlhdGlvbnMsXHJcbiAgICAgKiBldmVuIHRob3VnaCB0aGlzIGlzIHRoZSBvcHBvc2l0ZSBvZiB3aGF0IG1hbnkgcGVvcGxlIGV4cGVjdC5cclxuICAgICAqIFBPU0lYIGhhcyBwb3NpdGl2ZSBzaWducyB3ZXN0IG9mIEdyZWVud2ljaCwgYnV0IG1hbnkgcGVvcGxlIGV4cGVjdFxyXG4gICAgICogcG9zaXRpdmUgc2lnbnMgZWFzdCBvZiBHcmVlbndpY2guICBGb3IgZXhhbXBsZSwgVFo9J0V0Yy9HTVQrNCcgdXNlc1xyXG4gICAgICogdGhlIGFiYnJldmlhdGlvbiBcIkdNVCs0XCIgYW5kIGNvcnJlc3BvbmRzIHRvIDQgaG91cnMgYmVoaW5kIFVUXHJcbiAgICAgKiAoaS5lLiB3ZXN0IG9mIEdyZWVud2ljaCkgZXZlbiB0aG91Z2ggbWFueSBwZW9wbGUgd291bGQgZXhwZWN0IGl0IHRvXHJcbiAgICAgKiBtZWFuIDQgaG91cnMgYWhlYWQgb2YgVVQgKGkuZS4gZWFzdCBvZiBHcmVlbndpY2gpLlxyXG4gICAgICovXHJcbiAgICBnZXRSZXBlYXRlZGx5KHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgZm9ybWF0PzogVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdCwgdGltZXpvbmU/OiBzdHJpbmcpOlxyXG4gICAgICAgIE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHJlcXVlc3RUaW1lUGVyaW9kLnN0YXJ0KSkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0RXJyb3JPYnNlcnZhYmxlKCdUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZ2V0UmVwZWF0ZWRseTogQXJndW1lbnQgZXhjZXB0aW9uJ1xyXG4gICAgICAgICAgICAgICAgKyAnIC0gUmVxdWVzdCBzdGFydCB0aW1lIGNhbm5vdCBiZSBzZXQgZm9yIHJlcGVhdGVkIGRhdGEgKHJlcXVlc3Q6ICdcclxuICAgICAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkocmVxdWVzdCkgKyAnIGNhbm5vdCBiZSBwcm9jZXNzZWQuJyk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChfLmlzTmlsKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSB8fCByZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiA+IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEVycm9yT2JzZXJ2YWJsZSgnVGltZXNlcmllc0RhdGFTZXJ2aWNlIGdldFJlcGVhdGVkbHk6IEFyZ3VtZW50IGV4Y2VwdGlvbidcclxuICAgICAgICAgICAgICAgICsgJyAtIFJlcXVlc3QgZHVyYXRpb24gaGF2ZSB0byBiZSBuZWdhdGl2ZSAocmVxdWVzdDogJ1xyXG4gICAgICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KSArICcgY2Fubm90IGJlIHByb2Nlc3NlZC4nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB0ejogc3RyaW5nO1xyXG4gICAgICAgIGlmIChNb21lbnRIZWxwZXJTZXJ2aWNlLmlzVmFsaWRUaW1lem9uZSh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgdHogPSB0aW1lem9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF8uaXNOaWwoZm9ybWF0KSB8fCBmb3JtYXQgPT09IFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQud2hvbGVJbnRlcnZhbCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UmVwZWF0ZWRseVdob2xlKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0eik7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKHJlcXVlc3QsIGN1c3RvbUludGVydmFsLCB0eik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==