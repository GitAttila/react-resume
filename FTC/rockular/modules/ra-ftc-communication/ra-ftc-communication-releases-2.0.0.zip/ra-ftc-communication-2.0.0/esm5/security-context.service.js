import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
export function ISecurityContextResponse() { }
function ISecurityContextResponse_tsickle_Closure_declarations() {
    ISecurityContextResponse.prototype.username;
    ISecurityContextResponse.prototype.roles;
    ISecurityContextResponse.prototype.identities;
}
var SecurityContextService = (function (_super) {
    tslib_1.__extends(SecurityContextService, _super);
    function SecurityContextService(config, http) {
        return _super.call(this, config.baseUrl + '/api/1/securitycontext/', config, http) || this;
    }
    SecurityContextService.prototype.getSecurityContextData = function () {
        return this._sendGetRequest();
    };
    SecurityContextService.decorators = [
        { type: Injectable },
    ];
    SecurityContextService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return SecurityContextService;
}(BaseService));
export { SecurityContextService };
function SecurityContextService_tsickle_Closure_declarations() {
    SecurityContextService.decorators;
    SecurityContextService.ctorParameters;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjdXJpdHktY29udGV4dC5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbInNlY3VyaXR5LWNvbnRleHQuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUMsTUFBTSxlQUFlLENBQUM7QUFDakQsT0FBTyxFQUFDLFVBQVUsRUFBQyxNQUFNLHNCQUFzQixDQUFDO0FBQ2hELE9BQU8sRUFBQyxvQkFBb0IsRUFBdUIsTUFBTSxVQUFVLENBQUM7QUFFcEUsT0FBTyxFQUFDLFdBQVcsRUFBQyxNQUFNLGdCQUFnQixDQUFDOzs7Ozs7OztJQWlCQyxrREFBVztJQUVyRCxnQ0FBMEMsUUFBOEIsSUFBZ0I7ZUFDdEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyx5QkFBeUIsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0tBQ2hFO0lBS00sdURBQXNCO1FBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7OztnQkFYakMsVUFBVTs7O2dEQUdJLE1BQU0sU0FBQyxvQkFBb0I7Z0JBdEJsQyxVQUFVOztpQ0FEbEI7RUFxQjRDLFdBQVc7U0FBMUMsc0JBQXNCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0h0dHBDbGllbnR9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtCYXNlU2VydmljZX0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuLyoqXHJcbiAqIE5hdmlnYXRpb24gcmVzcG9uc2UgaW50ZXJmYWNlXHJcbiAqIEBwYXJhbSB1c2VybmFtZSAtIGlkZW50aXR5IHByb3ZpZGVyIChlbWFpbClcclxuICogQHBhcmFtIHJvbGVzIC0gbGlzdCBvZiB1c2VyIHJvbGVzXHJcbiAqIEBwYXJhbSBpZGVudGl0aWVzIC0gbGlzdCBvZiBpZGVudGl0aWVzIHByb3ZpZGVyc1xyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJU2VjdXJpdHlDb250ZXh0UmVzcG9uc2Uge1xyXG4gIHVzZXJuYW1lOiBzdHJpbmc7XHJcbiAgcm9sZXM6IHN0cmluZ1tdO1xyXG4gIGlkZW50aXRpZXM6IHN0cmluZ1tdO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBTZWN1cml0eUNvbnRleHRSZXNwb25zZSA9IElTZWN1cml0eUNvbnRleHRSZXNwb25zZTtcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFNlY3VyaXR5Q29udGV4dFNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS9zZWN1cml0eWNvbnRleHQvJywgY29uZmlnLCBodHRwKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIE1ha2VzIGEgcmVxdWVzdCB0byBKU09OIFNlY3VyaXR5IENvbnRleHQgc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRTZWN1cml0eUNvbnRleHREYXRhKCk6IE9ic2VydmFibGU8U2VjdXJpdHlDb250ZXh0UmVzcG9uc2U+IHtcclxuICAgIHJldHVybiB0aGlzLl9zZW5kR2V0UmVxdWVzdCgpO1xyXG4gIH1cclxufVxyXG5cclxuIl19