import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { InstanceService } from './instance.service';
import { LiveDataService } from './live-data.service';
import { TimeseriesDataService } from './timeseries-data.service';
import { COMMUNICATION_CONFIG } from './config';
import { OperationService } from './operation.service';
import { PersistenceService } from './persistence.service';
import { NavigationService } from './navigation.service';
import { OpcQualityService } from './opc-quality.service';
import { SecurityContextService } from './security-context.service';
import { MimeService } from './mime.service';
import { NavigationHandlerService } from './navigation-handler.service';
export function setupInstanceSvc(config, httpClient) {
    return new InstanceService(config, httpClient);
}
export function setupLiveDataSvc(config, httpClient) {
    return new LiveDataService(config, httpClient);
}
export function setupTimeseriesDataSvc(config, httpClient, qualitySvc) {
    return new TimeseriesDataService(config, httpClient, qualitySvc);
}
export function setupOperationSvc(config, httpClient) {
    return new OperationService(config, httpClient);
}
export function setupPersistenceSvc(config, httpClient) {
    return new PersistenceService(config, httpClient);
}
export function setupNavigationSvc(config, httpClient) {
    return new NavigationService(config, httpClient);
}
export function setupSecurityContextSvc(config, httpClient) {
    return new SecurityContextService(config, httpClient);
}
export function setupMimeSvc(config, httpClient) {
    return new MimeService(config, httpClient);
}
export function setupNavigationHandlerSvc(config, httpClient) {
    return new NavigationHandlerService(config, httpClient);
}
var RaFtcCommunicationModule = (function () {
    function RaFtcCommunicationModule() {
    }
    RaFtcCommunicationModule.forRoot = function (config) {
        return {
            ngModule: RaFtcCommunicationModule,
            providers: [
                {
                    provide: InstanceService,
                    useFactory: setupInstanceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: LiveDataService,
                    useFactory: setupLiveDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: TimeseriesDataService,
                    useFactory: setupTimeseriesDataSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient, OpcQualityService
                    ]
                },
                {
                    provide: OperationService,
                    useFactory: setupOperationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: PersistenceService,
                    useFactory: setupPersistenceSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationService,
                    useFactory: setupNavigationSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: SecurityContextService,
                    useFactory: setupSecurityContextSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: MimeService,
                    useFactory: setupMimeSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                {
                    provide: NavigationHandlerService,
                    useFactory: setupNavigationHandlerSvc,
                    deps: [
                        COMMUNICATION_CONFIG, HttpClient
                    ]
                },
                { provide: COMMUNICATION_CONFIG, useValue: config }
            ]
        };
    };
    RaFtcCommunicationModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        HttpClientModule
                    ],
                    providers: [OpcQualityService],
                    declarations: []
                },] },
    ];
    return RaFtcCommunicationModule;
}());
export { RaFtcCommunicationModule };
function RaFtcCommunicationModule_tsickle_Closure_declarations() {
    RaFtcCommunicationModule.decorators;
    RaFtcCommunicationModule.ctorParameters;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbXVuaWNhdGlvbi5tb2R1bGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsiY29tbXVuaWNhdGlvbi5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBdUIsTUFBTSxlQUFlLENBQUM7QUFDOUQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUNwRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDckQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsTUFBTSxVQUFVLENBQUM7QUFDdEUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDekQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDMUQsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDcEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBRXhFLE1BQU0sMkJBQ0YsTUFBNEIsRUFBRSxVQUFzQjtJQUNwRCxNQUFNLENBQUMsSUFBSSxlQUFlLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQ2xEO0FBQ0QsTUFBTSwyQkFDRixNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE1BQU0sQ0FBQyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDbEQ7QUFDRCxNQUFNLGlDQUNGLE1BQTRCLEVBQUUsVUFBc0IsRUFBRSxVQUE2QjtJQUNuRixNQUFNLENBQUMsSUFBSSxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQ3BFO0FBRUQsTUFBTSw0QkFDRixNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE1BQU0sQ0FBQyxJQUFJLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztDQUNuRDtBQUNELE1BQU0sOEJBQ0YsTUFBNEIsRUFBRSxVQUFzQjtJQUNwRCxNQUFNLENBQUMsSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7Q0FDckQ7QUFDRCxNQUFNLDZCQUNGLE1BQTRCLEVBQUUsVUFBc0I7SUFDcEQsTUFBTSxDQUFDLElBQUksaUJBQWlCLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQ3BEO0FBQ0QsTUFBTSxrQ0FDRixNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE1BQU0sQ0FBQyxJQUFJLHNCQUFzQixDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztDQUN6RDtBQUNELE1BQU0sdUJBQ0YsTUFBNEIsRUFBRSxVQUFzQjtJQUNwRCxNQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBQzlDO0FBQ0QsTUFBTSxvQ0FDSixNQUE0QixFQUFFLFVBQXNCO0lBQ3BELE1BQU0sQ0FBQyxJQUFJLHdCQUF3QixDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztDQUN6RDs7OztJQVdVLGdDQUFPLEdBQWQsVUFBZSxNQUE0QjtRQUN2QyxNQUFNLENBQUM7WUFDSCxRQUFRLEVBQUUsd0JBQXdCO1lBQ2xDLFNBQVMsRUFBRTtnQkFDUDtvQkFDSSxPQUFPLEVBQUUsZUFBZTtvQkFDeEIsVUFBVSxFQUFFLGdCQUFnQjtvQkFDNUIsSUFBSSxFQUFFO3dCQUNGLG9CQUFvQixFQUFFLFVBQVU7cUJBQ25DO2lCQUNKO2dCQUNEO29CQUNJLE9BQU8sRUFBRSxlQUFlO29CQUN4QixVQUFVLEVBQUUsZ0JBQWdCO29CQUM1QixJQUFJLEVBQUU7d0JBQ0Ysb0JBQW9CLEVBQUUsVUFBVTtxQkFDbkM7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksT0FBTyxFQUFFLHFCQUFxQjtvQkFDOUIsVUFBVSxFQUFFLHNCQUFzQjtvQkFDbEMsSUFBSSxFQUFFO3dCQUNGLG9CQUFvQixFQUFFLFVBQVUsRUFBRSxpQkFBaUI7cUJBQ3REO2lCQUNKO2dCQUNEO29CQUNJLE9BQU8sRUFBRSxnQkFBZ0I7b0JBQ3pCLFVBQVUsRUFBRSxpQkFBaUI7b0JBQzdCLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVO3FCQUNuQztpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsa0JBQWtCO29CQUMzQixVQUFVLEVBQUUsbUJBQW1CO29CQUMvQixJQUFJLEVBQUU7d0JBQ0Ysb0JBQW9CLEVBQUUsVUFBVTtxQkFDbkM7aUJBQ0o7Z0JBQ0Q7b0JBQ0ksT0FBTyxFQUFFLGlCQUFpQjtvQkFDMUIsVUFBVSxFQUFFLGtCQUFrQjtvQkFDOUIsSUFBSSxFQUFFO3dCQUNGLG9CQUFvQixFQUFFLFVBQVU7cUJBQ25DO2lCQUNKO2dCQUNEO29CQUNJLE9BQU8sRUFBRSxzQkFBc0I7b0JBQy9CLFVBQVUsRUFBRSx1QkFBdUI7b0JBQ25DLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVO3FCQUNuQztpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsV0FBVztvQkFDcEIsVUFBVSxFQUFFLFlBQVk7b0JBQ3hCLElBQUksRUFBRTt3QkFDRixvQkFBb0IsRUFBRSxVQUFVO3FCQUNuQztpQkFDSjtnQkFDRDtvQkFDSSxPQUFPLEVBQUUsd0JBQXdCO29CQUNqQyxVQUFVLEVBQUUseUJBQXlCO29CQUNyQyxJQUFJLEVBQUU7d0JBQ0osb0JBQW9CLEVBQUUsVUFBVTtxQkFDakM7aUJBQ0o7Z0JBQ0QsRUFBRSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRTthQUN0RDtTQUNKLENBQUM7S0FDTDs7Z0JBL0VKLFFBQVEsU0FBQztvQkFDTixPQUFPLEVBQUU7d0JBQ0wsWUFBWTt3QkFDWixnQkFBZ0I7cUJBQ25CO29CQUNELFNBQVMsRUFBRSxDQUFDLGlCQUFpQixDQUFDO29CQUM5QixZQUFZLEVBQUUsRUFBRTtpQkFDbkI7O21DQTVERDs7U0E2RGEsd0JBQXdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUsIE1vZHVsZVdpdGhQcm92aWRlcnMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgSHR0cENsaWVudE1vZHVsZSwgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgSW5zdGFuY2VTZXJ2aWNlIH0gZnJvbSAnLi9pbnN0YW5jZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTGl2ZURhdGFTZXJ2aWNlIH0gZnJvbSAnLi9saXZlLWRhdGEuc2VydmljZSc7XHJcbmltcG9ydCB7IFRpbWVzZXJpZXNEYXRhU2VydmljZSB9IGZyb20gJy4vdGltZXNlcmllcy1kYXRhLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IE9wZXJhdGlvblNlcnZpY2UgfSBmcm9tICcuL29wZXJhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgUGVyc2lzdGVuY2VTZXJ2aWNlIH0gZnJvbSAnLi9wZXJzaXN0ZW5jZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2aWdhdGlvblNlcnZpY2UgfSBmcm9tICcuL25hdmlnYXRpb24uc2VydmljZSc7XHJcbmltcG9ydCB7IE9wY1F1YWxpdHlTZXJ2aWNlIH0gZnJvbSAnLi9vcGMtcXVhbGl0eS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU2VjdXJpdHlDb250ZXh0U2VydmljZSB9IGZyb20gJy4vc2VjdXJpdHktY29udGV4dC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTWltZVNlcnZpY2UgfSBmcm9tICcuL21pbWUuc2VydmljZSc7XHJcbmltcG9ydCB7IE5hdmlnYXRpb25IYW5kbGVyU2VydmljZSB9IGZyb20gJy4vbmF2aWdhdGlvbi1oYW5kbGVyLnNlcnZpY2UnO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwSW5zdGFuY2VTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IEluc3RhbmNlU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cExpdmVEYXRhU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBMaXZlRGF0YVNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBUaW1lc2VyaWVzRGF0YVN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQsIHF1YWxpdHlTdmM6IE9wY1F1YWxpdHlTZXJ2aWNlKSB7XHJcbiAgICByZXR1cm4gbmV3IFRpbWVzZXJpZXNEYXRhU2VydmljZShjb25maWcsIGh0dHBDbGllbnQsIHF1YWxpdHlTdmMpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBPcGVyYXRpb25TdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IE9wZXJhdGlvblNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBQZXJzaXN0ZW5jZVN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgUGVyc2lzdGVuY2VTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwTmF2aWdhdGlvblN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgTmF2aWdhdGlvblNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBTZWN1cml0eUNvbnRleHRTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IFNlY3VyaXR5Q29udGV4dFNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBNaW1lU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBNaW1lU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cE5hdmlnYXRpb25IYW5kbGVyU3ZjKFxyXG4gIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICByZXR1cm4gbmV3IE5hdmlnYXRpb25IYW5kbGVyU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gICAgaW1wb3J0czogW1xyXG4gICAgICAgIENvbW1vbk1vZHVsZSxcclxuICAgICAgICBIdHRwQ2xpZW50TW9kdWxlXHJcbiAgICBdLFxyXG4gICAgcHJvdmlkZXJzOiBbT3BjUXVhbGl0eVNlcnZpY2VdLFxyXG4gICAgZGVjbGFyYXRpb25zOiBbXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgUmFGdGNDb21tdW5pY2F0aW9uTW9kdWxlIHtcclxuICAgIHN0YXRpYyBmb3JSb290KGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcpOiBNb2R1bGVXaXRoUHJvdmlkZXJzIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBuZ01vZHVsZTogUmFGdGNDb21tdW5pY2F0aW9uTW9kdWxlLFxyXG4gICAgICAgICAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBJbnN0YW5jZVNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBJbnN0YW5jZVN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBMaXZlRGF0YVNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBMaXZlRGF0YVN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBUaW1lc2VyaWVzRGF0YVNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBUaW1lc2VyaWVzRGF0YVN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50LCBPcGNRdWFsaXR5U2VydmljZVxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogT3BlcmF0aW9uU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cE9wZXJhdGlvblN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBQZXJzaXN0ZW5jZVNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBQZXJzaXN0ZW5jZVN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBOYXZpZ2F0aW9uU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cE5hdmlnYXRpb25TdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogU2VjdXJpdHlDb250ZXh0U2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cFNlY3VyaXR5Q29udGV4dFN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBNaW1lU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cE1pbWVTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvdmlkZTogTmF2aWdhdGlvbkhhbmRsZXJTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwTmF2aWdhdGlvbkhhbmRsZXJTdmMsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVwczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgeyBwcm92aWRlOiBDT01NVU5JQ0FUSU9OX0NPTkZJRywgdXNlVmFsdWU6IGNvbmZpZyB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==