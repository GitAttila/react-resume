import { Injectable } from '@angular/core';
export function IQuality() { }
function IQuality_tsickle_Closure_declarations() {
    IQuality.prototype.overall;
    IQuality.prototype.da;
    IQuality.prototype.limit;
    IQuality.prototype.hda;
}
var OpcQualityService = (function () {
    function OpcQualityService() {
        this.opcDaQualityMask = 0xfffC;
        this.opcDaQualityMasterMask = 0x00C0;
        this.opcHdaQualityMask = 0xffff0000;
        this.opcDaQualityFieldMasks = {
            limitField: 0x0003,
            subStatusField: 0x003C,
            quality: 0x00C0
        };
        this.opcDaQualityMaster = {
            bad: 0x0000,
            uncertain: 0x0040,
            notDefined: 0x0080,
            good: 0x00C0
        };
        this.opcDaQualityStatus = {
            bad: 0x0000,
            configError: 0x0004,
            notConnected: 0x0008,
            deviceFailure: 0x000c,
            sensorFailure: 0x0010,
            lastKnown: 0x0014,
            commFailure: 0x0018,
            outOfService: 0x001c,
            initializing: 0x0020,
            uncertain: 0x0040,
            lastUsable: 0x0044,
            sensorNotAccurate: 0x0050,
            engUnitsExceeded: 0x0054,
            subNormal: 0x0058,
            good: 0x00C0,
            localOverride: 0x00D8
        };
        this.opcDaQualityLimit = {
            limitOk: 0x0000,
            limitLow: 0x0001,
            limitHigh: 0x0002,
            constant: 0x0003
        };
        this.opcHdaQuality = {
            extraData: 0x00010000,
            interpolated: 0x00020000,
            raw: 0x00040000,
            calculated: 0x00080000,
            noBound: 0x00100000,
            noData: 0x00200000,
            dataLost: 0x00400000,
            conversion: 0x00800000,
            partial: 0x01000000
        };
        this.overallMessages = {
            0x0000: 'Bad',
            0x0040: 'Uncertain',
            0x0080: 'Not defined',
            0x00C0: 'Good'
        };
        this.detailsMessages = {
            0x0000: 'Not limited',
            0x0001: 'Low limited',
            0x0002: 'High limited',
            0x0003: 'Constant',
            0x0004: 'Config error',
            0x0008: 'Not connected',
            0x000c: 'Device failure',
            0x0010: 'Sensor failure',
            0x0014: 'Last known',
            0x0018: 'Comm failure',
            0x001C: 'Out of service',
            0x0020: 'Initializing',
            0x0044: 'Last usable',
            0x0050: 'Sensors not accurate',
            0x0054: 'Engineering units exceeded',
            0x0058: 'Sub-Normal',
            0x00D8: 'Local override',
            0x00010000: 'Extra data',
            0x00020000: 'Interpolated',
            0x00040000: 'Raw',
            0x00080000: 'Calculated',
            0x00100000: 'No bound',
            0x00200000: 'No data',
            0x00400000: 'Data lost',
            0x00800000: 'Conversion',
            0x01000000: 'Partial'
        };
    }
    OpcQualityService.prototype.asObject = function (qualityAsInt) {
        var mask;
        var quality = ({});
        mask = qualityAsInt & this.opcDaQualityMasterMask;
        quality.overall = this.overallMessages[mask];
        mask = qualityAsInt & this.opcDaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.da = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        if (mask && this.detailsMessages[mask]) {
            quality.limit = this.detailsMessages[mask];
        }
        mask = qualityAsInt & this.opcHdaQualityMask;
        if (mask && this.detailsMessages[mask]) {
            quality.hda = this.detailsMessages[mask];
        }
        return quality;
    };
    OpcQualityService.prototype.asString = function (qualityAsInt) {
        var hasDaQuality = false;
        var qObj = this.asObject(qualityAsInt);
        var qString;
        qString = qObj.overall;
        if (qObj.da) {
            qString = qString + ': ' + qObj.da;
            hasDaQuality = true;
        }
        if (qObj.limit) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.limit;
            hasDaQuality = true;
        }
        if (qObj.hda) {
            qString = qString +
                (hasDaQuality ? ', ' : ': ') + qObj.hda;
        }
        return qString;
    };
    OpcQualityService.prototype.getOpcDaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMask;
    };
    OpcQualityService.prototype.getOpcLimitStatus = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
    };
    OpcQualityService.prototype.getSimpleQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcDaQualityMasterMask;
    };
    OpcQualityService.prototype.getOpcHdaQuality = function (qualityAsInt) {
        return qualityAsInt & this.opcHdaQualityMask;
    };
    OpcQualityService.prototype.isGood = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
    };
    OpcQualityService.prototype.isUncertain = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
    };
    OpcQualityService.prototype.isBad = function (qualityAsInt) {
        return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
    };
    OpcQualityService.prototype.isDaConfigError = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
    };
    OpcQualityService.prototype.isDaNotConnected = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
    };
    OpcQualityService.prototype.isDaDeviceFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
    };
    OpcQualityService.prototype.isDaSensorFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
    };
    OpcQualityService.prototype.isDaLastKnown = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
    };
    OpcQualityService.prototype.isDaCommFailure = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
    };
    OpcQualityService.prototype.isDaOutOfService = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
    };
    OpcQualityService.prototype.isDaInitializing = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
    };
    OpcQualityService.prototype.isDaLastUsable = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
    };
    OpcQualityService.prototype.isDaSensorNotAccurate = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
    };
    OpcQualityService.prototype.isDaEngUnitsExceeded = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
    };
    OpcQualityService.prototype.isDaSubNormal = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
    };
    OpcQualityService.prototype.isDaLocalOverride = function (qualityAsInt) {
        return (this.getOpcDaQuality(qualityAsInt) &
            this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
    };
    OpcQualityService.prototype.isLimitOk = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
    };
    OpcQualityService.prototype.isLimitLow = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
    };
    OpcQualityService.prototype.isLimitHigh = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
    };
    OpcQualityService.prototype.isLimitConstant = function (qualityAsInt) {
        return (this.getOpcLimitStatus(qualityAsInt) &
            this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
    };
    OpcQualityService.prototype.isHdaExtraData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
    };
    OpcQualityService.prototype.isHdaInterpolated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
    };
    OpcQualityService.prototype.isHdaRaw = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
    };
    OpcQualityService.prototype.isHdaCalculated = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
    };
    OpcQualityService.prototype.isHdaNoBound = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
    };
    OpcQualityService.prototype.isHdaNoData = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
    };
    OpcQualityService.prototype.isHdaDataLost = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
    };
    OpcQualityService.prototype.isHdaConversion = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
    };
    OpcQualityService.prototype.isHdaPartial = function (qualityAsInt) {
        return (this.getOpcHdaQuality(qualityAsInt) &
            this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
    };
    OpcQualityService.decorators = [
        { type: Injectable },
    ];
    return OpcQualityService;
}());
export { OpcQualityService };
function OpcQualityService_tsickle_Closure_declarations() {
    OpcQualityService.decorators;
    OpcQualityService.ctorParameters;
    OpcQualityService.prototype.opcDaQualityMask;
    OpcQualityService.prototype.opcDaQualityMasterMask;
    OpcQualityService.prototype.opcHdaQualityMask;
    OpcQualityService.prototype.opcDaQualityFieldMasks;
    OpcQualityService.prototype.opcDaQualityMaster;
    OpcQualityService.prototype.opcDaQualityStatus;
    OpcQualityService.prototype.opcDaQualityLimit;
    OpcQualityService.prototype.opcHdaQuality;
    OpcQualityService.prototype.overallMessages;
    OpcQualityService.prototype.detailsMessages;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BjLXF1YWxpdHkuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vIiwic291cmNlcyI6WyJvcGMtcXVhbGl0eS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7Ozs7Ozs7Ozs7Z0NBcUJkLE1BQU07c0NBQ0EsTUFBTTtpQ0FDWCxVQUFVO3NDQUNMO1lBQy9CLFVBQVUsRUFBRSxNQUFNO1lBQ2xCLGNBQWMsRUFBRSxNQUFNO1lBQ3RCLE9BQU8sRUFBRSxNQUFNO1NBQ2hCO2tDQUM0QjtZQUMzQixHQUFHLEVBQUUsTUFBTTtZQUNYLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLFVBQVUsRUFBRSxNQUFNO1lBQ2xCLElBQUksRUFBRSxNQUFNO1NBQ2I7a0NBQzRCO1lBQzNCLEdBQUcsRUFBRSxNQUFNO1lBQ1gsV0FBVyxFQUFFLE1BQU07WUFDbkIsWUFBWSxFQUFFLE1BQU07WUFDcEIsYUFBYSxFQUFFLE1BQU07WUFDckIsYUFBYSxFQUFFLE1BQU07WUFDckIsU0FBUyxFQUFFLE1BQU07WUFDakIsV0FBVyxFQUFFLE1BQU07WUFDbkIsWUFBWSxFQUFFLE1BQU07WUFDcEIsWUFBWSxFQUFFLE1BQU07WUFDcEIsU0FBUyxFQUFFLE1BQU07WUFDakIsVUFBVSxFQUFFLE1BQU07WUFDbEIsaUJBQWlCLEVBQUUsTUFBTTtZQUN6QixnQkFBZ0IsRUFBRSxNQUFNO1lBQ3hCLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLElBQUksRUFBRSxNQUFNO1lBQ1osYUFBYSxFQUFFLE1BQU07U0FDdEI7aUNBQzJCO1lBQzFCLE9BQU8sRUFBRSxNQUFNO1lBQ2YsUUFBUSxFQUFFLE1BQU07WUFDaEIsU0FBUyxFQUFFLE1BQU07WUFDakIsUUFBUSxFQUFFLE1BQU07U0FDakI7NkJBQ3VCO1lBQ3RCLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLFlBQVksRUFBRSxVQUFVO1lBQ3hCLEdBQUcsRUFBRSxVQUFVO1lBQ2YsVUFBVSxFQUFFLFVBQVU7WUFDdEIsT0FBTyxFQUFFLFVBQVU7WUFDbkIsTUFBTSxFQUFFLFVBQVU7WUFDbEIsUUFBUSxFQUFFLFVBQVU7WUFDcEIsVUFBVSxFQUFFLFVBQVU7WUFDdEIsT0FBTyxFQUFFLFVBQVU7U0FDcEI7K0JBQ3lCO1lBQ3hCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsTUFBTSxFQUFFLFdBQVc7WUFDbkIsTUFBTSxFQUFFLGFBQWE7WUFDckIsTUFBTSxFQUFFLE1BQU07U0FDZjsrQkFFeUI7WUFFeEIsTUFBTSxFQUFFLGFBQWE7WUFDckIsTUFBTSxFQUFFLGFBQWE7WUFDckIsTUFBTSxFQUFFLGNBQWM7WUFDdEIsTUFBTSxFQUFFLFVBQVU7WUFFbEIsTUFBTSxFQUFFLGNBQWM7WUFDdEIsTUFBTSxFQUFFLGVBQWU7WUFDdkIsTUFBTSxFQUFFLGdCQUFnQjtZQUN4QixNQUFNLEVBQUUsZ0JBQWdCO1lBQ3hCLE1BQU0sRUFBRSxZQUFZO1lBQ3BCLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLE1BQU0sRUFBRSxnQkFBZ0I7WUFDeEIsTUFBTSxFQUFFLGNBQWM7WUFFdEIsTUFBTSxFQUFFLGFBQWE7WUFDckIsTUFBTSxFQUFFLHNCQUFzQjtZQUM5QixNQUFNLEVBQUUsNEJBQTRCO1lBQ3BDLE1BQU0sRUFBRSxZQUFZO1lBRXBCLE1BQU0sRUFBRSxnQkFBZ0I7WUFFeEIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsVUFBVSxFQUFFLGNBQWM7WUFDMUIsVUFBVSxFQUFFLEtBQUs7WUFDakIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsVUFBVSxFQUFFLFVBQVU7WUFDdEIsVUFBVSxFQUFFLFNBQVM7WUFDckIsVUFBVSxFQUFFLFdBQVc7WUFDdkIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsVUFBVSxFQUFFLFNBQVM7U0FDdEI7O0lBTU0sb0NBQVEsYUFBQyxZQUFvQjtRQUNsQyxJQUFJLElBQVksQ0FBQztRQUNqQixJQUFNLE9BQU8sSUFBRyxFQUFjLENBQUEsQ0FBQztRQUUvQixJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztRQUNsRCxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFN0MsSUFBSSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDNUMsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN6QztRQUVELElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQztRQUM3RCxFQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkMsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzVDO1FBRUQsSUFBSSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDN0MsRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxQztRQUNELE1BQU0sQ0FBQyxPQUFPLENBQUM7O0lBT1Ysb0NBQVEsYUFBQyxZQUFvQjtRQUNsQyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDekIsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN6QyxJQUFJLE9BQWUsQ0FBQztRQUVwQixPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUN2QixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNaLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDbkMsWUFBWSxHQUFHLElBQUksQ0FBQztTQUNyQjtRQUNELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ2YsT0FBTyxHQUFHLE9BQU87Z0JBQ2YsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUM1QyxZQUFZLEdBQUcsSUFBSSxDQUFDO1NBQ3JCO1FBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDYixPQUFPLEdBQUcsT0FBTztnQkFDZixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1NBQzNDO1FBQ0QsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7SUFPViwyQ0FBZSxhQUFDLFlBQW9CO1FBQ3pDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDOztJQU92Qyw2Q0FBaUIsYUFBQyxZQUFvQjtRQUMzQyxNQUFNLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUM7O0lBT3hELDRDQUFnQixhQUFDLFlBQW9CO1FBQzFDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDOztJQU83Qyw0Q0FBZ0IsYUFBQyxZQUFvQjtRQUMxQyxNQUFNLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQzs7SUFPeEMsa0NBQU0sYUFBQyxZQUFvQjtRQUNoQyxNQUFNLENBQUMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7O0lBT3hGLHVDQUFXLGFBQUMsWUFBb0I7UUFDckMsTUFBTSxDQUFDLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDOztJQU83RixpQ0FBSyxhQUFDLFlBQW9CO1FBQy9CLE1BQU0sQ0FBQyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQzs7SUFPdkYsMkNBQWUsYUFBQyxZQUFvQjtRQUN6QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQzs7SUFNMUUsNENBQWdCLGFBQUMsWUFBb0I7UUFDMUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7O0lBTTVFLDZDQUFpQixhQUFDLFlBQW9CO1FBQzNDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDOztJQU05RSw2Q0FBaUIsYUFBQyxZQUFvQjtRQUMzQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQzs7SUFNOUUseUNBQWEsYUFBQyxZQUFvQjtRQUN2QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7SUFNdEUsMkNBQWUsYUFBQyxZQUFvQjtRQUN6QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQzs7SUFNMUUsNENBQWdCLGFBQUMsWUFBb0I7UUFDMUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7O0lBTTVFLDRDQUFnQixhQUFDLFlBQW9CO1FBQzFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDOztJQU01RSwwQ0FBYyxhQUFDLFlBQW9CO1FBQ3hDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDOztJQU14RSxpREFBcUIsYUFBQyxZQUFvQjtRQUMvQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUM7O0lBTXRGLGdEQUFvQixhQUFDLFlBQW9CO1FBQzlDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQzs7SUFNcEYseUNBQWEsYUFBQyxZQUFvQjtRQUN2QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7SUFNdEUsNkNBQWlCLGFBQUMsWUFBb0I7UUFDM0MsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxLQUFLLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUM7O0lBTzlFLHFDQUFTLGFBQUMsWUFBb0I7UUFDbkMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztZQUMxQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7SUFNaEUsc0NBQVUsYUFBQyxZQUFvQjtRQUNwQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDOztJQU1sRSx1Q0FBVyxhQUFDLFlBQW9CO1FBQ3JDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUM7WUFDMUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7O0lBTXBFLDJDQUFlLGFBQUMsWUFBb0I7UUFDekMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztZQUMxQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQzs7SUFNbEUsMENBQWMsYUFBQyxZQUFvQjtRQUN4QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7O0lBTTVELDZDQUFpQixhQUFDLFlBQW9CO1FBQzNDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQzs7SUFNbEUsb0NBQVEsYUFBQyxZQUFvQjtRQUNsQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUM7O0lBTWhELDJDQUFlLGFBQUMsWUFBb0I7UUFDekMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDOztJQU05RCx3Q0FBWSxhQUFDLFlBQW9CO1FBQ3RDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQzs7SUFNeEQsdUNBQVcsYUFBQyxZQUFvQjtRQUNyQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7O0lBTXRELHlDQUFhLGFBQUMsWUFBb0I7UUFDdkMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOztJQU0xRCwyQ0FBZSxhQUFDLFlBQW9CO1FBQ3pDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7WUFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQzs7SUFNOUQsd0NBQVksYUFBQyxZQUFvQjtRQUN0QyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7OztnQkExWmhFLFVBQVU7OzRCQW5CWDs7U0FvQmEsaUJBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiLyogdHNsaW50OmRpc2FibGU6bm8tYml0d2lzZSAqL1xyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGhlIHF1YWxpdHkuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVF1YWxpdHkge1xyXG4gIC8qKiBnb29kLCBiYWQsIHVuY2VydGFpbiBvciBub3QgZGVmaW5lZCBxdWFsaXR5IHZhbHVlICovXHJcbiAgb3ZlcmFsbDogc3RyaW5nO1xyXG4gIC8qKiBPUEMgREEgcXVhbGl0eSAqL1xyXG4gIGRhPzogc3RyaW5nO1xyXG4gIC8qKiBPUEMgbGltaXQgc3RhdHVzICovXHJcbiAgbGltaXQ/OiBzdHJpbmc7XHJcbiAgLyoqIE9QQyBIREEgcXVhbGl0eSAqL1xyXG4gIGhkYT86IHN0cmluZztcclxufVxyXG5cclxuLyoqXHJcbiAqIFRoaXMgc2VydmljZSBwcm92aWRlcyBhIHNldCBvZiBtZXRob2RzIGZvciBldmFsdWF0aW5nIE9QQyBEQSBxdWFsaXR5LCBPUEMgbGltaXRcclxuICogc3RhdHVzIG9yIE9QQyBIREEgcXVhbGl0eSBieSBwYXNzZWQgYXJndW1lbnQuXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBPcGNRdWFsaXR5U2VydmljZSB7XHJcblxyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5TWFzayA9IDB4ZmZmQztcclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eU1hc3Rlck1hc2sgPSAweDAwQzA7XHJcbiAgcHJpdmF0ZSBvcGNIZGFRdWFsaXR5TWFzayA9IDB4ZmZmZjAwMDA7XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlGaWVsZE1hc2tzID0ge1xyXG4gICAgbGltaXRGaWVsZDogMHgwMDAzLFxyXG4gICAgc3ViU3RhdHVzRmllbGQ6IDB4MDAzQyxcclxuICAgIHF1YWxpdHk6IDB4MDBDMFxyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlNYXN0ZXIgPSB7XHJcbiAgICBiYWQ6IDB4MDAwMCxcclxuICAgIHVuY2VydGFpbjogMHgwMDQwLFxyXG4gICAgbm90RGVmaW5lZDogMHgwMDgwLFxyXG4gICAgZ29vZDogMHgwMEMwXHJcbiAgfTtcclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eVN0YXR1cyA9IHtcclxuICAgIGJhZDogMHgwMDAwLFxyXG4gICAgY29uZmlnRXJyb3I6IDB4MDAwNCxcclxuICAgIG5vdENvbm5lY3RlZDogMHgwMDA4LFxyXG4gICAgZGV2aWNlRmFpbHVyZTogMHgwMDBjLFxyXG4gICAgc2Vuc29yRmFpbHVyZTogMHgwMDEwLFxyXG4gICAgbGFzdEtub3duOiAweDAwMTQsXHJcbiAgICBjb21tRmFpbHVyZTogMHgwMDE4LFxyXG4gICAgb3V0T2ZTZXJ2aWNlOiAweDAwMWMsXHJcbiAgICBpbml0aWFsaXppbmc6IDB4MDAyMCxcclxuICAgIHVuY2VydGFpbjogMHgwMDQwLFxyXG4gICAgbGFzdFVzYWJsZTogMHgwMDQ0LFxyXG4gICAgc2Vuc29yTm90QWNjdXJhdGU6IDB4MDA1MCxcclxuICAgIGVuZ1VuaXRzRXhjZWVkZWQ6IDB4MDA1NCxcclxuICAgIHN1Yk5vcm1hbDogMHgwMDU4LFxyXG4gICAgZ29vZDogMHgwMEMwLFxyXG4gICAgbG9jYWxPdmVycmlkZTogMHgwMEQ4XHJcbiAgfTtcclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eUxpbWl0ID0ge1xyXG4gICAgbGltaXRPazogMHgwMDAwLFxyXG4gICAgbGltaXRMb3c6IDB4MDAwMSxcclxuICAgIGxpbWl0SGlnaDogMHgwMDAyLFxyXG4gICAgY29uc3RhbnQ6IDB4MDAwM1xyXG4gIH07XHJcbiAgcHJpdmF0ZSBvcGNIZGFRdWFsaXR5ID0ge1xyXG4gICAgZXh0cmFEYXRhOiAweDAwMDEwMDAwLFxyXG4gICAgaW50ZXJwb2xhdGVkOiAweDAwMDIwMDAwLFxyXG4gICAgcmF3OiAweDAwMDQwMDAwLFxyXG4gICAgY2FsY3VsYXRlZDogMHgwMDA4MDAwMCxcclxuICAgIG5vQm91bmQ6IDB4MDAxMDAwMDAsXHJcbiAgICBub0RhdGE6IDB4MDAyMDAwMDAsXHJcbiAgICBkYXRhTG9zdDogMHgwMDQwMDAwMCxcclxuICAgIGNvbnZlcnNpb246IDB4MDA4MDAwMDAsXHJcbiAgICBwYXJ0aWFsOiAweDAxMDAwMDAwXHJcbiAgfTtcclxuICBwcml2YXRlIG92ZXJhbGxNZXNzYWdlcyA9IHtcclxuICAgIDB4MDAwMDogJ0JhZCcsXHJcbiAgICAweDAwNDA6ICdVbmNlcnRhaW4nLFxyXG4gICAgMHgwMDgwOiAnTm90IGRlZmluZWQnLFxyXG4gICAgMHgwMEMwOiAnR29vZCdcclxuICB9O1xyXG5cclxuICBwcml2YXRlIGRldGFpbHNNZXNzYWdlcyA9IHtcclxuICAgIC8vIExpbWl0IHN0YXR1c1xyXG4gICAgMHgwMDAwOiAnTm90IGxpbWl0ZWQnLFxyXG4gICAgMHgwMDAxOiAnTG93IGxpbWl0ZWQnLFxyXG4gICAgMHgwMDAyOiAnSGlnaCBsaW1pdGVkJyxcclxuICAgIDB4MDAwMzogJ0NvbnN0YW50JyxcclxuICAgIC8vIEJhZFxyXG4gICAgMHgwMDA0OiAnQ29uZmlnIGVycm9yJyxcclxuICAgIDB4MDAwODogJ05vdCBjb25uZWN0ZWQnLFxyXG4gICAgMHgwMDBjOiAnRGV2aWNlIGZhaWx1cmUnLFxyXG4gICAgMHgwMDEwOiAnU2Vuc29yIGZhaWx1cmUnLFxyXG4gICAgMHgwMDE0OiAnTGFzdCBrbm93bicsXHJcbiAgICAweDAwMTg6ICdDb21tIGZhaWx1cmUnLFxyXG4gICAgMHgwMDFDOiAnT3V0IG9mIHNlcnZpY2UnLFxyXG4gICAgMHgwMDIwOiAnSW5pdGlhbGl6aW5nJyxcclxuICAgIC8vIFVuY2VydGFpblxyXG4gICAgMHgwMDQ0OiAnTGFzdCB1c2FibGUnLFxyXG4gICAgMHgwMDUwOiAnU2Vuc29ycyBub3QgYWNjdXJhdGUnLFxyXG4gICAgMHgwMDU0OiAnRW5naW5lZXJpbmcgdW5pdHMgZXhjZWVkZWQnLFxyXG4gICAgMHgwMDU4OiAnU3ViLU5vcm1hbCcsXHJcbiAgICAvLyBHb29kXHJcbiAgICAweDAwRDg6ICdMb2NhbCBvdmVycmlkZScsXHJcbiAgICAvLyBIZGEgZmxhZ3NcclxuICAgIDB4MDAwMTAwMDA6ICdFeHRyYSBkYXRhJyxcclxuICAgIDB4MDAwMjAwMDA6ICdJbnRlcnBvbGF0ZWQnLFxyXG4gICAgMHgwMDA0MDAwMDogJ1JhdycsXHJcbiAgICAweDAwMDgwMDAwOiAnQ2FsY3VsYXRlZCcsXHJcbiAgICAweDAwMTAwMDAwOiAnTm8gYm91bmQnLFxyXG4gICAgMHgwMDIwMDAwMDogJ05vIGRhdGEnLFxyXG4gICAgMHgwMDQwMDAwMDogJ0RhdGEgbG9zdCcsXHJcbiAgICAweDAwODAwMDAwOiAnQ29udmVyc2lvbicsXHJcbiAgICAweDAxMDAwMDAwOiAnUGFydGlhbCdcclxuICB9O1xyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIGFuIG9iamVjdCByZXByZXNlbnRhdGlvbiBvZiB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGFzT2JqZWN0KHF1YWxpdHlBc0ludDogbnVtYmVyKTogSVF1YWxpdHkge1xyXG4gICAgbGV0IG1hc2s6IG51bWJlcjtcclxuICAgIGNvbnN0IHF1YWxpdHkgPSB7fSBhcyBJUXVhbGl0eTtcclxuXHJcbiAgICBtYXNrID0gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlNYXN0ZXJNYXNrO1xyXG4gICAgcXVhbGl0eS5vdmVyYWxsID0gdGhpcy5vdmVyYWxsTWVzc2FnZXNbbWFza107XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5TWFzaztcclxuICAgIGlmIChtYXNrICYmIHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdKSB7XHJcbiAgICAgIHF1YWxpdHkuZGEgPSB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXTtcclxuICAgIH1cclxuXHJcbiAgICBtYXNrID0gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLmxpbWl0RmllbGQ7XHJcbiAgICBpZiAobWFzayAmJiB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXSkge1xyXG4gICAgICBxdWFsaXR5LmxpbWl0ID0gdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza107XHJcbiAgICB9XHJcblxyXG4gICAgbWFzayA9IHF1YWxpdHlBc0ludCAmIHRoaXMub3BjSGRhUXVhbGl0eU1hc2s7XHJcbiAgICBpZiAobWFzayAmJiB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXSkge1xyXG4gICAgICBxdWFsaXR5LmhkYSA9IHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHF1YWxpdHk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIGEgc3RyaW5nIHdoaWNoIGlzIGEgd3JpdHRlbiByZXByZXNlbnRhdGlvbiBvZiB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGFzU3RyaW5nKHF1YWxpdHlBc0ludDogbnVtYmVyKSB7XHJcbiAgICBsZXQgaGFzRGFRdWFsaXR5ID0gZmFsc2U7XHJcbiAgICBjb25zdCBxT2JqID0gdGhpcy5hc09iamVjdChxdWFsaXR5QXNJbnQpO1xyXG4gICAgbGV0IHFTdHJpbmc6IHN0cmluZztcclxuXHJcbiAgICBxU3RyaW5nID0gcU9iai5vdmVyYWxsO1xyXG4gICAgaWYgKHFPYmouZGEpIHtcclxuICAgICAgcVN0cmluZyA9IHFTdHJpbmcgKyAnOiAnICsgcU9iai5kYTtcclxuICAgICAgaGFzRGFRdWFsaXR5ID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIGlmIChxT2JqLmxpbWl0KSB7XHJcbiAgICAgIHFTdHJpbmcgPSBxU3RyaW5nICtcclxuICAgICAgICAoaGFzRGFRdWFsaXR5ID8gJywgJyA6ICc6ICcpICsgcU9iai5saW1pdDtcclxuICAgICAgaGFzRGFRdWFsaXR5ID0gdHJ1ZTtcclxuICAgIH1cclxuICAgIGlmIChxT2JqLmhkYSkge1xyXG4gICAgICBxU3RyaW5nID0gcVN0cmluZyArXHJcbiAgICAgICAgKGhhc0RhUXVhbGl0eSA/ICcsICcgOiAnOiAnKSArIHFPYmouaGRhO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHFTdHJpbmc7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIHRoZSBPUEMgREEgcXVhbGl0eSBwb3J0aW9uIChsb3dlciAxNiBiaXRzKS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICByZXR1cm4gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlNYXNrO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgT1BDIGxpbWl0IHN0YXR1cyBwb3J0aW9uLiAobm90IGxpbWl0ZWQsIGxvdyBsaW1pdGVkLCBoaWdoIGxpbWl0ZWQgb3IgY29uc3RhbnQpLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5saW1pdEZpZWxkO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgT1BDIERBIE1hc3RlciBxdWFsaXR5IHBvcnRpb24gKGdvb2QsIHVuY2VydGFpbiwgYmFkLCBvciB1bmRlZmluZWQpLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0U2ltcGxlUXVhbGl0eShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICByZXR1cm4gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlNYXN0ZXJNYXNrO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgT1BDIEhEQSBxdWFsaXR5IHBvcnRpb24gKHVwcGVyIDE2IGJpdHMpLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnRcclxuICAgKi9cclxuICBwdWJsaWMgZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICByZXR1cm4gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNIZGFRdWFsaXR5TWFzaztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEEgbWV0aG9kIGZvciBjaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGlzIG9mIGdvb2QgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzR29vZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIChxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MucXVhbGl0eSkgPT09IHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyLmdvb2Q7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBIG1ldGhvZCBmb3IgY2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBpcyBvZiB1bmNlcnRhaW4gcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzVW5jZXJ0YWluKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5xdWFsaXR5KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlNYXN0ZXIudW5jZXJ0YWluO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQSBtZXRob2QgZm9yIGNoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaXMgb2YgYmFkIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0JhZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIChxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MucXVhbGl0eSkgPT09IHRoaXMub3BjRGFRdWFsaXR5TWFzdGVyLmJhZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhQ29uZmlnRXJyb3IocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbmZpZ0Vycm9yKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuY29uZmlnRXJyb3I7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhTm90Q29ubmVjdGVkKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5ub3RDb25uZWN0ZWQpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5ub3RDb25uZWN0ZWQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhRGV2aWNlRmFpbHVyZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuZGV2aWNlRmFpbHVyZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmRldmljZUZhaWx1cmU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhU2Vuc29yRmFpbHVyZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc2Vuc29yRmFpbHVyZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvckZhaWx1cmU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhTGFzdEtub3duKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sYXN0S25vd24pID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sYXN0S25vd247XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhQ29tbUZhaWx1cmUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmNvbW1GYWlsdXJlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuY29tbUZhaWx1cmU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhT3V0T2ZTZXJ2aWNlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5vdXRPZlNlcnZpY2UpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5vdXRPZlNlcnZpY2U7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhSW5pdGlhbGl6aW5nKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5pbml0aWFsaXppbmcpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5pbml0aWFsaXppbmc7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhTGFzdFVzYWJsZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdFVzYWJsZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxhc3RVc2FibGU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhU2Vuc29yTm90QWNjdXJhdGUocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnNlbnNvck5vdEFjY3VyYXRlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc2Vuc29yTm90QWNjdXJhdGU7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhRW5nVW5pdHNFeGNlZWRlZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuZW5nVW5pdHNFeGNlZWRlZCkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmVuZ1VuaXRzRXhjZWVkZWQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhU3ViTm9ybWFsKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zdWJOb3JtYWwpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zdWJOb3JtYWw7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBEQSBxdWFsaXR5IChnb29kLCBiYWQsIHVuY2VydGFpbikgd2l0aCBhcHByb3ByaWF0ZSBzdWJzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0RhTG9jYWxPdmVycmlkZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubG9jYWxPdmVycmlkZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxvY2FsT3ZlcnJpZGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgbGltaXQgc3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNMaW1pdE9rKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRPaykgPT09IHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRPaztcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRMb3cocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdExvdykgPT09IHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRMb3c7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBsaW1pdCBzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0xpbWl0SGlnaChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0SGlnaCkgPT09IHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRIaWdoO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgbGltaXQgc3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNMaW1pdENvbnN0YW50KHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5TGltaXQuY29uc3RhbnQpID09PSB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmNvbnN0YW50O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFFeHRyYURhdGEocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuZXh0cmFEYXRhKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmV4dHJhRGF0YTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhSW50ZXJwb2xhdGVkKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmludGVycG9sYXRlZCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5pbnRlcnBvbGF0ZWQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYVJhdyhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5yYXcpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkucmF3O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFDYWxjdWxhdGVkKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmNhbGN1bGF0ZWQpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuY2FsY3VsYXRlZDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhTm9Cb3VuZChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5ub0JvdW5kKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5Lm5vQm91bmQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYU5vRGF0YShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5ub0RhdGEpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkubm9EYXRhO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFEYXRhTG9zdChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5kYXRhTG9zdCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5kYXRhTG9zdDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhQ29udmVyc2lvbihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5jb252ZXJzaW9uKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmNvbnZlcnNpb247XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYVBhcnRpYWwocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkucGFydGlhbCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5wYXJ0aWFsO1xyXG4gIH1cclxufVxyXG5cclxuIl19