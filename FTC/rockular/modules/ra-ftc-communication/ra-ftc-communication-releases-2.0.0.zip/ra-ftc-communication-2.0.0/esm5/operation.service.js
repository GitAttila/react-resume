import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
var OperationService = (function (_super) {
    tslib_1.__extends(OperationService, _super);
    function OperationService(config, http) {
        return _super.call(this, config.baseUrl + '/api/1/operation/', config, http) || this;
    }
    OperationService.prototype.getOperationData = function (operationReq) {
        return this._sendPostRequest(operationReq);
    };
    OperationService.decorators = [
        { type: Injectable },
    ];
    OperationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return OperationService;
}(BaseService));
export { OperationService };
function OperationService_tsickle_Closure_declarations() {
    OperationService.decorators;
    OperationService.ctorParameters;
}
var OperationRequest = (function () {
    function OperationRequest(target, operation, parameters) {
        this.target = target;
        this.operation = operation;
        this.parameters = parameters;
    }
    return OperationRequest;
}());
export { OperationRequest };
function OperationRequest_tsickle_Closure_declarations() {
    OperationRequest.prototype.target;
    OperationRequest.prototype.operation;
    OperationRequest.prototype.parameters;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlcmF0aW9uLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsib3BlcmF0aW9uLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBQyxNQUFNLEVBQUUsVUFBVSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBQ2pELE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUNoRCxPQUFPLEVBQUMsb0JBQW9CLEVBQXVCLE1BQU0sVUFBVSxDQUFDO0FBRXBFLE9BQU8sRUFBQyxXQUFXLEVBQUMsTUFBTSxnQkFBZ0IsQ0FBQzs7SUFHTCw0Q0FBVztJQUU3QywwQkFBMEMsUUFBOEIsSUFBZ0I7ZUFDcEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0tBQzVEO0lBS00sMkNBQWdCLGFBQUMsWUFBOEI7UUFDbEQsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7O2dCQVhsRCxVQUFVOzs7Z0RBR00sTUFBTSxTQUFDLG9CQUFvQjtnQkFScEMsVUFBVTs7MkJBRGxCO0VBT3NDLFdBQVc7U0FBcEMsZ0JBQWdCOzs7OztBQWM3QixJQUFBO0lBT0ksMEJBQW1CLE1BQWMsRUFBUyxTQUFpQixFQUFTLFVBQW1CO1FBQXBFLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBUyxjQUFTLEdBQVQsU0FBUyxDQUFRO1FBQVMsZUFBVSxHQUFWLFVBQVUsQ0FBUztLQUN0RjsyQkE3Qkw7SUE4QkMsQ0FBQTtBQVRELDRCQVNDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0h0dHBDbGllbnR9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtCYXNlU2VydmljZX0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgT3BlcmF0aW9uU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL29wZXJhdGlvbi8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gT3BlcmF0aW9uIHNlcnZpY2Ugb24gdGhlIHNlcnZlci5cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldE9wZXJhdGlvbkRhdGEob3BlcmF0aW9uUmVxOiBPcGVyYXRpb25SZXF1ZXN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KG9wZXJhdGlvblJlcSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPcGVyYXRpb25SZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogT3BlcmF0aW9uIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSB0YXJnZXQgLSBUaGUgRlFOIG9mIHRhcmdldCBpdGVtXHJcbiAgICAgKiBAcGFyYW0gb3BlcmF0aW9uIC0gVGhlIG5hbWUgb2YgdGhlIG9wZXJhdGlvblxyXG4gICAgICogQHBhcmFtIHBhcmFtZXRlcnMgLSBUaGUgcGFyYW1ldGVycyBmb3IgdGhlIHJlcXVlc3RcclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IocHVibGljIHRhcmdldDogc3RyaW5nLCBwdWJsaWMgb3BlcmF0aW9uOiBzdHJpbmcsIHB1YmxpYyBwYXJhbWV0ZXJzPzogb2JqZWN0KSB7XHJcbiAgICB9XHJcbn1cclxuIl19