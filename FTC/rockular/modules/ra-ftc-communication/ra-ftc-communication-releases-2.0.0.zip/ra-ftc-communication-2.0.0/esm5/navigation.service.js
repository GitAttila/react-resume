import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { BaseService } from './base.service';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import * as _ from 'lodash';
var NavigationService = (function (_super) {
    tslib_1.__extends(NavigationService, _super);
    function NavigationService(config, http) {
        return _super.call(this, config.baseUrl + '/api/1/navigation/', config, http) || this;
    }
    NavigationService.prototype.getNavigationData = function (navigationRequest) {
        var request = navigationRequest;
        if (_.isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
            if (_.isNil(request.hideRules) && _.isNil(request.skipRules)) {
                request = _.clone(navigationRequest);
                request.skipRules = _.clone(this.config.defaultNavigationRules.skipRules);
                request.hideRules = _.clone(this.config.defaultNavigationRules.hideRules);
            }
        }
        return this._sendPostRequest(request);
    };
    NavigationService.decorators = [
        { type: Injectable },
    ];
    NavigationService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return NavigationService;
}(BaseService));
export { NavigationService };
function NavigationService_tsickle_Closure_declarations() {
    NavigationService.decorators;
    NavigationService.ctorParameters;
}
var NavigationRequest = (function () {
    function NavigationRequest(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
        this.fqn = fqn;
        this.propNames = propNames;
        this.includeParents = includeParents;
        this.navHandlerFqn = navHandlerFqn;
        this.hideRules = hideRules;
        this.skipRules = skipRules;
    }
    return NavigationRequest;
}());
export { NavigationRequest };
function NavigationRequest_tsickle_Closure_declarations() {
    NavigationRequest.prototype.fqn;
    NavigationRequest.prototype.propNames;
    NavigationRequest.prototype.includeParents;
    NavigationRequest.prototype.navHandlerFqn;
    NavigationRequest.prototype.hideRules;
    NavigationRequest.prototype.skipRules;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmF2aWdhdGlvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbIm5hdmlnYXRpb24uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUVsRCxPQUFPLEVBQUUsb0JBQW9CLEVBQXdCLE1BQU0sVUFBVSxDQUFDO0FBQ3RFLE9BQU8sS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDOztJQUlXLDZDQUFXO0lBRTlDLDJCQUEwQyxRQUE4QixJQUFnQjtlQUNwRixrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLG9CQUFvQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUM7S0FDN0Q7SUFLRCw2Q0FBaUIsR0FBakIsVUFBa0IsaUJBQW9DO1FBQ2xELElBQUksT0FBTyxHQUFHLGlCQUFpQixDQUFDO1FBQ2hDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLElBQUksaUJBQWlCLENBQUMsYUFBYSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckYsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO2dCQUNyQyxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDMUUsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDN0U7U0FDSjtRQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDekM7O2dCQXBCSixVQUFVOzs7Z0RBR00sTUFBTSxTQUFDLG9CQUFvQjtnQkFUbkMsVUFBVTs7NEJBRm5CO0VBU3VDLFdBQVc7U0FBckMsaUJBQWlCOzs7OztBQXNCOUIsSUFBQTtJQVdJLDJCQUNXLEtBQW9CLFNBQW9CLEVBQVMsY0FBd0IsRUFDekUsZUFBK0IsU0FBMkIsRUFBUyxTQUEyQjtRQUQ5RixRQUFHLEdBQUgsR0FBRztRQUFpQixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQVMsbUJBQWMsR0FBZCxjQUFjLENBQVU7UUFDekUsa0JBQWEsR0FBYixhQUFhO1FBQWtCLGNBQVMsR0FBVCxTQUFTLENBQWtCO1FBQVMsY0FBUyxHQUFULFNBQVMsQ0FBa0I7S0FDeEc7NEJBN0NMO0lBK0NDLENBQUE7QUFoQkQsNkJBZ0JDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uUnVsZXMgfSBmcm9tICcuL3NoYXJlZCc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0aW9uU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL25hdmlnYXRpb24vJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ha2VzIGEgcmVxdWVzdCB0byBKU09OIE5hdmlnYXRpb24gc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAgICovXHJcbiAgICBnZXROYXZpZ2F0aW9uRGF0YShuYXZpZ2F0aW9uUmVxdWVzdDogTmF2aWdhdGlvblJlcXVlc3QpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIGxldCByZXF1ZXN0ID0gbmF2aWdhdGlvblJlcXVlc3Q7XHJcbiAgICAgICAgaWYgKF8uaXNOaWwobmF2aWdhdGlvblJlcXVlc3QubmF2SGFuZGxlckZxbikgfHwgbmF2aWdhdGlvblJlcXVlc3QubmF2SGFuZGxlckZxbiA9PT0gJycpIHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwocmVxdWVzdC5oaWRlUnVsZXMpICYmIF8uaXNOaWwocmVxdWVzdC5za2lwUnVsZXMpKSB7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0ID0gXy5jbG9uZShuYXZpZ2F0aW9uUmVxdWVzdCk7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0LnNraXBSdWxlcyA9IF8uY2xvbmUodGhpcy5jb25maWcuZGVmYXVsdE5hdmlnYXRpb25SdWxlcy5za2lwUnVsZXMpO1xyXG4gICAgICAgICAgICAgICAgcmVxdWVzdC5oaWRlUnVsZXMgPSBfLmNsb25lKHRoaXMuY29uZmlnLmRlZmF1bHROYXZpZ2F0aW9uUnVsZXMuaGlkZVJ1bGVzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTmF2aWdhdGlvblJlcXVlc3Qge1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogTmF2aWdhdGlvbiByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFuIC0gVGhlIEZRTiBvZiBOYXZpZ2F0aW9uUmVxdWVzdFxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lcyAtIFRoZSBQcm9wZXJ0eSBOYW1lc1xyXG4gICAgICogQHBhcmFtIGluY2x1ZGVQYXJlbnRzIC0gV2hldGhlciB0byBpbmNsdWRlIHBhcmVudHMgaW4gcmVzdWx0c1xyXG4gICAgICogQHBhcmFtIG5hdkhhbmRsZXJGcW4gLSBUaGUgRlFOIG9mIE5hdmlnYXRpb24gSGFuZGxlciBJdGVtXHJcbiAgICAgKiBAcGFyYW0gaGlkZVJ1bGVzIC0gVGhlIEhpZGUgUnVsZXMgZm9yIE5hdmlnYXRpb25cclxuICAgICAqIEBwYXJhbSBza2lwUnVsZXMgLSBUaGUgU2tpcCBSdWxlcyBmb3IgTmF2aWdhdGlvblxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgZnFuOiBzdHJpbmcsIHB1YmxpYyBwcm9wTmFtZXM/OiBzdHJpbmdbXSwgcHVibGljIGluY2x1ZGVQYXJlbnRzPzogYm9vbGVhbixcclxuICAgICAgICBwdWJsaWMgbmF2SGFuZGxlckZxbj86IHN0cmluZywgcHVibGljIGhpZGVSdWxlcz86IE5hdmlnYXRpb25SdWxlcywgcHVibGljIHNraXBSdWxlcz86IE5hdmlnYXRpb25SdWxlcykge1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=