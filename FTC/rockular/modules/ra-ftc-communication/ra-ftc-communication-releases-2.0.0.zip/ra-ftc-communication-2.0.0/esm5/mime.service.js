import * as tslib_1 from "tslib";
import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
var MimeService = (function (_super) {
    tslib_1.__extends(MimeService, _super);
    function MimeService(config, http) {
        return _super.call(this, config.baseUrl + '/api/1/mime/', config, http) || this;
    }
    MimeService.prototype.getMimeItemPath = function (fqn) {
        return this.endpointUrl.concat(fqn);
    };
    MimeService.decorators = [
        { type: Injectable },
    ];
    MimeService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
        { type: HttpClient, },
    ]; };
    return MimeService;
}(BaseService));
export { MimeService };
function MimeService_tsickle_Closure_declarations() {
    MimeService.decorators;
    MimeService.ctorParameters;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWltZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbIm1pbWUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxvQkFBb0IsRUFBd0IsTUFBTSxVQUFVLENBQUM7QUFDdEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDOztJQUdaLHVDQUFXO0lBRXhDLHFCQUEwQyxRQUE4QixJQUFnQjtlQUNwRixrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDO0tBQ3ZEO0lBRUQscUNBQWUsR0FBZixVQUFnQixHQUFXO1FBQ3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUN2Qzs7Z0JBVEosVUFBVTs7O2dEQUdNLE1BQU0sU0FBQyxvQkFBb0I7Z0JBUG5DLFVBQVU7O3NCQURuQjtFQU1pQyxXQUFXO1NBQS9CLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE1pbWVTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbWltZS8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIGdldE1pbWVJdGVtUGF0aChmcW46IHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmVuZHBvaW50VXJsLmNvbmNhdChmcW4pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==