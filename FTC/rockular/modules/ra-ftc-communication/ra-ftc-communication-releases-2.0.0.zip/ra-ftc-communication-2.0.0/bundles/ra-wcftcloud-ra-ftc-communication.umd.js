(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('lodash'), require('@angular/common/http'), require('rxjs'), require('rxjs/operators'), require('moment-timezone'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@ra-wcftcloud/ra-ftc-communication', ['exports', '@angular/core', 'lodash', '@angular/common/http', 'rxjs', 'rxjs/operators', 'moment-timezone', '@angular/common'], factory) :
    (factory((global['ra-wcftcloud'] = global['ra-wcftcloud'] || {}, global['ra-wcftcloud']['ra-ftc-communication'] = {}),global.ng.core,null,global.ng.common.http,global.rxjs,global.rxjs.operators,null,global.ng.common));
}(this, (function (exports,core,_,http,rxjs,operators,moment,common) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b)
            if (b.hasOwnProperty(p))
                d[p] = b[p]; };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var DEFAULT_REPEATED_DATA_INTERVAL = 5;
    var COMMUNICATION_CONFIG = new core.InjectionToken('COMMUNICATION_CONFIGURATION');

    var BaseService = (function () {
        function BaseService(endpointUrl, config, http$$1) {
            this.endpointUrl = endpointUrl;
            this.config = config;
            this.http = http$$1;
        }
        BaseService.prototype._sendPostRequest = function (request) {
            return this.http.post(this.endpointUrl, request, _.extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
        };
        BaseService.prototype._sendGetRequest = function () {
            return this.http.get(this.endpointUrl, _.extend({ headers: { 'content-type': 'application/x-www-form-urlencoded' } }, this.config.httpOptions));
        };
        return BaseService;
    }());

    var InstanceService = (function (_super) {
        __extends(InstanceService, _super);
        function InstanceService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/instance/', config, http$$1) || this;
        }
        InstanceService.prototype.getInstances = function (instanceRequest) {
            return this._sendPostRequest(instanceRequest);
        };
        InstanceService.decorators = [
            { type: core.Injectable },
        ];
        InstanceService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return InstanceService;
    }(BaseService));
    var InstanceRequest = (function () {
        function InstanceRequest(camelCasePropertyNames) {
            if (!_.isNil(camelCasePropertyNames)) {
                this.camelCasePropertyNames = camelCasePropertyNames;
            }
            else {
                this.camelCasePropertyNames = true;
            }
        }
        InstanceRequest.prototype.addResponseFormat = function (instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts) {
            instanceFqnItem.responseFormat = {};
            if (includeAccessControl) {
                instanceFqnItem.responseFormat.includeAcl = includeAccessControl;
            }
            if (!_.isNil(retrievalDepth) && retrievalDepth > 0) {
                instanceFqnItem.responseFormat.depth = retrievalDepth;
            }
            if (includeShortcuts) {
                instanceFqnItem.responseFormat.includeShortcuts = includeShortcuts;
            }
        };
        InstanceRequest.prototype.addItemFqn = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
            var instanceFqnItem = {
                fqn: fqn
            };
            this.addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
            if (!this.fqns) {
                this.fqns = [];
            }
            this.fqns.push(instanceFqnItem);
            return this;
        };
        InstanceRequest.prototype.addItemFqnExcludeVolatile = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
            var instanceFqnItem = {
                fqn: fqn,
                excludeVolatileProperties: true
            };
            this.addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
            if (!this.fqns) {
                this.fqns = [];
            }
            this.fqns.push(instanceFqnItem);
            return this;
        };
        InstanceRequest.prototype.addPropertyFqn = function (fqn, includeAccessControl, retrievalDepth, includeShortcuts, pageSize, page) {
            var instanceFqnPropertyItem = {
                propertyFqn: fqn,
                excludeVolatileProperties: true
            };
            this.addResponseFormat(instanceFqnPropertyItem, includeAccessControl, retrievalDepth, includeShortcuts);
            if (!_.isNil(pageSize)) {
                instanceFqnPropertyItem.pageSize = pageSize;
            }
            if (!_.isNil(page)) {
                instanceFqnPropertyItem.page = page;
            }
            if (!this.fqns) {
                this.fqns = [];
            }
            this.fqns.push(instanceFqnPropertyItem);
            return this;
        };
        InstanceRequest.prototype.addQuery = function (queryExpression, includeAccessControl, retrievalDepth, includeShortcuts) {
            var instanceQueryItem = {
                query: queryExpression
            };
            this.addResponseFormat(instanceQueryItem, includeAccessControl, retrievalDepth, includeShortcuts);
            if (!this.queries) {
                this.queries = [];
            }
            this.queries.push(instanceQueryItem);
            return this;
        };
        return InstanceRequest;
    }());

    var LiveRequest = (function () {
        function LiveRequest(fqns) {
            this.fqns = fqns;
            this.fqns = _.clone(fqns);
        }
        LiveRequest.prototype.addFqn = function (fqn) {
            this.fqns.push(fqn);
        };
        LiveRequest.prototype.removeFqn = function (fqn) {
            var index = _.indexOf(this.fqns, fqn);
            if (index > 0) {
                this.fqns.splice(index, 1);
            }
        };
        return LiveRequest;
    }());
    var LiveDataService = (function (_super) {
        __extends(LiveDataService, _super);
        function LiveDataService(config, http$$1) {
            var _this = _super.call(this, config.baseUrl + '/api/1/live/', config, http$$1) || this;
            _this._fqns = new Map();
            return _this;
        }
        LiveDataService.prototype.getOnce = function (request) {
            return this._sendPostRequest(request).pipe(operators.map(function (response) {
                var ret = [];
                _.each(response.fqnsResults, function (oneResult) {
                    ret.push({
                        name: oneResult.name,
                        fqn: oneResult.fqn,
                        valueType: oneResult.valueType,
                        engineeringUnit: oneResult.engineeringUnit,
                        v: oneResult.value.v,
                        q: oneResult.value.q,
                        t: oneResult.value.t
                    });
                });
                return ret;
            }));
        };
        LiveDataService.prototype._getInnerRepeatedObservable = function () {
            return this._sendPostRequest({ fqns: Array.from(this._fqns.keys()) })
                .pipe(operators.map(function (response) {
                var ret = [];
                _.each(response.fqnsResults, function (oneResult) {
                    ret.push({
                        name: oneResult.name,
                        fqn: oneResult.fqn,
                        valueType: oneResult.valueType,
                        engineeringUnit: oneResult.engineeringUnit,
                        v: oneResult.value.v,
                        q: oneResult.value.q,
                        t: oneResult.value.t
                    });
                });
                return ret;
            }));
        };
        LiveDataService.prototype._initializeRepeatedData = function () {
            var _this = this;
            if (!this._repeatedDataSubject) {
                this._repeatedDataSubject = new rxjs.Subject();
            }
            if (!this._repeatedDataObservable || this._reinitializeRepeatedObservable) {
                var repeatedInterval_1 = this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
                repeatedInterval_1 = repeatedInterval_1 * 1000;
                this._repeatedDataObservable = this._getInnerRepeatedObservable();
                this._repeatedDataSubscription = this._repeatedDataObservable.pipe(operators.expand(function () { return rxjs.timer(repeatedInterval_1).pipe(operators.concatMap(function () { return _this._getInnerRepeatedObservable(); })); })).subscribe(function (response) {
                    _this._repeatedDataSubject.next(response);
                }, function (err) {
                    _this._repeatedDataSubscription.unsubscribe();
                    _this._reinitializeRepeatedObservable = true;
                    _this._repeatedDataSubject.error(err);
                }, function () {
                    _this._reinitializeRepeatedObservable = true;
                    _this._repeatedDataSubject.complete();
                });
                this._reinitializeRepeatedObservable = false;
            }
            return this._repeatedDataObservable;
        };
        LiveDataService.prototype.getRepeatedly = function (request) {
            var _this = this;
            return new rxjs.Observable(function (observer) {
                _.each(request.fqns, function (fqn) {
                    var newVal = 0;
                    if (_this._fqns.has(fqn)) {
                        newVal = _this._fqns.get(fqn);
                    }
                    _this._fqns.set(fqn, ++newVal);
                });
                _this._initializeRepeatedData();
                var subscription = _this._repeatedDataSubject.asObservable().pipe(operators.map(function (currentResponse) {
                    return _.filter(currentResponse, function (o) {
                        return _.indexOf(request.fqns, o.fqn) > -1;
                    });
                })).subscribe(function (response) {
                    observer.next(response);
                }, function (error) {
                    observer.error(error);
                }, function () {
                    observer.complete();
                });
                return function () {
                    _.each(request.fqns, function (fqn) {
                        var newVal = 1;
                        if (_this._fqns.has(fqn)) {
                            newVal = _this._fqns.get(fqn);
                        }
                        if (newVal === 1) {
                            _this._fqns.delete(fqn);
                        }
                        else {
                            _this._fqns.set(fqn, --newVal);
                        }
                    });
                    subscription.unsubscribe();
                    observer.unsubscribe();
                    if (_this._fqns.size === 0) {
                        if (_this._repeatedDataSubscription) {
                            _this._repeatedDataSubscription.unsubscribe();
                        }
                        _this._repeatedDataSubject.complete();
                        delete _this._repeatedDataSubject;
                        _this._reinitializeRepeatedObservable = true;
                    }
                };
            });
        };
        LiveDataService.decorators = [
            { type: core.Injectable },
        ];
        LiveDataService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return LiveDataService;
    }(BaseService));

    var OpcQualityService = (function () {
        function OpcQualityService() {
            this.opcDaQualityMask = 0xfffC;
            this.opcDaQualityMasterMask = 0x00C0;
            this.opcHdaQualityMask = 0xffff0000;
            this.opcDaQualityFieldMasks = {
                limitField: 0x0003,
                subStatusField: 0x003C,
                quality: 0x00C0
            };
            this.opcDaQualityMaster = {
                bad: 0x0000,
                uncertain: 0x0040,
                notDefined: 0x0080,
                good: 0x00C0
            };
            this.opcDaQualityStatus = {
                bad: 0x0000,
                configError: 0x0004,
                notConnected: 0x0008,
                deviceFailure: 0x000c,
                sensorFailure: 0x0010,
                lastKnown: 0x0014,
                commFailure: 0x0018,
                outOfService: 0x001c,
                initializing: 0x0020,
                uncertain: 0x0040,
                lastUsable: 0x0044,
                sensorNotAccurate: 0x0050,
                engUnitsExceeded: 0x0054,
                subNormal: 0x0058,
                good: 0x00C0,
                localOverride: 0x00D8
            };
            this.opcDaQualityLimit = {
                limitOk: 0x0000,
                limitLow: 0x0001,
                limitHigh: 0x0002,
                constant: 0x0003
            };
            this.opcHdaQuality = {
                extraData: 0x00010000,
                interpolated: 0x00020000,
                raw: 0x00040000,
                calculated: 0x00080000,
                noBound: 0x00100000,
                noData: 0x00200000,
                dataLost: 0x00400000,
                conversion: 0x00800000,
                partial: 0x01000000
            };
            this.overallMessages = {
                0x0000: 'Bad',
                0x0040: 'Uncertain',
                0x0080: 'Not defined',
                0x00C0: 'Good'
            };
            this.detailsMessages = {
                0x0000: 'Not limited',
                0x0001: 'Low limited',
                0x0002: 'High limited',
                0x0003: 'Constant',
                0x0004: 'Config error',
                0x0008: 'Not connected',
                0x000c: 'Device failure',
                0x0010: 'Sensor failure',
                0x0014: 'Last known',
                0x0018: 'Comm failure',
                0x001C: 'Out of service',
                0x0020: 'Initializing',
                0x0044: 'Last usable',
                0x0050: 'Sensors not accurate',
                0x0054: 'Engineering units exceeded',
                0x0058: 'Sub-Normal',
                0x00D8: 'Local override',
                0x00010000: 'Extra data',
                0x00020000: 'Interpolated',
                0x00040000: 'Raw',
                0x00080000: 'Calculated',
                0x00100000: 'No bound',
                0x00200000: 'No data',
                0x00400000: 'Data lost',
                0x00800000: 'Conversion',
                0x01000000: 'Partial'
            };
        }
        OpcQualityService.prototype.asObject = function (qualityAsInt) {
            var mask;
            var quality = ({});
            mask = qualityAsInt & this.opcDaQualityMasterMask;
            quality.overall = this.overallMessages[mask];
            mask = qualityAsInt & this.opcDaQualityMask;
            if (mask && this.detailsMessages[mask]) {
                quality.da = this.detailsMessages[mask];
            }
            mask = qualityAsInt & this.opcDaQualityFieldMasks.limitField;
            if (mask && this.detailsMessages[mask]) {
                quality.limit = this.detailsMessages[mask];
            }
            mask = qualityAsInt & this.opcHdaQualityMask;
            if (mask && this.detailsMessages[mask]) {
                quality.hda = this.detailsMessages[mask];
            }
            return quality;
        };
        OpcQualityService.prototype.asString = function (qualityAsInt) {
            var hasDaQuality = false;
            var qObj = this.asObject(qualityAsInt);
            var qString;
            qString = qObj.overall;
            if (qObj.da) {
                qString = qString + ': ' + qObj.da;
                hasDaQuality = true;
            }
            if (qObj.limit) {
                qString = qString +
                    (hasDaQuality ? ', ' : ': ') + qObj.limit;
                hasDaQuality = true;
            }
            if (qObj.hda) {
                qString = qString +
                    (hasDaQuality ? ', ' : ': ') + qObj.hda;
            }
            return qString;
        };
        OpcQualityService.prototype.getOpcDaQuality = function (qualityAsInt) {
            return qualityAsInt & this.opcDaQualityMask;
        };
        OpcQualityService.prototype.getOpcLimitStatus = function (qualityAsInt) {
            return qualityAsInt & this.opcDaQualityFieldMasks.limitField;
        };
        OpcQualityService.prototype.getSimpleQuality = function (qualityAsInt) {
            return qualityAsInt & this.opcDaQualityMasterMask;
        };
        OpcQualityService.prototype.getOpcHdaQuality = function (qualityAsInt) {
            return qualityAsInt & this.opcHdaQualityMask;
        };
        OpcQualityService.prototype.isGood = function (qualityAsInt) {
            return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.good;
        };
        OpcQualityService.prototype.isUncertain = function (qualityAsInt) {
            return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.uncertain;
        };
        OpcQualityService.prototype.isBad = function (qualityAsInt) {
            return (qualityAsInt & this.opcDaQualityFieldMasks.quality) === this.opcDaQualityMaster.bad;
        };
        OpcQualityService.prototype.isDaConfigError = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.configError) === this.opcDaQualityStatus.configError;
        };
        OpcQualityService.prototype.isDaNotConnected = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.notConnected) === this.opcDaQualityStatus.notConnected;
        };
        OpcQualityService.prototype.isDaDeviceFailure = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.deviceFailure) === this.opcDaQualityStatus.deviceFailure;
        };
        OpcQualityService.prototype.isDaSensorFailure = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.sensorFailure) === this.opcDaQualityStatus.sensorFailure;
        };
        OpcQualityService.prototype.isDaLastKnown = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.lastKnown) === this.opcDaQualityStatus.lastKnown;
        };
        OpcQualityService.prototype.isDaCommFailure = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.commFailure) === this.opcDaQualityStatus.commFailure;
        };
        OpcQualityService.prototype.isDaOutOfService = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.outOfService) === this.opcDaQualityStatus.outOfService;
        };
        OpcQualityService.prototype.isDaInitializing = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.initializing) === this.opcDaQualityStatus.initializing;
        };
        OpcQualityService.prototype.isDaLastUsable = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.lastUsable) === this.opcDaQualityStatus.lastUsable;
        };
        OpcQualityService.prototype.isDaSensorNotAccurate = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.sensorNotAccurate) === this.opcDaQualityStatus.sensorNotAccurate;
        };
        OpcQualityService.prototype.isDaEngUnitsExceeded = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.engUnitsExceeded) === this.opcDaQualityStatus.engUnitsExceeded;
        };
        OpcQualityService.prototype.isDaSubNormal = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.subNormal) === this.opcDaQualityStatus.subNormal;
        };
        OpcQualityService.prototype.isDaLocalOverride = function (qualityAsInt) {
            return (this.getOpcDaQuality(qualityAsInt) &
                this.opcDaQualityStatus.localOverride) === this.opcDaQualityStatus.localOverride;
        };
        OpcQualityService.prototype.isLimitOk = function (qualityAsInt) {
            return (this.getOpcLimitStatus(qualityAsInt) &
                this.opcDaQualityLimit.limitOk) === this.opcDaQualityLimit.limitOk;
        };
        OpcQualityService.prototype.isLimitLow = function (qualityAsInt) {
            return (this.getOpcLimitStatus(qualityAsInt) &
                this.opcDaQualityLimit.limitLow) === this.opcDaQualityLimit.limitLow;
        };
        OpcQualityService.prototype.isLimitHigh = function (qualityAsInt) {
            return (this.getOpcLimitStatus(qualityAsInt) &
                this.opcDaQualityLimit.limitHigh) === this.opcDaQualityLimit.limitHigh;
        };
        OpcQualityService.prototype.isLimitConstant = function (qualityAsInt) {
            return (this.getOpcLimitStatus(qualityAsInt) &
                this.opcDaQualityLimit.constant) === this.opcDaQualityLimit.constant;
        };
        OpcQualityService.prototype.isHdaExtraData = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.extraData) === this.opcHdaQuality.extraData;
        };
        OpcQualityService.prototype.isHdaInterpolated = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.interpolated) === this.opcHdaQuality.interpolated;
        };
        OpcQualityService.prototype.isHdaRaw = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.raw) === this.opcHdaQuality.raw;
        };
        OpcQualityService.prototype.isHdaCalculated = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.calculated) === this.opcHdaQuality.calculated;
        };
        OpcQualityService.prototype.isHdaNoBound = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.noBound) === this.opcHdaQuality.noBound;
        };
        OpcQualityService.prototype.isHdaNoData = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.noData) === this.opcHdaQuality.noData;
        };
        OpcQualityService.prototype.isHdaDataLost = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.dataLost) === this.opcHdaQuality.dataLost;
        };
        OpcQualityService.prototype.isHdaConversion = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.conversion) === this.opcHdaQuality.conversion;
        };
        OpcQualityService.prototype.isHdaPartial = function (qualityAsInt) {
            return (this.getOpcHdaQuality(qualityAsInt) &
                this.opcHdaQuality.partial) === this.opcHdaQuality.partial;
        };
        OpcQualityService.decorators = [
            { type: core.Injectable },
        ];
        return OpcQualityService;
    }());

    var MomentHelperService = (function () {
        function MomentHelperService() {
        }
        MomentHelperService.applyTimezone = function (datetime, timezone) {
            var mDate = moment.utc(datetime);
            mDate.tz(timezone);
            return mDate.format(this.MOMENT_DATETIME_FORMAT_TZ_FULL);
        };
        MomentHelperService.getAllTimezones = function () {
            return moment.tz.names();
        };
        MomentHelperService.isValidTimezone = function (timezone) {
            return timezone && moment.tz.zone(timezone);
        };
        MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL = 'YYYY-MM-DDTHH:mm:ss.SSS[Z]';
        MomentHelperService.MOMENT_DATETIME_FORMAT_TZ_FULL = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
        MomentHelperService.decorators = [
            { type: core.Injectable },
        ];
        return MomentHelperService;
    }());

    var TimeseriesRequestQuality = {
        includeGood: 1,
        includeBad: 2,
        includeUncertain: 4,
        includeAll: 7,
    };
    TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = "includeGood";
    TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = "includeBad";
    TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = "includeUncertain";
    TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = "includeAll";
    var TimeseriesRepeatedDataFormat = {
        wholeInterval: 'wholeInterval',
        increments: 'increments',
    };
    var SamplingTypes = {
        Interpolative: 'Interpolative',
        SampleAndHold: 'SampleAndHold',
        Linear: 'Linear',
        Total: 'Total',
        Sum: 'Sum',
        Average: 'Average',
        TimeAverage: 'TimeAverage',
        Count: 'Count',
        StandardDeviation: 'StandardDeviation',
        MinimumActualTime: 'MinimumActualTime',
        Maximum: 'Maximum',
        Start: 'Start',
        End: 'End',
        Delta: 'Delta',
        Variance: 'Variance',
        Range: 'Range',
        DurationGood: 'DurationGood',
        DurationBad: 'DurationBad',
        PercentGood: 'PercentGood',
        PercentBad: 'PercentBad',
        WorstQuality: 'WorstQuality',
        TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
        TotalSampleAndHold: 'TotalSampleAndHold',
        MinSampleAndHold: 'MinSampleAndHold',
        MaxSampleAndHold: 'MaxSampleAndHold',
        CumulativeTotal: 'CumulativeTotal',
    };
    var TimeseriesRequest = (function () {
        function TimeseriesRequest(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
            this.fqns = fqns;
            this.timePeriod = timePeriod;
            this.samplingDefinition = samplingDefinition;
            this.timeDeadBand = timeDeadBand;
            this.valueDeadBand = valueDeadBand;
            this.qualityFilter = qualityFilter;
            this.setFqns(fqns);
            this.setTimePeriod(timePeriod);
            this.setSamplingDefinition(samplingDefinition);
        }
        TimeseriesRequest.prototype.addFqn = function (fqn) {
            this.fqns.push(fqn);
        };
        TimeseriesRequest.prototype.removeFqn = function (fqn) {
            var index = _.indexOf(this.fqns, fqn);
            if (index > 0) {
                this.fqns.splice(index, 1);
            }
        };
        TimeseriesRequest.prototype.setFqns = function (fqns) {
            this.fqns = _.clone(fqns);
        };
        TimeseriesRequest.prototype.getFqns = function () {
            return _.clone(this.fqns);
        };
        TimeseriesRequest.prototype.setTimePeriod = function (timePeriod) {
            this.timePeriod = _.clone(timePeriod);
        };
        TimeseriesRequest.prototype.getTimePeriod = function () {
            return _.clone(this.timePeriod);
        };
        TimeseriesRequest.prototype.setSamplingDefinition = function (samplingDefinition) {
            this.samplingDefinition = _.clone(samplingDefinition);
        };
        TimeseriesRequest.prototype.getSamplingDefinition = function () {
            return _.clone(this.samplingDefinition);
        };
        TimeseriesRequest.prototype.setTimeDeadBand = function (timeDeadBand) {
            this.timeDeadBand = timeDeadBand;
        };
        TimeseriesRequest.prototype.getTimeDeadband = function () {
            return this.timeDeadBand;
        };
        TimeseriesRequest.prototype.setValueDeadBand = function (valueDeadBand) {
            this.valueDeadBand = valueDeadBand;
        };
        TimeseriesRequest.prototype.getValueDeadBand = function () {
            return this.valueDeadBand;
        };
        TimeseriesRequest.prototype.setQualityFilter = function (qualityFilter) {
            this.qualityFilter = qualityFilter;
        };
        TimeseriesRequest.prototype.getQualityFilter = function () {
            return this.qualityFilter;
        };
        return TimeseriesRequest;
    }());
    var TimeseriesDataService = (function (_super) {
        __extends(TimeseriesDataService, _super);
        function TimeseriesDataService(config, http$$1, opcQualitySvc) {
            var _this = _super.call(this, config.baseUrl + '/api/1/timeseries/', config, http$$1) || this;
            _this.opcQualitySvc = opcQualitySvc;
            return _this;
        }
        TimeseriesDataService.prototype.getOnce = function (request, timezone) {
            var _this = this;
            var tz;
            if (MomentHelperService.isValidTimezone(timezone)) {
                tz = timezone;
            }
            return this._sendPostRequest(request).pipe(operators.map(function (response) {
                return _this._transformTimeseriesInternalResponse(response, tz);
            }));
        };
        TimeseriesDataService.prototype._getErrorObservable = function (errorString) {
            return new rxjs.Observable(function (observer) {
                observer.error(errorString);
                return function () {
                    observer.unsubscribe();
                };
            });
        };
        TimeseriesDataService.prototype._applyTimezoneToVqtData = function (vqtData, timezone) {
            _.each(vqtData, function (vqt) {
                vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
            });
            return vqtData;
        };
        TimeseriesDataService.prototype._getRequestDataNextStartValues = function (response, nextStartMoment) {
            var beforeNextRequestValues = new Map();
            var last;
            _.each(response.fqnsResults, function (el) {
                if (!_.isNil(el) && el.values.length) {
                    last = _.last(el.values);
                    beforeNextRequestValues.set(el.fqn, last);
                }
            });
            return beforeNextRequestValues;
        };
        TimeseriesDataService.prototype._getStartForNextRequest = function (response, originalDuration, repeatedInterval) {
            var opcQualitySvc = this.opcQualitySvc;
            function getLastTimeToUse(fqnResult) {
                var timeString = _.first(fqnResult.values).t;
                for (var i = fqnResult.values.length - 1; i >= 0; i--) {
                    var val = fqnResult.values[i];
                    if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                        return val.t;
                    }
                }
                return timeString;
            }
            var result;
            var currentTimeMinusDuration = moment.utc().subtract(Math.abs(originalDuration), 'seconds');
            _.each(response.fqnsResults, function (fqnResult) {
                if (_.isNil(fqnResult) || fqnResult.values.length === 0) {
                    return;
                }
                var lastValue = moment.utc(getLastTimeToUse(fqnResult));
                if (_.isNil(result) || result.isAfter(lastValue)) {
                    result = lastValue.clone();
                }
            });
            if (_.isNil(result)) {
                result = moment.utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
            }
            if (currentTimeMinusDuration.isAfter(result)) {
                result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
            }
            return result;
        };
        TimeseriesDataService.prototype._filterStartResponseData = function (response, previousResponseLastData, requestTimePeriod) {
            var firstVqt;
            var firstVqtMoment;
            var secondVqt;
            var opcQualitySvc = this.opcQualitySvc;
            var cutBeforeDate = moment.utc(response.timePeriod.end);
            cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
            _.each(response.fqnsResults, function (el) {
                if (!_.isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                    var onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                    var onePreviousResponseLastDataMoment = moment.utc(onePreviousResponseLastData.t);
                    firstVqt = el.values.slice(0, 1)[0];
                    firstVqtMoment = moment.utc(firstVqt.t);
                    if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                        secondVqt = el.values.slice(1, 2)[0];
                        if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                            firstVqtMoment < moment.utc(secondVqt.t) &&
                            opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                            opcQualitySvc.isGood(secondVqt.q)) {
                            el.values.splice(0, 1);
                        }
                    }
                }
            });
        };
        TimeseriesDataService.prototype._transformTimeseriesInternalResponse = function (response, timezone) {
            var _this = this;
            var applyTimezone = false;
            if (!_.isNil(timezone)) {
                applyTimezone = true;
                response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
                response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
            }
            var ret = {
                timePeriod: response.timePeriod,
                results: []
            };
            _.each(response.fqnsResults, function (oneResult) {
                if (_.isNil(oneResult)) {
                    return;
                }
                if (applyTimezone) {
                    _this._applyTimezoneToVqtData(oneResult.values, timezone);
                }
                ret.results.push({
                    name: oneResult.name,
                    fqn: oneResult.fqn,
                    valueType: oneResult.valueType,
                    engineeringUnit: oneResult.engineeringUnit,
                    values: oneResult.values
                });
            });
            return ret;
        };
        TimeseriesDataService.prototype._filterDuplicateDataAndCut = function (values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
            var ids = [];
            var objectToAddToArray;
            var firstIsAfter = false;
            function arrayFilter(o) {
                var currentItemMoment = moment.utc(o.t);
                if (cutBeforeMoment.isAfter(currentItemMoment)) {
                    if (!firstIsAfter) {
                        objectToAddToArray = _.clone(o);
                        var cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                        if (!_.isNil(timezone)) {
                            objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                        }
                        else {
                            objectToAddToArray.t = cutBeforeMomentUTCFormat;
                        }
                        firstIsAfter = true;
                    }
                    return false;
                }
                if (ids.indexOf(o.t) !== -1) {
                    return false;
                }
                ids.push(o.t);
                return true;
            }
            var filteredArray = values.reverse().filter(arrayFilter);
            if (!doNotShiftFirstValue && firstIsAfter) {
                var lastValue = _.last(filteredArray);
                if (!lastValue || !moment.utc(lastValue.t).isSame(moment.utc(objectToAddToArray.t))) {
                    filteredArray.push(objectToAddToArray);
                }
            }
            return filteredArray.reverse();
        };
        TimeseriesDataService.prototype._getRepeatedlyWhole = function (request, customInterval, timezone) {
            var _this = this;
            var lastMergedResponse;
            var tz = timezone;
            var repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
                .pipe(operators.map(function (response) {
                if (!_.isNil(lastMergedResponse)) {
                    var requestTimePeriod = request.getTimePeriod();
                    var cutBeforeDate_1 = moment.utc(response.timePeriod.end);
                    cutBeforeDate_1.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                    var cutBeforeDateUTCFormat = cutBeforeDate_1.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!_.isNil(tz)) {
                        lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz);
                        lastMergedResponse.timePeriod.end = response.timePeriod.end;
                    }
                    else {
                        lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                        lastMergedResponse.timePeriod.end =
                            moment.utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    }
                    _.each(lastMergedResponse.results, function (result) {
                        var newResults = _.find(response.results, { fqn: result.fqn });
                        if (!_.isNil(newResults)) {
                            result.values = result.values.concat(newResults.values);
                            result.values = _.sortBy(result.values, [function (o) {
                                    return moment.utc(o.t);
                                }]);
                            result.values = _this._filterDuplicateDataAndCut(result.values, cutBeforeDate_1, false, tz);
                        }
                    });
                    _.each(response.results, function (newResult) {
                        if (!_.find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                            lastMergedResponse.results.push(newResult);
                        }
                    });
                    return lastMergedResponse;
                }
                else {
                    lastMergedResponse = response;
                    return response;
                }
            }));
            return repeatedlyObs;
        };
        TimeseriesDataService.prototype._getRepeatedlyIncrements = function (request, customInterval, timezone) {
            var _this = this;
            var requestTimePeriod = request.getTimePeriod();
            var lastResponseData;
            var repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
            repeatedInterval = repeatedInterval * 1000;
            var lastRepeatedRequest = _.clone(request);
            var originalDuration = requestTimePeriod.duration;
            var nextRequestStartMoment;
            var repeatedDataObservable = this._sendPostRequest(request).pipe(operators.map(function (response) {
                nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return _this._transformTimeseriesInternalResponse(response, timezone);
            }));
            var expandedObservable = repeatedDataObservable.pipe(operators.expand(function () {
                return rxjs.timer(repeatedInterval).pipe(operators.concatMap(function () {
                    if (!_.isNil(nextRequestStartMoment)) {
                        lastRepeatedRequest.setTimePeriod(_.extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
                    }
                    return _this._sendPostRequest(lastRepeatedRequest).pipe(operators.map(function (response) {
                        if (lastResponseData.size > 0) {
                            _this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                        }
                        nextRequestStartMoment = _this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                        lastResponseData = _this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                        return _this._transformTimeseriesInternalResponse(response, timezone);
                    }));
                }));
            }));
            return expandedObservable;
        };
        TimeseriesDataService.prototype.getRepeatedly = function (request, customInterval, format, timezone) {
            var requestTimePeriod = request.getTimePeriod();
            if (!_.isNil(requestTimePeriod.start)) {
                return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                    + ' - Request start time cannot be set for repeated data (request: '
                    + JSON.stringify(request) + ' cannot be processed.');
            }
            else if (_.isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
                return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                    + ' - Request duration have to be negative (request: '
                    + JSON.stringify(request) + ' cannot be processed.');
            }
            var tz;
            if (MomentHelperService.isValidTimezone(timezone)) {
                tz = timezone;
            }
            if (_.isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
                return this._getRepeatedlyWhole(request, customInterval, tz);
            }
            else {
                return this._getRepeatedlyIncrements(request, customInterval, tz);
            }
        };
        TimeseriesDataService.decorators = [
            { type: core.Injectable },
        ];
        TimeseriesDataService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
                { type: OpcQualityService, },
            ];
        };
        return TimeseriesDataService;
    }(BaseService));

    var OperationService = (function (_super) {
        __extends(OperationService, _super);
        function OperationService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/operation/', config, http$$1) || this;
        }
        OperationService.prototype.getOperationData = function (operationReq) {
            return this._sendPostRequest(operationReq);
        };
        OperationService.decorators = [
            { type: core.Injectable },
        ];
        OperationService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return OperationService;
    }(BaseService));
    var OperationRequest = (function () {
        function OperationRequest(target, operation, parameters) {
            this.target = target;
            this.operation = operation;
            this.parameters = parameters;
        }
        return OperationRequest;
    }());

    var PersistenceService = (function (_super) {
        __extends(PersistenceService, _super);
        function PersistenceService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/persistence/', config, http$$1) || this;
        }
        PersistenceService.prototype.commit = function (persistRequest) {
            return this._sendPostRequest(persistRequest);
        };
        PersistenceService.decorators = [
            { type: core.Injectable },
        ];
        PersistenceService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return PersistenceService;
    }(BaseService));
    var PropNameValues = (function () {
        function PropNameValues() {
        }
        PropNameValues.prototype.add = function (name, value) {
            if (name) {
                this[name] = value;
            }
        };
        PropNameValues.prototype.remove = function (name) {
            if (!_.isNil(this[name])) {
                delete this[name];
            }
        };
        PropNameValues.prototype.isEmpty = function () {
            return !_.some(this);
        };
        return PropNameValues;
    }());
    var PersistRequest = (function () {
        function PersistRequest() {
        }
        PersistRequest.prototype.createItem = function (parentPropertyFqn, itemType, propNameValues) {
            var createRequest = {
                parentPropertyFqn: parentPropertyFqn,
                itemType: itemType
            };
            if (propNameValues) {
                createRequest.props = propNameValues;
            }
            if (!this.newItems) {
                this.newItems = [];
            }
            this.newItems.push(createRequest);
            return this;
        };
        PersistRequest.prototype.renameItem = function (itemFqn, newName) {
            this.renamedItem = {
                fqn: itemFqn,
                newName: newName
            };
            return this;
        };
        PersistRequest.prototype.changeItem = function (itemFqn, propNameValues) {
            if (!propNameValues.isEmpty()) {
                var changeRequest = {
                    FullyQualifiedName: itemFqn
                };
                _.extend(changeRequest, propNameValues);
                if (!this.changedItems) {
                    this.changedItems = [];
                }
                this.changedItems.push(changeRequest);
            }
            return this;
        };
        PersistRequest.prototype.deleteItem = function (itemFqn) {
            if (!this.deletedItems) {
                this.deletedItems = [];
            }
            this.deletedItems.push(itemFqn);
            return this;
        };
        return PersistRequest;
    }());

    var NavigationService = (function (_super) {
        __extends(NavigationService, _super);
        function NavigationService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/navigation/', config, http$$1) || this;
        }
        NavigationService.prototype.getNavigationData = function (navigationRequest) {
            var request = navigationRequest;
            if (_.isNil(navigationRequest.navHandlerFqn) || navigationRequest.navHandlerFqn === '') {
                if (_.isNil(request.hideRules) && _.isNil(request.skipRules)) {
                    request = _.clone(navigationRequest);
                    request.skipRules = _.clone(this.config.defaultNavigationRules.skipRules);
                    request.hideRules = _.clone(this.config.defaultNavigationRules.hideRules);
                }
            }
            return this._sendPostRequest(request);
        };
        NavigationService.decorators = [
            { type: core.Injectable },
        ];
        NavigationService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return NavigationService;
    }(BaseService));
    var NavigationRequest = (function () {
        function NavigationRequest(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules) {
            this.fqn = fqn;
            this.propNames = propNames;
            this.includeParents = includeParents;
            this.navHandlerFqn = navHandlerFqn;
            this.hideRules = hideRules;
            this.skipRules = skipRules;
        }
        return NavigationRequest;
    }());

    var SecurityContextService = (function (_super) {
        __extends(SecurityContextService, _super);
        function SecurityContextService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/securitycontext/', config, http$$1) || this;
        }
        SecurityContextService.prototype.getSecurityContextData = function () {
            return this._sendGetRequest();
        };
        SecurityContextService.decorators = [
            { type: core.Injectable },
        ];
        SecurityContextService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return SecurityContextService;
    }(BaseService));

    var MimeService = (function (_super) {
        __extends(MimeService, _super);
        function MimeService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/mime/', config, http$$1) || this;
        }
        MimeService.prototype.getMimeItemPath = function (fqn) {
            return this.endpointUrl.concat(fqn);
        };
        MimeService.decorators = [
            { type: core.Injectable },
        ];
        MimeService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return MimeService;
    }(BaseService));

    var NavigationHandlerService = (function (_super) {
        __extends(NavigationHandlerService, _super);
        function NavigationHandlerService(config, http$$1) {
            return _super.call(this, config.baseUrl + '/api/1/navigationhandler/', config, http$$1) || this;
        }
        NavigationHandlerService.prototype.getNavigationHandlerData = function (navigationHandlerReq) {
            return this._sendPostRequest(navigationHandlerReq);
        };
        NavigationHandlerService.decorators = [
            { type: core.Injectable },
        ];
        NavigationHandlerService.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Inject, args: [COMMUNICATION_CONFIG,] },] },
                { type: http.HttpClient, },
            ];
        };
        return NavigationHandlerService;
    }(BaseService));
    var NavigationHandlerRequest = (function () {
        function NavigationHandlerRequest(fqn, currentNavHandlerFqn, navHandlerProviderFqn) {
            this.fqn = fqn;
            this.currentNavHandlerFqn = currentNavHandlerFqn;
            this.navHandlerProviderFqn = navHandlerProviderFqn;
        }
        return NavigationHandlerRequest;
    }());

    function setupInstanceSvc(config, httpClient) {
        return new InstanceService(config, httpClient);
    }
    function setupLiveDataSvc(config, httpClient) {
        return new LiveDataService(config, httpClient);
    }
    function setupTimeseriesDataSvc(config, httpClient, qualitySvc) {
        return new TimeseriesDataService(config, httpClient, qualitySvc);
    }
    function setupOperationSvc(config, httpClient) {
        return new OperationService(config, httpClient);
    }
    function setupPersistenceSvc(config, httpClient) {
        return new PersistenceService(config, httpClient);
    }
    function setupNavigationSvc(config, httpClient) {
        return new NavigationService(config, httpClient);
    }
    function setupSecurityContextSvc(config, httpClient) {
        return new SecurityContextService(config, httpClient);
    }
    function setupMimeSvc(config, httpClient) {
        return new MimeService(config, httpClient);
    }
    function setupNavigationHandlerSvc(config, httpClient) {
        return new NavigationHandlerService(config, httpClient);
    }
    var RaFtcCommunicationModule = (function () {
        function RaFtcCommunicationModule() {
        }
        RaFtcCommunicationModule.forRoot = function (config) {
            return {
                ngModule: RaFtcCommunicationModule,
                providers: [
                    {
                        provide: InstanceService,
                        useFactory: setupInstanceSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: LiveDataService,
                        useFactory: setupLiveDataSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: TimeseriesDataService,
                        useFactory: setupTimeseriesDataSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient, OpcQualityService
                        ]
                    },
                    {
                        provide: OperationService,
                        useFactory: setupOperationSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: PersistenceService,
                        useFactory: setupPersistenceSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: NavigationService,
                        useFactory: setupNavigationSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: SecurityContextService,
                        useFactory: setupSecurityContextSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: MimeService,
                        useFactory: setupMimeSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    {
                        provide: NavigationHandlerService,
                        useFactory: setupNavigationHandlerSvc,
                        deps: [
                            COMMUNICATION_CONFIG, http.HttpClient
                        ]
                    },
                    { provide: COMMUNICATION_CONFIG, useValue: config }
                ]
            };
        };
        RaFtcCommunicationModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            http.HttpClientModule
                        ],
                        providers: [OpcQualityService],
                        declarations: []
                    },] },
        ];
        return RaFtcCommunicationModule;
    }());

    exports.setupInstanceSvc = setupInstanceSvc;
    exports.setupLiveDataSvc = setupLiveDataSvc;
    exports.setupTimeseriesDataSvc = setupTimeseriesDataSvc;
    exports.setupOperationSvc = setupOperationSvc;
    exports.setupPersistenceSvc = setupPersistenceSvc;
    exports.setupNavigationSvc = setupNavigationSvc;
    exports.setupSecurityContextSvc = setupSecurityContextSvc;
    exports.setupMimeSvc = setupMimeSvc;
    exports.setupNavigationHandlerSvc = setupNavigationHandlerSvc;
    exports.RaFtcCommunicationModule = RaFtcCommunicationModule;
    exports.BaseService = BaseService;
    exports.InstanceService = InstanceService;
    exports.InstanceRequest = InstanceRequest;
    exports.LiveRequest = LiveRequest;
    exports.LiveDataService = LiveDataService;
    exports.NavigationService = NavigationService;
    exports.NavigationRequest = NavigationRequest;
    exports.OperationService = OperationService;
    exports.OperationRequest = OperationRequest;
    exports.PersistenceService = PersistenceService;
    exports.PropNameValues = PropNameValues;
    exports.PersistRequest = PersistRequest;
    exports.TimeseriesRequestQuality = TimeseriesRequestQuality;
    exports.TimeseriesRepeatedDataFormat = TimeseriesRepeatedDataFormat;
    exports.SamplingTypes = SamplingTypes;
    exports.TimeseriesRequest = TimeseriesRequest;
    exports.TimeseriesDataService = TimeseriesDataService;
    exports.OpcQualityService = OpcQualityService;
    exports.SecurityContextService = SecurityContextService;
    exports.MomentHelperService = MomentHelperService;
    exports.MimeService = MimeService;
    exports.NavigationHandlerService = NavigationHandlerService;
    exports.NavigationHandlerRequest = NavigationHandlerRequest;
    exports.DEFAULT_REPEATED_DATA_INTERVAL = DEFAULT_REPEATED_DATA_INTERVAL;
    exports.COMMUNICATION_CONFIG = COMMUNICATION_CONFIG;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmEtd2NmdGNsb3VkLXJhLWZ0Yy1jb21tdW5pY2F0aW9uLnVtZC5qcy5tYXAiLCJzb3VyY2VzIjpbbnVsbCwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL2NvbmZpZy50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9iYXNlLnNlcnZpY2UudHMiLCJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vaW5zdGFuY2Uuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9saXZlLWRhdGEuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9vcGMtcXVhbGl0eS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL21vbWVudC1oZWxwZXIuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi90aW1lc2VyaWVzLWRhdGEuc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9vcGVyYXRpb24uc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9wZXJzaXN0ZW5jZS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL25hdmlnYXRpb24uc2VydmljZS50cyIsIm5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi9zZWN1cml0eS1jb250ZXh0LnNlcnZpY2UudHMiLCJuZzovL0ByYS13Y2Z0Y2xvdWQvcmEtZnRjLWNvbW11bmljYXRpb24vbWltZS5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL25hdmlnYXRpb24taGFuZGxlci5zZXJ2aWNlLnRzIiwibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uL2NvbW11bmljYXRpb24ubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qISAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5Db3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cclxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTsgeW91IG1heSBub3QgdXNlXHJcbnRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlXHJcbkxpY2Vuc2UgYXQgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXHJcblxyXG5USElTIENPREUgSVMgUFJPVklERUQgT04gQU4gKkFTIElTKiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZXHJcbktJTkQsIEVJVEhFUiBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBXSVRIT1VUIExJTUlUQVRJT04gQU5ZIElNUExJRURcclxuV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIFRJVExFLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSxcclxuTUVSQ0hBTlRBQkxJVFkgT1IgTk9OLUlORlJJTkdFTUVOVC5cclxuXHJcblNlZSB0aGUgQXBhY2hlIFZlcnNpb24gMi4wIExpY2Vuc2UgZm9yIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9uc1xyXG5hbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXHJcbi8qIGdsb2JhbCBSZWZsZWN0LCBQcm9taXNlICovXHJcblxyXG52YXIgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoYi5oYXNPd25Qcm9wZXJ0eShwKSkgZFtwXSA9IGJbcF07IH07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHRlbmRzKGQsIGIpIHtcclxuICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxufVxyXG5cclxuZXhwb3J0IHZhciBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xyXG4gICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcclxuICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpIHRbcF0gPSBzW3BdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJpbXBvcnQge0luamVjdGlvblRva2VufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtOYXZpZ2F0aW9uUnVsZXN9IGZyb20gJy4vc2hhcmVkJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNvbW1vbkh0dHBDb25maWcge1xyXG4gICAgd2l0aENyZWRlbnRpYWxzOiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElOYXZpZ2F0aW9uUnVsZXMge1xyXG4gICAgaGlkZVJ1bGVzPzogTmF2aWdhdGlvblJ1bGVzO1xyXG4gICAgc2tpcFJ1bGVzPzogTmF2aWdhdGlvblJ1bGVzO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMID0gNTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNvbW11bmljYXRpb25Db25maWcge1xyXG4gICAgYmFzZVVybDogc3RyaW5nO1xyXG4gICAgZGVmYXVsdFJlcGVhdGVkRGF0YUludGVydmFsPzogbnVtYmVyO1xyXG4gICAgZGVmYXVsdE5hdmlnYXRpb25SdWxlcz86IElOYXZpZ2F0aW9uUnVsZXM7XHJcbiAgICBodHRwT3B0aW9ucz86IElDb21tb25IdHRwQ29uZmlnO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBDT05GSUdfVFlQRSA9IElDb21tdW5pY2F0aW9uQ29uZmlnO1xyXG5cclxuZXhwb3J0IGNvbnN0IENPTU1VTklDQVRJT05fQ09ORklHID0gbmV3IEluamVjdGlvblRva2VuPElDb21tdW5pY2F0aW9uQ29uZmlnPignQ09NTVVOSUNBVElPTl9DT05GSUdVUkFUSU9OJyk7XHJcbiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcgfSBmcm9tICcuL2NvbmZpZyc7XHJcblxyXG5leHBvcnQgY2xhc3MgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByb3RlY3RlZCBlbmRwb2ludFVybDogc3RyaW5nLFxyXG4gICAgICAgIHByb3RlY3RlZCBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLFxyXG4gICAgICAgIHByb3RlY3RlZCBodHRwOiBIdHRwQ2xpZW50KSB7IH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0OiBhbnkpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHAucG9zdCh0aGlzLmVuZHBvaW50VXJsLCByZXF1ZXN0LFxyXG4gICAgICAgICAgICBfLmV4dGVuZCh7IGhlYWRlcnM6IHsgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnIH0gfSwgdGhpcy5jb25maWcuaHR0cE9wdGlvbnMpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgX3NlbmRHZXRSZXF1ZXN0KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQodGhpcy5lbmRwb2ludFVybCxcclxuICAgICAgICAgICAgXy5leHRlbmQoeyBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyB9IH0sIHRoaXMuY29uZmlnLmh0dHBPcHRpb25zKSk7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCAqIGFzIF8gZnJvbSAnbG9kYXNoJztcclxuXHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCByZXNwb25zZSBmb3JtYXQgb2YgZnFuIGl0ZW0uICAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElGcW5JdGVtUmVzcG9uc2VGb3JtYXQge1xyXG4gICAgLyoqIERlcHRoIG9mIHJlc3BvbnNlIG9iamVjdCAqL1xyXG4gICAgZGVwdGg/OiBudW1iZXI7XHJcbiAgICAvKiogV2hldGhlciB0byBpbmNsdWRlIHNob3J0Y3V0cyBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90ICovXHJcbiAgICBpbmNsdWRlU2hvcnRjdXRzPzogYm9vbGVhbjtcclxuICAgIC8qKiBXaGV0aGVyIHRvIGluY2x1ZGUgYWNjZXNzIGNvbnRyb2wgaW5mb3JtYXRpb24gaW4gcmVzcG9uc2Ugb2JqZWN0IG9yIG5vdCAqL1xyXG4gICAgaW5jbHVkZUFjbD86IGJvb2xlYW47XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCBmcW4gaXRlbS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJRnFuSXRlbSB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIGV4Y2x1ZGVWb2xhdGlsZVByb3BlcnRpZXM/OiBib29sZWFuO1xyXG4gICAgLyoqIFNpemUgb2YgcGFnZSAoZGVmYXVsdCAwIC0gZG8gbm90IHVzZSBwYWdpbmcpICovXHJcbiAgICBwYWdlU2l6ZT86IG51bWJlcjtcclxuICAgIC8qKiBJbmRleCBvZiBwYWdlIChkZWZhdWx0IDApICovXHJcbiAgICBwYWdlPzogbnVtYmVyO1xyXG4gICAgcmVzcG9uc2VGb3JtYXQ/OiBJRnFuSXRlbVJlc3BvbnNlRm9ybWF0O1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgZnFuIHByb3BlcnR5IGl0ZW0uICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUZxblByb3BlcnR5SXRlbSB7XHJcbiAgICBwcm9wZXJ0eUZxbjogc3RyaW5nO1xyXG4gICAgLyoqIFNpemUgb2YgcGFnZSAoZGVmYXVsdCAwIC0gZG8gbm90IHVzZSBwYWdpbmcpICovXHJcbiAgICBwYWdlU2l6ZT86IG51bWJlcjtcclxuICAgIC8qKiBJbmRleCBvZiBwYWdlIChkZWZhdWx0IDApICovXHJcbiAgICBwYWdlPzogbnVtYmVyO1xyXG4gICAgcmVzcG9uc2VGb3JtYXQ/OiBJRnFuSXRlbVJlc3BvbnNlRm9ybWF0O1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgcXVlcnkgaXRlbS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJUXVlcnlJdGVtIHtcclxuICAgIC8qKiBRdWVyeSBFeHByZXNzaW9uICovXHJcbiAgICBxdWVyeTogc3RyaW5nO1xyXG4gICAgcmVzcG9uc2VGb3JtYXQ/OiBJRnFuSXRlbVJlc3BvbnNlRm9ybWF0O1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBJbnN0YW5jZUZxbkl0ZW0gPSBJRnFuSXRlbSB8IElGcW5Qcm9wZXJ0eUl0ZW07XHJcbmV4cG9ydCB0eXBlIEluc3RhbmNlUXVlcnlJdGVtID0gSVF1ZXJ5SXRlbTtcclxuXHJcbi8qKlxyXG4gKiBUaGUgSW5zdGFuY2UgU2VydmljZSByZXRyaWV2ZXMgaXRlbSAoaW5zdGFuY2UpIGRhdGEgZnJvbSB0aGUgbW9kZWwuIEl0ZW1zIGNhbiBiZSByZXF1ZXN0ZWQgZWl0aGVyIGJ5IHVzaW5nIGEgbGlzdCBvZlxyXG4gKiBmdWxseSBxdWFsaWZpZWQgbmFtZXMgKEZRTikgb3IgYSBxdWVyeSBleHByZXNzaW9uLiBBIHNpbmdsZSByZXF1ZXN0IGNhbiBpbmNsdWRlIG11bHRwbGUgRlFOIGxpc3RzIGFuZCBtdWx0aXBsZSBxdWVyeVxyXG4gKiBleHByZXNzaW9ucy5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEluc3RhbmNlU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL2luc3RhbmNlLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNYWtlcyBhIHJlcXVlc3QgdG8gdGhlIEpTT04gSW5zdGFuY2Ugc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0SW5zdGFuY2VzKGluc3RhbmNlUmVxdWVzdDogSW5zdGFuY2VSZXF1ZXN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KGluc3RhbmNlUmVxdWVzdCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBJbnN0YW5jZVJlcXVlc3Qge1xyXG4gICAgcHJpdmF0ZSBxdWVyaWVzOiBJbnN0YW5jZVF1ZXJ5SXRlbVtdO1xyXG4gICAgcHJpdmF0ZSBmcW5zOiBJbnN0YW5jZUZxbkl0ZW1bXTtcclxuICAgIHB1YmxpYyBjYW1lbENhc2VQcm9wZXJ0eU5hbWVzOiBib29sZWFuO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogSW5zdGFuY2UgcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIGNhbWVsQ2FzZVByb3BlcnR5TmFtZXMgLSB0cnVlIGlmIHByb3BlcnR5IG5hbWVzIGFyZSBjYW1lbENhc2UuIERlZmF1bHQgaXMgdHJ1ZS5cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoY2FtZWxDYXNlUHJvcGVydHlOYW1lcz86IGJvb2xlYW4pIHtcclxuICAgICAgICBpZiAoIV8uaXNOaWwoY2FtZWxDYXNlUHJvcGVydHlOYW1lcykpIHtcclxuICAgICAgICAgICAgdGhpcy5jYW1lbENhc2VQcm9wZXJ0eU5hbWVzID0gY2FtZWxDYXNlUHJvcGVydHlOYW1lcztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmNhbWVsQ2FzZVByb3BlcnR5TmFtZXMgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBSZXNwb25zZSBGb3JtYXQgdG8gSW5zdGFuY2UgUmVxdWVzdCBPYmplY3RcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBhZGRSZXNwb25zZUZvcm1hdChcclxuICAgICAgICBpbnN0YW5jZUZxbkl0ZW06IEluc3RhbmNlRnFuSXRlbSB8IEluc3RhbmNlUXVlcnlJdGVtLCBpbmNsdWRlQWNjZXNzQ29udHJvbDogYm9vbGVhbixcclxuICAgICAgICByZXRyaWV2YWxEZXB0aDogbnVtYmVyLCBpbmNsdWRlU2hvcnRjdXRzOiBib29sZWFuKSB7XHJcblxyXG4gICAgICAgIGluc3RhbmNlRnFuSXRlbS5yZXNwb25zZUZvcm1hdCA9IHt9O1xyXG4gICAgICAgIGlmIChpbmNsdWRlQWNjZXNzQ29udHJvbCkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUZxbkl0ZW0ucmVzcG9uc2VGb3JtYXQuaW5jbHVkZUFjbCA9IGluY2x1ZGVBY2Nlc3NDb250cm9sO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIV8uaXNOaWwocmV0cmlldmFsRGVwdGgpICYmIHJldHJpZXZhbERlcHRoID4gMCkge1xyXG4gICAgICAgICAgICBpbnN0YW5jZUZxbkl0ZW0ucmVzcG9uc2VGb3JtYXQuZGVwdGggPSByZXRyaWV2YWxEZXB0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGluY2x1ZGVTaG9ydGN1dHMpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2VGcW5JdGVtLnJlc3BvbnNlRm9ybWF0LmluY2x1ZGVTaG9ydGN1dHMgPSBpbmNsdWRlU2hvcnRjdXRzO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBJdGVtIEZRTiB0byBJbnN0YW5jZSBSZXF1ZXN0IE9iamVjdFxyXG4gICAgICogQHBhcmFtIGZxbiAtIEZRTiB0byBhZGQgdG8gdGhlIHJlcXVlc3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlQWNjZXNzQ29udHJvbCAtIFdoZXRoZXIgdG8gaW5jbHVkZSBBQ0wgaW4gcmVzcG9uc2Ugb2JqZWN0IG9yIG5vdFxyXG4gICAgICogQHBhcmFtIHJldHJpZXZhbERlcHRoIC0gRGVwdGggb2YgcmVzcG9uc2Ugb2JqZWN0XHJcbiAgICAgKiBAcGFyYW0gaW5jbHVkZVNob3J0Y3V0cyAtIFdoZXRoZXIgdG8gaW5jbHVkZSBzaG9ydGN1dHMgaW4gcmVzcG9uc2Ugb2JqZWN0IG9yIG5vdFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYWRkSXRlbUZxbihmcW46IHN0cmluZywgaW5jbHVkZUFjY2Vzc0NvbnRyb2w/OiBib29sZWFuLCByZXRyaWV2YWxEZXB0aD86IG51bWJlciwgaW5jbHVkZVNob3J0Y3V0cz86IGJvb2xlYW4pIHtcclxuICAgICAgICBjb25zdCBpbnN0YW5jZUZxbkl0ZW06IEluc3RhbmNlRnFuSXRlbSA9IHtcclxuICAgICAgICAgICAgZnFuOiBmcW5cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYWRkUmVzcG9uc2VGb3JtYXQoaW5zdGFuY2VGcW5JdGVtLCBpbmNsdWRlQWNjZXNzQ29udHJvbCwgcmV0cmlldmFsRGVwdGgsIGluY2x1ZGVTaG9ydGN1dHMpO1xyXG4gICAgICAgIGlmICghdGhpcy5mcW5zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucyA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmZxbnMucHVzaChpbnN0YW5jZUZxbkl0ZW0pO1xyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIEl0ZW0gRlFOIHRvIEluc3RhbmNlIFJlcXVlc3QgT2JqZWN0IC0gRXhjbHVkZSBWb2xhdGlsZSBQcm9wZXJ0aWVzXHJcbiAgICAgKiBAcGFyYW0gZnFuIC0gRlFOIHRvIGFkZCB0byB0aGUgcmVxdWVzdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVBY2Nlc3NDb250cm9sIC0gV2hldGhlciB0byBpbmNsdWRlIEFDTCBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKiBAcGFyYW0gcmV0cmlldmFsRGVwdGggLSBEZXB0aCBvZiByZXNwb25zZSBvYmplY3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlU2hvcnRjdXRzIC0gV2hldGhlciB0byBpbmNsdWRlIHNob3J0Y3V0cyBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBhZGRJdGVtRnFuRXhjbHVkZVZvbGF0aWxlKFxyXG4gICAgICAgIGZxbjogc3RyaW5nLFxyXG4gICAgICAgIGluY2x1ZGVBY2Nlc3NDb250cm9sOiBib29sZWFuLFxyXG4gICAgICAgIHJldHJpZXZhbERlcHRoOiBudW1iZXIsXHJcbiAgICAgICAgaW5jbHVkZVNob3J0Y3V0czogYm9vbGVhbikge1xyXG5cclxuICAgICAgICBjb25zdCBpbnN0YW5jZUZxbkl0ZW06IEluc3RhbmNlRnFuSXRlbSA9IHtcclxuICAgICAgICAgICAgZnFuOiBmcW4sXHJcbiAgICAgICAgICAgIGV4Y2x1ZGVWb2xhdGlsZVByb3BlcnRpZXM6IHRydWVcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYWRkUmVzcG9uc2VGb3JtYXQoaW5zdGFuY2VGcW5JdGVtLCBpbmNsdWRlQWNjZXNzQ29udHJvbCwgcmV0cmlldmFsRGVwdGgsIGluY2x1ZGVTaG9ydGN1dHMpO1xyXG4gICAgICAgIGlmICghdGhpcy5mcW5zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucyA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmZxbnMucHVzaChpbnN0YW5jZUZxbkl0ZW0pO1xyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIFByb3BlcnR5IEZRTiB0byBJbnN0YW5jZSBSZXF1ZXN0IE9iamVjdFxyXG4gICAgICogQHBhcmFtIGZxbiAtIEZRTiB0byBhZGQgdG8gdGhlIHJlcXVlc3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlQWNjZXNzQ29udHJvbCAtIFdoZXRoZXIgdG8gaW5jbHVkZSBBQ0wgaW4gcmVzcG9uc2Ugb2JqZWN0IG9yIG5vdFxyXG4gICAgICogQHBhcmFtIHJldHJpZXZhbERlcHRoIC0gRGVwdGggb2YgcmVzcG9uc2Ugb2JqZWN0XHJcbiAgICAgKiBAcGFyYW0gaW5jbHVkZVNob3J0Y3V0cyAtIFdoZXRoZXIgdG8gaW5jbHVkZSBzaG9ydGN1dHMgaW4gcmVzcG9uc2Ugb2JqZWN0IG9yIG5vdFxyXG4gICAgICogQHBhcmFtIHBhZ2VTaXplIC0gU2l6ZSBvZiByZXR1cm5lZCBwYWdlIChkZWZhdWx0IDAgLSBkbyBub3QgdXNlIHBhZ2luZylcclxuICAgICAqIEBwYXJhbSBwYWdlIC0gSW5kZXggb2YgcmV0dXJuZWQgcGFnZSAoZGVmYXVsdCAwKVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYWRkUHJvcGVydHlGcW4oXHJcbiAgICAgICAgZnFuOiBzdHJpbmcsIGluY2x1ZGVBY2Nlc3NDb250cm9sPzogYm9vbGVhbiwgcmV0cmlldmFsRGVwdGg/OiBudW1iZXIsXHJcbiAgICAgICAgaW5jbHVkZVNob3J0Y3V0cz86IGJvb2xlYW4sIHBhZ2VTaXplPzogbnVtYmVyLCBwYWdlPzogbnVtYmVyKSB7XHJcblxyXG4gICAgICAgIGNvbnN0IGluc3RhbmNlRnFuUHJvcGVydHlJdGVtOiBJbnN0YW5jZUZxbkl0ZW0gPSB7XHJcbiAgICAgICAgICAgIHByb3BlcnR5RnFuOiBmcW4sXHJcbiAgICAgICAgICAgIGV4Y2x1ZGVWb2xhdGlsZVByb3BlcnRpZXM6IHRydWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFkZFJlc3BvbnNlRm9ybWF0KGluc3RhbmNlRnFuUHJvcGVydHlJdGVtLCBpbmNsdWRlQWNjZXNzQ29udHJvbCwgcmV0cmlldmFsRGVwdGgsIGluY2x1ZGVTaG9ydGN1dHMpO1xyXG4gICAgICAgIGlmICghXy5pc05pbChwYWdlU2l6ZSkpIHtcclxuICAgICAgICAgICAgaW5zdGFuY2VGcW5Qcm9wZXJ0eUl0ZW0ucGFnZVNpemUgPSBwYWdlU2l6ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHBhZ2UpKSB7XHJcbiAgICAgICAgICAgIGluc3RhbmNlRnFuUHJvcGVydHlJdGVtLnBhZ2UgPSBwYWdlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuZnFucykge1xyXG4gICAgICAgICAgICB0aGlzLmZxbnMgPSBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5mcW5zLnB1c2goaW5zdGFuY2VGcW5Qcm9wZXJ0eUl0ZW0pO1xyXG4gICAgICAgIHJldHVybiB0aGlzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIFF1ZXJ5IEV4cHJlc3Npb24gdG8gSW5zdGFuY2UgUmVxdWVzdCBPYmplY3RcclxuICAgICAqIEBwYXJhbSBxdWVyeUV4cHJlc3Npb24gLSBRdWVyeSBFeHByZXNzaW9uIHRvIGFkZCB0byB0aGUgcmVxdWVzdFxyXG4gICAgICogQHBhcmFtIGluY2x1ZGVBY2Nlc3NDb250cm9sIC0gV2hldGhlciB0byBpbmNsdWRlIEFDTCBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKiBAcGFyYW0gcmV0cmlldmFsRGVwdGggLSBEZXB0aCBvZiByZXNwb25zZSBvYmplY3RcclxuICAgICAqIEBwYXJhbSBpbmNsdWRlU2hvcnRjdXRzIC0gV2hldGhlciB0byBpbmNsdWRlIHNob3J0Y3V0cyBpbiByZXNwb25zZSBvYmplY3Qgb3Igbm90XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBhZGRRdWVyeShcclxuICAgICAgICBxdWVyeUV4cHJlc3Npb246IHN0cmluZywgaW5jbHVkZUFjY2Vzc0NvbnRyb2w/OiBib29sZWFuLFxyXG4gICAgICAgIHJldHJpZXZhbERlcHRoPzogbnVtYmVyLCBpbmNsdWRlU2hvcnRjdXRzPzogYm9vbGVhbikge1xyXG5cclxuICAgICAgICBjb25zdCBpbnN0YW5jZVF1ZXJ5SXRlbTogSW5zdGFuY2VRdWVyeUl0ZW0gPSB7XHJcbiAgICAgICAgICAgIHF1ZXJ5OiBxdWVyeUV4cHJlc3Npb25cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYWRkUmVzcG9uc2VGb3JtYXQoaW5zdGFuY2VRdWVyeUl0ZW0sIGluY2x1ZGVBY2Nlc3NDb250cm9sLCByZXRyaWV2YWxEZXB0aCwgaW5jbHVkZVNob3J0Y3V0cyk7XHJcbiAgICAgICAgaWYgKCF0aGlzLnF1ZXJpZXMpIHtcclxuICAgICAgICAgICAgdGhpcy5xdWVyaWVzID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMucXVlcmllcy5wdXNoKGluc3RhbmNlUXVlcnlJdGVtKTtcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJzY3JpcHRpb24sIFN1YmplY3QsIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCwgZXhwYW5kLCBjb25jYXRNYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZywgREVGQVVMVF9SRVBFQVRFRF9EQVRBX0lOVEVSVkFMIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBpZGVudGlmaWVyLCBJUmVzcG9uc2UgfSBmcm9tICcuL3NoYXJlZCc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGxpdmUgZGF0YSBwcm94eSB2YWx1ZSBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUxpdmVSZXNwb25zZVByb3h5VmFsdWUge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICB0eXBlOiBzdHJpbmc7XHJcbiAgICBjcmVhdGVkT24/OiBzdHJpbmc7XHJcbiAgICBjcmVhdGVkT25PZmZzZXQ/OiBudW1iZXI7XHJcbiAgICBtb2RpZmllZE9uPzogc3RyaW5nO1xyXG4gICAgbW9kaWZpZWRPbk9mZnNldD86IG51bWJlcjtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGxpdmUgZGF0YSByZXNwb25zZSBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUxpdmVSZXNwb25zZSBleHRlbmRzIElSZXNwb25zZSB7XHJcbiAgICB2OiBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuIHwgSUxpdmVSZXNwb25zZVByb3h5VmFsdWVbXTtcclxuICAgIHE6IG51bWJlcjtcclxuICAgIHQ6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgTGl2ZVJlc3BvbnNlID0gSUxpdmVSZXNwb25zZVtdO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IGxpdmUgZGF0YSB2cXQgaW50ZXJuYWwgc3RydWN0dXJlLiAqL1xyXG5pbnRlcmZhY2UgSUxpdmVSZXNwb25zZUludGVybmFsVnF0T2JqZWN0IHtcclxuICAgIHY6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW4gfCBJTGl2ZVJlc3BvbnNlUHJveHlWYWx1ZVtdO1xyXG4gICAgcTogbnVtYmVyO1xyXG4gICAgdDogc3RyaW5nO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHJlc3BvbnNlIG9iamVjdCBpbnRlcm5hbCBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJTGl2ZVJlc3BvbnNlSW50ZXJuYWxPYmplY3Qge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuYW1lPzogc3RyaW5nO1xyXG4gICAgZW5naW5lZXJpbmdVbml0Pzogc3RyaW5nO1xyXG4gICAgdmFsdWVUeXBlPzogc3RyaW5nO1xyXG4gICAgdmFsdWU6IElMaXZlUmVzcG9uc2VJbnRlcm5hbFZxdE9iamVjdDtcclxufVxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgbGl2ZSBkYXRhIHJlc3BvbnNlIGludGVybmFsIChyYXcpIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElMaXZlUmVzcG9uc2VJbnRlcm5hbCB7XHJcbiAgICBmcW5zUmVzdWx0cz86IElMaXZlUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG4gICAgcXVlcnlSZXN1bHRzPzogSUxpdmVSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBMaXZlUmVxdWVzdCB7XHJcbiAgICAvKipcclxuICAgICAqIExpdmUgcmVxdWVzdCBjb25zdHJ1Y3RvclxyXG4gICAgICogQHBhcmFtIGZxbnMgTGlzdCBvZiBmcW5zIChpZGVudGlmaWNhdG9ycykgdG8gYmUgdXNlZCBmb3IgcmVxdWVzdFxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihyZWFkb25seSBmcW5zOiBpZGVudGlmaWVyW11cclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuZnFucyA9IF8uY2xvbmUoZnFucyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBZGQgb25lIGZxbiB0byByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byBhZGRcclxuICAgICAqL1xyXG4gICAgYWRkRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIHRoaXMuZnFucy5wdXNoKGZxbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmUgb25lIGZxbiBmcm9tIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIHJlbW92ZVxyXG4gICAgICovXHJcbiAgICByZW1vdmVGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgY29uc3QgaW5kZXggPSBfLmluZGV4T2YodGhpcy5mcW5zLCBmcW4pO1xyXG4gICAgICAgIGlmIChpbmRleCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy5mcW5zLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogVGhpcyBzZXJ2aWNlIHByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgZm9yIHNlbmRpbmcgcmVxdWVzdHMgdG8gb2J0YWluIGxpdmUgZGF0YS5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIExpdmVEYXRhU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuICAgIC8qKiBAaW50ZXJuYWwgYWN0dWFsIHJlcGVhdGVkIGxpdmUgcmVxdWVzdCBmcW5zICovXHJcbiAgICBwcml2YXRlIF9mcW5zOiBNYXA8c3RyaW5nLCBudW1iZXI+ID0gbmV3IE1hcCgpO1xyXG4gICAgcHJpdmF0ZSBfcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZTogT2JzZXJ2YWJsZTxMaXZlUmVzcG9uc2U+O1xyXG4gICAgcHJpdmF0ZSBfcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9yZXBlYXRlZERhdGFTdWJqZWN0OiBTdWJqZWN0PExpdmVSZXNwb25zZT47XHJcbiAgICBwcml2YXRlIF9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGU6IGJvb2xlYW47XHJcblxyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgICAgIHN1cGVyKGNvbmZpZy5iYXNlVXJsICsgJy9hcGkvMS9saXZlLycsIGNvbmZpZywgaHR0cCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCBsaXZlIHJlcXVlc3QgdG8gc2VydmVyLCBidXQgb25seSBvbmNlLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgbGl2ZSByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqL1xyXG4gICAgZ2V0T25jZShyZXF1ZXN0OiBMaXZlUmVxdWVzdCk6IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKFxyXG4gICAgICAgICAgICBtYXAoKHJlc3BvbnNlOiBJTGl2ZVJlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJldDogTGl2ZVJlc3BvbnNlID0gW107XHJcbiAgICAgICAgICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChvbmVSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXQucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IG9uZVJlc3VsdC5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmcW46IG9uZVJlc3VsdC5mcW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogb25lUmVzdWx0LnZhbHVlVHlwZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5naW5lZXJpbmdVbml0OiBvbmVSZXN1bHQuZW5naW5lZXJpbmdVbml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2OiBvbmVSZXN1bHQudmFsdWUudixcclxuICAgICAgICAgICAgICAgICAgICAgICAgcTogb25lUmVzdWx0LnZhbHVlLnEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHQ6IG9uZVJlc3VsdC52YWx1ZS50XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXQ7XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRJbm5lclJlcGVhdGVkT2JzZXJ2YWJsZSgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHsgZnFuczogQXJyYXkuZnJvbSh0aGlzLl9mcW5zLmtleXMoKSkgfSlcclxuICAgICAgICAgICAgLnBpcGUobWFwKChyZXNwb25zZTogSUxpdmVSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXQ6IExpdmVSZXNwb25zZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAob25lUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBvbmVSZXN1bHQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnFuOiBvbmVSZXN1bHQuZnFuLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6IG9uZVJlc3VsdC52YWx1ZVR5cGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuZ2luZWVyaW5nVW5pdDogb25lUmVzdWx0LmVuZ2luZWVyaW5nVW5pdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdjogb25lUmVzdWx0LnZhbHVlLnYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHE6IG9uZVJlc3VsdC52YWx1ZS5xLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0OiBvbmVSZXN1bHQudmFsdWUudFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmV0O1xyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdGlhbGl6ZVJlcGVhdGVkRGF0YSgpOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4ge1xyXG4gICAgICAgIGlmICghdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0ID0gbmV3IFN1YmplY3Q8TGl2ZVJlc3BvbnNlPigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlIHx8IHRoaXMuX3JlaW5pdGlhbGl6ZVJlcGVhdGVkT2JzZXJ2YWJsZSkge1xyXG4gICAgICAgICAgICBsZXQgcmVwZWF0ZWRJbnRlcnZhbCA9IHRoaXMuY29uZmlnLmRlZmF1bHRSZXBlYXRlZERhdGFJbnRlcnZhbCB8fCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUw7XHJcbiAgICAgICAgICAgIHJlcGVhdGVkSW50ZXJ2YWwgPSByZXBlYXRlZEludGVydmFsICogMTAwMDtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YU9ic2VydmFibGUgPSB0aGlzLl9nZXRJbm5lclJlcGVhdGVkT2JzZXJ2YWJsZSgpO1xyXG4gICAgICAgICAgICAvLyBFeHBhbmQgY3VycmVudCBvYnNlcnZhYmxlIHNlcXVlbmNlIGJ5IHJlY3Vyc2l2ZWx5IGludm9raW5nIHNlbGVjdG9yIC1cclxuICAgICAgICAgICAgLy8gYSB0aW1lciBiYXNlZCBvbiBpbnRlcnZhbCwgd2hpY2ggd2lsbCByZXBlYXQgcmVxdWVzdCBhbmQgcHJvY2VzcyByZXNwb25zZS5cclxuICAgICAgICAgICAgLy8gT2JzZXJ2YWJsZSB0aW1lcjpcclxuICAgICAgICAgICAgLy8gUmV0dXJucyBhbiBvYnNlcnZhYmxlIHNlcXVlbmNlIHRoYXQgcHJvZHVjZXMgYSB2YWx1ZSBhZnRlciBkdWVUaW1lIGhhcyBlbGFwc2VkIGFuZCB0aGVuIGFmdGVyIGVhY2ggcGVyaW9kLlxyXG4gICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJzY3JpcHRpb24gPSB0aGlzLl9yZXBlYXRlZERhdGFPYnNlcnZhYmxlLnBpcGUoXHJcbiAgICAgICAgICAgICAgICBleHBhbmQoKCkgPT4gdGltZXIocmVwZWF0ZWRJbnRlcnZhbCkucGlwZShjb25jYXRNYXAoKCkgPT4gdGhpcy5fZ2V0SW5uZXJSZXBlYXRlZE9ic2VydmFibGUoKSkpKVxyXG4gICAgICAgICAgICApLnN1YnNjcmliZSgocmVzcG9uc2U6IExpdmVSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5uZXh0KHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgfSwgKGVycikgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICB9LCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWluaXRpYWxpemVSZXBlYXRlZE9ic2VydmFibGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHJlcXVlc3QgZm9yIGxpdmUgZGF0YSByZXBlYXRlZGx5LiBJdCByZXBlYXRlZGx5IHNlbmRzIHJlcXVlc3RzIHRvIHNlcnZlci5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IGxpdmUgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKi9cclxuICAgIGdldFJlcGVhdGVkbHkocmVxdWVzdDogTGl2ZVJlcXVlc3QpOiBPYnNlcnZhYmxlPExpdmVSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8TGl2ZVJlc3BvbnNlPigob2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICAgICAgLy8gd2UgcmVnaXN0ZXIgbmV3IGlkZW50aWZpY2F0b3JzIGZvciBwZXJpb2RpYyBsaXZlIHVwZGF0ZXNcclxuICAgICAgICAgICAgXy5lYWNoKHJlcXVlc3QuZnFucywgKGZxbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld1ZhbCA9IDA7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZnFucy5oYXMoZnFuKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld1ZhbCA9IHRoaXMuX2ZxbnMuZ2V0KGZxbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mcW5zLnNldChmcW4sICsrbmV3VmFsKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRpYWxpemVSZXBlYXRlZERhdGEoKTtcclxuICAgICAgICAgICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gdGhpcy5fcmVwZWF0ZWREYXRhU3ViamVjdC5hc09ic2VydmFibGUoKS5waXBlKG1hcCgoY3VycmVudFJlc3BvbnNlOiBMaXZlUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfLmZpbHRlcihjdXJyZW50UmVzcG9uc2UsIChvKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF8uaW5kZXhPZihyZXF1ZXN0LmZxbnMsIG8uZnFuKSA+IC0xO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pKS5zdWJzY3JpYmUoKHJlc3BvbnNlOiBMaXZlUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLm5leHQocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICB9LCAoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLmVycm9yKGVycm9yKTtcclxuICAgICAgICAgICAgfSwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gd2UgdW5yZWdpc3RlciBpZGVudGlmaWNhdG9ycyBmb3IgcGVyaW9kaWMgbGl2ZSB1cGRhdGVzXHJcbiAgICAgICAgICAgICAgICBfLmVhY2gocmVxdWVzdC5mcW5zLCAoZnFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5ld1ZhbCA9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2ZxbnMuaGFzKGZxbikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3VmFsID0gdGhpcy5fZnFucy5nZXQoZnFuKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5ld1ZhbCA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9mcW5zLmRlbGV0ZShmcW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZxbnMuc2V0KGZxbiwgLS1uZXdWYWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mcW5zLnNpemUgPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVwZWF0ZWREYXRhU3Vic2NyaXB0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlcGVhdGVkRGF0YVN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXBlYXRlZERhdGFTdWJqZWN0LmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHRoaXMuX3JlcGVhdGVkRGF0YVN1YmplY3Q7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVpbml0aWFsaXplUmVwZWF0ZWRPYnNlcnZhYmxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufVxyXG4iLCIvKiB0c2xpbnQ6ZGlzYWJsZTpuby1iaXR3aXNlICovXHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgcXVhbGl0eS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJUXVhbGl0eSB7XHJcbiAgLyoqIGdvb2QsIGJhZCwgdW5jZXJ0YWluIG9yIG5vdCBkZWZpbmVkIHF1YWxpdHkgdmFsdWUgKi9cclxuICBvdmVyYWxsOiBzdHJpbmc7XHJcbiAgLyoqIE9QQyBEQSBxdWFsaXR5ICovXHJcbiAgZGE/OiBzdHJpbmc7XHJcbiAgLyoqIE9QQyBsaW1pdCBzdGF0dXMgKi9cclxuICBsaW1pdD86IHN0cmluZztcclxuICAvKiogT1BDIEhEQSBxdWFsaXR5ICovXHJcbiAgaGRhPzogc3RyaW5nO1xyXG59XHJcblxyXG4vKipcclxuICogVGhpcyBzZXJ2aWNlIHByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgZm9yIGV2YWx1YXRpbmcgT1BDIERBIHF1YWxpdHksIE9QQyBsaW1pdFxyXG4gKiBzdGF0dXMgb3IgT1BDIEhEQSBxdWFsaXR5IGJ5IHBhc3NlZCBhcmd1bWVudC5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE9wY1F1YWxpdHlTZXJ2aWNlIHtcclxuXHJcbiAgcHJpdmF0ZSBvcGNEYVF1YWxpdHlNYXNrID0gMHhmZmZDO1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5TWFzdGVyTWFzayA9IDB4MDBDMDtcclxuICBwcml2YXRlIG9wY0hkYVF1YWxpdHlNYXNrID0gMHhmZmZmMDAwMDtcclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eUZpZWxkTWFza3MgPSB7XHJcbiAgICBsaW1pdEZpZWxkOiAweDAwMDMsXHJcbiAgICBzdWJTdGF0dXNGaWVsZDogMHgwMDNDLFxyXG4gICAgcXVhbGl0eTogMHgwMEMwXHJcbiAgfTtcclxuICBwcml2YXRlIG9wY0RhUXVhbGl0eU1hc3RlciA9IHtcclxuICAgIGJhZDogMHgwMDAwLFxyXG4gICAgdW5jZXJ0YWluOiAweDAwNDAsXHJcbiAgICBub3REZWZpbmVkOiAweDAwODAsXHJcbiAgICBnb29kOiAweDAwQzBcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5U3RhdHVzID0ge1xyXG4gICAgYmFkOiAweDAwMDAsXHJcbiAgICBjb25maWdFcnJvcjogMHgwMDA0LFxyXG4gICAgbm90Q29ubmVjdGVkOiAweDAwMDgsXHJcbiAgICBkZXZpY2VGYWlsdXJlOiAweDAwMGMsXHJcbiAgICBzZW5zb3JGYWlsdXJlOiAweDAwMTAsXHJcbiAgICBsYXN0S25vd246IDB4MDAxNCxcclxuICAgIGNvbW1GYWlsdXJlOiAweDAwMTgsXHJcbiAgICBvdXRPZlNlcnZpY2U6IDB4MDAxYyxcclxuICAgIGluaXRpYWxpemluZzogMHgwMDIwLFxyXG4gICAgdW5jZXJ0YWluOiAweDAwNDAsXHJcbiAgICBsYXN0VXNhYmxlOiAweDAwNDQsXHJcbiAgICBzZW5zb3JOb3RBY2N1cmF0ZTogMHgwMDUwLFxyXG4gICAgZW5nVW5pdHNFeGNlZWRlZDogMHgwMDU0LFxyXG4gICAgc3ViTm9ybWFsOiAweDAwNTgsXHJcbiAgICBnb29kOiAweDAwQzAsXHJcbiAgICBsb2NhbE92ZXJyaWRlOiAweDAwRDhcclxuICB9O1xyXG4gIHByaXZhdGUgb3BjRGFRdWFsaXR5TGltaXQgPSB7XHJcbiAgICBsaW1pdE9rOiAweDAwMDAsXHJcbiAgICBsaW1pdExvdzogMHgwMDAxLFxyXG4gICAgbGltaXRIaWdoOiAweDAwMDIsXHJcbiAgICBjb25zdGFudDogMHgwMDAzXHJcbiAgfTtcclxuICBwcml2YXRlIG9wY0hkYVF1YWxpdHkgPSB7XHJcbiAgICBleHRyYURhdGE6IDB4MDAwMTAwMDAsXHJcbiAgICBpbnRlcnBvbGF0ZWQ6IDB4MDAwMjAwMDAsXHJcbiAgICByYXc6IDB4MDAwNDAwMDAsXHJcbiAgICBjYWxjdWxhdGVkOiAweDAwMDgwMDAwLFxyXG4gICAgbm9Cb3VuZDogMHgwMDEwMDAwMCxcclxuICAgIG5vRGF0YTogMHgwMDIwMDAwMCxcclxuICAgIGRhdGFMb3N0OiAweDAwNDAwMDAwLFxyXG4gICAgY29udmVyc2lvbjogMHgwMDgwMDAwMCxcclxuICAgIHBhcnRpYWw6IDB4MDEwMDAwMDBcclxuICB9O1xyXG4gIHByaXZhdGUgb3ZlcmFsbE1lc3NhZ2VzID0ge1xyXG4gICAgMHgwMDAwOiAnQmFkJyxcclxuICAgIDB4MDA0MDogJ1VuY2VydGFpbicsXHJcbiAgICAweDAwODA6ICdOb3QgZGVmaW5lZCcsXHJcbiAgICAweDAwQzA6ICdHb29kJ1xyXG4gIH07XHJcblxyXG4gIHByaXZhdGUgZGV0YWlsc01lc3NhZ2VzID0ge1xyXG4gICAgLy8gTGltaXQgc3RhdHVzXHJcbiAgICAweDAwMDA6ICdOb3QgbGltaXRlZCcsXHJcbiAgICAweDAwMDE6ICdMb3cgbGltaXRlZCcsXHJcbiAgICAweDAwMDI6ICdIaWdoIGxpbWl0ZWQnLFxyXG4gICAgMHgwMDAzOiAnQ29uc3RhbnQnLFxyXG4gICAgLy8gQmFkXHJcbiAgICAweDAwMDQ6ICdDb25maWcgZXJyb3InLFxyXG4gICAgMHgwMDA4OiAnTm90IGNvbm5lY3RlZCcsXHJcbiAgICAweDAwMGM6ICdEZXZpY2UgZmFpbHVyZScsXHJcbiAgICAweDAwMTA6ICdTZW5zb3IgZmFpbHVyZScsXHJcbiAgICAweDAwMTQ6ICdMYXN0IGtub3duJyxcclxuICAgIDB4MDAxODogJ0NvbW0gZmFpbHVyZScsXHJcbiAgICAweDAwMUM6ICdPdXQgb2Ygc2VydmljZScsXHJcbiAgICAweDAwMjA6ICdJbml0aWFsaXppbmcnLFxyXG4gICAgLy8gVW5jZXJ0YWluXHJcbiAgICAweDAwNDQ6ICdMYXN0IHVzYWJsZScsXHJcbiAgICAweDAwNTA6ICdTZW5zb3JzIG5vdCBhY2N1cmF0ZScsXHJcbiAgICAweDAwNTQ6ICdFbmdpbmVlcmluZyB1bml0cyBleGNlZWRlZCcsXHJcbiAgICAweDAwNTg6ICdTdWItTm9ybWFsJyxcclxuICAgIC8vIEdvb2RcclxuICAgIDB4MDBEODogJ0xvY2FsIG92ZXJyaWRlJyxcclxuICAgIC8vIEhkYSBmbGFnc1xyXG4gICAgMHgwMDAxMDAwMDogJ0V4dHJhIGRhdGEnLFxyXG4gICAgMHgwMDAyMDAwMDogJ0ludGVycG9sYXRlZCcsXHJcbiAgICAweDAwMDQwMDAwOiAnUmF3JyxcclxuICAgIDB4MDAwODAwMDA6ICdDYWxjdWxhdGVkJyxcclxuICAgIDB4MDAxMDAwMDA6ICdObyBib3VuZCcsXHJcbiAgICAweDAwMjAwMDAwOiAnTm8gZGF0YScsXHJcbiAgICAweDAwNDAwMDAwOiAnRGF0YSBsb3N0JyxcclxuICAgIDB4MDA4MDAwMDA6ICdDb252ZXJzaW9uJyxcclxuICAgIDB4MDEwMDAwMDA6ICdQYXJ0aWFsJ1xyXG4gIH07XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHJlcHJlc2VudGF0aW9uIG9mIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgYXNPYmplY3QocXVhbGl0eUFzSW50OiBudW1iZXIpOiBJUXVhbGl0eSB7XHJcbiAgICBsZXQgbWFzazogbnVtYmVyO1xyXG4gICAgY29uc3QgcXVhbGl0eSA9IHt9IGFzIElRdWFsaXR5O1xyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlck1hc2s7XHJcbiAgICBxdWFsaXR5Lm92ZXJhbGwgPSB0aGlzLm92ZXJhbGxNZXNzYWdlc1ttYXNrXTtcclxuXHJcbiAgICBtYXNrID0gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlNYXNrO1xyXG4gICAgaWYgKG1hc2sgJiYgdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza10pIHtcclxuICAgICAgcXVhbGl0eS5kYSA9IHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdO1xyXG4gICAgfVxyXG5cclxuICAgIG1hc2sgPSBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eUZpZWxkTWFza3MubGltaXRGaWVsZDtcclxuICAgIGlmIChtYXNrICYmIHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdKSB7XHJcbiAgICAgIHF1YWxpdHkubGltaXQgPSB0aGlzLmRldGFpbHNNZXNzYWdlc1ttYXNrXTtcclxuICAgIH1cclxuXHJcbiAgICBtYXNrID0gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNIZGFRdWFsaXR5TWFzaztcclxuICAgIGlmIChtYXNrICYmIHRoaXMuZGV0YWlsc01lc3NhZ2VzW21hc2tdKSB7XHJcbiAgICAgIHF1YWxpdHkuaGRhID0gdGhpcy5kZXRhaWxzTWVzc2FnZXNbbWFza107XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcXVhbGl0eTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgYSBzdHJpbmcgd2hpY2ggaXMgYSB3cml0dGVuIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgYXNTdHJpbmcocXVhbGl0eUFzSW50OiBudW1iZXIpIHtcclxuICAgIGxldCBoYXNEYVF1YWxpdHkgPSBmYWxzZTtcclxuICAgIGNvbnN0IHFPYmogPSB0aGlzLmFzT2JqZWN0KHF1YWxpdHlBc0ludCk7XHJcbiAgICBsZXQgcVN0cmluZzogc3RyaW5nO1xyXG5cclxuICAgIHFTdHJpbmcgPSBxT2JqLm92ZXJhbGw7XHJcbiAgICBpZiAocU9iai5kYSkge1xyXG4gICAgICBxU3RyaW5nID0gcVN0cmluZyArICc6ICcgKyBxT2JqLmRhO1xyXG4gICAgICBoYXNEYVF1YWxpdHkgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKHFPYmoubGltaXQpIHtcclxuICAgICAgcVN0cmluZyA9IHFTdHJpbmcgK1xyXG4gICAgICAgIChoYXNEYVF1YWxpdHkgPyAnLCAnIDogJzogJykgKyBxT2JqLmxpbWl0O1xyXG4gICAgICBoYXNEYVF1YWxpdHkgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKHFPYmouaGRhKSB7XHJcbiAgICAgIHFTdHJpbmcgPSBxU3RyaW5nICtcclxuICAgICAgICAoaGFzRGFRdWFsaXR5ID8gJywgJyA6ICc6ICcpICsgcU9iai5oZGE7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcVN0cmluZztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIE9QQyBEQSBxdWFsaXR5IHBvcnRpb24gKGxvd2VyIDE2IGJpdHMpLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eU1hc2s7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIHRoZSBPUEMgbGltaXQgc3RhdHVzIHBvcnRpb24uIChub3QgbGltaXRlZCwgbG93IGxpbWl0ZWQsIGhpZ2ggbGltaXRlZCBvciBjb25zdGFudCkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICByZXR1cm4gcXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLmxpbWl0RmllbGQ7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIHRoZSBPUEMgREEgTWFzdGVyIHF1YWxpdHkgcG9ydGlvbiAoZ29vZCwgdW5jZXJ0YWluLCBiYWQsIG9yIHVuZGVmaW5lZCkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRTaW1wbGVRdWFsaXR5KHF1YWxpdHlBc0ludDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlck1hc2s7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIHRoZSBPUEMgSERBIHF1YWxpdHkgcG9ydGlvbiAodXBwZXIgMTYgYml0cykuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludFxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBxdWFsaXR5QXNJbnQgJiB0aGlzLm9wY0hkYVF1YWxpdHlNYXNrO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQSBtZXRob2QgZm9yIGNoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaXMgb2YgZ29vZCBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNHb29kKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5xdWFsaXR5KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlNYXN0ZXIuZ29vZDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEEgbWV0aG9kIGZvciBjaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGlzIG9mIHVuY2VydGFpbiBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNVbmNlcnRhaW4ocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAocXVhbGl0eUFzSW50ICYgdGhpcy5vcGNEYVF1YWxpdHlGaWVsZE1hc2tzLnF1YWxpdHkpID09PSB0aGlzLm9wY0RhUXVhbGl0eU1hc3Rlci51bmNlcnRhaW47XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBBIG1ldGhvZCBmb3IgY2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBpcyBvZiBiYWQgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzQmFkKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHF1YWxpdHlBc0ludCAmIHRoaXMub3BjRGFRdWFsaXR5RmllbGRNYXNrcy5xdWFsaXR5KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlNYXN0ZXIuYmFkO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFDb25maWdFcnJvcihxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuY29uZmlnRXJyb3IpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb25maWdFcnJvcjtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFOb3RDb25uZWN0ZWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLm5vdENvbm5lY3RlZCkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLm5vdENvbm5lY3RlZDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFEZXZpY2VGYWlsdXJlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5kZXZpY2VGYWlsdXJlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuZGV2aWNlRmFpbHVyZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFTZW5zb3JGYWlsdXJlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JGYWlsdXJlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc2Vuc29yRmFpbHVyZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFMYXN0S25vd24ocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxhc3RLbm93bikgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmxhc3RLbm93bjtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFDb21tRmFpbHVyZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuY29tbUZhaWx1cmUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5jb21tRmFpbHVyZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFPdXRPZlNlcnZpY2UocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLm91dE9mU2VydmljZSkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLm91dE9mU2VydmljZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFJbml0aWFsaXppbmcocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmluaXRpYWxpemluZykgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLmluaXRpYWxpemluZztcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFMYXN0VXNhYmxlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sYXN0VXNhYmxlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubGFzdFVzYWJsZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFTZW5zb3JOb3RBY2N1cmF0ZShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0RhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuc2Vuc29yTm90QWNjdXJhdGUpID09PSB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5zZW5zb3JOb3RBY2N1cmF0ZTtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFFbmdVbml0c0V4Y2VlZGVkKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5lbmdVbml0c0V4Y2VlZGVkKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMuZW5nVW5pdHNFeGNlZWRlZDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFTdWJOb3JtYWwocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNEYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnN1Yk5vcm1hbCkgPT09IHRoaXMub3BjRGFRdWFsaXR5U3RhdHVzLnN1Yk5vcm1hbDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIERBIHF1YWxpdHkgKGdvb2QsIGJhZCwgdW5jZXJ0YWluKSB3aXRoIGFwcHJvcHJpYXRlIHN1YnN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzRGFMb2NhbE92ZXJyaWRlKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjRGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eVN0YXR1cy5sb2NhbE92ZXJyaWRlKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlTdGF0dXMubG9jYWxPdmVycmlkZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBsaW1pdCBzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0xpbWl0T2socXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdE9rKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdE9rO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBPUEMgbGltaXQgc3RhdHVzLlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNMaW1pdExvdyhxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0xpbWl0U3RhdHVzKHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0RhUXVhbGl0eUxpbWl0LmxpbWl0TG93KSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdExvdztcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgT1BDIGxpbWl0IHN0YXR1cy5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzTGltaXRIaWdoKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjTGltaXRTdGF0dXMocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjRGFRdWFsaXR5TGltaXQubGltaXRIaWdoKSA9PT0gdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5saW1pdEhpZ2g7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIE9QQyBsaW1pdCBzdGF0dXMuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0xpbWl0Q29uc3RhbnQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNMaW1pdFN0YXR1cyhxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNEYVF1YWxpdHlMaW1pdC5jb25zdGFudCkgPT09IHRoaXMub3BjRGFRdWFsaXR5TGltaXQuY29uc3RhbnQ7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUV4dHJhRGF0YShxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5leHRyYURhdGEpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuZXh0cmFEYXRhO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFJbnRlcnBvbGF0ZWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuaW50ZXJwb2xhdGVkKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmludGVycG9sYXRlZDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhUmF3KHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LnJhdykgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5yYXc7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYUNhbGN1bGF0ZWQocXVhbGl0eUFzSW50OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAodGhpcy5nZXRPcGNIZGFRdWFsaXR5KHF1YWxpdHlBc0ludCkgJlxyXG4gICAgICB0aGlzLm9wY0hkYVF1YWxpdHkuY2FsY3VsYXRlZCkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5jYWxjdWxhdGVkO1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFOb0JvdW5kKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5Lm5vQm91bmQpID09PSB0aGlzLm9wY0hkYVF1YWxpdHkubm9Cb3VuZDtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhTm9EYXRhKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5Lm5vRGF0YSkgPT09IHRoaXMub3BjSGRhUXVhbGl0eS5ub0RhdGE7XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIENoZWNraW5nIGlmIHRoZSBwYXNzZWQgYXJndW1lbnQgaGFzIGFwcHJvcHJpYXRlIE9QQyBIREEgcXVhbGl0eSB3aXRoIGFzc29jaWF0ZWQgT1BDIERBIHF1YWxpdHkuXHJcbiAgICogQHBhcmFtIHF1YWxpdHlBc0ludCAtIFRoZSBudW1iZXIgcmVwcmVzZW50aW5nIHRoZSBxdWFsaXR5IHZhbHVlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpc0hkYURhdGFMb3N0KHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmRhdGFMb3N0KSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LmRhdGFMb3N0O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVja2luZyBpZiB0aGUgcGFzc2VkIGFyZ3VtZW50IGhhcyBhcHByb3ByaWF0ZSBPUEMgSERBIHF1YWxpdHkgd2l0aCBhc3NvY2lhdGVkIE9QQyBEQSBxdWFsaXR5LlxyXG4gICAqIEBwYXJhbSBxdWFsaXR5QXNJbnQgLSBUaGUgbnVtYmVyIHJlcHJlc2VudGluZyB0aGUgcXVhbGl0eSB2YWx1ZS5cclxuICAgKi9cclxuICBwdWJsaWMgaXNIZGFDb252ZXJzaW9uKHF1YWxpdHlBc0ludDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gKHRoaXMuZ2V0T3BjSGRhUXVhbGl0eShxdWFsaXR5QXNJbnQpICZcclxuICAgICAgdGhpcy5vcGNIZGFRdWFsaXR5LmNvbnZlcnNpb24pID09PSB0aGlzLm9wY0hkYVF1YWxpdHkuY29udmVyc2lvbjtcclxuICB9XHJcbiAgLyoqXHJcbiAgICogQ2hlY2tpbmcgaWYgdGhlIHBhc3NlZCBhcmd1bWVudCBoYXMgYXBwcm9wcmlhdGUgT1BDIEhEQSBxdWFsaXR5IHdpdGggYXNzb2NpYXRlZCBPUEMgREEgcXVhbGl0eS5cclxuICAgKiBAcGFyYW0gcXVhbGl0eUFzSW50IC0gVGhlIG51bWJlciByZXByZXNlbnRpbmcgdGhlIHF1YWxpdHkgdmFsdWUuXHJcbiAgICovXHJcbiAgcHVibGljIGlzSGRhUGFydGlhbChxdWFsaXR5QXNJbnQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuICh0aGlzLmdldE9wY0hkYVF1YWxpdHkocXVhbGl0eUFzSW50KSAmXHJcbiAgICAgIHRoaXMub3BjSGRhUXVhbGl0eS5wYXJ0aWFsKSA9PT0gdGhpcy5vcGNIZGFRdWFsaXR5LnBhcnRpYWw7XHJcbiAgfVxyXG59XHJcblxyXG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCAqIGFzIG1vbWVudCBmcm9tICdtb21lbnQtdGltZXpvbmUnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgTW9tZW50SGVscGVyU2VydmljZSB7XHJcbiAgICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwgPSAnWVlZWS1NTS1ERFRISDptbTpzcy5TU1NbWl0nO1xyXG4gICAgcHVibGljIHN0YXRpYyByZWFkb25seSBNT01FTlRfREFURVRJTUVfRk9STUFUX1RaX0ZVTEwgPSAnWVlZWS1NTS1ERFRISDptbTpzcy5TU1NaJztcclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBhcHBseSB0aW1lem9uZSB0byBVVEMgc3RyaW5nLlxyXG4gICAgICogUmV0dXJucyBkYXRlIHN0cmluZyBpbiBtYXhpbXVtIGphdmFzY3JpcHQgcmVzb2x1dGlvbiBwb3NzaWJsZSwgc3VwcG9ydGVkIGJ5IHVzaW5nIG1vbWVudCBsaWJyYXJ5IChKYXZhc2NyaXB0IGRhdGUgLSBtaWxsaXNlY29uZHMpLlxyXG4gICAgICogUmVzb2x1dGlvbiBmb3IgdGltZSBhZnRlciBtaWxsaXNlY29uZHMgd2lsbCBiZSBsb3N0LlxyXG4gICAgICogQHBhcmFtIGRhdGV0aW1lIGRhdGV0aW1lIHN0cmluZyBpbiBVVEMgZm9ybWF0XHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgdGltZXpvbmUgdG8gYXBwbHlcclxuICAgICAqIElmIHdvcmtpbmcgd2l0aCB0aW1lem9uZSBpbiBkYXRldGltZSBzdHJpbmcgaXQgaXMgcmVjb21tZW5kZWQgdG8gdXNlIG1vbWVudC5wYXJzZVpvbmUgdG8gcHJlc2VydmUgdGltZXpvbmUgaW5mb3JtYXRpb24uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgYXBwbHlUaW1lem9uZShkYXRldGltZTogc3RyaW5nLCB0aW1lem9uZTogc3RyaW5nKSB7XHJcbiAgICAgIGNvbnN0IG1EYXRlID0gbW9tZW50LnV0YyhkYXRldGltZSk7XHJcbiAgICAgIG1EYXRlLnR6KHRpbWV6b25lKTtcclxuICAgICAgcmV0dXJuIG1EYXRlLmZvcm1hdCh0aGlzLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVFpfRlVMTCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN0YXRpYyBnZXRBbGxUaW1lem9uZXMoKSB7XHJcbiAgICAgICAgcmV0dXJuIG1vbWVudC50ei5uYW1lcygpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgaXNWYWxpZFRpbWV6b25lKHRpbWV6b25lKSB7XHJcbiAgICAgIHJldHVybiB0aW1lem9uZSAmJiBtb21lbnQudHouem9uZSh0aW1lem9uZSk7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCAqIGFzIF8gZnJvbSAnbG9kYXNoJztcclxuaW1wb3J0ICogYXMgbW9tZW50IGZyb20gJ21vbWVudC10aW1lem9uZSc7XHJcbmltcG9ydCB7IE9wY1F1YWxpdHlTZXJ2aWNlIH0gZnJvbSAnLi9vcGMtcXVhbGl0eS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgbWFwLCBjb25jYXRNYXAsIGV4cGFuZCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnLCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUwgfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7IGlkZW50aWZpZXIsIElSZXNwb25zZSB9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0IHsgQmFzZVNlcnZpY2UgfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7IE1vbWVudEhlbHBlclNlcnZpY2UgfSBmcm9tICcuL21vbWVudC1oZWxwZXIuc2VydmljZSc7XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB2cXQgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzIHtcclxuICAgIHY6IHN0cmluZyB8IG51bWJlciB8IGJvb2xlYW47XHJcbiAgICBxOiBudW1iZXI7XHJcbiAgICB0OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHZxdCBsaXN0IHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlIGV4dGVuZHMgSVJlc3BvbnNlIHtcclxuICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2Ugc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzUmVzcG9uc2Uge1xyXG4gICAgdGltZVBlcmlvZDogSVRpbWVQZXJpb2RSZXNwb25zZTtcclxuICAgIHJlc3VsdHM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VbXTtcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgVGltZXNlcmllc1Jlc3BvbnNlID0gSVRpbWVzZXJpZXNSZXNwb25zZTtcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIGludGVybmFsIG9iamVjdCBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3Qge1xyXG4gICAgZnFuOiBzdHJpbmc7XHJcbiAgICBuYW1lPzogc3RyaW5nO1xyXG4gICAgZW5naW5lZXJpbmdVbml0Pzogc3RyaW5nO1xyXG4gICAgdmFsdWVUeXBlPzogc3RyaW5nO1xyXG4gICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSB0aW1lIHBlcmlvZCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVQZXJpb2RSZXNwb25zZSB7XHJcbiAgICBzdGFydDogc3RyaW5nO1xyXG4gICAgZW5kOiBzdHJpbmc7XHJcbiAgICBkdXJhdGlvbjogbnVtYmVyO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBpbnRlcm5hbCAocmF3KSBzdHJ1Y3R1cmUuICovXHJcbmludGVyZmFjZSBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwge1xyXG4gICAgdGltZVBlcmlvZDogSVRpbWVQZXJpb2RSZXNwb25zZTtcclxuICAgIGZxbnNSZXN1bHRzPzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsT2JqZWN0W107XHJcbiAgICBxdWVyeVJlc3VsdHM/OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVxdWVzdCB0aW1lIHBlcmlvZCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVQZXJpb2Qge1xyXG4gICAgc3RhcnQ/OiBEYXRlIHwgbW9tZW50Lk1vbWVudDtcclxuICAgIGVuZD86IERhdGUgfCBtb21lbnQuTW9tZW50O1xyXG4gICAgZHVyYXRpb24/OiBudW1iZXI7XHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB7XHJcbiAgICBpbmNsdWRlR29vZCA9IDEsXHJcbiAgICBpbmNsdWRlQmFkID0gMixcclxuICAgIGluY2x1ZGVVbmNlcnRhaW4gPSA0LFxyXG4gICAgaW5jbHVkZUFsbCA9IDdcclxufVxyXG5cclxuZXhwb3J0IGVudW0gVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdCB7XHJcbiAgICB3aG9sZUludGVydmFsID0gJ3dob2xlSW50ZXJ2YWwnLFxyXG4gICAgaW5jcmVtZW50cyA9ICdpbmNyZW1lbnRzJ1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBTYW1wbGluZ1R5cGVzIHtcclxuICAgIEludGVycG9sYXRpdmUgPSAnSW50ZXJwb2xhdGl2ZScsXHJcbiAgICBTYW1wbGVBbmRIb2xkID0gJ1NhbXBsZUFuZEhvbGQnLFxyXG4gICAgTGluZWFyID0gJ0xpbmVhcicsXHJcbiAgICBUb3RhbCA9ICdUb3RhbCcsXHJcbiAgICBTdW0gPSAnU3VtJyxcclxuICAgIEF2ZXJhZ2UgPSAnQXZlcmFnZScsXHJcbiAgICBUaW1lQXZlcmFnZSA9ICdUaW1lQXZlcmFnZScsXHJcbiAgICBDb3VudCA9ICdDb3VudCcsXHJcbiAgICBTdGFuZGFyZERldmlhdGlvbiA9ICdTdGFuZGFyZERldmlhdGlvbicsXHJcbiAgICBNaW5pbXVtQWN0dWFsVGltZSA9ICdNaW5pbXVtQWN0dWFsVGltZScsXHJcbiAgICBNYXhpbXVtID0gJ01heGltdW0nLFxyXG4gICAgU3RhcnQgPSAnU3RhcnQnLFxyXG4gICAgRW5kID0gJ0VuZCcsXHJcbiAgICBEZWx0YSA9ICdEZWx0YScsXHJcbiAgICBWYXJpYW5jZSA9ICdWYXJpYW5jZScsXHJcbiAgICBSYW5nZSA9ICdSYW5nZScsXHJcbiAgICBEdXJhdGlvbkdvb2QgPSAnRHVyYXRpb25Hb29kJyxcclxuICAgIER1cmF0aW9uQmFkID0gJ0R1cmF0aW9uQmFkJyxcclxuICAgIFBlcmNlbnRHb29kID0gJ1BlcmNlbnRHb29kJyxcclxuICAgIFBlcmNlbnRCYWQgPSAnUGVyY2VudEJhZCcsXHJcbiAgICBXb3JzdFF1YWxpdHkgPSAnV29yc3RRdWFsaXR5JyxcclxuICAgIFRpbWVBdmVyYWdlU2FtcGxlQW5kSG9sZCA9ICdUaW1lQXZlcmFnZVNhbXBsZUFuZEhvbGQnLFxyXG4gICAgVG90YWxTYW1wbGVBbmRIb2xkID0gJ1RvdGFsU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBNaW5TYW1wbGVBbmRIb2xkID0gJ01pblNhbXBsZUFuZEhvbGQnLFxyXG4gICAgTWF4U2FtcGxlQW5kSG9sZCA9ICdNYXhTYW1wbGVBbmRIb2xkJyxcclxuICAgIEN1bXVsYXRpdmVUb3RhbCA9ICdDdW11bGF0aXZlVG90YWwnXHJcbn1cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgc2FtcGxpbmcgZGVmaW5pdGlvbi4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJU2FtcGxpbmdEZWZpbml0aW9uIHtcclxuICAgIC8qKiBUaGUgbnVtYmVyIG9mIHRoZSBzbGljZXMgdGhhdCB0aGUgcHJvdmlkZWQgdGltZSBwZXJpb2Qgc2hvdWxkIGJlIGN1dCBpbnRvLlxyXG4gICAgICogSWYgemVybyB0aGVuIGEgbm9uLXplcm8gRGVsdGFUIHZhbHVlIG5lZWRzIHRvIGJlIHByb3ZpZGVkLiAqL1xyXG4gICAgc2xpY2VDb3VudD86IG51bWJlcjtcclxuICAgIC8qKiBJZiB0aGUgc2xpY2UgY291bnQgaXMgemVybywgdGhlbiBhIG5vbi16ZXJvIHZhbHVlIHJlcHJlc2VudGluZyB0aGUgd2lkdGggb2YgYSB0aW1lIHNsaWNlIGluIHNlY29uZHNcclxuICAgICAqIG11c3QgYmUgcHJvdmlkZWQuIEEgcG9zaXRpdmUgdmFsdWUgbWVhbnMgdGhlIHNsaWNlcyBhcmUgYW5jaG9yZWQgYXQgdGhlIHN0YXJ0IHRpbWUgb2YgdGhlIHJlcXVlc3RlZCB0aW1lIHBlcmlvZC5cclxuICAgICAqIEEgbmVnYXRpdmUgdmFsdWUgaW5kaWNhdGVzIGFuY2hvcmluZyBhdCB0aGUgZW5kIG9mIHRoZSB0aW1lIHBlcmlvZC4gKi9cclxuICAgIGRlbHRhVD86IG51bWJlcjtcclxuICAgIC8qKiBPbmUgb2YgdGhlIHNhbXBsaW5nIHR5cGVzIHN1cHBvcnRlZCBieSB0aGUgdGltZXNlcmllcy4gU2VlIFNhbXBsaW5nVHlwZXMgZW51bS4gKi9cclxuICAgIHNhbXBsaW5nVHlwZTogU2FtcGxpbmdUeXBlcztcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFRpbWVzZXJpZXNSZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogVGltZXNlcmllcyByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFucyBMaXN0IG9mIGZxbnMgKGlkZW50aWZpY2F0b3JzKSB0byBiZSB1c2VkIGZvciByZXF1ZXN0XHJcbiAgICAgKiBAcGFyYW0gdGltZVBlcmlvZCBTZXR0aW5ncyBmb3IgdGltZSBwZXJpb2Qgb2YgdGltZXNlcmllcyByZXF1ZXN0LCBlLmcuIHN0YXJ0IHRpbWUsIGVuZCB0aW1lIGFuZCBkdXJhdGlvblxyXG4gICAgICogQHBhcmFtIHNhbXBsaW5nRGVmaW5pdGlvbiAoT3B0aW9uYWwpIGRlZmluaXRpb24gZm9yIHRpbWVzZXJpZXMgdG8gc2V0IGhvdyB0byBwcm9jZXNzIGRhdGEsIHdoaWNoIFNhbXBsaW5nIHR5cGUgdG8gdXNlXHJcbiAgICAgKiBAcGFyYW0gdGltZURlYWRCYW5kIChPcHRpb25hbCkgU2V0dGluZ3MgZm9yIHRpbWUgZGVhZGJhbmQgLSBwb3NzaWJsZSBzdHJ1Y3R1cmUgW3dzXVstXSBkIHwgZC5oaDptbVs6c3NbLmZmXV0gfCBoaDptbVs6c3NbLmZmXV0gW3dzXVxyXG4gICAgICogQHBhcmFtIHZhbHVlRGVhZEJhbmQgKE9wdGlvbmFsKSBTcGVjaWZpZXMgdGhlIHZhbHVlIGRlYWQgYmFuZCwgY2FuIGJlIGFueSBmbG9hdCBudW1iZXIuXHJcbiAgICAgKiBAcGFyYW0gcXVhbGl0eUZpbHRlciAoT3B0aW9uYWwpIFRoaXMgaXMgYSBiaXQgZmxhZyB2YWx1ZSB3aXRoIHRoZSBmb2xsb3dpbmcgb3B0aW9uczpcclxuICAgICAqIEluY2x1ZGVHb29kIDogMVxyXG4gICAgICogSW5jbHVkZUJhZCA6IDJcclxuICAgICAqIEluY2x1ZGVVbmNlcnRhaW4gOiA0XHJcbiAgICAgKiBJbmNsdWRlQWxsIDogN1xyXG4gICAgICogVXNlIGEgdmFsdWUgZnJvbSBwcmVkZWZpbmVkIGVudW0gVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IG9yIHNwZWNpZnkgYSB2YWxsdWUuXHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgZnFuczogaWRlbnRpZmllcltdLFxyXG4gICAgICAgIHByaXZhdGUgdGltZVBlcmlvZDogSVRpbWVQZXJpb2QsXHJcbiAgICAgICAgcHJpdmF0ZSBzYW1wbGluZ0RlZmluaXRpb24/OiBJU2FtcGxpbmdEZWZpbml0aW9uLFxyXG4gICAgICAgIHByaXZhdGUgdGltZURlYWRCYW5kPzogc3RyaW5nLFxyXG4gICAgICAgIHByaXZhdGUgdmFsdWVEZWFkQmFuZD86IG51bWJlcixcclxuICAgICAgICBwcml2YXRlIHF1YWxpdHlGaWx0ZXI/OiBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgfCBudW1iZXJcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuc2V0RnFucyhmcW5zKTtcclxuICAgICAgICB0aGlzLnNldFRpbWVQZXJpb2QodGltZVBlcmlvZCk7XHJcbiAgICAgICAgdGhpcy5zZXRTYW1wbGluZ0RlZmluaXRpb24oc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFkZCBvbmUgZnFuIHRvIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gZnFuIGZxbiBpZGVudGlmaWNhdG9yIHRvIGFkZFxyXG4gICAgICovXHJcbiAgICBhZGRGcW4oZnFuOiBpZGVudGlmaWVyKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zLnB1c2goZnFuKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlbW92ZSBvbmUgZnFuIGZyb20gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICBjb25zdCBpbmRleCA9IF8uaW5kZXhPZih0aGlzLmZxbnMsIGZxbik7XHJcbiAgICAgICAgaWYgKGluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmZxbnMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZXBsYWNlIGN1cnJlbnQgZnFucyBpbiByZXF1ZXN0IHRvIG5ldyBvbmVzLlxyXG4gICAgICogQHBhcmFtIGZxbnMgbGlzdCBvZiBmcW4gaWRlbnRpZmljYXRvcnMgdG8gc2V0XHJcbiAgICAgKi9cclxuICAgIHNldEZxbnMoZnFuczogaWRlbnRpZmllcltdKSB7XHJcbiAgICAgICAgdGhpcy5mcW5zID0gXy5jbG9uZShmcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBmcW4gaWRlbnRpZmljYXRvcnMuXHJcbiAgICAgKi9cclxuICAgIGdldEZxbnMoKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy5mcW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCByZXF1ZXN0IHRpbWUgcGVyaW9kLlxyXG4gICAgICogQHBhcmFtIHRpbWVQZXJpb2RcclxuICAgICAqL1xyXG4gICAgc2V0VGltZVBlcmlvZCh0aW1lUGVyaW9kOiBJVGltZVBlcmlvZCkge1xyXG4gICAgICAgIHRoaXMudGltZVBlcmlvZCA9IF8uY2xvbmUodGltZVBlcmlvZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgcmVxdWVzdCB0aW1lIHBlcmlvZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VGltZVBlcmlvZCgpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLnRpbWVQZXJpb2QpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHNhbXBsaW5nIGRlZmluaXRpb24uXHJcbiAgICAgKiBAcGFyYW0gc2FtcGxpbmdEZWZpbml0aW9uXHJcbiAgICAgKi9cclxuICAgIHNldFNhbXBsaW5nRGVmaW5pdGlvbihzYW1wbGluZ0RlZmluaXRpb24/OiBJU2FtcGxpbmdEZWZpbml0aW9uKSB7XHJcbiAgICAgICAgdGhpcy5zYW1wbGluZ0RlZmluaXRpb24gPSBfLmNsb25lKHNhbXBsaW5nRGVmaW5pdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3Qgc2FtcGxpbmcgZGVmaW5pdGlvbi5cclxuICAgICAqL1xyXG4gICAgZ2V0U2FtcGxpbmdEZWZpbml0aW9uKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMuc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCB0aW1lIGRlYWRiYW5kLlxyXG4gICAgICogQHBhcmFtIHRpbWVEZWFkQmFuZFxyXG4gICAgICovXHJcbiAgICBzZXRUaW1lRGVhZEJhbmQodGltZURlYWRCYW5kPzogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy50aW1lRGVhZEJhbmQgPSB0aW1lRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgdGltZSBkZWFkYmFuZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VGltZURlYWRiYW5kKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLnRpbWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCB2YWx1ZSBkZWFkYmFuZC5cclxuICAgICAqIEBwYXJhbSB2YWx1ZURlYWRCYW5kXHJcbiAgICAgKi9cclxuICAgIHNldFZhbHVlRGVhZEJhbmQodmFsdWVEZWFkQmFuZD86IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMudmFsdWVEZWFkQmFuZCA9IHZhbHVlRGVhZEJhbmQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgdmFsdWUgZGVhZGJhbmQuXHJcbiAgICAgKi9cclxuICAgIGdldFZhbHVlRGVhZEJhbmQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudmFsdWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldCBxdWFsaXR5IGZpbHRlci5cclxuICAgICAqIEBwYXJhbSBxdWFsaXR5RmlsdGVyXHJcbiAgICAgKi9cclxuICAgIHNldFF1YWxpdHlGaWx0ZXIocXVhbGl0eUZpbHRlcj86IFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB8IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMucXVhbGl0eUZpbHRlciA9IHF1YWxpdHlGaWx0ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBHZXQgYWN0dWFsIHJlcXVlc3QgcXVhbGl0eSBmaWx0ZXIuXHJcbiAgICAgKi9cclxuICAgIGdldFF1YWxpdHlGaWx0ZXIoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMucXVhbGl0eUZpbHRlcjtcclxuICAgIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFRoaXMgc2VydmljZSBwcm92aWRlcyBhIHNldCBvZiBtZXRob2RzIGZvciBzZW5kaW5nIHJlcXVlc3RzIHRvIG9idGFpbiB0aW1lc2VyaWVzIGRhdGEuXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZXh0ZW5kcyBCYXNlU2VydmljZSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZyxcclxuICAgICAgICBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIG9wY1F1YWxpdHlTdmM6IE9wY1F1YWxpdHlTZXJ2aWNlKSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL3RpbWVzZXJpZXMvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHRpbWVzZXJpZXMgcmVxdWVzdCB0byBzZXJ2ZXIsIGJ1dCBvbmx5IG9uY2UuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIHRpbWV6b25lIHRvIGFwcGx5IHRvIHRpbWVzZXJpZXMgcmVzcG9uc2UgZGF0YSwgb25seSBtb21lbnQgdGltZXpvbmVzIGFyZSBzdXBwb3J0ZWRcclxuICAgICAqIElmIHdvcmtpbmcgd2l0aCB0aW1lem9uZSBpbiBkYXRldGltZSBzdHJpbmcgaXQgaXMgcmVjb21tZW5kZWQgdG8gdXNlIG1vbWVudC5wYXJzZVpvbmUgdG8gcHJlc2VydmUgdGltZXpvbmUgaW5mb3JtYXRpb24uXHJcbiAgICAgKiBNb21lbnQgdGltZXpvbmVzIHRoYXQgc3RhcnQgd2l0aCBcIkV0Yy9HTVRcIiB1c2UgUE9TSVgtc3R5bGUgc2lnbnMgaW4gdGhlIFpvbmUgbmFtZXMgYW5kIHRoZSBvdXRwdXQgYWJicmV2aWF0aW9ucyxcclxuICAgICAqIGV2ZW4gdGhvdWdoIHRoaXMgaXMgdGhlIG9wcG9zaXRlIG9mIHdoYXQgbWFueSBwZW9wbGUgZXhwZWN0LlxyXG4gICAgICogUE9TSVggaGFzIHBvc2l0aXZlIHNpZ25zIHdlc3Qgb2YgR3JlZW53aWNoLCBidXQgbWFueSBwZW9wbGUgZXhwZWN0XHJcbiAgICAgKiBwb3NpdGl2ZSBzaWducyBlYXN0IG9mIEdyZWVud2ljaC4gIEZvciBleGFtcGxlLCBUWj0nRXRjL0dNVCs0JyB1c2VzXHJcbiAgICAgKiB0aGUgYWJicmV2aWF0aW9uIFwiR01UKzRcIiBhbmQgY29ycmVzcG9uZHMgdG8gNCBob3VycyBiZWhpbmQgVVRcclxuICAgICAqIChpLmUuIHdlc3Qgb2YgR3JlZW53aWNoKSBldmVuIHRob3VnaCBtYW55IHBlb3BsZSB3b3VsZCBleHBlY3QgaXQgdG9cclxuICAgICAqIG1lYW4gNCBob3VycyBhaGVhZCBvZiBVVCAoaS5lLiBlYXN0IG9mIEdyZWVud2ljaCkuXHJcbiAgICAgKi9cclxuICAgIGdldE9uY2UocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIHRpbWV6b25lPzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICBsZXQgdHo6IHN0cmluZztcclxuICAgICAgICBpZiAoTW9tZW50SGVscGVyU2VydmljZS5pc1ZhbGlkVGltZXpvbmUodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIHR6ID0gdGltZXpvbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+XHJcbiAgICAgICAgICAgIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0eikpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byByZXR1cm4gYW4gb2JzZXJ2YWJsZSB3aGljaCBpbW1lZGlhdGVsbHkgZXJyb3JzIG91dCB3aXRoIGdpdmVuIGVycm9yIHN0cmluZy5cclxuICAgICAqIEBwYXJhbSBlcnJvclN0cmluZ1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRFcnJvck9ic2VydmFibGUoZXJyb3JTdHJpbmc6IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4oKG9ic2VydmVyKSA9PiB7XHJcbiAgICAgICAgICAgIG9ic2VydmVyLmVycm9yKGVycm9yU3RyaW5nKTtcclxuICAgICAgICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ic2VydmVyLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gYXBwbHkgdGltZXpvbmUgdG8gd2hvbGVcclxuICAgICAqIEBwYXJhbSB2cXREYXRhIGxpc3Qgb2YgVlFUIGRhdGFcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSB0aW1lem9uZSBzdHJpbmdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfYXBwbHlUaW1lem9uZVRvVnF0RGF0YSh2cXREYXRhOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdLCB0aW1lem9uZSkge1xyXG4gICAgICAgIF8uZWFjaCh2cXREYXRhLCAodnF0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykgPT4ge1xyXG4gICAgICAgICAgICB2cXQudCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZSh2cXQudCwgdGltZXpvbmUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiB2cXREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIGdldCBmaXJzdCB2YWx1ZSBiZWZvcmUgbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgaW4gY3VycmVudCBkYXRhLlxyXG4gICAgICpcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgbmV4dFN0YXJ0TW9tZW50OiBtb21lbnQuTW9tZW50KTpcclxuICAgICAgICBNYXA8c3RyaW5nLCBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cz4ge1xyXG4gICAgICAgIGNvbnN0IGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzOiBNYXA8c3RyaW5nLCBhbnk+ID0gbmV3IE1hcCgpO1xyXG4gICAgICAgIGxldCBsYXN0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cztcclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChlbCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIV8uaXNOaWwoZWwpICYmIGVsLnZhbHVlcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGxhc3QgPSBfLmxhc3QoZWwudmFsdWVzKTtcclxuICAgICAgICAgICAgICAgIGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzLnNldChlbC5mcW4sIGxhc3QpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiBiZWZvcmVOZXh0UmVxdWVzdFZhbHVlcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldHMgc3RhcnQgdGltZSBmb3IgbmV4dCByZXF1ZXN0IHdoZW4gZ2V0dGluZyBkYXRhIHJlcGVhdGVkbHkuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QoXHJcbiAgICAgICAgcmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgb3JpZ2luYWxEdXJhdGlvbjogbnVtYmVyLCByZXBlYXRlZEludGVydmFsOiBudW1iZXIpOiBtb21lbnQuTW9tZW50IHtcclxuICAgICAgICBjb25zdCBvcGNRdWFsaXR5U3ZjID0gdGhpcy5vcGNRdWFsaXR5U3ZjO1xyXG4gICAgICAgIGZ1bmN0aW9uIGdldExhc3RUaW1lVG9Vc2UoZnFuUmVzdWx0OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3QpOiBzdHJpbmcge1xyXG4gICAgICAgICAgICBjb25zdCB0aW1lU3RyaW5nID0gXy5maXJzdChmcW5SZXN1bHQudmFsdWVzKS50O1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IGZxblJlc3VsdC52YWx1ZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGZxblJlc3VsdC52YWx1ZXNbaV07XHJcbiAgICAgICAgICAgICAgICBpZiAoIW9wY1F1YWxpdHlTdmMuaXNIZGFJbnRlcnBvbGF0ZWQodmFsLnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbC50O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gdGltZVN0cmluZztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCByZXN1bHQ6IG1vbWVudC5Nb21lbnQ7XHJcbiAgICAgICAgY29uc3QgY3VycmVudFRpbWVNaW51c0R1cmF0aW9uID0gbW9tZW50LnV0YygpLnN1YnRyYWN0KE1hdGguYWJzKG9yaWdpbmFsRHVyYXRpb24pLCAnc2Vjb25kcycpO1xyXG5cclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChmcW5SZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwoZnFuUmVzdWx0KSB8fCBmcW5SZXN1bHQudmFsdWVzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgLy8gbm8gdGltZXNlcmllcyBkYXRhXHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY29uc3QgbGFzdFZhbHVlID0gbW9tZW50LnV0YyhnZXRMYXN0VGltZVRvVXNlKGZxblJlc3VsdCkpO1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChyZXN1bHQpIHx8IHJlc3VsdC5pc0FmdGVyKGxhc3RWYWx1ZSkpIHtcclxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IGxhc3RWYWx1ZS5jbG9uZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChfLmlzTmlsKHJlc3VsdCkpIHtcclxuICAgICAgICAgICAgLy8gbm8gZ29vZCBxdWFsaXR5IC0gYWRkIHBlcmlvZCB0byByZXNwb25zZSBzdGFydCB0aW1lIC0gYXMgZGVmYXVsdCBmb3IgbmV4dCByZXF1ZXN0XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCkuYWRkKHJlcGVhdGVkSW50ZXJ2YWwsICdtaWxsaXNlY29uZHMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50VGltZU1pbnVzRHVyYXRpb24uaXNBZnRlcihyZXN1bHQpKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbi5jbG9uZSgpLmFkZChyZXBlYXRlZEludGVydmFsLCAnbWlsbGlzZWNvbmRzJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgKiBGdW5jdGlvbiB0byBvcHRpb25hbGx5IGZpbHRlciBmaXJzdCB2YWx1ZSBpbiByZXBlYXRlZCByZXF1ZXN0IHdoZW4gaXQgaXMgaW50ZXJwb2xhdGVkIGJldHdlZW5cclxuICAgICogdHdvIGdvb2QvYmFkIG9uZXMuIERpcmVjdGx5IG1vZGlmaWVzIHJlc3BvbnNlIGlucHV0IHBhcmFtZXRlci5cclxuICAgICovXHJcbiAgICBwcml2YXRlIF9maWx0ZXJTdGFydFJlc3BvbnNlRGF0YShcclxuICAgICAgICByZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLFxyXG4gICAgICAgIHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YTogTWFwPHN0cmluZywgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHM+LCByZXF1ZXN0VGltZVBlcmlvZDogSVRpbWVQZXJpb2QpIHtcclxuICAgICAgICBsZXQgZmlyc3RWcXQ7XHJcbiAgICAgICAgbGV0IGZpcnN0VnF0TW9tZW50O1xyXG4gICAgICAgIGxldCBzZWNvbmRWcXQ7XHJcbiAgICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgY29uc3Qgb3BjUXVhbGl0eVN2YyA9IHRoaXMub3BjUXVhbGl0eVN2YztcclxuICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCk7XHJcbiAgICAgICAgY3V0QmVmb3JlRGF0ZS5zdWJ0cmFjdChNYXRoLmFicyhyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAoZWwpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGVsKSAmJiBwcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEuaGFzKGVsLmZxbikgJiYgZWwudmFsdWVzLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YSA9IHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5nZXQoZWwuZnFuKTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YU1vbWVudCA9IG1vbWVudC51dGMob25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhLnQpO1xyXG4gICAgICAgICAgICAgICAgZmlyc3RWcXQgPSBlbC52YWx1ZXMuc2xpY2UoMCwgMSlbMF07XHJcbiAgICAgICAgICAgICAgICBmaXJzdFZxdE1vbWVudCA9IG1vbWVudC51dGMoZmlyc3RWcXQudCk7XHJcbiAgICAgICAgICAgICAgICBpZiAob3BjUXVhbGl0eVN2Yy5pc0hkYUludGVycG9sYXRlZChmaXJzdFZxdC5xKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNlY29uZFZxdCA9IGVsLnZhbHVlcy5zbGljZSgxLCAyKVswXTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZmlyc3RWcXRNb21lbnQgPiBvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGFNb21lbnQgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlyc3RWcXRNb21lbnQgPCBtb21lbnQudXRjKHNlY29uZFZxdC50KSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGNRdWFsaXR5U3ZjLmlzR29vZChvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEucSkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgb3BjUXVhbGl0eVN2Yy5pc0dvb2Qoc2Vjb25kVnF0LnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsLnZhbHVlcy5zcGxpY2UoMCwgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCwgdGltZXpvbmU/OiBzdHJpbmcpOiBUaW1lc2VyaWVzUmVzcG9uc2Uge1xyXG4gICAgICAgIGxldCBhcHBseVRpbWV6b25lID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICghXy5pc05pbCh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgLy8gd2UgZG8gaGF2ZSB0aW1lem9uZVxyXG4gICAgICAgICAgICBhcHBseVRpbWV6b25lID0gdHJ1ZTtcclxuICAgICAgICAgICAgLy8gYXBwbHkgdGltZXpvbmUgYWxzbyB0byByZXNwb25zZSB0aW1lIHBlcmlvZCB0byBtYXRjaCBkYXRhXHJcbiAgICAgICAgICAgIHJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUocmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICByZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShyZXNwb25zZS50aW1lUGVyaW9kLmVuZCwgdGltZXpvbmUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmV0OiBUaW1lc2VyaWVzUmVzcG9uc2UgPSB7XHJcbiAgICAgICAgICAgIHRpbWVQZXJpb2Q6IHJlc3BvbnNlLnRpbWVQZXJpb2QsXHJcbiAgICAgICAgICAgIHJlc3VsdHM6IFtdXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgXy5lYWNoKHJlc3BvbnNlLmZxbnNSZXN1bHRzLCAob25lUmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKG9uZVJlc3VsdCkpIHtcclxuICAgICAgICAgICAgICAgIC8vIG5vIHRpbWVzZXJpZXMgZGF0YVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoYXBwbHlUaW1lem9uZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYXBwbHlUaW1lem9uZVRvVnF0RGF0YShvbmVSZXN1bHQudmFsdWVzLCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldC5yZXN1bHRzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogb25lUmVzdWx0Lm5hbWUsXHJcbiAgICAgICAgICAgICAgICBmcW46IG9uZVJlc3VsdC5mcW4sXHJcbiAgICAgICAgICAgICAgICB2YWx1ZVR5cGU6IG9uZVJlc3VsdC52YWx1ZVR5cGUsXHJcbiAgICAgICAgICAgICAgICBlbmdpbmVlcmluZ1VuaXQ6IG9uZVJlc3VsdC5lbmdpbmVlcmluZ1VuaXQsXHJcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IG9uZVJlc3VsdC52YWx1ZXNcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJldDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEZ1bmN0aW9uIHRvIGZpbHRlciBub3QgbmVlZGVkIGRhdGEgYW5kIGR1cGxpY2F0ZSBkYXRhLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9maWx0ZXJEdXBsaWNhdGVEYXRhQW5kQ3V0KFxyXG4gICAgICAgIHZhbHVlczogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHNbXSwgY3V0QmVmb3JlTW9tZW50OiBtb21lbnQuTW9tZW50LFxyXG4gICAgICAgIGRvTm90U2hpZnRGaXJzdFZhbHVlPzogYm9vbGVhbiwgdGltZXpvbmU/OiBzdHJpbmcpIHtcclxuICAgICAgICBjb25zdCBpZHM6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICBsZXQgb2JqZWN0VG9BZGRUb0FycmF5OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cztcclxuICAgICAgICBsZXQgZmlyc3RJc0FmdGVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGFycmF5RmlsdGVyKG86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRJdGVtTW9tZW50ID0gbW9tZW50LnV0YyhvLnQpO1xyXG4gICAgICAgICAgICBpZiAoY3V0QmVmb3JlTW9tZW50LmlzQWZ0ZXIoY3VycmVudEl0ZW1Nb21lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWZpcnN0SXNBZnRlcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG9iamVjdFRvQWRkVG9BcnJheSA9IF8uY2xvbmUobyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0ID0gY3V0QmVmb3JlTW9tZW50LmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbCh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5LnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUoY3V0QmVmb3JlTW9tZW50VVRDRm9ybWF0LCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5LnQgPSBjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpcnN0SXNBZnRlciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGlkcy5pbmRleE9mKG8udCkgIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWRzLnB1c2goby50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZpbHRlcmVkQXJyYXkgPSB2YWx1ZXMucmV2ZXJzZSgpLmZpbHRlcihhcnJheUZpbHRlcik7XHJcbiAgICAgICAgaWYgKCFkb05vdFNoaWZ0Rmlyc3RWYWx1ZSAmJiBmaXJzdElzQWZ0ZXIpIHtcclxuICAgICAgICAgICAgY29uc3QgbGFzdFZhbHVlID0gXy5sYXN0KGZpbHRlcmVkQXJyYXkpO1xyXG4gICAgICAgICAgICBpZiAoIWxhc3RWYWx1ZSB8fCAhbW9tZW50LnV0YyhsYXN0VmFsdWUudCkuaXNTYW1lKG1vbWVudC51dGMob2JqZWN0VG9BZGRUb0FycmF5LnQpKSkge1xyXG4gICAgICAgICAgICAgICAgLy8gaXQgaXMgcmV2ZXJzZWQgYXJyYXkgc28gcHVzaCB0byBpdFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRBcnJheS5wdXNoKG9iamVjdFRvQWRkVG9BcnJheSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZpbHRlcmVkQXJyYXkucmV2ZXJzZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0cyByZXBlYXRlZGx5IGFuZCByZXR1cm4gYWxsIGRhdGEgaW4gZ2l2ZW4gcmVxdWVzdCBpbnRlcnZhbCAoYnkgZHVyYXRpb24sIHN0YXJ0IGFuZC9vciBlbmQgdGltZSkuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGludGVydmFsIGluIHNlY29uZHNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVwZWF0ZWRseVdob2xlKHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIGxldCBsYXN0TWVyZ2VkUmVzcG9uc2U6IFRpbWVzZXJpZXNSZXNwb25zZTtcclxuICAgICAgICBjb25zdCB0eiA9IHRpbWV6b25lO1xyXG5cclxuICAgICAgICBjb25zdCByZXBlYXRlZGx5T2JzID0gdGhpcy5fZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHRpbWV6b25lKVxyXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlc3BvbnNlOiBUaW1lc2VyaWVzUmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChsYXN0TWVyZ2VkUmVzcG9uc2UpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLmVuZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY3V0QmVmb3JlRGF0ZS5zdWJ0cmFjdChNYXRoLmFicyhyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdCA9IGN1dEJlZm9yZURhdGUuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbCh0eikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2Quc3RhcnQgPSBNb21lbnRIZWxwZXJTZXJ2aWNlLmFwcGx5VGltZXpvbmUoY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdCwgdHopO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5lbmQgPSByZXNwb25zZS50aW1lUGVyaW9kLmVuZDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IGN1dEJlZm9yZURhdGVVVENGb3JtYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKS5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIF8uZWFjaChsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cywgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdSZXN1bHRzID0gXy5maW5kKHJlc3BvbnNlLnJlc3VsdHMsIHsgZnFuOiByZXN1bHQuZnFuIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobmV3UmVzdWx0cykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSByZXN1bHQudmFsdWVzLmNvbmNhdChuZXdSZXN1bHRzLnZhbHVlcyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IF8uc29ydEJ5KHJlc3VsdC52YWx1ZXMsIFsobzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9tZW50LnV0YyhvLnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfV0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52YWx1ZXMgPSB0aGlzLl9maWx0ZXJEdXBsaWNhdGVEYXRhQW5kQ3V0KHJlc3VsdC52YWx1ZXMsIGN1dEJlZm9yZURhdGUsIGZhbHNlLCB0eik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgYW55IG5ldyBmcW5zIGRhdGFcclxuICAgICAgICAgICAgICAgICAgICBfLmVhY2gocmVzcG9uc2UucmVzdWx0cywgKG5ld1Jlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uZmluZChsYXN0TWVyZ2VkUmVzcG9uc2UucmVzdWx0cywgeyBmcW46IG5ld1Jlc3VsdC5mcW4gfSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLnB1c2gobmV3UmVzdWx0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBsYXN0TWVyZ2VkUmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZSA9IHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgIHJldHVybiByZXBlYXRlZGx5T2JzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0cyByZXBlYXRlZGx5IGFuZCByZXR1cm4gZGF0YSBhcyBpbmNyZW1lbnRzLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBpbnRlcnZhbCBpbiBzZWNvbmRzXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFJlcGVhdGVkbHlJbmNyZW1lbnRzKFxyXG4gICAgICAgIHJlcXVlc3Q6IFRpbWVzZXJpZXNSZXF1ZXN0LCBjdXN0b21JbnRlcnZhbD86IG51bWJlciwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG5cclxuICAgICAgICBsZXQgbGFzdFJlc3BvbnNlRGF0YTogTWFwPHN0cmluZywgYW55PjtcclxuICAgICAgICBsZXQgcmVwZWF0ZWRJbnRlcnZhbCA9IGN1c3RvbUludGVydmFsIHx8IHRoaXMuY29uZmlnLmRlZmF1bHRSZXBlYXRlZERhdGFJbnRlcnZhbCB8fCBERUZBVUxUX1JFUEVBVEVEX0RBVEFfSU5URVJWQUw7XHJcbiAgICAgICAgcmVwZWF0ZWRJbnRlcnZhbCA9IHJlcGVhdGVkSW50ZXJ2YWwgKiAxMDAwO1xyXG5cclxuICAgICAgICBjb25zdCBsYXN0UmVwZWF0ZWRSZXF1ZXN0ID0gXy5jbG9uZShyZXF1ZXN0KTtcclxuICAgICAgICBjb25zdCBvcmlnaW5hbER1cmF0aW9uID0gcmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb247XHJcbiAgICAgICAgbGV0IG5leHRSZXF1ZXN0U3RhcnRNb21lbnQ6IG1vbWVudC5Nb21lbnQ7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcGVhdGVkRGF0YU9ic2VydmFibGUgPSB0aGlzLl9zZW5kUG9zdFJlcXVlc3QocmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgbmV4dFJlcXVlc3RTdGFydE1vbWVudCA9IHRoaXMuX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QocmVzcG9uc2UsIG9yaWdpbmFsRHVyYXRpb24sIHJlcGVhdGVkSW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICAvLyB3ZSByZW1lbWJlciBsYXN0IHZhbHVlIGJlZm9yZSBuZXh0U3RhcnQgaW4gY3VycmVudCByZXF1ZXN0IHRvIGNoZWNrIGl0c1xyXG4gICAgICAgICAgICAvLyBxdWFsaXR5IHZzLiBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSB2YWx1ZSBxdWFsaXR5LCBwb3NzaWJseVxyXG4gICAgICAgICAgICAvLyB0byBvbWl0IHN0YXJ0IHZhbHVlXHJcbiAgICAgICAgICAgIC8vIC0gaXQgbWF5IGJlIGludGVycG9sYXRlZCBiZXR3ZWVuIHR3byBnb29kIHF1YWxpdHkgdmFsdWVzXHJcbiAgICAgICAgICAgIGxhc3RSZXNwb25zZURhdGEgPSB0aGlzLl9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZSwgbmV4dFJlcXVlc3RTdGFydE1vbWVudCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdGltZXpvbmUpO1xyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBjb25zdCBleHBhbmRlZE9ic2VydmFibGUgPSByZXBlYXRlZERhdGFPYnNlcnZhYmxlLnBpcGUoXHJcbiAgICAgICAgICAgIGV4cGFuZCgoKSA9PiB0aW1lcihyZXBlYXRlZEludGVydmFsKS5waXBlKGNvbmNhdE1hcCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV8uaXNOaWwobmV4dFJlcXVlc3RTdGFydE1vbWVudCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsYXN0UmVwZWF0ZWRSZXF1ZXN0LnNldFRpbWVQZXJpb2QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF8uZXh0ZW5kKGxhc3RSZXBlYXRlZFJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpLCB7IGR1cmF0aW9uOiAwLCBzdGFydDogbmV4dFJlcXVlc3RTdGFydE1vbWVudC50b0RhdGUoKSB9KSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KGxhc3RSZXBlYXRlZFJlcXVlc3QpLnBpcGUobWFwKChyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RSZXNwb25zZURhdGEuc2l6ZSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgY2hlY2sgcHJldmlvdXMgdmFsdWVzIHRvIGN1cnJlbnQgc3RhcnRpbmcgb25lc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBmaWx0ZXIgb3V0IHBvc3NpYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0YXJ0IGludGVycG9sYXRlZCBvbmVzIGlmIHRoZXkgYXJlIGJldHdlZW4gZ29vZCBvbmVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZpbHRlclN0YXJ0UmVzcG9uc2VEYXRhKHJlc3BvbnNlLCBsYXN0UmVzcG9uc2VEYXRhLCByZXF1ZXN0VGltZVBlcmlvZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQgPSB0aGlzLl9nZXRTdGFydEZvck5leHRSZXF1ZXN0KHJlc3BvbnNlLCBvcmlnaW5hbER1cmF0aW9uLCByZXBlYXRlZEludGVydmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB3ZSByZW1lbWJlciBsYXN0IHZhbHVlIGJlZm9yZSBuZXh0U3RhcnQgaW4gY3VycmVudCByZXF1ZXN0IHRvIGNoZWNrIGl0c1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHF1YWxpdHkgdnMuIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIHZhbHVlIHF1YWxpdHksIHBvc3NpYmx5XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdG8gb21pdCBzdGFydCB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIC0gaXQgbWF5IGJlIGludGVycG9sYXRlZCBiZXR3ZWVuIHR3byBnb29kIHF1YWxpdHkgdmFsdWVzXHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdFJlc3BvbnNlRGF0YSA9IHRoaXMuX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlLCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfSkpKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgcmV0dXJuIGV4cGFuZGVkT2JzZXJ2YWJsZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBzZW5kIHJlcXVlc3QgZm9yIHRpbWVzZXJpZXMgZGF0YSByZXBlYXRlZGx5LiBJdCByZXBlYXRlZGx5IHNlbmRzIHJlcXVlc3RzIHRvIHNlcnZlci5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgY3VzdG9tIGludGVydmFsIGZvciByZXBlYXRlZCBkYXRhLCBpbiBzZWNvbmRzXHJcbiAgICAgKiBAcGFyYW0gZm9ybWF0IChPcHRpb25hbCkgZm9ybWF0IGZvciByZXBlYXRlZCBkYXRhIHJlc3BvbnNlXHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgKE9wdGlvbmFsKSBTZXQgdGhlIHRpbWV6b25lIHRvIGFwcGx5IHRvIGRhdGV0aW1lIHN0cmluZ3MgZm9yIHRpbWVzZXJpZXMgcmVzcG9uc2UgZGF0YS5cclxuICAgICAqIFJldHVybmVkIGRhdGUgc3RyaW5ncyBhcmUgaW4gbWF4aW11bSBqYXZhc2NyaXB0IHJlc29sdXRpb24gcG9zc2libGVcclxuICAgICAqIHN1cHBvcnRlZCBieSB1c2luZyBtb21lbnQgbGlicmFyeSAoSmF2YXNjcmlwdCBkYXRlIC0gbWlsbGlzZWNvbmRzKS5cclxuICAgICAqIFJlc29sdXRpb24gZm9yIHRpbWUgYWZ0ZXIgbWlsbGlzZWNvbmRzIHdpbGwgYmUgbG9zdC5cclxuICAgICAqIElmIHdvcmtpbmcgd2l0aCB0aW1lem9uZSBpbiBkYXRldGltZSBzdHJpbmcgaXQgaXMgcmVjb21tZW5kZWQgdG8gdXNlIG1vbWVudC5wYXJzZVpvbmUgdG8gcHJlc2VydmUgdGltZXpvbmUgaW5mb3JtYXRpb24uXHJcbiAgICAgKiBNb21lbnQgdGltZXpvbmVzIHRoYXQgc3RhcnQgd2l0aCBcIkV0Yy9HTVRcIiB1c2UgUE9TSVgtc3R5bGUgc2lnbnMgaW4gdGhlIFpvbmUgbmFtZXMgYW5kIHRoZSBvdXRwdXQgYWJicmV2aWF0aW9ucyxcclxuICAgICAqIGV2ZW4gdGhvdWdoIHRoaXMgaXMgdGhlIG9wcG9zaXRlIG9mIHdoYXQgbWFueSBwZW9wbGUgZXhwZWN0LlxyXG4gICAgICogUE9TSVggaGFzIHBvc2l0aXZlIHNpZ25zIHdlc3Qgb2YgR3JlZW53aWNoLCBidXQgbWFueSBwZW9wbGUgZXhwZWN0XHJcbiAgICAgKiBwb3NpdGl2ZSBzaWducyBlYXN0IG9mIEdyZWVud2ljaC4gIEZvciBleGFtcGxlLCBUWj0nRXRjL0dNVCs0JyB1c2VzXHJcbiAgICAgKiB0aGUgYWJicmV2aWF0aW9uIFwiR01UKzRcIiBhbmQgY29ycmVzcG9uZHMgdG8gNCBob3VycyBiZWhpbmQgVVRcclxuICAgICAqIChpLmUuIHdlc3Qgb2YgR3JlZW53aWNoKSBldmVuIHRob3VnaCBtYW55IHBlb3BsZSB3b3VsZCBleHBlY3QgaXQgdG9cclxuICAgICAqIG1lYW4gNCBob3VycyBhaGVhZCBvZiBVVCAoaS5lLiBlYXN0IG9mIEdyZWVud2ljaCkuXHJcbiAgICAgKi9cclxuICAgIGdldFJlcGVhdGVkbHkocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCBmb3JtYXQ/OiBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0LCB0aW1lem9uZT86IHN0cmluZyk6XHJcbiAgICAgICAgT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWVQZXJpb2QgPSByZXF1ZXN0LmdldFRpbWVQZXJpb2QoKTtcclxuICAgICAgICBpZiAoIV8uaXNOaWwocmVxdWVzdFRpbWVQZXJpb2Quc3RhcnQpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRFcnJvck9ic2VydmFibGUoJ1RpbWVzZXJpZXNEYXRhU2VydmljZSBnZXRSZXBlYXRlZGx5OiBBcmd1bWVudCBleGNlcHRpb24nXHJcbiAgICAgICAgICAgICAgICArICcgLSBSZXF1ZXN0IHN0YXJ0IHRpbWUgY2Fubm90IGJlIHNldCBmb3IgcmVwZWF0ZWQgZGF0YSAocmVxdWVzdDogJ1xyXG4gICAgICAgICAgICAgICAgKyBKU09OLnN0cmluZ2lmeShyZXF1ZXN0KSArICcgY2Fubm90IGJlIHByb2Nlc3NlZC4nKTtcclxuICAgICAgICB9IGVsc2UgaWYgKF8uaXNOaWwocmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24pIHx8IHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uID4gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0RXJyb3JPYnNlcnZhYmxlKCdUaW1lc2VyaWVzRGF0YVNlcnZpY2UgZ2V0UmVwZWF0ZWRseTogQXJndW1lbnQgZXhjZXB0aW9uJ1xyXG4gICAgICAgICAgICAgICAgKyAnIC0gUmVxdWVzdCBkdXJhdGlvbiBoYXZlIHRvIGJlIG5lZ2F0aXZlIChyZXF1ZXN0OiAnXHJcbiAgICAgICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpICsgJyBjYW5ub3QgYmUgcHJvY2Vzc2VkLicpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHR6OiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKE1vbWVudEhlbHBlclNlcnZpY2UuaXNWYWxpZFRpbWV6b25lKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICB0eiA9IHRpbWV6b25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoXy5pc05pbChmb3JtYXQpIHx8IGZvcm1hdCA9PT0gVGltZXNlcmllc1JlcGVhdGVkRGF0YUZvcm1hdC53aG9sZUludGVydmFsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRSZXBlYXRlZGx5V2hvbGUocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHR6KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMocmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWwsIHR6KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0h0dHBDbGllbnR9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHtDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWd9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHtPYnNlcnZhYmxlfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtCYXNlU2VydmljZX0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgT3BlcmF0aW9uU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL29wZXJhdGlvbi8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gT3BlcmF0aW9uIHNlcnZpY2Ugb24gdGhlIHNlcnZlci5cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldE9wZXJhdGlvbkRhdGEob3BlcmF0aW9uUmVxOiBPcGVyYXRpb25SZXF1ZXN0KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KG9wZXJhdGlvblJlcSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPcGVyYXRpb25SZXF1ZXN0IHtcclxuICAgIC8qKlxyXG4gICAgICogT3BlcmF0aW9uIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSB0YXJnZXQgLSBUaGUgRlFOIG9mIHRhcmdldCBpdGVtXHJcbiAgICAgKiBAcGFyYW0gb3BlcmF0aW9uIC0gVGhlIG5hbWUgb2YgdGhlIG9wZXJhdGlvblxyXG4gICAgICogQHBhcmFtIHBhcmFtZXRlcnMgLSBUaGUgcGFyYW1ldGVycyBmb3IgdGhlIHJlcXVlc3RcclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IocHVibGljIHRhcmdldDogc3RyaW5nLCBwdWJsaWMgb3BlcmF0aW9uOiBzdHJpbmcsIHB1YmxpYyBwYXJhbWV0ZXJzPzogb2JqZWN0KSB7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHtJbmplY3QsIEluamVjdGFibGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge0Jhc2VTZXJ2aWNlfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcbmltcG9ydCB7Q09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7SHR0cENsaWVudH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge2lkZW50aWZpZXJ9IGZyb20gJy4vc2hhcmVkJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJTmV3SXRlbSB7XHJcbiAgICBwYXJlbnRQcm9wZXJ0eUZxbjogc3RyaW5nO1xyXG4gICAgaXRlbVR5cGU6IHN0cmluZztcclxuICAgIHByb3BzPzogUHJvcE5hbWVWYWx1ZXM7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVJlbmFtZWRJdGVtIHtcclxuICAgIGZxbjogc3RyaW5nO1xyXG4gICAgbmV3TmFtZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElDaGFuZ2VkSXRlbSB7XHJcbiAgICBGdWxseVF1YWxpZmllZE5hbWU6IHN0cmluZztcclxuICAgIFtrZXk6IHN0cmluZ106IGFueTtcclxufVxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgUGVyc2lzdGVuY2VTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvcGVyc2lzdGVuY2UvJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gUGVyc2lzdGVuY2Ugc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAqL1xyXG4gICAgY29tbWl0KHBlcnNpc3RSZXF1ZXN0OiBQZXJzaXN0UmVxdWVzdCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChwZXJzaXN0UmVxdWVzdCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQcm9wTmFtZVZhbHVlcyB7XHJcblxyXG4gIC8qKlxyXG4gICAqIEFkZHMgcHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyIGZvciBOZXcgSXRlbSBDcmVhdGlvblxyXG4gICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gYWRkXHJcbiAgICogQHBhcmFtIHZhbHVlIC0gVmFsdWUgdG8gYWRkIGF0IE5hbWUgcHJvcGVydHkgbmFtZVxyXG4gICAqL1xyXG4gICAgYWRkKG5hbWU6IHN0cmluZywgdmFsdWU6IHN0cmluZykge1xyXG4gICAgICAgIGlmIChuYW1lKSB7XHJcbiAgICAgICAgICAgIHRoaXNbbmFtZV0gPSB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW1vdmVzIHByb3BlcnR5IE5hbWVcclxuICAgICAqIEBwYXJhbSBuYW1lIC0gTmFtZSBvZiB0aGUgcHJvcGVydHkgdG8gcmVtb3ZlXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZShuYW1lOiBzdHJpbmcpIHtcclxuICAgICAgICBpZiAoIV8uaXNOaWwodGhpc1tuYW1lXSkpIHtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXNbbmFtZV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlzRW1wdHkoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICFfLnNvbWUodGhpcyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAvKiogTGlzdCBvZiBuZXcgaXRlbXMgdG8gcGVyc2lzdCAqL1xyXG4gICAgbmV3SXRlbXM6IElOZXdJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byByZW5hbWUgKi9cclxuICAgIHJlbmFtZWRJdGVtOiBJUmVuYW1lZEl0ZW07XHJcbiAgICAvKiogTGlzdCBvZiBjaGFuZ2VkIGl0ZW1zIHRvIHBlcnNpc3QgKi9cclxuICAgIGNoYW5nZWRJdGVtczogSUNoYW5nZWRJdGVtW107XHJcbiAgICAvKiogTGlzdCBvZiBpdGVtcyB0byBkZWxldGUgKi9cclxuICAgIGRlbGV0ZWRJdGVtczogaWRlbnRpZmllcltdO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ3JlYXRlIEl0ZW0gdmlhIFBlcnNpc3RlbmNlIFNlcnZpY2VcclxuICAgICAqIEBwYXJhbSBwYXJlbnRQcm9wZXJ0eUZxbiAtIEZRTiBvZiBQYXJlbnQgUHJvcGVydHlcclxuICAgICAqIEBwYXJhbSBpdGVtVHlwZSAtIEl0ZW0gVHlwZVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydHkgTmFtZSBWYWx1ZSBQYWlyc1xyXG4gICAgICovXHJcbiAgICBjcmVhdGVJdGVtKHBhcmVudFByb3BlcnR5RnFuOiBzdHJpbmcsIGl0ZW1UeXBlOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzPzogUHJvcE5hbWVWYWx1ZXMpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgY29uc3QgY3JlYXRlUmVxdWVzdDogSU5ld0l0ZW0gPSB7XHJcbiAgICAgICAgICAgIHBhcmVudFByb3BlcnR5RnFuOiBwYXJlbnRQcm9wZXJ0eUZxbixcclxuICAgICAgICAgICAgaXRlbVR5cGU6IGl0ZW1UeXBlXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKHByb3BOYW1lVmFsdWVzKSB7XHJcbiAgICAgICAgICAgIGNyZWF0ZVJlcXVlc3QucHJvcHMgPSBwcm9wTmFtZVZhbHVlcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5uZXdJdGVtcykge1xyXG4gICAgICAgICAgICB0aGlzLm5ld0l0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5ld0l0ZW1zLnB1c2goY3JlYXRlUmVxdWVzdCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBSZW5hbWUgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIG5ld05hbWUgLSBOZXcgTmFtZSBvZiBJdGVtXHJcbiAgICAgKi9cclxuICAgIHJlbmFtZUl0ZW0oaXRlbUZxbjogc3RyaW5nLCBuZXdOYW1lOiBzdHJpbmcpOiBQZXJzaXN0UmVxdWVzdCB7XHJcbiAgICAgICAgdGhpcy5yZW5hbWVkSXRlbSA9IHtcclxuICAgICAgICAgICAgZnFuOiBpdGVtRnFuLFxyXG4gICAgICAgICAgICBuZXdOYW1lOiBuZXdOYW1lXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDaGFuZ2UgSXRlbSB2aWEgUGVyc2lzdGVuY2UgU2VydmljZVxyXG4gICAgICogQHBhcmFtIGl0ZW1GcW4gLSBGUU4gb2YgSXRlbVxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lVmFsdWVzIC0gUHJvcGVydGllcyB0byBjaGFuZ2VcclxuICAgICAqL1xyXG4gICAgY2hhbmdlSXRlbShpdGVtRnFuOiBzdHJpbmcsIHByb3BOYW1lVmFsdWVzOiBQcm9wTmFtZVZhbHVlcyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXByb3BOYW1lVmFsdWVzLmlzRW1wdHkoKSkge1xyXG4gICAgICAgICAgICBjb25zdCBjaGFuZ2VSZXF1ZXN0OiBJQ2hhbmdlZEl0ZW0gPSB7XHJcbiAgICAgICAgICAgICAgICBGdWxseVF1YWxpZmllZE5hbWU6IGl0ZW1GcW5cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgXy5leHRlbmQoY2hhbmdlUmVxdWVzdCwgcHJvcE5hbWVWYWx1ZXMpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNoYW5nZWRJdGVtcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VkSXRlbXMgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmNoYW5nZWRJdGVtcy5wdXNoKGNoYW5nZVJlcXVlc3QpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIERlbGV0ZSBJdGVtIHZpYSBQZXJzaXN0ZW5jZSBTZXJ2aWNlXHJcbiAgICAgKiBAcGFyYW0gaXRlbUZxbiAtIEZRTiBvZiBJdGVtIHRvIGRlbGV0ZVxyXG4gICAgICovXHJcbiAgICBkZWxldGVJdGVtKGl0ZW1GcW46IHN0cmluZyk6IFBlcnNpc3RSZXF1ZXN0IHtcclxuICAgICAgICBpZiAoIXRoaXMuZGVsZXRlZEl0ZW1zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZGVsZXRlZEl0ZW1zLnB1c2goaXRlbUZxbik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXM7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEJhc2VTZXJ2aWNlIH0gZnJvbSAnLi9iYXNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uUnVsZXMgfSBmcm9tICcuL3NoYXJlZCc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBOYXZpZ2F0aW9uU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICAgICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL25hdmlnYXRpb24vJywgY29uZmlnLCBodHRwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ha2VzIGEgcmVxdWVzdCB0byBKU09OIE5hdmlnYXRpb24gc2VydmljZSBvbiB0aGUgc2VydmVyLlxyXG4gICAgICovXHJcbiAgICBnZXROYXZpZ2F0aW9uRGF0YShuYXZpZ2F0aW9uUmVxdWVzdDogTmF2aWdhdGlvblJlcXVlc3QpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIGxldCByZXF1ZXN0ID0gbmF2aWdhdGlvblJlcXVlc3Q7XHJcbiAgICAgICAgaWYgKF8uaXNOaWwobmF2aWdhdGlvblJlcXVlc3QubmF2SGFuZGxlckZxbikgfHwgbmF2aWdhdGlvblJlcXVlc3QubmF2SGFuZGxlckZxbiA9PT0gJycpIHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwocmVxdWVzdC5oaWRlUnVsZXMpICYmIF8uaXNOaWwocmVxdWVzdC5za2lwUnVsZXMpKSB7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0ID0gXy5jbG9uZShuYXZpZ2F0aW9uUmVxdWVzdCk7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0LnNraXBSdWxlcyA9IF8uY2xvbmUodGhpcy5jb25maWcuZGVmYXVsdE5hdmlnYXRpb25SdWxlcy5za2lwUnVsZXMpO1xyXG4gICAgICAgICAgICAgICAgcmVxdWVzdC5oaWRlUnVsZXMgPSBfLmNsb25lKHRoaXMuY29uZmlnLmRlZmF1bHROYXZpZ2F0aW9uUnVsZXMuaGlkZVJ1bGVzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VuZFBvc3RSZXF1ZXN0KHJlcXVlc3QpO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTmF2aWdhdGlvblJlcXVlc3Qge1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogTmF2aWdhdGlvbiByZXF1ZXN0IGNvbnN0cnVjdG9yXHJcbiAgICAgKiBAcGFyYW0gZnFuIC0gVGhlIEZRTiBvZiBOYXZpZ2F0aW9uUmVxdWVzdFxyXG4gICAgICogQHBhcmFtIHByb3BOYW1lcyAtIFRoZSBQcm9wZXJ0eSBOYW1lc1xyXG4gICAgICogQHBhcmFtIGluY2x1ZGVQYXJlbnRzIC0gV2hldGhlciB0byBpbmNsdWRlIHBhcmVudHMgaW4gcmVzdWx0c1xyXG4gICAgICogQHBhcmFtIG5hdkhhbmRsZXJGcW4gLSBUaGUgRlFOIG9mIE5hdmlnYXRpb24gSGFuZGxlciBJdGVtXHJcbiAgICAgKiBAcGFyYW0gaGlkZVJ1bGVzIC0gVGhlIEhpZGUgUnVsZXMgZm9yIE5hdmlnYXRpb25cclxuICAgICAqIEBwYXJhbSBza2lwUnVsZXMgLSBUaGUgU2tpcCBSdWxlcyBmb3IgTmF2aWdhdGlvblxyXG4gICAgICovXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgZnFuOiBzdHJpbmcsIHB1YmxpYyBwcm9wTmFtZXM/OiBzdHJpbmdbXSwgcHVibGljIGluY2x1ZGVQYXJlbnRzPzogYm9vbGVhbixcclxuICAgICAgICBwdWJsaWMgbmF2SGFuZGxlckZxbj86IHN0cmluZywgcHVibGljIGhpZGVSdWxlcz86IE5hdmlnYXRpb25SdWxlcywgcHVibGljIHNraXBSdWxlcz86IE5hdmlnYXRpb25SdWxlcykge1xyXG4gICAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge0luamVjdCwgSW5qZWN0YWJsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7SHR0cENsaWVudH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQge0NPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZ30gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQge09ic2VydmFibGV9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge0Jhc2VTZXJ2aWNlfSBmcm9tICcuL2Jhc2Uuc2VydmljZSc7XHJcblxyXG4vKipcclxuICogTmF2aWdhdGlvbiByZXNwb25zZSBpbnRlcmZhY2VcclxuICogQHBhcmFtIHVzZXJuYW1lIC0gaWRlbnRpdHkgcHJvdmlkZXIgKGVtYWlsKVxyXG4gKiBAcGFyYW0gcm9sZXMgLSBsaXN0IG9mIHVzZXIgcm9sZXNcclxuICogQHBhcmFtIGlkZW50aXRpZXMgLSBsaXN0IG9mIGlkZW50aXRpZXMgcHJvdmlkZXJzXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElTZWN1cml0eUNvbnRleHRSZXNwb25zZSB7XHJcbiAgdXNlcm5hbWU6IHN0cmluZztcclxuICByb2xlczogc3RyaW5nW107XHJcbiAgaWRlbnRpdGllczogc3RyaW5nW107XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIFNlY3VyaXR5Q29udGV4dFJlc3BvbnNlID0gSVNlY3VyaXR5Q29udGV4dFJlc3BvbnNlO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgU2VjdXJpdHlDb250ZXh0U2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoQEluamVjdChDT01NVU5JQ0FUSU9OX0NPTkZJRykgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cDogSHR0cENsaWVudCkge1xyXG4gICAgc3VwZXIoY29uZmlnLmJhc2VVcmwgKyAnL2FwaS8xL3NlY3VyaXR5Y29udGV4dC8nLCBjb25maWcsIGh0dHApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTWFrZXMgYSByZXF1ZXN0IHRvIEpTT04gU2VjdXJpdHkgQ29udGV4dCBzZXJ2aWNlIG9uIHRoZSBzZXJ2ZXIuXHJcbiAgICovXHJcbiAgcHVibGljIGdldFNlY3VyaXR5Q29udGV4dERhdGEoKTogT2JzZXJ2YWJsZTxTZWN1cml0eUNvbnRleHRSZXNwb25zZT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuX3NlbmRHZXRSZXF1ZXN0KCk7XHJcbiAgfVxyXG59XHJcblxyXG4iLCJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE1pbWVTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbWltZS8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIGdldE1pbWVJdGVtUGF0aChmcW46IHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmVuZHBvaW50VXJsLmNvbmNhdChmcW4pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCB7SW5qZWN0LCBJbmplY3RhYmxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7Q09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnfSBmcm9tICcuL2NvbmZpZyc7XHJcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7QmFzZVNlcnZpY2V9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbi8qKlxyXG4gKiBOYXZpZ2F0aW9uIGhhbmRsZXIgcmVzcG9uc2UgaW50ZXJmYWNlXHJcbiAqIEBwYXJhbSB1c2VybmFtZSAtIGlkZW50aXR5IHByb3ZpZGVyIChlbWFpbClcclxuICogQHBhcmFtIHJvbGVzIC0gbGlzdCBvZiB1c2VyIHJvbGVzXHJcbiAqIEBwYXJhbSBpZGVudGl0aWVzIC0gbGlzdCBvZiBpZGVudGl0aWVzIHByb3ZpZGVyc1xyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJTmF2aWdhdGlvbkhhbmRsZXJSZXNwb25zZSB7XHJcbiAgbmF2aGFuZGxlcmZxbjogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgTmF2aWdhdGlvbkhhbmRsZXJSZXNwb25zZSA9IElOYXZpZ2F0aW9uSGFuZGxlclJlc3BvbnNlO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgTmF2aWdhdGlvbkhhbmRsZXJTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwOiBIdHRwQ2xpZW50KSB7XHJcbiAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbmF2aWdhdGlvbmhhbmRsZXIvJywgY29uZmlnLCBodHRwKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIE1ha2VzIGEgcmVxdWVzdCB0byBKU09OIE5hdmlnYXRpb25IYW5kbGVyIHNlcnZpY2Ugb24gdGhlIHNlcnZlci5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0TmF2aWdhdGlvbkhhbmRsZXJEYXRhKG5hdmlnYXRpb25IYW5kbGVyUmVxOiBOYXZpZ2F0aW9uSGFuZGxlclJlcXVlc3QpOiBPYnNlcnZhYmxlPE5hdmlnYXRpb25IYW5kbGVyUmVzcG9uc2U+IHtcclxuICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QobmF2aWdhdGlvbkhhbmRsZXJSZXEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE5hdmlnYXRpb25IYW5kbGVyUmVxdWVzdCB7XHJcbiAgLyoqXHJcbiAgICogTmF2aWdhdGlvbkhhbmRsZXIgcmVxdWVzdCBjb25zdHJ1Y3Rvci5cclxuICAgKiBBdCBsZWFzdCBvbmUgb2Ygb3B0aW9uYWwgcGFyYW1ldGVycyBtdXN0IGJlIHVzZWRcclxuICAgKiBAcGFyYW0gZnFuIFRoZSBGUU4gb2YgTmF2aWdhdGlvbkhhbmRsZXJSZXF1ZXN0XHJcbiAgICogQHBhcmFtIGN1cnJlbnROYXZIYW5kbGVyRnFuIFRoZSBGUU4gb2YgY3VycmVudCBOYXZpZ2F0aW9uIGhhbmRsZXJcclxuICAgKiBAcGFyYW0gbmF2SGFuZGxlclByb3ZpZGVyRnFuIFRoZSBGUU4gb2YgTmF2aWdhdGlvbiBIYW5kbGVyIFByb3ZpZGVyXHJcbiAgICovXHJcbiAgY29uc3RydWN0b3IocHVibGljIGZxbjogc3RyaW5nLCBwdWJsaWMgY3VycmVudE5hdkhhbmRsZXJGcW4/OiBzdHJpbmcsXHJcbiAgICAgICAgICAgICAgcHVibGljIG5hdkhhbmRsZXJQcm92aWRlckZxbj86IHN0cmluZykge1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBOZ01vZHVsZSwgTW9kdWxlV2l0aFByb3ZpZGVycyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50TW9kdWxlLCBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBJbnN0YW5jZVNlcnZpY2UgfSBmcm9tICcuL2luc3RhbmNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBMaXZlRGF0YVNlcnZpY2UgfSBmcm9tICcuL2xpdmUtZGF0YS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgVGltZXNlcmllc0RhdGFTZXJ2aWNlIH0gZnJvbSAnLi90aW1lc2VyaWVzLWRhdGEuc2VydmljZSc7XHJcbmltcG9ydCB7IENPTU1VTklDQVRJT05fQ09ORklHLCBJQ29tbXVuaWNhdGlvbkNvbmZpZyB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgT3BlcmF0aW9uU2VydmljZSB9IGZyb20gJy4vb3BlcmF0aW9uLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBQZXJzaXN0ZW5jZVNlcnZpY2UgfSBmcm9tICcuL3BlcnNpc3RlbmNlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uU2VydmljZSB9IGZyb20gJy4vbmF2aWdhdGlvbi5zZXJ2aWNlJztcclxuaW1wb3J0IHsgT3BjUXVhbGl0eVNlcnZpY2UgfSBmcm9tICcuL29wYy1xdWFsaXR5LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBTZWN1cml0eUNvbnRleHRTZXJ2aWNlIH0gZnJvbSAnLi9zZWN1cml0eS1jb250ZXh0LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBNaW1lU2VydmljZSB9IGZyb20gJy4vbWltZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTmF2aWdhdGlvbkhhbmRsZXJTZXJ2aWNlIH0gZnJvbSAnLi9uYXZpZ2F0aW9uLWhhbmRsZXIuc2VydmljZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBJbnN0YW5jZVN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgSW5zdGFuY2VTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwTGl2ZURhdGFTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IExpdmVEYXRhU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cFRpbWVzZXJpZXNEYXRhU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCwgcXVhbGl0eVN2YzogT3BjUXVhbGl0eVNlcnZpY2UpIHtcclxuICAgIHJldHVybiBuZXcgVGltZXNlcmllc0RhdGFTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCwgcXVhbGl0eVN2Yyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cE9wZXJhdGlvblN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgT3BlcmF0aW9uU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cFBlcnNpc3RlbmNlU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBQZXJzaXN0ZW5jZVNlcnZpY2UoY29uZmlnLCBodHRwQ2xpZW50KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gc2V0dXBOYXZpZ2F0aW9uU3ZjKFxyXG4gICAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gICAgcmV0dXJuIG5ldyBOYXZpZ2F0aW9uU2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cFNlY3VyaXR5Q29udGV4dFN2YyhcclxuICAgIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICAgIHJldHVybiBuZXcgU2VjdXJpdHlDb250ZXh0U2VydmljZShjb25maWcsIGh0dHBDbGllbnQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBzZXR1cE1pbWVTdmMoXHJcbiAgICBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7XHJcbiAgICByZXR1cm4gbmV3IE1pbWVTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwTmF2aWdhdGlvbkhhbmRsZXJTdmMoXHJcbiAgY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZywgaHR0cENsaWVudDogSHR0cENsaWVudCkge1xyXG4gIHJldHVybiBuZXcgTmF2aWdhdGlvbkhhbmRsZXJTZXJ2aWNlKGNvbmZpZywgaHR0cENsaWVudCk7XHJcbn1cclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgICBpbXBvcnRzOiBbXHJcbiAgICAgICAgQ29tbW9uTW9kdWxlLFxyXG4gICAgICAgIEh0dHBDbGllbnRNb2R1bGVcclxuICAgIF0sXHJcbiAgICBwcm92aWRlcnM6IFtPcGNRdWFsaXR5U2VydmljZV0sXHJcbiAgICBkZWNsYXJhdGlvbnM6IFtdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBSYUZ0Y0NvbW11bmljYXRpb25Nb2R1bGUge1xyXG4gICAgc3RhdGljIGZvclJvb3QoY29uZmlnOiBJQ29tbXVuaWNhdGlvbkNvbmZpZyk6IE1vZHVsZVdpdGhQcm92aWRlcnMge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG5nTW9kdWxlOiBSYUZ0Y0NvbW11bmljYXRpb25Nb2R1bGUsXHJcbiAgICAgICAgICAgIHByb3ZpZGVyczogW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IEluc3RhbmNlU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cEluc3RhbmNlU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IExpdmVEYXRhU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cExpdmVEYXRhU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IFRpbWVzZXJpZXNEYXRhU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cFRpbWVzZXJpZXNEYXRhU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnQsIE9wY1F1YWxpdHlTZXJ2aWNlXHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBPcGVyYXRpb25TZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwT3BlcmF0aW9uU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IFBlcnNpc3RlbmNlU2VydmljZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VGYWN0b3J5OiBzZXR1cFBlcnNpc3RlbmNlU3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IE5hdmlnYXRpb25TZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwTmF2aWdhdGlvblN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBTZWN1cml0eUNvbnRleHRTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwU2VjdXJpdHlDb250ZXh0U3ZjLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlcHM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgQ09NTVVOSUNBVElPTl9DT05GSUcsIEh0dHBDbGllbnRcclxuICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHByb3ZpZGU6IE1pbWVTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZUZhY3Rvcnk6IHNldHVwTWltZVN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENPTU1VTklDQVRJT05fQ09ORklHLCBIdHRwQ2xpZW50XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwcm92aWRlOiBOYXZpZ2F0aW9uSGFuZGxlclNlcnZpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlRmFjdG9yeTogc2V0dXBOYXZpZ2F0aW9uSGFuZGxlclN2YyxcclxuICAgICAgICAgICAgICAgICAgICBkZXBzOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSHR0cENsaWVudFxyXG4gICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7IHByb3ZpZGU6IENPTU1VTklDQVRJT05fQ09ORklHLCB1c2VWYWx1ZTogY29uZmlnIH1cclxuICAgICAgICAgICAgXVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbIkluamVjdGlvblRva2VuIiwiaHR0cCIsIl8uZXh0ZW5kIiwidHNsaWJfMS5fX2V4dGVuZHMiLCJJbmplY3RhYmxlIiwiSW5qZWN0IiwiSHR0cENsaWVudCIsIl8uaXNOaWwiLCJfLmNsb25lIiwiXy5pbmRleE9mIiwibWFwIiwiXy5lYWNoIiwiU3ViamVjdCIsImV4cGFuZCIsInRpbWVyIiwiY29uY2F0TWFwIiwiT2JzZXJ2YWJsZSIsIl8uZmlsdGVyIiwibW9tZW50LnV0YyIsIm1vbWVudC50eiIsIl8ubGFzdCIsIl8uZmlyc3QiLCJfLmZpbmQiLCJfLnNvcnRCeSIsIl8uc29tZSIsIk5nTW9kdWxlIiwiQ29tbW9uTW9kdWxlIiwiSHR0cENsaWVudE1vZHVsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0lBQUE7Ozs7Ozs7Ozs7Ozs7O0lBY0E7SUFFQSxJQUFJLGFBQWEsR0FBRyxNQUFNLENBQUMsY0FBYztTQUNwQyxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsWUFBWSxLQUFLLElBQUksVUFBVSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM1RSxVQUFVLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQUUsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztnQkFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUUvRSx1QkFBMEIsQ0FBQyxFQUFFLENBQUM7UUFDMUIsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwQixnQkFBZ0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsRUFBRTtRQUN2QyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsS0FBSyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7O1FDWlksOEJBQThCLEdBQUcsQ0FBQyxDQUFDO1FBV25DLG9CQUFvQixHQUFHLElBQUlBLG1CQUFjLENBQXVCLDZCQUE2QixDQUFDOztRQ2xCM0c7UUFFSSxxQkFDYyxXQUFtQixFQUNuQixNQUE0QixFQUM1QkMsT0FBZ0I7WUFGaEIsZ0JBQVcsR0FBWCxXQUFXLENBQVE7WUFDbkIsV0FBTSxHQUFOLE1BQU0sQ0FBc0I7WUFDNUIsU0FBSSxHQUFKQSxPQUFJLENBQVk7U0FBSztRQUV6QixzQ0FBZ0IsR0FBMUIsVUFBMkIsT0FBWTtZQUNuQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUMzQ0MsUUFBUSxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLG1DQUFtQyxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7U0FDaEg7UUFFUyxxQ0FBZSxHQUF6QjtZQUNJLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFDakNBLFFBQVEsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxtQ0FBbUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1NBQ2hIOzBCQXBCTDtRQXFCQzs7O1FDa0NvQ0MsbUNBQVc7UUFFNUMseUJBQTBDLFFBQThCRixPQUFnQjttQkFDcEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQztTQUMzRDtRQUtNLHNDQUFZLGFBQUMsZUFBZ0M7WUFDaEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLENBQUM7OztvQkFYckRHLGVBQVU7Ozs7d0RBR01DLFdBQU0sU0FBQyxvQkFBb0I7d0JBeERuQ0MsZUFBVTs7OzhCQURuQjtNQXVEcUMsV0FBVztRQWNoRDtRQVNJLHlCQUFZLHNCQUFnQztZQUN4QyxJQUFJLENBQUNDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsc0JBQXNCLENBQUM7YUFDeEQ7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQzthQUN0QztTQUNKO1FBS08sMkNBQWlCLGFBQ3JCLGVBQW9ELEVBQUUsb0JBQTZCLEVBQ25GLGNBQXNCLEVBQUUsZ0JBQXlCO1lBRWpELGVBQWUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1lBQ3BDLElBQUksb0JBQW9CLEVBQUU7Z0JBQ3RCLGVBQWUsQ0FBQyxjQUFjLENBQUMsVUFBVSxHQUFHLG9CQUFvQixDQUFDO2FBQ3BFO1lBQ0QsSUFBSSxDQUFDQSxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksY0FBYyxHQUFHLENBQUMsRUFBRTtnQkFDaEQsZUFBZSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEdBQUcsY0FBYyxDQUFDO2FBQ3pEO1lBQ0QsSUFBSSxnQkFBZ0IsRUFBRTtnQkFDbEIsZUFBZSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQzthQUN0RTs7UUFVRSxvQ0FBVSxhQUFDLEdBQVcsRUFBRSxvQkFBOEIsRUFBRSxjQUF1QixFQUFFLGdCQUEwQjtZQUM5RyxJQUFNLGVBQWUsR0FBb0I7Z0JBQ3JDLEdBQUcsRUFBRSxHQUFHO2FBQ1gsQ0FBQztZQUNGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLEVBQUUsb0JBQW9CLEVBQUUsY0FBYyxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDaEcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7YUFDbEI7WUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUNoQyxPQUFPLElBQUksQ0FBQzs7UUFVVCxtREFBeUIsYUFDNUIsR0FBVyxFQUNYLG9CQUE2QixFQUM3QixjQUFzQixFQUN0QixnQkFBeUI7WUFFekIsSUFBTSxlQUFlLEdBQW9CO2dCQUNyQyxHQUFHLEVBQUUsR0FBRztnQkFDUix5QkFBeUIsRUFBRSxJQUFJO2FBQ2xDLENBQUM7WUFDRixJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxFQUFFLG9CQUFvQixFQUFFLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2hHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNaLElBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO2FBQ2xCO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDaEMsT0FBTyxJQUFJLENBQUM7O1FBWVQsd0NBQWMsYUFDakIsR0FBVyxFQUFFLG9CQUE4QixFQUFFLGNBQXVCLEVBQ3BFLGdCQUEwQixFQUFFLFFBQWlCLEVBQUUsSUFBYTtZQUU1RCxJQUFNLHVCQUF1QixHQUFvQjtnQkFDN0MsV0FBVyxFQUFFLEdBQUc7Z0JBQ2hCLHlCQUF5QixFQUFFLElBQUk7YUFDbEMsQ0FBQztZQUVGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyx1QkFBdUIsRUFBRSxvQkFBb0IsRUFBRSxjQUFjLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztZQUN4RyxJQUFJLENBQUNBLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDcEIsdUJBQXVCLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQzthQUMvQztZQUNELElBQUksQ0FBQ0EsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNoQix1QkFBdUIsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2FBQ3ZDO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7YUFDbEI7WUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3hDLE9BQU8sSUFBSSxDQUFDOztRQVVULGtDQUFRLGFBQ1gsZUFBdUIsRUFBRSxvQkFBOEIsRUFDdkQsY0FBdUIsRUFBRSxnQkFBMEI7WUFFbkQsSUFBTSxpQkFBaUIsR0FBc0I7Z0JBQ3pDLEtBQUssRUFBRSxlQUFlO2FBQ3pCLENBQUM7WUFDRixJQUFJLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLEVBQUUsb0JBQW9CLEVBQUUsY0FBYyxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDbEcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7YUFDckI7WUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDOzs4QkF4TXBCO1FBME1DOztRQ3hKRDtRQUtJLHFCQUFxQixJQUFrQjtZQUFsQixTQUFJLEdBQUosSUFBSSxDQUFjO1lBRW5DLElBQUksQ0FBQyxJQUFJLEdBQUdDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3QjtRQU1ELDRCQUFNLEdBQU4sVUFBTyxHQUFlO1lBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCO1FBTUQsK0JBQVMsR0FBVCxVQUFVLEdBQWU7WUFDckIsSUFBTSxLQUFLLEdBQUdDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3hDLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRTtnQkFDWCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDOUI7U0FDSjswQkE3RUw7UUE4RUMsQ0FBQTtBQTVCRDtRQWtDcUNOLG1DQUFXO1FBUTVDLHlCQUEwQyxRQUE4QkYsT0FBZ0I7WUFBeEYsWUFDSSxrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQyxTQUN2RDswQkFSb0MsSUFBSSxHQUFHLEVBQUU7O1NBUTdDO1FBTUQsaUNBQU8sR0FBUCxVQUFRLE9BQW9CO1lBQ3hCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FDdENTLGFBQUcsQ0FBQyxVQUFDLFFBQStCO2dCQUNoQyxJQUFNLEdBQUcsR0FBaUIsRUFBRSxDQUFDO2dCQUM3QkMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBQyxTQUFTO29CQUNuQyxHQUFHLENBQUMsSUFBSSxDQUFDO3dCQUNMLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTt3QkFDcEIsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHO3dCQUNsQixTQUFTLEVBQUUsU0FBUyxDQUFDLFNBQVM7d0JBQzlCLGVBQWUsRUFBRSxTQUFTLENBQUMsZUFBZTt3QkFDMUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDcEIsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDcEIsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdkIsQ0FBQyxDQUFDO2lCQUNOLENBQUMsQ0FBQztnQkFDSCxPQUFPLEdBQUcsQ0FBQzthQUNkLENBQUMsQ0FBQyxDQUFDO1NBQ1g7UUFFTyxxREFBMkI7WUFDL0IsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQztpQkFDaEUsSUFBSSxDQUFDRCxhQUFHLENBQUMsVUFBQyxRQUErQjtnQkFDdEMsSUFBTSxHQUFHLEdBQWlCLEVBQUUsQ0FBQztnQkFDN0JDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQUMsU0FBUztvQkFDbkMsR0FBRyxDQUFDLElBQUksQ0FBQzt3QkFDTCxJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUk7d0JBQ3BCLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRzt3QkFDbEIsU0FBUyxFQUFFLFNBQVMsQ0FBQyxTQUFTO3dCQUM5QixlQUFlLEVBQUUsU0FBUyxDQUFDLGVBQWU7d0JBQzFDLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3BCLENBQUMsRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3ZCLENBQUMsQ0FBQztpQkFDTixDQUFDLENBQUM7Z0JBQ0gsT0FBTyxHQUFHLENBQUM7YUFDZCxDQUFDLENBQUMsQ0FBQzs7UUFHSixpREFBdUI7O1lBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJQyxZQUFPLEVBQWdCLENBQUM7YUFDM0Q7WUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixJQUFJLElBQUksQ0FBQywrQkFBK0IsRUFBRTtnQkFDdkUsSUFBSSxrQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLDJCQUEyQixJQUFJLDhCQUE4QixDQUFDO2dCQUNqRyxrQkFBZ0IsR0FBRyxrQkFBZ0IsR0FBRyxJQUFJLENBQUM7Z0JBRTNDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFLbEUsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQzlEQyxnQkFBTSxDQUFDLGNBQU0sT0FBQUMsVUFBSyxDQUFDLGtCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDQyxtQkFBUyxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsMkJBQTJCLEVBQUUsR0FBQSxDQUFDLENBQUMsR0FBQSxDQUFDLENBQ2xHLENBQUMsU0FBUyxDQUFDLFVBQUMsUUFBc0I7b0JBQy9CLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQzVDLEVBQUUsVUFBQyxHQUFHO29CQUNILEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDN0MsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztvQkFDNUMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDeEMsRUFBRTtvQkFDQyxLQUFJLENBQUMsK0JBQStCLEdBQUcsSUFBSSxDQUFDO29CQUM1QyxLQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxFQUFFLENBQUM7aUJBQ3hDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsK0JBQStCLEdBQUcsS0FBSyxDQUFDO2FBQ2hEO1lBRUQsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7O1FBT3hDLHVDQUFhLEdBQWIsVUFBYyxPQUFvQjtZQUFsQyxpQkFrREM7WUFoREcsT0FBTyxJQUFJQyxlQUFVLENBQWUsVUFBQyxRQUFRO2dCQUV6Q0wsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsVUFBQyxHQUFHO29CQUNyQixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDckIsTUFBTSxHQUFHLEtBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNoQztvQkFDRCxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztpQkFDakMsQ0FBQyxDQUFDO2dCQUNILEtBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO2dCQUMvQixJQUFNLFlBQVksR0FBRyxLQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDRCxhQUFHLENBQUMsVUFBQyxlQUE2QjtvQkFDakcsT0FBT08sUUFBUSxDQUFDLGVBQWUsRUFBRSxVQUFDLENBQUM7d0JBQy9CLE9BQU9SLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztxQkFDOUMsQ0FBQyxDQUFDO2lCQUNOLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFDLFFBQXNCO29CQUNqQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUMzQixFQUFFLFVBQUMsS0FBSztvQkFDTCxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN6QixFQUFFO29CQUNDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDdkIsQ0FBQyxDQUFDO2dCQUVILE9BQU87b0JBRUhFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFVBQUMsR0FBRzt3QkFDckIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNmLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7NEJBQ3JCLE1BQU0sR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDaEM7d0JBQ0QsSUFBSSxNQUFNLEtBQUssQ0FBQyxFQUFFOzRCQUNkLEtBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUMxQjs2QkFBTTs0QkFDSCxLQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQzt5QkFDakM7cUJBQ0osQ0FBQyxDQUFDO29CQUVILFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDM0IsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUN2QixJQUFJLEtBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBRTt3QkFDdkIsSUFBSSxLQUFJLENBQUMseUJBQXlCLEVBQUU7NEJBQ2hDLEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQzt5QkFDaEQ7d0JBQ0QsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUNyQyxPQUFPLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQzt3QkFDakMsS0FBSSxDQUFDLCtCQUErQixHQUFHLElBQUksQ0FBQztxQkFDL0M7aUJBQ0osQ0FBQzthQUNMLENBQUMsQ0FBQztTQUNOOztvQkE3SUpQLGVBQVU7Ozs7d0RBU01DLFdBQU0sU0FBQyxvQkFBb0I7d0JBM0ZuQ0MsZUFBVTs7OzhCQURuQjtNQW9GcUMsV0FBVzs7OztvQ0M5RG5CLE1BQU07MENBQ0EsTUFBTTtxQ0FDWCxVQUFVOzBDQUNMO2dCQUMvQixVQUFVLEVBQUUsTUFBTTtnQkFDbEIsY0FBYyxFQUFFLE1BQU07Z0JBQ3RCLE9BQU8sRUFBRSxNQUFNO2FBQ2hCO3NDQUM0QjtnQkFDM0IsR0FBRyxFQUFFLE1BQU07Z0JBQ1gsU0FBUyxFQUFFLE1BQU07Z0JBQ2pCLFVBQVUsRUFBRSxNQUFNO2dCQUNsQixJQUFJLEVBQUUsTUFBTTthQUNiO3NDQUM0QjtnQkFDM0IsR0FBRyxFQUFFLE1BQU07Z0JBQ1gsV0FBVyxFQUFFLE1BQU07Z0JBQ25CLFlBQVksRUFBRSxNQUFNO2dCQUNwQixhQUFhLEVBQUUsTUFBTTtnQkFDckIsYUFBYSxFQUFFLE1BQU07Z0JBQ3JCLFNBQVMsRUFBRSxNQUFNO2dCQUNqQixXQUFXLEVBQUUsTUFBTTtnQkFDbkIsWUFBWSxFQUFFLE1BQU07Z0JBQ3BCLFlBQVksRUFBRSxNQUFNO2dCQUNwQixTQUFTLEVBQUUsTUFBTTtnQkFDakIsVUFBVSxFQUFFLE1BQU07Z0JBQ2xCLGlCQUFpQixFQUFFLE1BQU07Z0JBQ3pCLGdCQUFnQixFQUFFLE1BQU07Z0JBQ3hCLFNBQVMsRUFBRSxNQUFNO2dCQUNqQixJQUFJLEVBQUUsTUFBTTtnQkFDWixhQUFhLEVBQUUsTUFBTTthQUN0QjtxQ0FDMkI7Z0JBQzFCLE9BQU8sRUFBRSxNQUFNO2dCQUNmLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixTQUFTLEVBQUUsTUFBTTtnQkFDakIsUUFBUSxFQUFFLE1BQU07YUFDakI7aUNBQ3VCO2dCQUN0QixTQUFTLEVBQUUsVUFBVTtnQkFDckIsWUFBWSxFQUFFLFVBQVU7Z0JBQ3hCLEdBQUcsRUFBRSxVQUFVO2dCQUNmLFVBQVUsRUFBRSxVQUFVO2dCQUN0QixPQUFPLEVBQUUsVUFBVTtnQkFDbkIsTUFBTSxFQUFFLFVBQVU7Z0JBQ2xCLFFBQVEsRUFBRSxVQUFVO2dCQUNwQixVQUFVLEVBQUUsVUFBVTtnQkFDdEIsT0FBTyxFQUFFLFVBQVU7YUFDcEI7bUNBQ3lCO2dCQUN4QixNQUFNLEVBQUUsS0FBSztnQkFDYixNQUFNLEVBQUUsV0FBVztnQkFDbkIsTUFBTSxFQUFFLGFBQWE7Z0JBQ3JCLE1BQU0sRUFBRSxNQUFNO2FBQ2Y7bUNBRXlCO2dCQUV4QixNQUFNLEVBQUUsYUFBYTtnQkFDckIsTUFBTSxFQUFFLGFBQWE7Z0JBQ3JCLE1BQU0sRUFBRSxjQUFjO2dCQUN0QixNQUFNLEVBQUUsVUFBVTtnQkFFbEIsTUFBTSxFQUFFLGNBQWM7Z0JBQ3RCLE1BQU0sRUFBRSxlQUFlO2dCQUN2QixNQUFNLEVBQUUsZ0JBQWdCO2dCQUN4QixNQUFNLEVBQUUsZ0JBQWdCO2dCQUN4QixNQUFNLEVBQUUsWUFBWTtnQkFDcEIsTUFBTSxFQUFFLGNBQWM7Z0JBQ3RCLE1BQU0sRUFBRSxnQkFBZ0I7Z0JBQ3hCLE1BQU0sRUFBRSxjQUFjO2dCQUV0QixNQUFNLEVBQUUsYUFBYTtnQkFDckIsTUFBTSxFQUFFLHNCQUFzQjtnQkFDOUIsTUFBTSxFQUFFLDRCQUE0QjtnQkFDcEMsTUFBTSxFQUFFLFlBQVk7Z0JBRXBCLE1BQU0sRUFBRSxnQkFBZ0I7Z0JBRXhCLFVBQVUsRUFBRSxZQUFZO2dCQUN4QixVQUFVLEVBQUUsY0FBYztnQkFDMUIsVUFBVSxFQUFFLEtBQUs7Z0JBQ2pCLFVBQVUsRUFBRSxZQUFZO2dCQUN4QixVQUFVLEVBQUUsVUFBVTtnQkFDdEIsVUFBVSxFQUFFLFNBQVM7Z0JBQ3JCLFVBQVUsRUFBRSxXQUFXO2dCQUN2QixVQUFVLEVBQUUsWUFBWTtnQkFDeEIsVUFBVSxFQUFFLFNBQVM7YUFDdEI7O1FBTU0sb0NBQVEsYUFBQyxZQUFvQjtZQUNsQyxJQUFJLElBQVksQ0FBQztZQUNqQixJQUFNLE9BQU8sSUFBRyxFQUFjLENBQUEsQ0FBQztZQUUvQixJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztZQUNsRCxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0MsSUFBSSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDNUMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDdEMsT0FBTyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pDO1lBRUQsSUFBSSxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDO1lBQzdELElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3RDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUM1QztZQUVELElBQUksR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQzdDLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3RDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMxQztZQUNELE9BQU8sT0FBTyxDQUFDOztRQU9WLG9DQUFRLGFBQUMsWUFBb0I7WUFDbEMsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDekMsSUFBSSxPQUFlLENBQUM7WUFFcEIsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDdkIsSUFBSSxJQUFJLENBQUMsRUFBRSxFQUFFO2dCQUNYLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ25DLFlBQVksR0FBRyxJQUFJLENBQUM7YUFDckI7WUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ2QsT0FBTyxHQUFHLE9BQU87cUJBQ2QsWUFBWSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUM1QyxZQUFZLEdBQUcsSUFBSSxDQUFDO2FBQ3JCO1lBQ0QsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNaLE9BQU8sR0FBRyxPQUFPO3FCQUNkLFlBQVksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUMzQztZQUNELE9BQU8sT0FBTyxDQUFDOztRQU9WLDJDQUFlLGFBQUMsWUFBb0I7WUFDekMsT0FBTyxZQUFZLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDOztRQU92Qyw2Q0FBaUIsYUFBQyxZQUFvQjtZQUMzQyxPQUFPLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDOztRQU94RCw0Q0FBZ0IsYUFBQyxZQUFvQjtZQUMxQyxPQUFPLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUM7O1FBTzdDLDRDQUFnQixhQUFDLFlBQW9CO1lBQzFDLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQzs7UUFPeEMsa0NBQU0sYUFBQyxZQUFvQjtZQUNoQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQzs7UUFPeEYsdUNBQVcsYUFBQyxZQUFvQjtZQUNyQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7UUFPN0YsaUNBQUssYUFBQyxZQUFvQjtZQUMvQixPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQzs7UUFPdkYsMkNBQWUsYUFBQyxZQUFvQjtZQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQzs7UUFNMUUsNENBQWdCLGFBQUMsWUFBb0I7WUFDMUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO2dCQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7O1FBTTVFLDZDQUFpQixhQUFDLFlBQW9CO1lBQzNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDOztRQU05RSw2Q0FBaUIsYUFBQyxZQUFvQjtZQUMzQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQzs7UUFNOUUseUNBQWEsYUFBQyxZQUFvQjtZQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7UUFNdEUsMkNBQWUsYUFBQyxZQUFvQjtZQUN6QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQzs7UUFNMUUsNENBQWdCLGFBQUMsWUFBb0I7WUFDMUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO2dCQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7O1FBTTVFLDRDQUFnQixhQUFDLFlBQW9CO1lBQzFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDOztRQU01RSwwQ0FBYyxhQUFDLFlBQW9CO1lBQ3hDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDOztRQU14RSxpREFBcUIsYUFBQyxZQUFvQjtZQUMvQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLENBQUM7O1FBTXRGLGdEQUFvQixhQUFDLFlBQW9CO1lBQzlDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQzs7UUFNcEYseUNBQWEsYUFBQyxZQUFvQjtZQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQzs7UUFNdEUsNkNBQWlCLGFBQUMsWUFBb0I7WUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO2dCQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUM7O1FBTzlFLHFDQUFTLGFBQUMsWUFBb0I7WUFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7UUFNaEUsc0NBQVUsYUFBQyxZQUFvQjtZQUNwQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztnQkFDMUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDOztRQU1sRSx1Q0FBVyxhQUFDLFlBQW9CO1lBQ3JDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDO2dCQUMxQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7O1FBTXBFLDJDQUFlLGFBQUMsWUFBb0I7WUFDekMsT0FBTyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQzs7UUFNbEUsMENBQWMsYUFBQyxZQUFvQjtZQUN4QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztnQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7O1FBTTVELDZDQUFpQixhQUFDLFlBQW9CO1lBQzNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO2dCQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQzs7UUFNbEUsb0NBQVEsYUFBQyxZQUFvQjtZQUNsQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztnQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUM7O1FBTWhELDJDQUFlLGFBQUMsWUFBb0I7WUFDekMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDOztRQU05RCx3Q0FBWSxhQUFDLFlBQW9CO1lBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO2dCQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQzs7UUFNeEQsdUNBQVcsYUFBQyxZQUFvQjtZQUNyQyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztnQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7O1FBTXRELHlDQUFhLGFBQUMsWUFBb0I7WUFDdkMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOztRQU0xRCwyQ0FBZSxhQUFDLFlBQW9CO1lBQ3pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO2dCQUN6QyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQzs7UUFNOUQsd0NBQVksYUFBQyxZQUFvQjtZQUN0QyxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztnQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7OztvQkExWmhFRixlQUFVOztnQ0FuQlg7Ozs7OztRQ2dCa0IsaUNBQWEsYUFBQyxRQUFnQixFQUFFLFFBQWdCO1lBQzVELElBQU0sS0FBSyxHQUFHYyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbkMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuQixPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUM7O1FBRzdDLG1DQUFlO1lBQ3pCLE9BQU9DLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7UUFHZixtQ0FBZSxhQUFDLFFBQVE7WUFDcEMsT0FBTyxRQUFRLElBQUlBLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7OzhEQXRCVyw0QkFBNEI7NkRBQzdCLDBCQUEwQjs7b0JBSHJGZixlQUFVOztrQ0FIWDs7Ozs7Ozs7Ozs7Ozs7dUJDc0VvQixlQUFlO29CQUNsQixZQUFZOzs7dUJBSVQsZUFBZTt1QkFDZixlQUFlO2dCQUN0QixRQUFRO2VBQ1QsT0FBTzthQUNULEtBQUs7aUJBQ0QsU0FBUztxQkFDTCxhQUFhO2VBQ25CLE9BQU87MkJBQ0ssbUJBQW1COzJCQUNuQixtQkFBbUI7aUJBQzdCLFNBQVM7ZUFDWCxPQUFPO2FBQ1QsS0FBSztlQUNILE9BQU87a0JBQ0osVUFBVTtlQUNiLE9BQU87c0JBQ0EsY0FBYztxQkFDZixhQUFhO3FCQUNiLGFBQWE7b0JBQ2QsWUFBWTtzQkFDVixjQUFjO2tDQUNGLDBCQUEwQjs0QkFDaEMsb0JBQW9COzBCQUN0QixrQkFBa0I7MEJBQ2xCLGtCQUFrQjt5QkFDbkIsaUJBQWlCOztRQWV2QztRQWVJLDJCQUNZLE1BQ0EsWUFDQSxvQkFDQSxjQUNBLGVBQ0E7WUFMQSxTQUFJLEdBQUosSUFBSTtZQUNKLGVBQVUsR0FBVixVQUFVO1lBQ1YsdUJBQWtCLEdBQWxCLGtCQUFrQjtZQUNsQixpQkFBWSxHQUFaLFlBQVk7WUFDWixrQkFBYSxHQUFiLGFBQWE7WUFDYixrQkFBYSxHQUFiLGFBQWE7WUFFckIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQy9CLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ2xEO1FBTUQsa0NBQU0sR0FBTixVQUFPLEdBQWU7WUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7UUFNRCxxQ0FBUyxHQUFULFVBQVUsR0FBZTtZQUNyQixJQUFNLEtBQUssR0FBR0ssU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDeEMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO2dCQUNYLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQzthQUM5QjtTQUNKO1FBTUQsbUNBQU8sR0FBUCxVQUFRLElBQWtCO1lBQ3RCLElBQUksQ0FBQyxJQUFJLEdBQUdELE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3QjtRQUtELG1DQUFPLEdBQVA7WUFDSSxPQUFPQSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzdCO1FBTUQseUNBQWEsR0FBYixVQUFjLFVBQXVCO1lBQ2pDLElBQUksQ0FBQyxVQUFVLEdBQUdBLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUN6QztRQUtELHlDQUFhLEdBQWI7WUFDSSxPQUFPQSxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ25DO1FBTUQsaURBQXFCLEdBQXJCLFVBQXNCLGtCQUF3QztZQUMxRCxJQUFJLENBQUMsa0JBQWtCLEdBQUdBLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ3pEO1FBS0QsaURBQXFCLEdBQXJCO1lBQ0ksT0FBT0EsT0FBTyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQzNDO1FBTUQsMkNBQWUsR0FBZixVQUFnQixZQUFxQjtZQUNqQyxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztTQUNwQztRQUtELDJDQUFlLEdBQWY7WUFDSSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDNUI7UUFNRCw0Q0FBZ0IsR0FBaEIsVUFBaUIsYUFBc0I7WUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7U0FDdEM7UUFLRCw0Q0FBZ0IsR0FBaEI7WUFDSSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7U0FDN0I7UUFNRCw0Q0FBZ0IsR0FBaEIsVUFBaUIsYUFBaUQ7WUFDOUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7U0FDdEM7UUFLRCw0Q0FBZ0IsR0FBaEI7WUFDSSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7U0FDN0I7Z0NBMVBMO1FBMlBDLENBQUE7QUF4SUQ7UUE4STJDTCx5Q0FBVztRQUVsRCwrQkFDa0MsUUFDOUJGLE9BQWdCLEVBQVUsYUFBZ0M7WUFGOUQsWUFHSSxrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLG9CQUFvQixFQUFFLE1BQU0sRUFBRUEsT0FBSSxDQUFDLFNBQzdEO1lBRjZCLG1CQUFhLEdBQWIsYUFBYSxDQUFtQjs7U0FFN0Q7UUFlRCx1Q0FBTyxHQUFQLFVBQVEsT0FBMEIsRUFBRSxRQUFpQjtZQUFyRCxpQkFPQztZQU5HLElBQUksRUFBVSxDQUFDO1lBQ2YsSUFBSSxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQy9DLEVBQUUsR0FBRyxRQUFRLENBQUM7YUFDakI7WUFDRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUNTLGFBQUcsQ0FBQyxVQUFDLFFBQTJDO2dCQUN2RixPQUFBLEtBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO2FBQUEsQ0FBQyxDQUFDLENBQUM7U0FDakU7UUFNTyxtREFBbUIsYUFBQyxXQUFtQjtZQUMzQyxPQUFPLElBQUlNLGVBQVUsQ0FBcUIsVUFBQyxRQUFRO2dCQUMvQyxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM1QixPQUFPO29CQUNILFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDMUIsQ0FBQzthQUNMLENBQUMsQ0FBQzs7UUFRQyx1REFBdUIsYUFBQyxPQUF3QyxFQUFFLFFBQVE7WUFDOUVMLE1BQU0sQ0FBQyxPQUFPLEVBQUUsVUFBQyxHQUFrQztnQkFDL0MsR0FBRyxDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUM5RCxDQUFDLENBQUM7WUFDSCxPQUFPLE9BQU8sQ0FBQzs7UUFPWCw4REFBOEIsYUFBQyxRQUEyQyxFQUFFLGVBQThCO1lBRTlHLElBQU0sdUJBQXVCLEdBQXFCLElBQUksR0FBRyxFQUFFLENBQUM7WUFDNUQsSUFBSSxJQUFtQyxDQUFDO1lBQ3hDQSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLEVBQUU7Z0JBQzVCLElBQUksQ0FBQ0osT0FBTyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO29CQUNsQyxJQUFJLEdBQUdhLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pCLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUM3QzthQUNKLENBQUMsQ0FBQztZQUVILE9BQU8sdUJBQXVCLENBQUM7O1FBTTNCLHVEQUF1QixhQUMzQixRQUEyQyxFQUFFLGdCQUF3QixFQUFFLGdCQUF3QjtZQUMvRixJQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQ3pDLDBCQUEwQixTQUFrRDtnQkFDeEUsSUFBTSxVQUFVLEdBQUdDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUvQyxLQUFLLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNuRCxJQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDekMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUNoQjtpQkFDSjtnQkFFRCxPQUFPLFVBQVUsQ0FBQzthQUNyQjtZQUVELElBQUksTUFBcUIsQ0FBQztZQUMxQixJQUFNLHdCQUF3QixHQUFHSCxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBRTlGUCxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFDLFNBQVM7Z0JBQ25DLElBQUlKLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBRXJELE9BQU87aUJBQ1Y7Z0JBQ0QsSUFBTSxTQUFTLEdBQUdXLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUMxRCxJQUFJWCxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDOUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztpQkFDOUI7YUFDSixDQUFDLENBQUM7WUFFSCxJQUFJQSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBRWpCLE1BQU0sR0FBR1csVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO2FBQ3hGO1lBRUQsSUFBSSx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzFDLE1BQU0sR0FBRyx3QkFBd0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsY0FBYyxDQUFDLENBQUM7YUFDbkY7WUFFRCxPQUFPLE1BQU0sQ0FBQzs7UUFPVix3REFBd0IsYUFDNUIsUUFBMkMsRUFDM0Msd0JBQW9FLEVBQUUsaUJBQThCO1lBQ3BHLElBQUksUUFBUSxDQUFDO1lBQ2IsSUFBSSxjQUFjLENBQUM7WUFDbkIsSUFBSSxTQUFTLENBQUM7WUFFZCxJQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQ3pDLElBQU0sYUFBYSxHQUFHQSxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxRCxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDeEVQLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQUMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDSixPQUFPLENBQUMsRUFBRSxDQUFDLElBQUksd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQzlFLElBQU0sMkJBQTJCLEdBQUcsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDekUsSUFBTSxpQ0FBaUMsR0FBR1csVUFBVSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNwRixRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNwQyxjQUFjLEdBQUdBLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hDLElBQUksYUFBYSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MsU0FBUyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDckMsSUFBSSxjQUFjLEdBQUcsaUNBQWlDOzRCQUNsRCxjQUFjLEdBQUdBLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDOzRCQUN4QyxhQUFhLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQzs0QkFDbkQsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ25DLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt5QkFDMUI7cUJBQ0o7aUJBQ0o7YUFDSixDQUFDLENBQUM7O1FBR0Msb0VBQW9DLGFBQUMsUUFBMkMsRUFBRSxRQUFpQjs7WUFDdkcsSUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBRTFCLElBQUksQ0FBQ1gsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUVwQixhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUVyQixRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ25HLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUNsRztZQUVELElBQU0sR0FBRyxHQUF1QjtnQkFDNUIsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVO2dCQUMvQixPQUFPLEVBQUUsRUFBRTthQUNkLENBQUM7WUFFRkksTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBQyxTQUFTO2dCQUNuQyxJQUFJSixPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7b0JBRXBCLE9BQU87aUJBQ1Y7Z0JBRUQsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsS0FBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7aUJBQzVEO2dCQUVELEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO29CQUNiLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTtvQkFDcEIsR0FBRyxFQUFFLFNBQVMsQ0FBQyxHQUFHO29CQUNsQixTQUFTLEVBQUUsU0FBUyxDQUFDLFNBQVM7b0JBQzlCLGVBQWUsRUFBRSxTQUFTLENBQUMsZUFBZTtvQkFDMUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxNQUFNO2lCQUMzQixDQUFDLENBQUM7YUFDTixDQUFDLENBQUM7WUFDSCxPQUFPLEdBQUcsQ0FBQzs7UUFNUCwwREFBMEIsYUFDOUIsTUFBdUMsRUFBRSxlQUE4QixFQUN2RSxvQkFBOEIsRUFBRSxRQUFpQjtZQUNqRCxJQUFNLEdBQUcsR0FBa0IsRUFBRSxDQUFDO1lBQzlCLElBQUksa0JBQWlELENBQUM7WUFDdEQsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBRXpCLHFCQUFxQixDQUFnQztnQkFDakQsSUFBTSxpQkFBaUIsR0FBR1csVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7b0JBQzVDLElBQUksQ0FBQyxZQUFZLEVBQUU7d0JBQ2Ysa0JBQWtCLEdBQUdWLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEMsSUFBTSx3QkFBd0IsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7d0JBQzdHLElBQUksQ0FBQ0QsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFOzRCQUNwQixrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsbUJBQW1CLENBQUMsYUFBYSxDQUFDLHdCQUF3QixFQUFFLFFBQVEsQ0FBQyxDQUFDO3lCQUNoRzs2QkFBTTs0QkFDSCxrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsd0JBQXdCLENBQUM7eUJBQ25EO3dCQUNELFlBQVksR0FBRyxJQUFJLENBQUM7cUJBQ3ZCO29CQUNELE9BQU8sS0FBSyxDQUFDO2lCQUNoQjtnQkFDRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO29CQUN6QixPQUFPLEtBQUssQ0FBQztpQkFDaEI7Z0JBQ0QsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2QsT0FBTyxJQUFJLENBQUM7YUFDZjtZQUNELElBQU0sYUFBYSxHQUFHLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDM0QsSUFBSSxDQUFDLG9CQUFvQixJQUFJLFlBQVksRUFBRTtnQkFDdkMsSUFBTSxTQUFTLEdBQUdhLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDRixVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQ0EsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBRWpGLGFBQWEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztpQkFDMUM7YUFDSjtZQUNELE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFDOztRQVEzQixtREFBbUIsYUFBQyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsUUFBaUI7O1lBQzlGLElBQUksa0JBQXNDLENBQUM7WUFDM0MsSUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDO1lBRXBCLElBQU0sYUFBYSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLFFBQVEsQ0FBQztpQkFDakYsSUFBSSxDQUFDUixhQUFHLENBQUMsVUFBQyxRQUE0QjtnQkFDbkMsSUFBSSxDQUFDSCxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDOUIsSUFBTSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ2xELElBQU0sZUFBYSxHQUFHVyxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDMUQsZUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO29CQUN4RSxJQUFNLHNCQUFzQixHQUFHLGVBQWEsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsK0JBQStCLENBQUMsQ0FBQztvQkFFekcsSUFBSSxDQUFDWCxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7d0JBQ2Qsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUM7d0JBQ3BHLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7cUJBQy9EO3lCQUFNO3dCQUNILGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsc0JBQXNCLENBQUM7d0JBQzdELGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHOzRCQUM3QlcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7cUJBQ3ZHO29CQUVEUCxNQUFNLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFVBQUMsTUFBTTt3QkFDdEMsSUFBTSxVQUFVLEdBQUdXLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO3dCQUNqRSxJQUFJLENBQUNmLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRTs0QkFDdEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7NEJBRXhELE1BQU0sQ0FBQyxNQUFNLEdBQUdnQixRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLFVBQUMsQ0FBZ0M7b0NBQ3RFLE9BQU9MLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUNBQzFCLENBQUMsQ0FBQyxDQUFDOzRCQUVKLE1BQU0sQ0FBQyxNQUFNLEdBQUcsS0FBSSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsZUFBYSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQzt5QkFDNUY7cUJBQ0osQ0FBQyxDQUFDO29CQUVIUCxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFNBQVM7d0JBQy9CLElBQUksQ0FBQ1csTUFBTSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRTs0QkFDN0Qsa0JBQWtCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt5QkFDOUM7cUJBQ0osQ0FBQyxDQUFDO29CQUNILE9BQU8sa0JBQWtCLENBQUM7aUJBQzdCO3FCQUFNO29CQUNILGtCQUFrQixHQUFHLFFBQVEsQ0FBQztvQkFDOUIsT0FBTyxRQUFRLENBQUM7aUJBQ25CO2FBQ0osQ0FBQyxDQUFDLENBQUM7WUFDUixPQUFPLGFBQWEsQ0FBQzs7UUFRakIsd0RBQXdCLGFBQzVCLE9BQTBCLEVBQUUsY0FBdUIsRUFBRSxRQUFpQjs7WUFFdEUsSUFBTSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7WUFFbEQsSUFBSSxnQkFBa0MsQ0FBQztZQUN2QyxJQUFJLGdCQUFnQixHQUFHLGNBQWMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLDJCQUEyQixJQUFJLDhCQUE4QixDQUFDO1lBQ25ILGdCQUFnQixHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUUzQyxJQUFNLG1CQUFtQixHQUFHZCxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0MsSUFBTSxnQkFBZ0IsR0FBRyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7WUFDcEQsSUFBSSxzQkFBcUMsQ0FBQztZQUUxQyxJQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUNFLGFBQUcsQ0FBQyxVQUFDLFFBQTJDO2dCQUMvRyxzQkFBc0IsR0FBRyxLQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBS3BHLGdCQUFnQixHQUFHLEtBQUksQ0FBQyw4QkFBOEIsQ0FBQyxRQUFRLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztnQkFDekYsT0FBTyxLQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ3hFLENBQUMsQ0FBQyxDQUFDO1lBQ0osSUFBTSxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQ2xERyxnQkFBTSxDQUFDO2dCQUFNLE9BQUFDLFVBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQ0MsbUJBQVMsQ0FBQztvQkFDaEQsSUFBSSxDQUFDUixPQUFPLENBQUMsc0JBQXNCLENBQUMsRUFBRTt3QkFDbEMsbUJBQW1CLENBQUMsYUFBYSxDQUM3QkwsUUFBUSxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsc0JBQXNCLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQy9HO29CQUNELE9BQU8sS0FBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDUSxhQUFHLENBQUMsVUFBQyxRQUEyQzt3QkFDbkcsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFOzRCQUkzQixLQUFJLENBQUMsd0JBQXdCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDLENBQUM7eUJBQ2hGO3dCQUNELHNCQUFzQixHQUFHLEtBQUksQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQzt3QkFLcEcsZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO3dCQUN6RixPQUFPLEtBQUksQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ3hFLENBQUMsQ0FBQyxDQUFDO2lCQUNQLENBQUMsQ0FBQzthQUFBLENBQUMsQ0FDUCxDQUFDO1lBQ0YsT0FBTyxrQkFBa0IsQ0FBQzs7UUFxQjlCLDZDQUFhLEdBQWIsVUFBYyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsTUFBcUMsRUFBRSxRQUFpQjtZQUd2SCxJQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNsRCxJQUFJLENBQUNILE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO3NCQUNuRixrRUFBa0U7c0JBQ2xFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQzthQUM1RDtpQkFBTSxJQUFJQSxPQUFPLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksaUJBQWlCLENBQUMsUUFBUSxHQUFHLENBQUMsRUFBRTtnQkFDOUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO3NCQUNuRixvREFBb0Q7c0JBQ3BELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQzthQUM1RDtZQUVELElBQUksRUFBVSxDQUFDO1lBQ2YsSUFBSSxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQy9DLEVBQUUsR0FBRyxRQUFRLENBQUM7YUFDakI7WUFDRCxJQUFJQSxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxLQUFLLDRCQUE0QixDQUFDLGFBQWEsRUFBRTtnQkFDMUUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQzthQUNoRTtpQkFBTTtnQkFDSCxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQ3JFO1NBQ0o7O29CQTFYSkgsZUFBVTs7Ozt3REFJRkMsV0FBTSxTQUFDLG9CQUFvQjt3QkFuUTNCQyxlQUFVO3dCQUdWLGlCQUFpQjs7O29DQUoxQjtNQWlRMkMsV0FBVzs7O1FDMVBoQkgsb0NBQVc7UUFFN0MsMEJBQTBDLFFBQThCRixPQUFnQjttQkFDcEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQztTQUM1RDtRQUtNLDJDQUFnQixhQUFDLFlBQThCO1lBQ2xELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDOzs7b0JBWGxERyxlQUFVOzs7O3dEQUdNQyxXQUFNLFNBQUMsb0JBQW9CO3dCQVJwQ0MsZUFBVTs7OytCQURsQjtNQU9zQyxXQUFXO1FBY2pEO1FBT0ksMEJBQW1CLE1BQWMsRUFBUyxTQUFpQixFQUFTLFVBQW1CO1lBQXBFLFdBQU0sR0FBTixNQUFNLENBQVE7WUFBUyxjQUFTLEdBQVQsU0FBUyxDQUFRO1lBQVMsZUFBVSxHQUFWLFVBQVUsQ0FBUztTQUN0RjsrQkE3Qkw7UUE4QkM7OztRQ0x1Q0gsc0NBQVc7UUFFL0MsNEJBQTBDLFFBQThCRixPQUFnQjttQkFDcEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQztTQUM5RDtRQUtELG1DQUFNLEdBQU4sVUFBTyxjQUE4QjtZQUNqQyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUNoRDs7b0JBWkpHLGVBQVU7Ozs7d0RBR01DLFdBQU0sU0FBQyxvQkFBb0I7d0JBeEJwQ0MsZUFBVTs7O2lDQUhsQjtNQXlCd0MsV0FBVztRQWNuRDs7O1FBT0ksNEJBQUcsR0FBSCxVQUFJLElBQVksRUFBRSxLQUFhO1lBQzNCLElBQUksSUFBSSxFQUFFO2dCQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDdEI7U0FDSjtRQU1ELCtCQUFNLEdBQU4sVUFBTyxJQUFZO1lBQ2YsSUFBSSxDQUFDQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUU7Z0JBQ3RCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3JCO1NBQ0o7UUFFRCxnQ0FBTyxHQUFQO1lBQ0ksT0FBTyxDQUFDaUIsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3hCOzZCQWhFTDtRQWlFQyxDQUFBO0FBMUJELFFBNEJBOzs7UUFnQkksbUNBQVUsR0FBVixVQUFXLGlCQUF5QixFQUFFLFFBQWdCLEVBQUUsY0FBK0I7WUFDbkYsSUFBTSxhQUFhLEdBQWE7Z0JBQzVCLGlCQUFpQixFQUFFLGlCQUFpQjtnQkFDcEMsUUFBUSxFQUFFLFFBQVE7YUFDckIsQ0FBQztZQUVGLElBQUksY0FBYyxFQUFFO2dCQUNoQixhQUFhLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQzthQUN4QztZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQzthQUN0QjtZQUVELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2xDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFPRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZSxFQUFFLE9BQWU7WUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRztnQkFDZixHQUFHLEVBQUUsT0FBTztnQkFDWixPQUFPLEVBQUUsT0FBTzthQUNuQixDQUFDO1lBRUYsT0FBTyxJQUFJLENBQUM7U0FDZjtRQU9ELG1DQUFVLEdBQVYsVUFBVyxPQUFlLEVBQUUsY0FBOEI7WUFDdEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtnQkFDM0IsSUFBTSxhQUFhLEdBQWlCO29CQUNoQyxrQkFBa0IsRUFBRSxPQUFPO2lCQUM5QixDQUFDO2dCQUNGdEIsUUFBUSxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUMsQ0FBQztnQkFFeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQ3BCLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2lCQUMxQjtnQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUN6QztZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFNRCxtQ0FBVSxHQUFWLFVBQVcsT0FBZTtZQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDcEIsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7YUFDMUI7WUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxPQUFPLElBQUksQ0FBQztTQUNmOzZCQWpKTDtRQWtKQzs7O1FDeklzQ0MscUNBQVc7UUFFOUMsMkJBQTBDLFFBQThCRixPQUFnQjttQkFDcEYsa0JBQU0sTUFBTSxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQztTQUM3RDtRQUtELDZDQUFpQixHQUFqQixVQUFrQixpQkFBb0M7WUFDbEQsSUFBSSxPQUFPLEdBQUcsaUJBQWlCLENBQUM7WUFDaEMsSUFBSU0sT0FBTyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLGFBQWEsS0FBSyxFQUFFLEVBQUU7Z0JBQ3BGLElBQUlBLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUlBLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7b0JBQzFELE9BQU8sR0FBR0MsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQ3JDLE9BQU8sQ0FBQyxTQUFTLEdBQUdBLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMxRSxPQUFPLENBQUMsU0FBUyxHQUFHQSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDN0U7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ3pDOztvQkFwQkpKLGVBQVU7Ozs7d0RBR01DLFdBQU0sU0FBQyxvQkFBb0I7d0JBVG5DQyxlQUFVOzs7Z0NBRm5CO01BU3VDLFdBQVc7UUFzQmxEO1FBV0ksMkJBQ1csS0FBb0IsU0FBb0IsRUFBUyxjQUF3QixFQUN6RSxlQUErQixTQUEyQixFQUFTLFNBQTJCO1lBRDlGLFFBQUcsR0FBSCxHQUFHO1lBQWlCLGNBQVMsR0FBVCxTQUFTLENBQVc7WUFBUyxtQkFBYyxHQUFkLGNBQWMsQ0FBVTtZQUN6RSxrQkFBYSxHQUFiLGFBQWE7WUFBa0IsY0FBUyxHQUFULFNBQVMsQ0FBa0I7WUFBUyxjQUFTLEdBQVQsU0FBUyxDQUFrQjtTQUN4RztnQ0E3Q0w7UUErQ0M7OztRQzFCMkNILDBDQUFXO1FBRXJELGdDQUEwQyxRQUE4QkYsT0FBZ0I7bUJBQ3RGLGtCQUFNLE1BQU0sQ0FBQyxPQUFPLEdBQUcseUJBQXlCLEVBQUUsTUFBTSxFQUFFQSxPQUFJLENBQUM7U0FDaEU7UUFLTSx1REFBc0I7WUFDM0IsT0FBTyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7OztvQkFYakNHLGVBQVU7Ozs7d0RBR0lDLFdBQU0sU0FBQyxvQkFBb0I7d0JBdEJsQ0MsZUFBVTs7O3FDQURsQjtNQXFCNEMsV0FBVzs7O1FDZnRCSCwrQkFBVztRQUV4QyxxQkFBMEMsUUFBOEJGLE9BQWdCO21CQUNwRixrQkFBTSxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUVBLE9BQUksQ0FBQztTQUN2RDtRQUVELHFDQUFlLEdBQWYsVUFBZ0IsR0FBVztZQUN2QixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZDOztvQkFUSkcsZUFBVTs7Ozt3REFHTUMsV0FBTSxTQUFDLG9CQUFvQjt3QkFQbkNDLGVBQVU7OzswQkFEbkI7TUFNaUMsV0FBVzs7O1FDYUVILDRDQUFXO1FBRXZELGtDQUEwQyxRQUE4QkYsT0FBZ0I7bUJBQ3RGLGtCQUFNLE1BQU0sQ0FBQyxPQUFPLEdBQUcsMkJBQTJCLEVBQUUsTUFBTSxFQUFFQSxPQUFJLENBQUM7U0FDbEU7UUFLTSwyREFBd0IsYUFBQyxvQkFBOEM7WUFDNUUsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsb0JBQW9CLENBQUMsQ0FBQzs7O29CQVh0REcsZUFBVTs7Ozt3REFHSUMsV0FBTSxTQUFDLG9CQUFvQjt3QkFwQmxDQyxlQUFVOzs7dUNBRGxCO01BbUI4QyxXQUFXO1FBY3pEO1FBUUUsa0NBQW1CLEdBQVcsRUFBUyxvQkFBNkIsRUFDakQ7WUFEQSxRQUFHLEdBQUgsR0FBRyxDQUFRO1lBQVMseUJBQW9CLEdBQXBCLG9CQUFvQixDQUFTO1lBQ2pELDBCQUFxQixHQUFyQixxQkFBcUI7U0FDdkM7dUNBM0NIO1FBNENDOzs4QkM1QkcsTUFBNEIsRUFBRSxVQUFzQjtRQUNwRCxPQUFPLElBQUksZUFBZSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztLQUNsRDtBQUNELDhCQUNJLE1BQTRCLEVBQUUsVUFBc0I7UUFDcEQsT0FBTyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDbEQ7QUFDRCxvQ0FDSSxNQUE0QixFQUFFLFVBQXNCLEVBQUUsVUFBNkI7UUFDbkYsT0FBTyxJQUFJLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDcEU7QUFFRCwrQkFDSSxNQUE0QixFQUFFLFVBQXNCO1FBQ3BELE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDbkQ7QUFDRCxpQ0FDSSxNQUE0QixFQUFFLFVBQXNCO1FBQ3BELE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDckQ7QUFDRCxnQ0FDSSxNQUE0QixFQUFFLFVBQXNCO1FBQ3BELE9BQU8sSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDcEQ7QUFDRCxxQ0FDSSxNQUE0QixFQUFFLFVBQXNCO1FBQ3BELE9BQU8sSUFBSSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7S0FDekQ7QUFDRCwwQkFDSSxNQUE0QixFQUFFLFVBQXNCO1FBQ3BELE9BQU8sSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0tBQzlDO0FBQ0QsdUNBQ0UsTUFBNEIsRUFBRSxVQUFzQjtRQUNwRCxPQUFPLElBQUksd0JBQXdCLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0tBQ3pEOzs7O1FBV1UsZ0NBQU8sR0FBZCxVQUFlLE1BQTRCO1lBQ3ZDLE9BQU87Z0JBQ0gsUUFBUSxFQUFFLHdCQUF3QjtnQkFDbEMsU0FBUyxFQUFFO29CQUNQO3dCQUNJLE9BQU8sRUFBRSxlQUFlO3dCQUN4QixVQUFVLEVBQUUsZ0JBQWdCO3dCQUM1QixJQUFJLEVBQUU7NEJBQ0Ysb0JBQW9CLEVBQUVBLGVBQVU7eUJBQ25DO3FCQUNKO29CQUNEO3dCQUNJLE9BQU8sRUFBRSxlQUFlO3dCQUN4QixVQUFVLEVBQUUsZ0JBQWdCO3dCQUM1QixJQUFJLEVBQUU7NEJBQ0Ysb0JBQW9CLEVBQUVBLGVBQVU7eUJBQ25DO3FCQUNKO29CQUNEO3dCQUNJLE9BQU8sRUFBRSxxQkFBcUI7d0JBQzlCLFVBQVUsRUFBRSxzQkFBc0I7d0JBQ2xDLElBQUksRUFBRTs0QkFDRixvQkFBb0IsRUFBRUEsZUFBVSxFQUFFLGlCQUFpQjt5QkFDdEQ7cUJBQ0o7b0JBQ0Q7d0JBQ0ksT0FBTyxFQUFFLGdCQUFnQjt3QkFDekIsVUFBVSxFQUFFLGlCQUFpQjt3QkFDN0IsSUFBSSxFQUFFOzRCQUNGLG9CQUFvQixFQUFFQSxlQUFVO3lCQUNuQztxQkFDSjtvQkFDRDt3QkFDSSxPQUFPLEVBQUUsa0JBQWtCO3dCQUMzQixVQUFVLEVBQUUsbUJBQW1CO3dCQUMvQixJQUFJLEVBQUU7NEJBQ0Ysb0JBQW9CLEVBQUVBLGVBQVU7eUJBQ25DO3FCQUNKO29CQUNEO3dCQUNJLE9BQU8sRUFBRSxpQkFBaUI7d0JBQzFCLFVBQVUsRUFBRSxrQkFBa0I7d0JBQzlCLElBQUksRUFBRTs0QkFDRixvQkFBb0IsRUFBRUEsZUFBVTt5QkFDbkM7cUJBQ0o7b0JBQ0Q7d0JBQ0ksT0FBTyxFQUFFLHNCQUFzQjt3QkFDL0IsVUFBVSxFQUFFLHVCQUF1Qjt3QkFDbkMsSUFBSSxFQUFFOzRCQUNGLG9CQUFvQixFQUFFQSxlQUFVO3lCQUNuQztxQkFDSjtvQkFDRDt3QkFDSSxPQUFPLEVBQUUsV0FBVzt3QkFDcEIsVUFBVSxFQUFFLFlBQVk7d0JBQ3hCLElBQUksRUFBRTs0QkFDRixvQkFBb0IsRUFBRUEsZUFBVTt5QkFDbkM7cUJBQ0o7b0JBQ0Q7d0JBQ0ksT0FBTyxFQUFFLHdCQUF3Qjt3QkFDakMsVUFBVSxFQUFFLHlCQUF5Qjt3QkFDckMsSUFBSSxFQUFFOzRCQUNKLG9CQUFvQixFQUFFQSxlQUFVO3lCQUNqQztxQkFDSjtvQkFDRCxFQUFFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO2lCQUN0RDthQUNKLENBQUM7U0FDTDs7b0JBL0VKbUIsYUFBUSxTQUFDO3dCQUNOLE9BQU8sRUFBRTs0QkFDTEMsbUJBQVk7NEJBQ1pDLHFCQUFnQjt5QkFDbkI7d0JBQ0QsU0FBUyxFQUFFLENBQUMsaUJBQWlCLENBQUM7d0JBQzlCLFlBQVksRUFBRSxFQUFFO3FCQUNuQjs7dUNBNUREOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsifQ==