import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as _ from 'lodash';
import * as moment from 'moment-timezone';
import { OpcQualityService } from './opc-quality.service';
import { Observable, timer } from 'rxjs';
import { map, concatMap, expand } from 'rxjs/operators';
import { COMMUNICATION_CONFIG, DEFAULT_REPEATED_DATA_INTERVAL } from './config';
import { BaseService } from './base.service';
import { MomentHelperService } from './moment-helper.service';
export function ITimeseriesValuesResponseVqts() { }
function ITimeseriesValuesResponseVqts_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseVqts.prototype.v;
    ITimeseriesValuesResponseVqts.prototype.q;
    ITimeseriesValuesResponseVqts.prototype.t;
}
export function ITimeseriesValuesResponse() { }
function ITimeseriesValuesResponse_tsickle_Closure_declarations() {
    ITimeseriesValuesResponse.prototype.values;
}
export function ITimeseriesResponse() { }
function ITimeseriesResponse_tsickle_Closure_declarations() {
    ITimeseriesResponse.prototype.timePeriod;
    ITimeseriesResponse.prototype.results;
}
function ITimeseriesValuesResponseInternalObject() { }
function ITimeseriesValuesResponseInternalObject_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseInternalObject.prototype.fqn;
    ITimeseriesValuesResponseInternalObject.prototype.name;
    ITimeseriesValuesResponseInternalObject.prototype.engineeringUnit;
    ITimeseriesValuesResponseInternalObject.prototype.valueType;
    ITimeseriesValuesResponseInternalObject.prototype.values;
}
export function ITimePeriodResponse() { }
function ITimePeriodResponse_tsickle_Closure_declarations() {
    ITimePeriodResponse.prototype.start;
    ITimePeriodResponse.prototype.end;
    ITimePeriodResponse.prototype.duration;
}
function ITimeseriesValuesResponseInternal() { }
function ITimeseriesValuesResponseInternal_tsickle_Closure_declarations() {
    ITimeseriesValuesResponseInternal.prototype.timePeriod;
    ITimeseriesValuesResponseInternal.prototype.fqnsResults;
    ITimeseriesValuesResponseInternal.prototype.queryResults;
}
export function ITimePeriod() { }
function ITimePeriod_tsickle_Closure_declarations() {
    ITimePeriod.prototype.start;
    ITimePeriod.prototype.end;
    ITimePeriod.prototype.duration;
}
const TimeseriesRequestQuality = {
    includeGood: 1,
    includeBad: 2,
    includeUncertain: 4,
    includeAll: 7,
};
export { TimeseriesRequestQuality };
TimeseriesRequestQuality[TimeseriesRequestQuality.includeGood] = "includeGood";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeBad] = "includeBad";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeUncertain] = "includeUncertain";
TimeseriesRequestQuality[TimeseriesRequestQuality.includeAll] = "includeAll";
const TimeseriesRepeatedDataFormat = {
    wholeInterval: 'wholeInterval',
    increments: 'increments',
};
export { TimeseriesRepeatedDataFormat };
const SamplingTypes = {
    Interpolative: 'Interpolative',
    SampleAndHold: 'SampleAndHold',
    Linear: 'Linear',
    Total: 'Total',
    Sum: 'Sum',
    Average: 'Average',
    TimeAverage: 'TimeAverage',
    Count: 'Count',
    StandardDeviation: 'StandardDeviation',
    MinimumActualTime: 'MinimumActualTime',
    Maximum: 'Maximum',
    Start: 'Start',
    End: 'End',
    Delta: 'Delta',
    Variance: 'Variance',
    Range: 'Range',
    DurationGood: 'DurationGood',
    DurationBad: 'DurationBad',
    PercentGood: 'PercentGood',
    PercentBad: 'PercentBad',
    WorstQuality: 'WorstQuality',
    TimeAverageSampleAndHold: 'TimeAverageSampleAndHold',
    TotalSampleAndHold: 'TotalSampleAndHold',
    MinSampleAndHold: 'MinSampleAndHold',
    MaxSampleAndHold: 'MaxSampleAndHold',
    CumulativeTotal: 'CumulativeTotal',
};
export { SamplingTypes };
export function ISamplingDefinition() { }
function ISamplingDefinition_tsickle_Closure_declarations() {
    ISamplingDefinition.prototype.sliceCount;
    ISamplingDefinition.prototype.deltaT;
    ISamplingDefinition.prototype.samplingType;
}
export class TimeseriesRequest {
    constructor(fqns, timePeriod, samplingDefinition, timeDeadBand, valueDeadBand, qualityFilter) {
        this.fqns = fqns;
        this.timePeriod = timePeriod;
        this.samplingDefinition = samplingDefinition;
        this.timeDeadBand = timeDeadBand;
        this.valueDeadBand = valueDeadBand;
        this.qualityFilter = qualityFilter;
        this.setFqns(fqns);
        this.setTimePeriod(timePeriod);
        this.setSamplingDefinition(samplingDefinition);
    }
    addFqn(fqn) {
        this.fqns.push(fqn);
    }
    removeFqn(fqn) {
        const index = _.indexOf(this.fqns, fqn);
        if (index > 0) {
            this.fqns.splice(index, 1);
        }
    }
    setFqns(fqns) {
        this.fqns = _.clone(fqns);
    }
    getFqns() {
        return _.clone(this.fqns);
    }
    setTimePeriod(timePeriod) {
        this.timePeriod = _.clone(timePeriod);
    }
    getTimePeriod() {
        return _.clone(this.timePeriod);
    }
    setSamplingDefinition(samplingDefinition) {
        this.samplingDefinition = _.clone(samplingDefinition);
    }
    getSamplingDefinition() {
        return _.clone(this.samplingDefinition);
    }
    setTimeDeadBand(timeDeadBand) {
        this.timeDeadBand = timeDeadBand;
    }
    getTimeDeadband() {
        return this.timeDeadBand;
    }
    setValueDeadBand(valueDeadBand) {
        this.valueDeadBand = valueDeadBand;
    }
    getValueDeadBand() {
        return this.valueDeadBand;
    }
    setQualityFilter(qualityFilter) {
        this.qualityFilter = qualityFilter;
    }
    getQualityFilter() {
        return this.qualityFilter;
    }
}
function TimeseriesRequest_tsickle_Closure_declarations() {
    TimeseriesRequest.prototype.fqns;
    TimeseriesRequest.prototype.timePeriod;
    TimeseriesRequest.prototype.samplingDefinition;
    TimeseriesRequest.prototype.timeDeadBand;
    TimeseriesRequest.prototype.valueDeadBand;
    TimeseriesRequest.prototype.qualityFilter;
}
export class TimeseriesDataService extends BaseService {
    constructor(config, http, opcQualitySvc) {
        super(config.baseUrl + '/api/1/timeseries/', config, http);
        this.opcQualitySvc = opcQualitySvc;
    }
    getOnce(request, timezone) {
        let tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        return this._sendPostRequest(request).pipe(map((response) => this._transformTimeseriesInternalResponse(response, tz)));
    }
    _getErrorObservable(errorString) {
        return new Observable((observer) => {
            observer.error(errorString);
            return () => {
                observer.unsubscribe();
            };
        });
    }
    _applyTimezoneToVqtData(vqtData, timezone) {
        _.each(vqtData, (vqt) => {
            vqt.t = MomentHelperService.applyTimezone(vqt.t, timezone);
        });
        return vqtData;
    }
    _getRequestDataNextStartValues(response, nextStartMoment) {
        const beforeNextRequestValues = new Map();
        let last;
        _.each(response.fqnsResults, (el) => {
            if (!_.isNil(el) && el.values.length) {
                last = _.last(el.values);
                beforeNextRequestValues.set(el.fqn, last);
            }
        });
        return beforeNextRequestValues;
    }
    _getStartForNextRequest(response, originalDuration, repeatedInterval) {
        const opcQualitySvc = this.opcQualitySvc;
        function getLastTimeToUse(fqnResult) {
            const timeString = _.first(fqnResult.values).t;
            for (let i = fqnResult.values.length - 1; i >= 0; i--) {
                const val = fqnResult.values[i];
                if (!opcQualitySvc.isHdaInterpolated(val.q)) {
                    return val.t;
                }
            }
            return timeString;
        }
        let result;
        const currentTimeMinusDuration = moment.utc().subtract(Math.abs(originalDuration), 'seconds');
        _.each(response.fqnsResults, (fqnResult) => {
            if (_.isNil(fqnResult) || fqnResult.values.length === 0) {
                return;
            }
            const lastValue = moment.utc(getLastTimeToUse(fqnResult));
            if (_.isNil(result) || result.isAfter(lastValue)) {
                result = lastValue.clone();
            }
        });
        if (_.isNil(result)) {
            result = moment.utc(response.timePeriod.start).add(repeatedInterval, 'milliseconds');
        }
        if (currentTimeMinusDuration.isAfter(result)) {
            result = currentTimeMinusDuration.clone().add(repeatedInterval, 'milliseconds');
        }
        return result;
    }
    _filterStartResponseData(response, previousResponseLastData, requestTimePeriod) {
        let firstVqt;
        let firstVqtMoment;
        let secondVqt;
        const self = this;
        const opcQualitySvc = this.opcQualitySvc;
        const cutBeforeDate = moment.utc(response.timePeriod.end);
        cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
        _.each(response.fqnsResults, (el) => {
            if (!_.isNil(el) && previousResponseLastData.has(el.fqn) && el.values.length > 1) {
                const onePreviousResponseLastData = previousResponseLastData.get(el.fqn);
                const onePreviousResponseLastDataMoment = moment.utc(onePreviousResponseLastData.t);
                firstVqt = el.values.slice(0, 1)[0];
                firstVqtMoment = moment.utc(firstVqt.t);
                if (opcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                    secondVqt = el.values.slice(1, 2)[0];
                    if (firstVqtMoment > onePreviousResponseLastDataMoment &&
                        firstVqtMoment < moment.utc(secondVqt.t) &&
                        opcQualitySvc.isGood(onePreviousResponseLastData.q) &&
                        opcQualitySvc.isGood(secondVqt.q)) {
                        el.values.splice(0, 1);
                    }
                }
            }
        });
    }
    _transformTimeseriesInternalResponse(response, timezone) {
        let applyTimezone = false;
        if (!_.isNil(timezone)) {
            applyTimezone = true;
            response.timePeriod.start = MomentHelperService.applyTimezone(response.timePeriod.start, timezone);
            response.timePeriod.end = MomentHelperService.applyTimezone(response.timePeriod.end, timezone);
        }
        const ret = {
            timePeriod: response.timePeriod,
            results: []
        };
        _.each(response.fqnsResults, (oneResult) => {
            if (_.isNil(oneResult)) {
                return;
            }
            if (applyTimezone) {
                this._applyTimezoneToVqtData(oneResult.values, timezone);
            }
            ret.results.push({
                name: oneResult.name,
                fqn: oneResult.fqn,
                valueType: oneResult.valueType,
                engineeringUnit: oneResult.engineeringUnit,
                values: oneResult.values
            });
        });
        return ret;
    }
    _filterDuplicateDataAndCut(values, cutBeforeMoment, doNotShiftFirstValue, timezone) {
        const ids = [];
        let objectToAddToArray;
        let firstIsAfter = false;
        function arrayFilter(o) {
            const currentItemMoment = moment.utc(o.t);
            if (cutBeforeMoment.isAfter(currentItemMoment)) {
                if (!firstIsAfter) {
                    objectToAddToArray = _.clone(o);
                    const cutBeforeMomentUTCFormat = cutBeforeMoment.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                    if (!_.isNil(timezone)) {
                        objectToAddToArray.t = MomentHelperService.applyTimezone(cutBeforeMomentUTCFormat, timezone);
                    }
                    else {
                        objectToAddToArray.t = cutBeforeMomentUTCFormat;
                    }
                    firstIsAfter = true;
                }
                return false;
            }
            if (ids.indexOf(o.t) !== -1) {
                return false;
            }
            ids.push(o.t);
            return true;
        }
        const filteredArray = values.reverse().filter(arrayFilter);
        if (!doNotShiftFirstValue && firstIsAfter) {
            const lastValue = _.last(filteredArray);
            if (!lastValue || !moment.utc(lastValue.t).isSame(moment.utc(objectToAddToArray.t))) {
                filteredArray.push(objectToAddToArray);
            }
        }
        return filteredArray.reverse();
    }
    _getRepeatedlyWhole(request, customInterval, timezone) {
        let lastMergedResponse;
        const tz = timezone;
        const repeatedlyObs = this._getRepeatedlyIncrements(request, customInterval, timezone)
            .pipe(map((response) => {
            if (!_.isNil(lastMergedResponse)) {
                const requestTimePeriod = request.getTimePeriod();
                const cutBeforeDate = moment.utc(response.timePeriod.end);
                cutBeforeDate.subtract(Math.abs(requestTimePeriod.duration), 'seconds');
                const cutBeforeDateUTCFormat = cutBeforeDate.format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                if (!_.isNil(tz)) {
                    lastMergedResponse.timePeriod.start = MomentHelperService.applyTimezone(cutBeforeDateUTCFormat, tz);
                    lastMergedResponse.timePeriod.end = response.timePeriod.end;
                }
                else {
                    lastMergedResponse.timePeriod.start = cutBeforeDateUTCFormat;
                    lastMergedResponse.timePeriod.end =
                        moment.utc(response.timePeriod.end).format(MomentHelperService.MOMENT_DATETIME_FORMAT_UTC_FULL);
                }
                _.each(lastMergedResponse.results, (result) => {
                    const newResults = _.find(response.results, { fqn: result.fqn });
                    if (!_.isNil(newResults)) {
                        result.values = result.values.concat(newResults.values);
                        result.values = _.sortBy(result.values, [(o) => {
                                return moment.utc(o.t);
                            }]);
                        result.values = this._filterDuplicateDataAndCut(result.values, cutBeforeDate, false, tz);
                    }
                });
                _.each(response.results, (newResult) => {
                    if (!_.find(lastMergedResponse.results, { fqn: newResult.fqn })) {
                        lastMergedResponse.results.push(newResult);
                    }
                });
                return lastMergedResponse;
            }
            else {
                lastMergedResponse = response;
                return response;
            }
        }));
        return repeatedlyObs;
    }
    _getRepeatedlyIncrements(request, customInterval, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        let lastResponseData;
        let repeatedInterval = customInterval || this.config.defaultRepeatedDataInterval || DEFAULT_REPEATED_DATA_INTERVAL;
        repeatedInterval = repeatedInterval * 1000;
        const lastRepeatedRequest = _.clone(request);
        const originalDuration = requestTimePeriod.duration;
        let nextRequestStartMoment;
        const repeatedDataObservable = this._sendPostRequest(request).pipe(map((response) => {
            nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
            lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
            return this._transformTimeseriesInternalResponse(response, timezone);
        }));
        const expandedObservable = repeatedDataObservable.pipe(expand(() => timer(repeatedInterval).pipe(concatMap(() => {
            if (!_.isNil(nextRequestStartMoment)) {
                lastRepeatedRequest.setTimePeriod(_.extend(lastRepeatedRequest.getTimePeriod(), { duration: 0, start: nextRequestStartMoment.toDate() }));
            }
            return this._sendPostRequest(lastRepeatedRequest).pipe(map((response) => {
                if (lastResponseData.size > 0) {
                    this._filterStartResponseData(response, lastResponseData, requestTimePeriod);
                }
                nextRequestStartMoment = this._getStartForNextRequest(response, originalDuration, repeatedInterval);
                lastResponseData = this._getRequestDataNextStartValues(response, nextRequestStartMoment);
                return this._transformTimeseriesInternalResponse(response, timezone);
            }));
        }))));
        return expandedObservable;
    }
    getRepeatedly(request, customInterval, format, timezone) {
        const requestTimePeriod = request.getTimePeriod();
        if (!_.isNil(requestTimePeriod.start)) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request start time cannot be set for repeated data (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        else if (_.isNil(requestTimePeriod.duration) || requestTimePeriod.duration > 0) {
            return this._getErrorObservable('TimeseriesDataService getRepeatedly: Argument exception'
                + ' - Request duration have to be negative (request: '
                + JSON.stringify(request) + ' cannot be processed.');
        }
        let tz;
        if (MomentHelperService.isValidTimezone(timezone)) {
            tz = timezone;
        }
        if (_.isNil(format) || format === TimeseriesRepeatedDataFormat.wholeInterval) {
            return this._getRepeatedlyWhole(request, customInterval, tz);
        }
        else {
            return this._getRepeatedlyIncrements(request, customInterval, tz);
        }
    }
}
TimeseriesDataService.decorators = [
    { type: Injectable },
];
TimeseriesDataService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
    { type: OpcQualityService, },
];
function TimeseriesDataService_tsickle_Closure_declarations() {
    TimeseriesDataService.decorators;
    TimeseriesDataService.ctorParameters;
    TimeseriesDataService.prototype.opcQualitySvc;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXNlcmllcy1kYXRhLnNlcnZpY2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcmEtd2NmdGNsb3VkL3JhLWZ0Yy1jb21tdW5pY2F0aW9uLyIsInNvdXJjZXMiOlsidGltZXNlcmllcy1kYXRhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQ2xELE9BQU8sS0FBSyxDQUFDLE1BQU0sUUFBUSxDQUFDO0FBQzVCLE9BQU8sS0FBSyxNQUFNLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDMUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDekMsT0FBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDeEQsT0FBTyxFQUFFLG9CQUFvQixFQUF3Qiw4QkFBOEIsRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUV0RyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0seUJBQXlCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQkE0RDFDLGVBQWU7Z0JBQ2xCLFlBQVk7Ozs7bUJBSVQsZUFBZTttQkFDZixlQUFlO1lBQ3RCLFFBQVE7V0FDVCxPQUFPO1NBQ1QsS0FBSzthQUNELFNBQVM7aUJBQ0wsYUFBYTtXQUNuQixPQUFPO3VCQUNLLG1CQUFtQjt1QkFDbkIsbUJBQW1CO2FBQzdCLFNBQVM7V0FDWCxPQUFPO1NBQ1QsS0FBSztXQUNILE9BQU87Y0FDSixVQUFVO1dBQ2IsT0FBTztrQkFDQSxjQUFjO2lCQUNmLGFBQWE7aUJBQ2IsYUFBYTtnQkFDZCxZQUFZO2tCQUNWLGNBQWM7OEJBQ0YsMEJBQTBCO3dCQUNoQyxvQkFBb0I7c0JBQ3RCLGtCQUFrQjtzQkFDbEIsa0JBQWtCO3FCQUNuQixpQkFBaUI7Ozs7Ozs7OztBQWV2QyxNQUFNO0lBZUYsWUFDWSxNQUNBLFlBQ0Esb0JBQ0EsY0FDQSxlQUNBO1FBTEEsU0FBSSxHQUFKLElBQUk7UUFDSixlQUFVLEdBQVYsVUFBVTtRQUNWLHVCQUFrQixHQUFsQixrQkFBa0I7UUFDbEIsaUJBQVksR0FBWixZQUFZO1FBQ1osa0JBQWEsR0FBYixhQUFhO1FBQ2Isa0JBQWEsR0FBYixhQUFhO1FBRXJCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztLQUNsRDtJQU1ELE1BQU0sQ0FBQyxHQUFlO1FBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQ3ZCO0lBTUQsU0FBUyxDQUFDLEdBQWU7UUFDckIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3hDLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQzlCO0tBQ0o7SUFNRCxPQUFPLENBQUMsSUFBa0I7UUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzdCO0lBS0QsT0FBTztRQUNILE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUM3QjtJQU1ELGFBQWEsQ0FBQyxVQUF1QjtRQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7S0FDekM7SUFLRCxhQUFhO1FBQ1QsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQ25DO0lBTUQscUJBQXFCLENBQUMsa0JBQXdDO1FBQzFELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDekQ7SUFLRCxxQkFBcUI7UUFDakIsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7S0FDM0M7SUFNRCxlQUFlLENBQUMsWUFBcUI7UUFDakMsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7S0FDcEM7SUFLRCxlQUFlO1FBQ1gsTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7S0FDNUI7SUFNRCxnQkFBZ0IsQ0FBQyxhQUFzQjtRQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztLQUN0QztJQUtELGdCQUFnQjtRQUNaLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO0tBQzdCO0lBTUQsZ0JBQWdCLENBQUMsYUFBaUQ7UUFDOUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7S0FDdEM7SUFLRCxnQkFBZ0I7UUFDWixNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztLQUM3QjtDQUNKOzs7Ozs7Ozs7QUFNRCxNQUFNLDRCQUE2QixTQUFRLFdBQVc7SUFFbEQsWUFDa0MsUUFDOUIsSUFBZ0IsRUFBVSxhQUFnQztRQUMxRCxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFEakMsa0JBQWEsR0FBYixhQUFhLENBQW1CO0tBRTdEO0lBZUQsT0FBTyxDQUFDLE9BQTBCLEVBQUUsUUFBaUI7UUFDakQsSUFBSSxFQUFVLENBQUM7UUFDZixFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hELEVBQUUsR0FBRyxRQUFRLENBQUM7U0FDakI7UUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUEyQyxFQUFFLEVBQUUsQ0FDM0YsSUFBSSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDakU7SUFNTyxtQkFBbUIsQ0FBQyxXQUFtQjtRQUMzQyxNQUFNLENBQUMsSUFBSSxVQUFVLENBQXFCLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDbkQsUUFBUSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM1QixNQUFNLENBQUMsR0FBRyxFQUFFO2dCQUNSLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUMxQixDQUFDO1NBQ0wsQ0FBQyxDQUFDOztJQVFDLHVCQUF1QixDQUFDLE9BQXdDLEVBQUUsUUFBUTtRQUM5RSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEdBQWtDLEVBQUUsRUFBRTtZQUNuRCxHQUFHLENBQUMsQ0FBQyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQzlELENBQUMsQ0FBQztRQUNILE1BQU0sQ0FBQyxPQUFPLENBQUM7O0lBT1gsOEJBQThCLENBQUMsUUFBMkMsRUFBRSxlQUE4QjtRQUU5RyxNQUFNLHVCQUF1QixHQUFxQixJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzVELElBQUksSUFBbUMsQ0FBQztRQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRTtZQUNoQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3pCLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzdDO1NBQ0osQ0FBQyxDQUFDO1FBRUgsTUFBTSxDQUFDLHVCQUF1QixDQUFDOztJQU0zQix1QkFBdUIsQ0FDM0IsUUFBMkMsRUFBRSxnQkFBd0IsRUFBRSxnQkFBd0I7UUFDL0YsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN6QywwQkFBMEIsU0FBa0Q7WUFDeEUsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRS9DLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ3BELE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNoQjthQUNKO1lBRUQsTUFBTSxDQUFDLFVBQVUsQ0FBQztTQUNyQjtRQUVELElBQUksTUFBcUIsQ0FBQztRQUMxQixNQUFNLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRTlGLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsRUFBRSxFQUFFO1lBQ3ZDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFdEQsTUFBTSxDQUFDO2FBQ1Y7WUFDRCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDMUQsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsTUFBTSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUM5QjtTQUNKLENBQUMsQ0FBQztRQUVILEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWxCLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3hGO1FBRUQsRUFBRSxDQUFDLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxNQUFNLEdBQUcsd0JBQXdCLENBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ25GO1FBRUQsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7SUFPVix3QkFBd0IsQ0FDNUIsUUFBMkMsRUFDM0Msd0JBQW9FLEVBQUUsaUJBQThCO1FBQ3BHLElBQUksUUFBUSxDQUFDO1FBQ2IsSUFBSSxjQUFjLENBQUM7UUFDbkIsSUFBSSxTQUFTLENBQUM7UUFDZCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN6QyxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDMUQsYUFBYSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3hFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFO1lBQ2hDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9FLE1BQU0sMkJBQTJCLEdBQUcsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDekUsTUFBTSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRixRQUFRLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxjQUFjLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM5QyxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxFQUFFLENBQUMsQ0FBQyxjQUFjLEdBQUcsaUNBQWlDO3dCQUNsRCxjQUFjLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO3dCQUN4QyxhQUFhLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQzt3QkFDbkQsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQzFCO2lCQUNKO2FBQ0o7U0FDSixDQUFDLENBQUM7O0lBR0Msb0NBQW9DLENBQUMsUUFBMkMsRUFBRSxRQUFpQjtRQUN2RyxJQUFJLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFFMUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVyQixhQUFhLEdBQUcsSUFBSSxDQUFDO1lBRXJCLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxHQUFHLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNuRyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUM7U0FDbEc7UUFFRCxNQUFNLEdBQUcsR0FBdUI7WUFDNUIsVUFBVSxFQUFFLFFBQVEsQ0FBQyxVQUFVO1lBQy9CLE9BQU8sRUFBRSxFQUFFO1NBQ2QsQ0FBQztRQUVGLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsRUFBRSxFQUFFO1lBQ3ZDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVyQixNQUFNLENBQUM7YUFDVjtZQUVELEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQzVEO1lBRUQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO2dCQUNwQixHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUc7Z0JBQ2xCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUztnQkFDOUIsZUFBZSxFQUFFLFNBQVMsQ0FBQyxlQUFlO2dCQUMxQyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU07YUFDM0IsQ0FBQyxDQUFDO1NBQ04sQ0FBQyxDQUFDO1FBQ0gsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7SUFNUCwwQkFBMEIsQ0FDOUIsTUFBdUMsRUFBRSxlQUE4QixFQUN2RSxvQkFBOEIsRUFBRSxRQUFpQjtRQUNqRCxNQUFNLEdBQUcsR0FBa0IsRUFBRSxDQUFDO1FBQzlCLElBQUksa0JBQWlELENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBRXpCLHFCQUFxQixDQUFnQztZQUNqRCxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFDaEIsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDaEMsTUFBTSx3QkFBd0IsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7b0JBQzdHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JCLGtCQUFrQixDQUFDLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQ2hHO29CQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNKLGtCQUFrQixDQUFDLENBQUMsR0FBRyx3QkFBd0IsQ0FBQztxQkFDbkQ7b0JBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQztpQkFDdkI7Z0JBQ0QsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNoQjtZQUNELEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUIsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNoQjtZQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQztTQUNmO1FBQ0QsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzRCxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDeEMsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN4QyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVsRixhQUFhLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7YUFDMUM7U0FDSjtRQUNELE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7O0lBUTNCLG1CQUFtQixDQUFDLE9BQTBCLEVBQUUsY0FBdUIsRUFBRSxRQUFpQjtRQUM5RixJQUFJLGtCQUFzQyxDQUFDO1FBQzNDLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQztRQUVwQixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUM7YUFDakYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQTRCLEVBQUUsRUFBRTtZQUN2QyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNsRCxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzFELGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDeEUsTUFBTSxzQkFBc0IsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7Z0JBRXpHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2Ysa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3BHLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7aUJBQy9EO2dCQUFDLElBQUksQ0FBQyxDQUFDO29CQUNKLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsc0JBQXNCLENBQUM7b0JBQzdELGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxHQUFHO3dCQUM3QixNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLCtCQUErQixDQUFDLENBQUM7aUJBQ3ZHO2dCQUVELENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUU7b0JBQzFDLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDakUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBRXhELE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFnQyxFQUFFLEVBQUU7Z0NBQzFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs2QkFDMUIsQ0FBQyxDQUFDLENBQUM7d0JBRUosTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUM1RjtpQkFDSixDQUFDLENBQUM7Z0JBRUgsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsU0FBUyxFQUFFLEVBQUU7b0JBQ25DLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5RCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUM5QztpQkFDSixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxDQUFDLGtCQUFrQixDQUFDO2FBQzdCO1lBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ0osa0JBQWtCLEdBQUcsUUFBUSxDQUFDO2dCQUM5QixNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ25CO1NBQ0osQ0FBQyxDQUFDLENBQUM7UUFDUixNQUFNLENBQUMsYUFBYSxDQUFDOztJQVFqQix3QkFBd0IsQ0FDNUIsT0FBMEIsRUFBRSxjQUF1QixFQUFFLFFBQWlCO1FBRXRFLE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRWxELElBQUksZ0JBQWtDLENBQUM7UUFDdkMsSUFBSSxnQkFBZ0IsR0FBRyxjQUFjLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSw4QkFBOEIsQ0FBQztRQUNuSCxnQkFBZ0IsR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFFM0MsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdDLE1BQU0sZ0JBQWdCLEdBQUcsaUJBQWlCLENBQUMsUUFBUSxDQUFDO1FBQ3BELElBQUksc0JBQXFDLENBQUM7UUFFMUMsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQTJDLEVBQUUsRUFBRTtZQUNuSCxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFLcEcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3pGLE1BQU0sQ0FBQyxJQUFJLENBQUMsb0NBQW9DLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1NBQ3hFLENBQUMsQ0FBQyxDQUFDO1FBQ0osTUFBTSxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLENBQ2xELE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNyRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLG1CQUFtQixDQUFDLGFBQWEsQ0FDN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLHNCQUFzQixDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQy9HO1lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUEyQyxFQUFFLEVBQUU7Z0JBQ3ZHLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUk1QixJQUFJLENBQUMsd0JBQXdCLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixDQUFDLENBQUM7aUJBQ2hGO2dCQUNELHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFLcEcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFFBQVEsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO2dCQUN6RixNQUFNLENBQUMsSUFBSSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUN4RSxDQUFDLENBQUMsQ0FBQztTQUNQLENBQUMsQ0FBQyxDQUFDLENBQ1AsQ0FBQztRQUNGLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQzs7SUFxQjlCLGFBQWEsQ0FBQyxPQUEwQixFQUFFLGNBQXVCLEVBQUUsTUFBcUMsRUFBRSxRQUFpQjtRQUd2SCxNQUFNLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNsRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixrRUFBa0U7a0JBQ2xFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtRQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9FLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMseURBQXlEO2tCQUNuRixvREFBb0Q7a0JBQ3BELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztTQUM1RDtRQUVELElBQUksRUFBVSxDQUFDO1FBQ2YsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoRCxFQUFFLEdBQUcsUUFBUSxDQUFDO1NBQ2pCO1FBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLEtBQUssNEJBQTRCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztZQUMzRSxNQUFNLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDaEU7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNKLE1BQU0sQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNyRTtLQUNKOzs7WUExWEosVUFBVTs7OzRDQUlGLE1BQU0sU0FBQyxvQkFBb0I7WUFuUTNCLFVBQVU7WUFHVixpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0ICogYXMgXyBmcm9tICdsb2Rhc2gnO1xyXG5pbXBvcnQgKiBhcyBtb21lbnQgZnJvbSAnbW9tZW50LXRpbWV6b25lJztcclxuaW1wb3J0IHsgT3BjUXVhbGl0eVNlcnZpY2UgfSBmcm9tICcuL29wYy1xdWFsaXR5LnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAsIGNvbmNhdE1hcCwgZXhwYW5kIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDT01NVU5JQ0FUSU9OX0NPTkZJRywgSUNvbW11bmljYXRpb25Db25maWcsIERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTCB9IGZyb20gJy4vY29uZmlnJztcclxuaW1wb3J0IHsgaWRlbnRpZmllciwgSVJlc3BvbnNlIH0gZnJvbSAnLi9zaGFyZWQnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgTW9tZW50SGVscGVyU2VydmljZSB9IGZyb20gJy4vbW9tZW50LWhlbHBlci5zZXJ2aWNlJztcclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHZxdCBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMge1xyXG4gICAgdjogc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbjtcclxuICAgIHE6IG51bWJlcjtcclxuICAgIHQ6IHN0cmluZztcclxufVxyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgdnF0IGxpc3Qgc3RydWN0dXJlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2UgZXh0ZW5kcyBJUmVzcG9uc2Uge1xyXG4gICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXNwb25zZSBzdHJ1Y3R1cmUuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVzZXJpZXNSZXNwb25zZSB7XHJcbiAgICB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZFJlc3BvbnNlO1xyXG4gICAgcmVzdWx0czogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVtdO1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBUaW1lc2VyaWVzUmVzcG9uc2UgPSBJVGltZXNlcmllc1Jlc3BvbnNlO1xyXG5cclxuLyoqIFdyYXBzIGluZm9ybWF0aW9uIGFib3V0IHRpbWVzZXJpZXMgcmVzcG9uc2UgaW50ZXJuYWwgb2JqZWN0IHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdCB7XHJcbiAgICBmcW46IHN0cmluZztcclxuICAgIG5hbWU/OiBzdHJpbmc7XHJcbiAgICBlbmdpbmVlcmluZ1VuaXQ/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZVR5cGU/OiBzdHJpbmc7XHJcbiAgICB2YWx1ZXM6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW107XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIHRpbWUgcGVyaW9kIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZVBlcmlvZFJlc3BvbnNlIHtcclxuICAgIHN0YXJ0OiBzdHJpbmc7XHJcbiAgICBlbmQ6IHN0cmluZztcclxuICAgIGR1cmF0aW9uOiBudW1iZXI7XHJcbn1cclxuXHJcbi8qKiBXcmFwcyBpbmZvcm1hdGlvbiBhYm91dCB0aW1lc2VyaWVzIHJlc3BvbnNlIGludGVybmFsIChyYXcpIHN0cnVjdHVyZS4gKi9cclxuaW50ZXJmYWNlIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCB7XHJcbiAgICB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZFJlc3BvbnNlO1xyXG4gICAgZnFuc1Jlc3VsdHM/OiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWxPYmplY3RbXTtcclxuICAgIHF1ZXJ5UmVzdWx0cz86IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdFtdO1xyXG59XHJcblxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyByZXF1ZXN0IHRpbWUgcGVyaW9kIHN0cnVjdHVyZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJVGltZVBlcmlvZCB7XHJcbiAgICBzdGFydD86IERhdGUgfCBtb21lbnQuTW9tZW50O1xyXG4gICAgZW5kPzogRGF0ZSB8IG1vbWVudC5Nb21lbnQ7XHJcbiAgICBkdXJhdGlvbj86IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGVudW0gVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHtcclxuICAgIGluY2x1ZGVHb29kID0gMSxcclxuICAgIGluY2x1ZGVCYWQgPSAyLFxyXG4gICAgaW5jbHVkZVVuY2VydGFpbiA9IDQsXHJcbiAgICBpbmNsdWRlQWxsID0gN1xyXG59XHJcblxyXG5leHBvcnQgZW51bSBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0IHtcclxuICAgIHdob2xlSW50ZXJ2YWwgPSAnd2hvbGVJbnRlcnZhbCcsXHJcbiAgICBpbmNyZW1lbnRzID0gJ2luY3JlbWVudHMnXHJcbn1cclxuXHJcbmV4cG9ydCBlbnVtIFNhbXBsaW5nVHlwZXMge1xyXG4gICAgSW50ZXJwb2xhdGl2ZSA9ICdJbnRlcnBvbGF0aXZlJyxcclxuICAgIFNhbXBsZUFuZEhvbGQgPSAnU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBMaW5lYXIgPSAnTGluZWFyJyxcclxuICAgIFRvdGFsID0gJ1RvdGFsJyxcclxuICAgIFN1bSA9ICdTdW0nLFxyXG4gICAgQXZlcmFnZSA9ICdBdmVyYWdlJyxcclxuICAgIFRpbWVBdmVyYWdlID0gJ1RpbWVBdmVyYWdlJyxcclxuICAgIENvdW50ID0gJ0NvdW50JyxcclxuICAgIFN0YW5kYXJkRGV2aWF0aW9uID0gJ1N0YW5kYXJkRGV2aWF0aW9uJyxcclxuICAgIE1pbmltdW1BY3R1YWxUaW1lID0gJ01pbmltdW1BY3R1YWxUaW1lJyxcclxuICAgIE1heGltdW0gPSAnTWF4aW11bScsXHJcbiAgICBTdGFydCA9ICdTdGFydCcsXHJcbiAgICBFbmQgPSAnRW5kJyxcclxuICAgIERlbHRhID0gJ0RlbHRhJyxcclxuICAgIFZhcmlhbmNlID0gJ1ZhcmlhbmNlJyxcclxuICAgIFJhbmdlID0gJ1JhbmdlJyxcclxuICAgIER1cmF0aW9uR29vZCA9ICdEdXJhdGlvbkdvb2QnLFxyXG4gICAgRHVyYXRpb25CYWQgPSAnRHVyYXRpb25CYWQnLFxyXG4gICAgUGVyY2VudEdvb2QgPSAnUGVyY2VudEdvb2QnLFxyXG4gICAgUGVyY2VudEJhZCA9ICdQZXJjZW50QmFkJyxcclxuICAgIFdvcnN0UXVhbGl0eSA9ICdXb3JzdFF1YWxpdHknLFxyXG4gICAgVGltZUF2ZXJhZ2VTYW1wbGVBbmRIb2xkID0gJ1RpbWVBdmVyYWdlU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBUb3RhbFNhbXBsZUFuZEhvbGQgPSAnVG90YWxTYW1wbGVBbmRIb2xkJyxcclxuICAgIE1pblNhbXBsZUFuZEhvbGQgPSAnTWluU2FtcGxlQW5kSG9sZCcsXHJcbiAgICBNYXhTYW1wbGVBbmRIb2xkID0gJ01heFNhbXBsZUFuZEhvbGQnLFxyXG4gICAgQ3VtdWxhdGl2ZVRvdGFsID0gJ0N1bXVsYXRpdmVUb3RhbCdcclxufVxyXG4vKiogV3JhcHMgaW5mb3JtYXRpb24gYWJvdXQgdGltZXNlcmllcyBzYW1wbGluZyBkZWZpbml0aW9uLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIElTYW1wbGluZ0RlZmluaXRpb24ge1xyXG4gICAgLyoqIFRoZSBudW1iZXIgb2YgdGhlIHNsaWNlcyB0aGF0IHRoZSBwcm92aWRlZCB0aW1lIHBlcmlvZCBzaG91bGQgYmUgY3V0IGludG8uXHJcbiAgICAgKiBJZiB6ZXJvIHRoZW4gYSBub24temVybyBEZWx0YVQgdmFsdWUgbmVlZHMgdG8gYmUgcHJvdmlkZWQuICovXHJcbiAgICBzbGljZUNvdW50PzogbnVtYmVyO1xyXG4gICAgLyoqIElmIHRoZSBzbGljZSBjb3VudCBpcyB6ZXJvLCB0aGVuIGEgbm9uLXplcm8gdmFsdWUgcmVwcmVzZW50aW5nIHRoZSB3aWR0aCBvZiBhIHRpbWUgc2xpY2UgaW4gc2Vjb25kc1xyXG4gICAgICogbXVzdCBiZSBwcm92aWRlZC4gQSBwb3NpdGl2ZSB2YWx1ZSBtZWFucyB0aGUgc2xpY2VzIGFyZSBhbmNob3JlZCBhdCB0aGUgc3RhcnQgdGltZSBvZiB0aGUgcmVxdWVzdGVkIHRpbWUgcGVyaW9kLlxyXG4gICAgICogQSBuZWdhdGl2ZSB2YWx1ZSBpbmRpY2F0ZXMgYW5jaG9yaW5nIGF0IHRoZSBlbmQgb2YgdGhlIHRpbWUgcGVyaW9kLiAqL1xyXG4gICAgZGVsdGFUPzogbnVtYmVyO1xyXG4gICAgLyoqIE9uZSBvZiB0aGUgc2FtcGxpbmcgdHlwZXMgc3VwcG9ydGVkIGJ5IHRoZSB0aW1lc2VyaWVzLiBTZWUgU2FtcGxpbmdUeXBlcyBlbnVtLiAqL1xyXG4gICAgc2FtcGxpbmdUeXBlOiBTYW1wbGluZ1R5cGVzO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgVGltZXNlcmllc1JlcXVlc3Qge1xyXG4gICAgLyoqXHJcbiAgICAgKiBUaW1lc2VyaWVzIHJlcXVlc3QgY29uc3RydWN0b3JcclxuICAgICAqIEBwYXJhbSBmcW5zIExpc3Qgb2YgZnFucyAoaWRlbnRpZmljYXRvcnMpIHRvIGJlIHVzZWQgZm9yIHJlcXVlc3RcclxuICAgICAqIEBwYXJhbSB0aW1lUGVyaW9kIFNldHRpbmdzIGZvciB0aW1lIHBlcmlvZCBvZiB0aW1lc2VyaWVzIHJlcXVlc3QsIGUuZy4gc3RhcnQgdGltZSwgZW5kIHRpbWUgYW5kIGR1cmF0aW9uXHJcbiAgICAgKiBAcGFyYW0gc2FtcGxpbmdEZWZpbml0aW9uIChPcHRpb25hbCkgZGVmaW5pdGlvbiBmb3IgdGltZXNlcmllcyB0byBzZXQgaG93IHRvIHByb2Nlc3MgZGF0YSwgd2hpY2ggU2FtcGxpbmcgdHlwZSB0byB1c2VcclxuICAgICAqIEBwYXJhbSB0aW1lRGVhZEJhbmQgKE9wdGlvbmFsKSBTZXR0aW5ncyBmb3IgdGltZSBkZWFkYmFuZCAtIHBvc3NpYmxlIHN0cnVjdHVyZSBbd3NdWy1dIGQgfCBkLmhoOm1tWzpzc1suZmZdXSB8IGhoOm1tWzpzc1suZmZdXSBbd3NdXHJcbiAgICAgKiBAcGFyYW0gdmFsdWVEZWFkQmFuZCAoT3B0aW9uYWwpIFNwZWNpZmllcyB0aGUgdmFsdWUgZGVhZCBiYW5kLCBjYW4gYmUgYW55IGZsb2F0IG51bWJlci5cclxuICAgICAqIEBwYXJhbSBxdWFsaXR5RmlsdGVyIChPcHRpb25hbCkgVGhpcyBpcyBhIGJpdCBmbGFnIHZhbHVlIHdpdGggdGhlIGZvbGxvd2luZyBvcHRpb25zOlxyXG4gICAgICogSW5jbHVkZUdvb2QgOiAxXHJcbiAgICAgKiBJbmNsdWRlQmFkIDogMlxyXG4gICAgICogSW5jbHVkZVVuY2VydGFpbiA6IDRcclxuICAgICAqIEluY2x1ZGVBbGwgOiA3XHJcbiAgICAgKiBVc2UgYSB2YWx1ZSBmcm9tIHByZWRlZmluZWQgZW51bSBUaW1lc2VyaWVzUmVxdWVzdFF1YWxpdHkgb3Igc3BlY2lmeSBhIHZhbGx1ZS5cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBmcW5zOiBpZGVudGlmaWVyW10sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lUGVyaW9kOiBJVGltZVBlcmlvZCxcclxuICAgICAgICBwcml2YXRlIHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24sXHJcbiAgICAgICAgcHJpdmF0ZSB0aW1lRGVhZEJhbmQ/OiBzdHJpbmcsXHJcbiAgICAgICAgcHJpdmF0ZSB2YWx1ZURlYWRCYW5kPzogbnVtYmVyLFxyXG4gICAgICAgIHByaXZhdGUgcXVhbGl0eUZpbHRlcj86IFRpbWVzZXJpZXNSZXF1ZXN0UXVhbGl0eSB8IG51bWJlclxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5zZXRGcW5zKGZxbnMpO1xyXG4gICAgICAgIHRoaXMuc2V0VGltZVBlcmlvZCh0aW1lUGVyaW9kKTtcclxuICAgICAgICB0aGlzLnNldFNhbXBsaW5nRGVmaW5pdGlvbihzYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWRkIG9uZSBmcW4gdG8gcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBmcW4gZnFuIGlkZW50aWZpY2F0b3IgdG8gYWRkXHJcbiAgICAgKi9cclxuICAgIGFkZEZxbihmcW46IGlkZW50aWZpZXIpIHtcclxuICAgICAgICB0aGlzLmZxbnMucHVzaChmcW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUmVtb3ZlIG9uZSBmcW4gZnJvbSByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIGZxbiBmcW4gaWRlbnRpZmljYXRvciB0byByZW1vdmVcclxuICAgICAqL1xyXG4gICAgcmVtb3ZlRnFuKGZxbjogaWRlbnRpZmllcikge1xyXG4gICAgICAgIGNvbnN0IGluZGV4ID0gXy5pbmRleE9mKHRoaXMuZnFucywgZnFuKTtcclxuICAgICAgICBpZiAoaW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZnFucy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJlcGxhY2UgY3VycmVudCBmcW5zIGluIHJlcXVlc3QgdG8gbmV3IG9uZXMuXHJcbiAgICAgKiBAcGFyYW0gZnFucyBsaXN0IG9mIGZxbiBpZGVudGlmaWNhdG9ycyB0byBzZXRcclxuICAgICAqL1xyXG4gICAgc2V0RnFucyhmcW5zOiBpZGVudGlmaWVyW10pIHtcclxuICAgICAgICB0aGlzLmZxbnMgPSBfLmNsb25lKGZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IGFjdHVhbCByZXF1ZXN0IGZxbiBpZGVudGlmaWNhdG9ycy5cclxuICAgICAqL1xyXG4gICAgZ2V0RnFucygpIHtcclxuICAgICAgICByZXR1cm4gXy5jbG9uZSh0aGlzLmZxbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHJlcXVlc3QgdGltZSBwZXJpb2QuXHJcbiAgICAgKiBAcGFyYW0gdGltZVBlcmlvZFxyXG4gICAgICovXHJcbiAgICBzZXRUaW1lUGVyaW9kKHRpbWVQZXJpb2Q6IElUaW1lUGVyaW9kKSB7XHJcbiAgICAgICAgdGhpcy50aW1lUGVyaW9kID0gXy5jbG9uZSh0aW1lUGVyaW9kKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCByZXF1ZXN0IHRpbWUgcGVyaW9kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lUGVyaW9kKCkge1xyXG4gICAgICAgIHJldHVybiBfLmNsb25lKHRoaXMudGltZVBlcmlvZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBTZXQgc2FtcGxpbmcgZGVmaW5pdGlvbi5cclxuICAgICAqIEBwYXJhbSBzYW1wbGluZ0RlZmluaXRpb25cclxuICAgICAqL1xyXG4gICAgc2V0U2FtcGxpbmdEZWZpbml0aW9uKHNhbXBsaW5nRGVmaW5pdGlvbj86IElTYW1wbGluZ0RlZmluaXRpb24pIHtcclxuICAgICAgICB0aGlzLnNhbXBsaW5nRGVmaW5pdGlvbiA9IF8uY2xvbmUoc2FtcGxpbmdEZWZpbml0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBzYW1wbGluZyBkZWZpbml0aW9uLlxyXG4gICAgICovXHJcbiAgICBnZXRTYW1wbGluZ0RlZmluaXRpb24oKSB7XHJcbiAgICAgICAgcmV0dXJuIF8uY2xvbmUodGhpcy5zYW1wbGluZ0RlZmluaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHRpbWUgZGVhZGJhbmQuXHJcbiAgICAgKiBAcGFyYW0gdGltZURlYWRCYW5kXHJcbiAgICAgKi9cclxuICAgIHNldFRpbWVEZWFkQmFuZCh0aW1lRGVhZEJhbmQ/OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLnRpbWVEZWFkQmFuZCA9IHRpbWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB0aW1lIGRlYWRiYW5kLlxyXG4gICAgICovXHJcbiAgICBnZXRUaW1lRGVhZGJhbmQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMudGltZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHZhbHVlIGRlYWRiYW5kLlxyXG4gICAgICogQHBhcmFtIHZhbHVlRGVhZEJhbmRcclxuICAgICAqL1xyXG4gICAgc2V0VmFsdWVEZWFkQmFuZCh2YWx1ZURlYWRCYW5kPzogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy52YWx1ZURlYWRCYW5kID0gdmFsdWVEZWFkQmFuZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCB2YWx1ZSBkZWFkYmFuZC5cclxuICAgICAqL1xyXG4gICAgZ2V0VmFsdWVEZWFkQmFuZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy52YWx1ZURlYWRCYW5kO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0IHF1YWxpdHkgZmlsdGVyLlxyXG4gICAgICogQHBhcmFtIHF1YWxpdHlGaWx0ZXJcclxuICAgICAqL1xyXG4gICAgc2V0UXVhbGl0eUZpbHRlcihxdWFsaXR5RmlsdGVyPzogVGltZXNlcmllc1JlcXVlc3RRdWFsaXR5IHwgbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5xdWFsaXR5RmlsdGVyID0gcXVhbGl0eUZpbHRlcjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCBhY3R1YWwgcmVxdWVzdCBxdWFsaXR5IGZpbHRlci5cclxuICAgICAqL1xyXG4gICAgZ2V0UXVhbGl0eUZpbHRlcigpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5xdWFsaXR5RmlsdGVyO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogVGhpcyBzZXJ2aWNlIHByb3ZpZGVzIGEgc2V0IG9mIG1ldGhvZHMgZm9yIHNlbmRpbmcgcmVxdWVzdHMgdG8gb2J0YWluIHRpbWVzZXJpZXMgZGF0YS5cclxuICovXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIFRpbWVzZXJpZXNEYXRhU2VydmljZSBleHRlbmRzIEJhc2VTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBASW5qZWN0KENPTU1VTklDQVRJT05fQ09ORklHKSBjb25maWc6IElDb21tdW5pY2F0aW9uQ29uZmlnLFxyXG4gICAgICAgIGh0dHA6IEh0dHBDbGllbnQsIHByaXZhdGUgb3BjUXVhbGl0eVN2YzogT3BjUXVhbGl0eVNlcnZpY2UpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvdGltZXNlcmllcy8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgdGltZXNlcmllcyByZXF1ZXN0IHRvIHNlcnZlciwgYnV0IG9ubHkgb25jZS5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gdGltZXpvbmUgdGltZXpvbmUgdG8gYXBwbHkgdG8gdGltZXNlcmllcyByZXNwb25zZSBkYXRhLCBvbmx5IG1vbWVudCB0aW1lem9uZXMgYXJlIHN1cHBvcnRlZFxyXG4gICAgICogSWYgd29ya2luZyB3aXRoIHRpbWV6b25lIGluIGRhdGV0aW1lIHN0cmluZyBpdCBpcyByZWNvbW1lbmRlZCB0byB1c2UgbW9tZW50LnBhcnNlWm9uZSB0byBwcmVzZXJ2ZSB0aW1lem9uZSBpbmZvcm1hdGlvbi5cclxuICAgICAqIE1vbWVudCB0aW1lem9uZXMgdGhhdCBzdGFydCB3aXRoIFwiRXRjL0dNVFwiIHVzZSBQT1NJWC1zdHlsZSBzaWducyBpbiB0aGUgWm9uZSBuYW1lcyBhbmQgdGhlIG91dHB1dCBhYmJyZXZpYXRpb25zLFxyXG4gICAgICogZXZlbiB0aG91Z2ggdGhpcyBpcyB0aGUgb3Bwb3NpdGUgb2Ygd2hhdCBtYW55IHBlb3BsZSBleHBlY3QuXHJcbiAgICAgKiBQT1NJWCBoYXMgcG9zaXRpdmUgc2lnbnMgd2VzdCBvZiBHcmVlbndpY2gsIGJ1dCBtYW55IHBlb3BsZSBleHBlY3RcclxuICAgICAqIHBvc2l0aXZlIHNpZ25zIGVhc3Qgb2YgR3JlZW53aWNoLiAgRm9yIGV4YW1wbGUsIFRaPSdFdGMvR01UKzQnIHVzZXNcclxuICAgICAqIHRoZSBhYmJyZXZpYXRpb24gXCJHTVQrNFwiIGFuZCBjb3JyZXNwb25kcyB0byA0IGhvdXJzIGJlaGluZCBVVFxyXG4gICAgICogKGkuZS4gd2VzdCBvZiBHcmVlbndpY2gpIGV2ZW4gdGhvdWdoIG1hbnkgcGVvcGxlIHdvdWxkIGV4cGVjdCBpdCB0b1xyXG4gICAgICogbWVhbiA0IGhvdXJzIGFoZWFkIG9mIFVUIChpLmUuIGVhc3Qgb2YgR3JlZW53aWNoKS5cclxuICAgICAqL1xyXG4gICAgZ2V0T25jZShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgdGltZXpvbmU/OiBzdHJpbmcpOiBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG4gICAgICAgIGxldCB0ejogc3RyaW5nO1xyXG4gICAgICAgIGlmIChNb21lbnRIZWxwZXJTZXJ2aWNlLmlzVmFsaWRUaW1lem9uZSh0aW1lem9uZSkpIHtcclxuICAgICAgICAgICAgdHogPSB0aW1lem9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT5cclxuICAgICAgICAgICAgdGhpcy5fdHJhbnNmb3JtVGltZXNlcmllc0ludGVybmFsUmVzcG9uc2UocmVzcG9uc2UsIHR6KSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHJldHVybiBhbiBvYnNlcnZhYmxlIHdoaWNoIGltbWVkaWF0ZWxseSBlcnJvcnMgb3V0IHdpdGggZ2l2ZW4gZXJyb3Igc3RyaW5nLlxyXG4gICAgICogQHBhcmFtIGVycm9yU3RyaW5nXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldEVycm9yT2JzZXJ2YWJsZShlcnJvclN0cmluZzogc3RyaW5nKTogT2JzZXJ2YWJsZTxUaW1lc2VyaWVzUmVzcG9uc2U+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPigob2JzZXJ2ZXIpID0+IHtcclxuICAgICAgICAgICAgb2JzZXJ2ZXIuZXJyb3IoZXJyb3JTdHJpbmcpO1xyXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIE1ldGhvZCB0byBhcHBseSB0aW1lem9uZSB0byB3aG9sZVxyXG4gICAgICogQHBhcmFtIHZxdERhdGEgbGlzdCBvZiBWUVQgZGF0YVxyXG4gICAgICogQHBhcmFtIHRpbWV6b25lIHRpbWV6b25lIHN0cmluZ1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9hcHBseVRpbWV6b25lVG9WcXREYXRhKHZxdERhdGE6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzW10sIHRpbWV6b25lKSB7XHJcbiAgICAgICAgXy5lYWNoKHZxdERhdGEsICh2cXQ6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzKSA9PiB7XHJcbiAgICAgICAgICAgIHZxdC50ID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHZxdC50LCB0aW1lem9uZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHZxdERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gZ2V0IGZpcnN0IHZhbHVlIGJlZm9yZSBuZXh0IHJlcXVlc3Qgc3RhcnQgdGltZSBpbiBjdXJyZW50IGRhdGEuXHJcbiAgICAgKlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXF1ZXN0RGF0YU5leHRTdGFydFZhbHVlcyhyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCBuZXh0U3RhcnRNb21lbnQ6IG1vbWVudC5Nb21lbnQpOlxyXG4gICAgICAgIE1hcDxzdHJpbmcsIElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzPiB7XHJcbiAgICAgICAgY29uc3QgYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXM6IE1hcDxzdHJpbmcsIGFueT4gPSBuZXcgTWFwKCk7XHJcbiAgICAgICAgbGV0IGxhc3Q6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzO1xyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGVsKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghXy5pc05pbChlbCkgJiYgZWwudmFsdWVzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgbGFzdCA9IF8ubGFzdChlbC52YWx1ZXMpO1xyXG4gICAgICAgICAgICAgICAgYmVmb3JlTmV4dFJlcXVlc3RWYWx1ZXMuc2V0KGVsLmZxbiwgbGFzdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGJlZm9yZU5leHRSZXF1ZXN0VmFsdWVzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0cyBzdGFydCB0aW1lIGZvciBuZXh0IHJlcXVlc3Qgd2hlbiBnZXR0aW5nIGRhdGEgcmVwZWF0ZWRseS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChcclxuICAgICAgICByZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCBvcmlnaW5hbER1cmF0aW9uOiBudW1iZXIsIHJlcGVhdGVkSW50ZXJ2YWw6IG51bWJlcik6IG1vbWVudC5Nb21lbnQge1xyXG4gICAgICAgIGNvbnN0IG9wY1F1YWxpdHlTdmMgPSB0aGlzLm9wY1F1YWxpdHlTdmM7XHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0TGFzdFRpbWVUb1VzZShmcW5SZXN1bHQ6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbE9iamVjdCk6IHN0cmluZyB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRpbWVTdHJpbmcgPSBfLmZpcnN0KGZxblJlc3VsdC52YWx1ZXMpLnQ7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gZnFuUmVzdWx0LnZhbHVlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdmFsID0gZnFuUmVzdWx0LnZhbHVlc1tpXTtcclxuICAgICAgICAgICAgICAgIGlmICghb3BjUXVhbGl0eVN2Yy5pc0hkYUludGVycG9sYXRlZCh2YWwucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsLnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB0aW1lU3RyaW5nO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHJlc3VsdDogbW9tZW50Lk1vbWVudDtcclxuICAgICAgICBjb25zdCBjdXJyZW50VGltZU1pbnVzRHVyYXRpb24gPSBtb21lbnQudXRjKCkuc3VidHJhY3QoTWF0aC5hYnMob3JpZ2luYWxEdXJhdGlvbiksICdzZWNvbmRzJyk7XHJcblxyXG4gICAgICAgIF8uZWFjaChyZXNwb25zZS5mcW5zUmVzdWx0cywgKGZxblJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoXy5pc05pbChmcW5SZXN1bHQpIHx8IGZxblJlc3VsdC52YWx1ZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBubyB0aW1lc2VyaWVzIGRhdGFcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBsYXN0VmFsdWUgPSBtb21lbnQudXRjKGdldExhc3RUaW1lVG9Vc2UoZnFuUmVzdWx0KSk7XHJcbiAgICAgICAgICAgIGlmIChfLmlzTmlsKHJlc3VsdCkgfHwgcmVzdWx0LmlzQWZ0ZXIobGFzdFZhbHVlKSkge1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gbGFzdFZhbHVlLmNsb25lKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKF8uaXNOaWwocmVzdWx0KSkge1xyXG4gICAgICAgICAgICAvLyBubyBnb29kIHF1YWxpdHkgLSBhZGQgcGVyaW9kIHRvIHJlc3BvbnNlIHN0YXJ0IHRpbWUgLSBhcyBkZWZhdWx0IGZvciBuZXh0IHJlcXVlc3RcclxuICAgICAgICAgICAgcmVzdWx0ID0gbW9tZW50LnV0YyhyZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0KS5hZGQocmVwZWF0ZWRJbnRlcnZhbCwgJ21pbGxpc2Vjb25kcycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGN1cnJlbnRUaW1lTWludXNEdXJhdGlvbi5pc0FmdGVyKHJlc3VsdCkpIHtcclxuICAgICAgICAgICAgcmVzdWx0ID0gY3VycmVudFRpbWVNaW51c0R1cmF0aW9uLmNsb25lKCkuYWRkKHJlcGVhdGVkSW50ZXJ2YWwsICdtaWxsaXNlY29uZHMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAqIEZ1bmN0aW9uIHRvIG9wdGlvbmFsbHkgZmlsdGVyIGZpcnN0IHZhbHVlIGluIHJlcGVhdGVkIHJlcXVlc3Qgd2hlbiBpdCBpcyBpbnRlcnBvbGF0ZWQgYmV0d2VlblxyXG4gICAgKiB0d28gZ29vZC9iYWQgb25lcy4gRGlyZWN0bHkgbW9kaWZpZXMgcmVzcG9uc2UgaW5wdXQgcGFyYW1ldGVyLlxyXG4gICAgKi9cclxuICAgIHByaXZhdGUgX2ZpbHRlclN0YXJ0UmVzcG9uc2VEYXRhKFxyXG4gICAgICAgIHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwsXHJcbiAgICAgICAgcHJldmlvdXNSZXNwb25zZUxhc3REYXRhOiBNYXA8c3RyaW5nLCBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cz4sIHJlcXVlc3RUaW1lUGVyaW9kOiBJVGltZVBlcmlvZCkge1xyXG4gICAgICAgIGxldCBmaXJzdFZxdDtcclxuICAgICAgICBsZXQgZmlyc3RWcXRNb21lbnQ7XHJcbiAgICAgICAgbGV0IHNlY29uZFZxdDtcclxuICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcclxuICAgICAgICBjb25zdCBvcGNRdWFsaXR5U3ZjID0gdGhpcy5vcGNRdWFsaXR5U3ZjO1xyXG4gICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGUgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKTtcclxuICAgICAgICBjdXRCZWZvcmVEYXRlLnN1YnRyYWN0KE1hdGguYWJzKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChlbCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIV8uaXNOaWwoZWwpICYmIHByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5oYXMoZWwuZnFuKSAmJiBlbC52YWx1ZXMubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhID0gcHJldmlvdXNSZXNwb25zZUxhc3REYXRhLmdldChlbC5mcW4pO1xyXG4gICAgICAgICAgICAgICAgY29uc3Qgb25lUHJldmlvdXNSZXNwb25zZUxhc3REYXRhTW9tZW50ID0gbW9tZW50LnV0YyhvbmVQcmV2aW91c1Jlc3BvbnNlTGFzdERhdGEudCk7XHJcbiAgICAgICAgICAgICAgICBmaXJzdFZxdCA9IGVsLnZhbHVlcy5zbGljZSgwLCAxKVswXTtcclxuICAgICAgICAgICAgICAgIGZpcnN0VnF0TW9tZW50ID0gbW9tZW50LnV0YyhmaXJzdFZxdC50KTtcclxuICAgICAgICAgICAgICAgIGlmIChvcGNRdWFsaXR5U3ZjLmlzSGRhSW50ZXJwb2xhdGVkKGZpcnN0VnF0LnEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2Vjb25kVnF0ID0gZWwudmFsdWVzLnNsaWNlKDEsIDIpWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChmaXJzdFZxdE1vbWVudCA+IG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YU1vbWVudCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaXJzdFZxdE1vbWVudCA8IG1vbWVudC51dGMoc2Vjb25kVnF0LnQpICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wY1F1YWxpdHlTdmMuaXNHb29kKG9uZVByZXZpb3VzUmVzcG9uc2VMYXN0RGF0YS5xKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcGNRdWFsaXR5U3ZjLmlzR29vZChzZWNvbmRWcXQucSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWwudmFsdWVzLnNwbGljZSgwLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZTogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZUludGVybmFsLCB0aW1lem9uZT86IHN0cmluZyk6IFRpbWVzZXJpZXNSZXNwb25zZSB7XHJcbiAgICAgICAgbGV0IGFwcGx5VGltZXpvbmUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKCFfLmlzTmlsKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICAvLyB3ZSBkbyBoYXZlIHRpbWV6b25lXHJcbiAgICAgICAgICAgIGFwcGx5VGltZXpvbmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAvLyBhcHBseSB0aW1lem9uZSBhbHNvIHRvIHJlc3BvbnNlIHRpbWUgcGVyaW9kIHRvIG1hdGNoIGRhdGFcclxuICAgICAgICAgICAgcmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShyZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0LCB0aW1lem9uZSk7XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID0gTW9tZW50SGVscGVyU2VydmljZS5hcHBseVRpbWV6b25lKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kLCB0aW1lem9uZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZXQ6IFRpbWVzZXJpZXNSZXNwb25zZSA9IHtcclxuICAgICAgICAgICAgdGltZVBlcmlvZDogcmVzcG9uc2UudGltZVBlcmlvZCxcclxuICAgICAgICAgICAgcmVzdWx0czogW11cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBfLmVhY2gocmVzcG9uc2UuZnFuc1Jlc3VsdHMsIChvbmVSZXN1bHQpID0+IHtcclxuICAgICAgICAgICAgaWYgKF8uaXNOaWwob25lUmVzdWx0KSkge1xyXG4gICAgICAgICAgICAgICAgLy8gbm8gdGltZXNlcmllcyBkYXRhXHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhcHBseVRpbWV6b25lKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hcHBseVRpbWV6b25lVG9WcXREYXRhKG9uZVJlc3VsdC52YWx1ZXMsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0LnJlc3VsdHMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICBuYW1lOiBvbmVSZXN1bHQubmFtZSxcclxuICAgICAgICAgICAgICAgIGZxbjogb25lUmVzdWx0LmZxbixcclxuICAgICAgICAgICAgICAgIHZhbHVlVHlwZTogb25lUmVzdWx0LnZhbHVlVHlwZSxcclxuICAgICAgICAgICAgICAgIGVuZ2luZWVyaW5nVW5pdDogb25lUmVzdWx0LmVuZ2luZWVyaW5nVW5pdCxcclxuICAgICAgICAgICAgICAgIHZhbHVlczogb25lUmVzdWx0LnZhbHVlc1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gcmV0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogRnVuY3Rpb24gdG8gZmlsdGVyIG5vdCBuZWVkZWQgZGF0YSBhbmQgZHVwbGljYXRlIGRhdGEuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2ZpbHRlckR1cGxpY2F0ZURhdGFBbmRDdXQoXHJcbiAgICAgICAgdmFsdWVzOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0c1tdLCBjdXRCZWZvcmVNb21lbnQ6IG1vbWVudC5Nb21lbnQsXHJcbiAgICAgICAgZG9Ob3RTaGlmdEZpcnN0VmFsdWU/OiBib29sZWFuLCB0aW1lem9uZT86IHN0cmluZykge1xyXG4gICAgICAgIGNvbnN0IGlkczogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIGxldCBvYmplY3RUb0FkZFRvQXJyYXk6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VWcXRzO1xyXG4gICAgICAgIGxldCBmaXJzdElzQWZ0ZXIgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gYXJyYXlGaWx0ZXIobzogSVRpbWVzZXJpZXNWYWx1ZXNSZXNwb25zZVZxdHMpIHtcclxuICAgICAgICAgICAgY29uc3QgY3VycmVudEl0ZW1Nb21lbnQgPSBtb21lbnQudXRjKG8udCk7XHJcbiAgICAgICAgICAgIGlmIChjdXRCZWZvcmVNb21lbnQuaXNBZnRlcihjdXJyZW50SXRlbU1vbWVudCkpIHtcclxuICAgICAgICAgICAgICAgIGlmICghZmlyc3RJc0FmdGVyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0VG9BZGRUb0FycmF5ID0gXy5jbG9uZShvKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQgPSBjdXRCZWZvcmVNb21lbnQuZm9ybWF0KE1vbWVudEhlbHBlclNlcnZpY2UuTU9NRU5UX0RBVEVUSU1FX0ZPUk1BVF9VVENfRlVMTCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKHRpbWV6b25lKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkudCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShjdXRCZWZvcmVNb21lbnRVVENGb3JtYXQsIHRpbWV6b25lKTtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3RUb0FkZFRvQXJyYXkudCA9IGN1dEJlZm9yZU1vbWVudFVUQ0Zvcm1hdDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3RJc0FmdGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaWRzLmluZGV4T2Yoby50KSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZHMucHVzaChvLnQpO1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZmlsdGVyZWRBcnJheSA9IHZhbHVlcy5yZXZlcnNlKCkuZmlsdGVyKGFycmF5RmlsdGVyKTtcclxuICAgICAgICBpZiAoIWRvTm90U2hpZnRGaXJzdFZhbHVlICYmIGZpcnN0SXNBZnRlcikge1xyXG4gICAgICAgICAgICBjb25zdCBsYXN0VmFsdWUgPSBfLmxhc3QoZmlsdGVyZWRBcnJheSk7XHJcbiAgICAgICAgICAgIGlmICghbGFzdFZhbHVlIHx8ICFtb21lbnQudXRjKGxhc3RWYWx1ZS50KS5pc1NhbWUobW9tZW50LnV0YyhvYmplY3RUb0FkZFRvQXJyYXkudCkpKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBpdCBpcyByZXZlcnNlZCBhcnJheSBzbyBwdXNoIHRvIGl0XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZEFycmF5LnB1c2gob2JqZWN0VG9BZGRUb0FycmF5KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRBcnJheS5yZXZlcnNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3RzIHJlcGVhdGVkbHkgYW5kIHJldHVybiBhbGwgZGF0YSBpbiBnaXZlbiByZXF1ZXN0IGludGVydmFsIChieSBkdXJhdGlvbiwgc3RhcnQgYW5kL29yIGVuZCB0aW1lKS5cclxuICAgICAqIEBwYXJhbSByZXF1ZXN0IHRpbWVzZXJpZXMgcmVxdWVzdCB0byBiZSBzZW50XHJcbiAgICAgKiBAcGFyYW0gY3VzdG9tSW50ZXJ2YWwgaW50ZXJ2YWwgaW4gc2Vjb25kc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRSZXBlYXRlZGx5V2hvbGUocmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcbiAgICAgICAgbGV0IGxhc3RNZXJnZWRSZXNwb25zZTogVGltZXNlcmllc1Jlc3BvbnNlO1xyXG4gICAgICAgIGNvbnN0IHR6ID0gdGltZXpvbmU7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcGVhdGVkbHlPYnMgPSB0aGlzLl9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdGltZXpvbmUpXHJcbiAgICAgICAgICAgIC5waXBlKG1hcCgocmVzcG9uc2U6IFRpbWVzZXJpZXNSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKGxhc3RNZXJnZWRSZXNwb25zZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1dEJlZm9yZURhdGUgPSBtb21lbnQudXRjKHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kKTtcclxuICAgICAgICAgICAgICAgICAgICBjdXRCZWZvcmVEYXRlLnN1YnRyYWN0KE1hdGguYWJzKHJlcXVlc3RUaW1lUGVyaW9kLmR1cmF0aW9uKSwgJ3NlY29uZHMnKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXRCZWZvcmVEYXRlVVRDRm9ybWF0ID0gY3V0QmVmb3JlRGF0ZS5mb3JtYXQoTW9tZW50SGVscGVyU2VydmljZS5NT01FTlRfREFURVRJTUVfRk9STUFUX1VUQ19GVUxMKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmlzTmlsKHR6KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0TWVyZ2VkUmVzcG9uc2UudGltZVBlcmlvZC5zdGFydCA9IE1vbWVudEhlbHBlclNlcnZpY2UuYXBwbHlUaW1lem9uZShjdXRCZWZvcmVEYXRlVVRDRm9ybWF0LCB0eik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLmVuZCA9IHJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RNZXJnZWRSZXNwb25zZS50aW1lUGVyaW9kLnN0YXJ0ID0gY3V0QmVmb3JlRGF0ZVVUQ0Zvcm1hdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnRpbWVQZXJpb2QuZW5kID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbWVudC51dGMocmVzcG9uc2UudGltZVBlcmlvZC5lbmQpLmZvcm1hdChNb21lbnRIZWxwZXJTZXJ2aWNlLk1PTUVOVF9EQVRFVElNRV9GT1JNQVRfVVRDX0ZVTEwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgXy5lYWNoKGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLCAocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld1Jlc3VsdHMgPSBfLmZpbmQocmVzcG9uc2UucmVzdWx0cywgeyBmcW46IHJlc3VsdC5mcW4gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChuZXdSZXN1bHRzKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IHJlc3VsdC52YWx1ZXMuY29uY2F0KG5ld1Jlc3VsdHMudmFsdWVzKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudmFsdWVzID0gXy5zb3J0QnkocmVzdWx0LnZhbHVlcywgWyhvOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlVnF0cykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBtb21lbnQudXRjKG8udCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnZhbHVlcyA9IHRoaXMuX2ZpbHRlckR1cGxpY2F0ZURhdGFBbmRDdXQocmVzdWx0LnZhbHVlcywgY3V0QmVmb3JlRGF0ZSwgZmFsc2UsIHR6KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGFkZCBhbnkgbmV3IGZxbnMgZGF0YVxyXG4gICAgICAgICAgICAgICAgICAgIF8uZWFjaChyZXNwb25zZS5yZXN1bHRzLCAobmV3UmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5maW5kKGxhc3RNZXJnZWRSZXNwb25zZS5yZXN1bHRzLCB7IGZxbjogbmV3UmVzdWx0LmZxbiB9KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlLnJlc3VsdHMucHVzaChuZXdSZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGxhc3RNZXJnZWRSZXNwb25zZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGFzdE1lcmdlZFJlc3BvbnNlID0gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgcmV0dXJuIHJlcGVhdGVkbHlPYnM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBNZXRob2QgdG8gc2VuZCB0aW1lc2VyaWVzIHJlcXVlc3RzIHJlcGVhdGVkbHkgYW5kIHJldHVybiBkYXRhIGFzIGluY3JlbWVudHMuXHJcbiAgICAgKiBAcGFyYW0gcmVxdWVzdCB0aW1lc2VyaWVzIHJlcXVlc3QgdG8gYmUgc2VudFxyXG4gICAgICogQHBhcmFtIGN1c3RvbUludGVydmFsIGludGVydmFsIGluIHNlY29uZHNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UmVwZWF0ZWRseUluY3JlbWVudHMoXHJcbiAgICAgICAgcmVxdWVzdDogVGltZXNlcmllc1JlcXVlc3QsIGN1c3RvbUludGVydmFsPzogbnVtYmVyLCB0aW1lem9uZT86IHN0cmluZyk6IE9ic2VydmFibGU8VGltZXNlcmllc1Jlc3BvbnNlPiB7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RUaW1lUGVyaW9kID0gcmVxdWVzdC5nZXRUaW1lUGVyaW9kKCk7XHJcblxyXG4gICAgICAgIGxldCBsYXN0UmVzcG9uc2VEYXRhOiBNYXA8c3RyaW5nLCBhbnk+O1xyXG4gICAgICAgIGxldCByZXBlYXRlZEludGVydmFsID0gY3VzdG9tSW50ZXJ2YWwgfHwgdGhpcy5jb25maWcuZGVmYXVsdFJlcGVhdGVkRGF0YUludGVydmFsIHx8IERFRkFVTFRfUkVQRUFURURfREFUQV9JTlRFUlZBTDtcclxuICAgICAgICByZXBlYXRlZEludGVydmFsID0gcmVwZWF0ZWRJbnRlcnZhbCAqIDEwMDA7XHJcblxyXG4gICAgICAgIGNvbnN0IGxhc3RSZXBlYXRlZFJlcXVlc3QgPSBfLmNsb25lKHJlcXVlc3QpO1xyXG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRHVyYXRpb24gPSByZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbjtcclxuICAgICAgICBsZXQgbmV4dFJlcXVlc3RTdGFydE1vbWVudDogbW9tZW50Lk1vbWVudDtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwZWF0ZWREYXRhT2JzZXJ2YWJsZSA9IHRoaXMuX3NlbmRQb3N0UmVxdWVzdChyZXF1ZXN0KS5waXBlKG1hcCgocmVzcG9uc2U6IElUaW1lc2VyaWVzVmFsdWVzUmVzcG9uc2VJbnRlcm5hbCkgPT4ge1xyXG4gICAgICAgICAgICBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50ID0gdGhpcy5fZ2V0U3RhcnRGb3JOZXh0UmVxdWVzdChyZXNwb25zZSwgb3JpZ2luYWxEdXJhdGlvbiwgcmVwZWF0ZWRJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgIC8vIHdlIHJlbWVtYmVyIGxhc3QgdmFsdWUgYmVmb3JlIG5leHRTdGFydCBpbiBjdXJyZW50IHJlcXVlc3QgdG8gY2hlY2sgaXRzXHJcbiAgICAgICAgICAgIC8vIHF1YWxpdHkgdnMuIG5leHQgcmVxdWVzdCBzdGFydCB0aW1lIHZhbHVlIHF1YWxpdHksIHBvc3NpYmx5XHJcbiAgICAgICAgICAgIC8vIHRvIG9taXQgc3RhcnQgdmFsdWVcclxuICAgICAgICAgICAgLy8gLSBpdCBtYXkgYmUgaW50ZXJwb2xhdGVkIGJldHdlZW4gdHdvIGdvb2QgcXVhbGl0eSB2YWx1ZXNcclxuICAgICAgICAgICAgbGFzdFJlc3BvbnNlRGF0YSA9IHRoaXMuX2dldFJlcXVlc3REYXRhTmV4dFN0YXJ0VmFsdWVzKHJlc3BvbnNlLCBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zZm9ybVRpbWVzZXJpZXNJbnRlcm5hbFJlc3BvbnNlKHJlc3BvbnNlLCB0aW1lem9uZSk7XHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIGNvbnN0IGV4cGFuZGVkT2JzZXJ2YWJsZSA9IHJlcGVhdGVkRGF0YU9ic2VydmFibGUucGlwZShcclxuICAgICAgICAgICAgZXhwYW5kKCgpID0+IHRpbWVyKHJlcGVhdGVkSW50ZXJ2YWwpLnBpcGUoY29uY2F0TWFwKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghXy5pc05pbChuZXh0UmVxdWVzdFN0YXJ0TW9tZW50KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RSZXBlYXRlZFJlcXVlc3Quc2V0VGltZVBlcmlvZChcclxuICAgICAgICAgICAgICAgICAgICAgICAgXy5leHRlbmQobGFzdFJlcGVhdGVkUmVxdWVzdC5nZXRUaW1lUGVyaW9kKCksIHsgZHVyYXRpb246IDAsIHN0YXJ0OiBuZXh0UmVxdWVzdFN0YXJ0TW9tZW50LnRvRGF0ZSgpIH0pKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zZW5kUG9zdFJlcXVlc3QobGFzdFJlcGVhdGVkUmVxdWVzdCkucGlwZShtYXAoKHJlc3BvbnNlOiBJVGltZXNlcmllc1ZhbHVlc1Jlc3BvbnNlSW50ZXJuYWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobGFzdFJlc3BvbnNlRGF0YS5zaXplID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3ZSBjaGVjayBwcmV2aW91cyB2YWx1ZXMgdG8gY3VycmVudCBzdGFydGluZyBvbmVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGZpbHRlciBvdXQgcG9zc2libGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RhcnQgaW50ZXJwb2xhdGVkIG9uZXMgaWYgdGhleSBhcmUgYmV0d2VlbiBnb29kIG9uZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZmlsdGVyU3RhcnRSZXNwb25zZURhdGEocmVzcG9uc2UsIGxhc3RSZXNwb25zZURhdGEsIHJlcXVlc3RUaW1lUGVyaW9kKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmV4dFJlcXVlc3RTdGFydE1vbWVudCA9IHRoaXMuX2dldFN0YXJ0Rm9yTmV4dFJlcXVlc3QocmVzcG9uc2UsIG9yaWdpbmFsRHVyYXRpb24sIHJlcGVhdGVkSW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHdlIHJlbWVtYmVyIGxhc3QgdmFsdWUgYmVmb3JlIG5leHRTdGFydCBpbiBjdXJyZW50IHJlcXVlc3QgdG8gY2hlY2sgaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gcXVhbGl0eSB2cy4gbmV4dCByZXF1ZXN0IHN0YXJ0IHRpbWUgdmFsdWUgcXVhbGl0eSwgcG9zc2libHlcclxuICAgICAgICAgICAgICAgICAgICAvLyB0byBvbWl0IHN0YXJ0IHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gLSBpdCBtYXkgYmUgaW50ZXJwb2xhdGVkIGJldHdlZW4gdHdvIGdvb2QgcXVhbGl0eSB2YWx1ZXNcclxuICAgICAgICAgICAgICAgICAgICBsYXN0UmVzcG9uc2VEYXRhID0gdGhpcy5fZ2V0UmVxdWVzdERhdGFOZXh0U3RhcnRWYWx1ZXMocmVzcG9uc2UsIG5leHRSZXF1ZXN0U3RhcnRNb21lbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc2Zvcm1UaW1lc2VyaWVzSW50ZXJuYWxSZXNwb25zZShyZXNwb25zZSwgdGltZXpvbmUpO1xyXG4gICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9KSkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICByZXR1cm4gZXhwYW5kZWRPYnNlcnZhYmxlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTWV0aG9kIHRvIHNlbmQgcmVxdWVzdCBmb3IgdGltZXNlcmllcyBkYXRhIHJlcGVhdGVkbHkuIEl0IHJlcGVhdGVkbHkgc2VuZHMgcmVxdWVzdHMgdG8gc2VydmVyLlxyXG4gICAgICogQHBhcmFtIHJlcXVlc3QgdGltZXNlcmllcyByZXF1ZXN0IHRvIGJlIHNlbnRcclxuICAgICAqIEBwYXJhbSBjdXN0b21JbnRlcnZhbCBjdXN0b20gaW50ZXJ2YWwgZm9yIHJlcGVhdGVkIGRhdGEsIGluIHNlY29uZHNcclxuICAgICAqIEBwYXJhbSBmb3JtYXQgKE9wdGlvbmFsKSBmb3JtYXQgZm9yIHJlcGVhdGVkIGRhdGEgcmVzcG9uc2VcclxuICAgICAqIEBwYXJhbSB0aW1lem9uZSAoT3B0aW9uYWwpIFNldCB0aGUgdGltZXpvbmUgdG8gYXBwbHkgdG8gZGF0ZXRpbWUgc3RyaW5ncyBmb3IgdGltZXNlcmllcyByZXNwb25zZSBkYXRhLlxyXG4gICAgICogUmV0dXJuZWQgZGF0ZSBzdHJpbmdzIGFyZSBpbiBtYXhpbXVtIGphdmFzY3JpcHQgcmVzb2x1dGlvbiBwb3NzaWJsZVxyXG4gICAgICogc3VwcG9ydGVkIGJ5IHVzaW5nIG1vbWVudCBsaWJyYXJ5IChKYXZhc2NyaXB0IGRhdGUgLSBtaWxsaXNlY29uZHMpLlxyXG4gICAgICogUmVzb2x1dGlvbiBmb3IgdGltZSBhZnRlciBtaWxsaXNlY29uZHMgd2lsbCBiZSBsb3N0LlxyXG4gICAgICogSWYgd29ya2luZyB3aXRoIHRpbWV6b25lIGluIGRhdGV0aW1lIHN0cmluZyBpdCBpcyByZWNvbW1lbmRlZCB0byB1c2UgbW9tZW50LnBhcnNlWm9uZSB0byBwcmVzZXJ2ZSB0aW1lem9uZSBpbmZvcm1hdGlvbi5cclxuICAgICAqIE1vbWVudCB0aW1lem9uZXMgdGhhdCBzdGFydCB3aXRoIFwiRXRjL0dNVFwiIHVzZSBQT1NJWC1zdHlsZSBzaWducyBpbiB0aGUgWm9uZSBuYW1lcyBhbmQgdGhlIG91dHB1dCBhYmJyZXZpYXRpb25zLFxyXG4gICAgICogZXZlbiB0aG91Z2ggdGhpcyBpcyB0aGUgb3Bwb3NpdGUgb2Ygd2hhdCBtYW55IHBlb3BsZSBleHBlY3QuXHJcbiAgICAgKiBQT1NJWCBoYXMgcG9zaXRpdmUgc2lnbnMgd2VzdCBvZiBHcmVlbndpY2gsIGJ1dCBtYW55IHBlb3BsZSBleHBlY3RcclxuICAgICAqIHBvc2l0aXZlIHNpZ25zIGVhc3Qgb2YgR3JlZW53aWNoLiAgRm9yIGV4YW1wbGUsIFRaPSdFdGMvR01UKzQnIHVzZXNcclxuICAgICAqIHRoZSBhYmJyZXZpYXRpb24gXCJHTVQrNFwiIGFuZCBjb3JyZXNwb25kcyB0byA0IGhvdXJzIGJlaGluZCBVVFxyXG4gICAgICogKGkuZS4gd2VzdCBvZiBHcmVlbndpY2gpIGV2ZW4gdGhvdWdoIG1hbnkgcGVvcGxlIHdvdWxkIGV4cGVjdCBpdCB0b1xyXG4gICAgICogbWVhbiA0IGhvdXJzIGFoZWFkIG9mIFVUIChpLmUuIGVhc3Qgb2YgR3JlZW53aWNoKS5cclxuICAgICAqL1xyXG4gICAgZ2V0UmVwZWF0ZWRseShyZXF1ZXN0OiBUaW1lc2VyaWVzUmVxdWVzdCwgY3VzdG9tSW50ZXJ2YWw/OiBudW1iZXIsIGZvcm1hdD86IFRpbWVzZXJpZXNSZXBlYXRlZERhdGFGb3JtYXQsIHRpbWV6b25lPzogc3RyaW5nKTpcclxuICAgICAgICBPYnNlcnZhYmxlPFRpbWVzZXJpZXNSZXNwb25zZT4ge1xyXG5cclxuICAgICAgICBjb25zdCByZXF1ZXN0VGltZVBlcmlvZCA9IHJlcXVlc3QuZ2V0VGltZVBlcmlvZCgpO1xyXG4gICAgICAgIGlmICghXy5pc05pbChyZXF1ZXN0VGltZVBlcmlvZC5zdGFydCkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEVycm9yT2JzZXJ2YWJsZSgnVGltZXNlcmllc0RhdGFTZXJ2aWNlIGdldFJlcGVhdGVkbHk6IEFyZ3VtZW50IGV4Y2VwdGlvbidcclxuICAgICAgICAgICAgICAgICsgJyAtIFJlcXVlc3Qgc3RhcnQgdGltZSBjYW5ub3QgYmUgc2V0IGZvciByZXBlYXRlZCBkYXRhIChyZXF1ZXN0OiAnXHJcbiAgICAgICAgICAgICAgICArIEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpICsgJyBjYW5ub3QgYmUgcHJvY2Vzc2VkLicpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoXy5pc05pbChyZXF1ZXN0VGltZVBlcmlvZC5kdXJhdGlvbikgfHwgcmVxdWVzdFRpbWVQZXJpb2QuZHVyYXRpb24gPiAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRFcnJvck9ic2VydmFibGUoJ1RpbWVzZXJpZXNEYXRhU2VydmljZSBnZXRSZXBlYXRlZGx5OiBBcmd1bWVudCBleGNlcHRpb24nXHJcbiAgICAgICAgICAgICAgICArICcgLSBSZXF1ZXN0IGR1cmF0aW9uIGhhdmUgdG8gYmUgbmVnYXRpdmUgKHJlcXVlc3Q6ICdcclxuICAgICAgICAgICAgICAgICsgSlNPTi5zdHJpbmdpZnkocmVxdWVzdCkgKyAnIGNhbm5vdCBiZSBwcm9jZXNzZWQuJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdHo6IHN0cmluZztcclxuICAgICAgICBpZiAoTW9tZW50SGVscGVyU2VydmljZS5pc1ZhbGlkVGltZXpvbmUodGltZXpvbmUpKSB7XHJcbiAgICAgICAgICAgIHR6ID0gdGltZXpvbmU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfLmlzTmlsKGZvcm1hdCkgfHwgZm9ybWF0ID09PSBUaW1lc2VyaWVzUmVwZWF0ZWREYXRhRm9ybWF0Lndob2xlSW50ZXJ2YWwpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJlcGVhdGVkbHlXaG9sZShyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdHopO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRSZXBlYXRlZGx5SW5jcmVtZW50cyhyZXF1ZXN0LCBjdXN0b21JbnRlcnZhbCwgdHopO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=