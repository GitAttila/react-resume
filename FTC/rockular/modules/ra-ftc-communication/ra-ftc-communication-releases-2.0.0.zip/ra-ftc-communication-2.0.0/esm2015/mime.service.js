import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { COMMUNICATION_CONFIG } from './config';
import { BaseService } from './base.service';
export class MimeService extends BaseService {
    constructor(config, http) {
        super(config.baseUrl + '/api/1/mime/', config, http);
    }
    getMimeItemPath(fqn) {
        return this.endpointUrl.concat(fqn);
    }
}
MimeService.decorators = [
    { type: Injectable },
];
MimeService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [COMMUNICATION_CONFIG,] },] },
    { type: HttpClient, },
];
function MimeService_tsickle_Closure_declarations() {
    MimeService.decorators;
    MimeService.ctorParameters;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWltZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHJhLXdjZnRjbG91ZC9yYS1mdGMtY29tbXVuaWNhdGlvbi8iLCJzb3VyY2VzIjpbIm1pbWUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNuRCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDbEQsT0FBTyxFQUFFLG9CQUFvQixFQUF3QixNQUFNLFVBQVUsQ0FBQztBQUN0RSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFHN0MsTUFBTSxrQkFBbUIsU0FBUSxXQUFXO0lBRXhDLFlBQTBDLFFBQThCLElBQWdCO1FBQ3BGLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLGNBQWMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDeEQ7SUFFRCxlQUFlLENBQUMsR0FBVztRQUN2QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdkM7OztZQVRKLFVBQVU7Ozs0Q0FHTSxNQUFNLFNBQUMsb0JBQW9CO1lBUG5DLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgQ09NTVVOSUNBVElPTl9DT05GSUcsIElDb21tdW5pY2F0aW9uQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xyXG5pbXBvcnQgeyBCYXNlU2VydmljZSB9IGZyb20gJy4vYmFzZS5zZXJ2aWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIE1pbWVTZXJ2aWNlIGV4dGVuZHMgQmFzZVNlcnZpY2Uge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKEBJbmplY3QoQ09NTVVOSUNBVElPTl9DT05GSUcpIGNvbmZpZzogSUNvbW11bmljYXRpb25Db25maWcsIGh0dHA6IEh0dHBDbGllbnQpIHtcclxuICAgICAgICBzdXBlcihjb25maWcuYmFzZVVybCArICcvYXBpLzEvbWltZS8nLCBjb25maWcsIGh0dHApO1xyXG4gICAgfVxyXG5cclxuICAgIGdldE1pbWVJdGVtUGF0aChmcW46IHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmVuZHBvaW50VXJsLmNvbmNhdChmcW4pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==