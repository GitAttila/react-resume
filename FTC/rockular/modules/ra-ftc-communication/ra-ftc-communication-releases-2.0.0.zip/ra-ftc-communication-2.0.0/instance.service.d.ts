import { HttpClient } from '@angular/common/http';
import { ICommunicationConfig } from './config';
import { Observable } from 'rxjs';
import { BaseService } from './base.service';
export interface IFqnItemResponseFormat {
    depth?: number;
    includeShortcuts?: boolean;
    includeAcl?: boolean;
}
export interface IFqnItem {
    fqn: string;
    excludeVolatileProperties?: boolean;
    pageSize?: number;
    page?: number;
    responseFormat?: IFqnItemResponseFormat;
}
export interface IFqnPropertyItem {
    propertyFqn: string;
    pageSize?: number;
    page?: number;
    responseFormat?: IFqnItemResponseFormat;
}
export interface IQueryItem {
    query: string;
    responseFormat?: IFqnItemResponseFormat;
}
export declare type InstanceFqnItem = IFqnItem | IFqnPropertyItem;
export declare type InstanceQueryItem = IQueryItem;
export declare class InstanceService extends BaseService {
    constructor(config: ICommunicationConfig, http: HttpClient);
    getInstances(instanceRequest: InstanceRequest): Observable<any>;
}
export declare class InstanceRequest {
    private queries;
    private fqns;
    camelCasePropertyNames: boolean;
    constructor(camelCasePropertyNames?: boolean);
    private addResponseFormat(instanceFqnItem, includeAccessControl, retrievalDepth, includeShortcuts);
    addItemFqn(fqn: string, includeAccessControl?: boolean, retrievalDepth?: number, includeShortcuts?: boolean): this;
    addItemFqnExcludeVolatile(fqn: string, includeAccessControl: boolean, retrievalDepth: number, includeShortcuts: boolean): this;
    addPropertyFqn(fqn: string, includeAccessControl?: boolean, retrievalDepth?: number, includeShortcuts?: boolean, pageSize?: number, page?: number): this;
    addQuery(queryExpression: string, includeAccessControl?: boolean, retrievalDepth?: number, includeShortcuts?: boolean): this;
}
