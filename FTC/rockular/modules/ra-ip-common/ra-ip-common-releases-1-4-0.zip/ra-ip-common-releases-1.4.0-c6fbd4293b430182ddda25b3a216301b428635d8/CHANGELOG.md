<meta name="ngdocTitle" content="Changelog" />

<!-----------------------------------------------------------------------------
Changelog documentation should be updated for all changes to toolkit, especially breaking changes.
Since we do not have a process to generate this changelog file, and at the time the changelog is updated on a branch,
we won't know the version number, we'll keep a "v.next" section at the top that we can all append to and merge into.
Then, before merge to master from develop, this can be updated.  Let's stick with the following format (comes from
AngularJS changelog.md file:

# [version number]

## Deprecated

## Bug Fixes

## Features

## Breaking Changes

Then on the final release before build, we can delete sections that do not apply for that build.

IMPORTANT: KEEP ONE LINE EMPTY AFTER THIS COMMENT TO GENERATE IT PROPERLY !!!
-->

# v1.4.0

## Features

- updated MFT dependency to version 8.0.0

- enhanced fqnSvc with methods to cut and find fqns

# v1.3.2

## Bug Fixes

- B-165437 trend widget in live mode doesn't refresh interpolated values with real one, interpolated values stay there

# v1.3.1

## Bug Fixes

- Fixed timeSeries service to use whole specified time frame when request contains data sampling

- Fixed timeSeries service repeated requests un-registering when trying to consequently reinitialize these requests.
Note that each registered timeSeries repeated request has to have unique ID (when ID is specified). Otherwise it will
not be repetitively called.

# v1.3.0

## Bug Fixes

- Fixed TimeSeries service to work properly with changing start time of the repeated requests

## Features

- It is now not possible to pass start date parameter to timeseriesSvc.getDataRepeatedly function.
Duration parameter can be still passed but has to be negative or zero. Otherwise, error is thrown.


# v1.2.0

## Features

- New version of MFT toolkit used (6.1.0)

- Enhanced API of persistenceSvc.commit function to accept flag for setting global httpConfig.raPassError value.

- Added buildFqnForQueryWithEscaping function to fqnSvc.

- Enhanced API of instanceSvc.getInstances function to accept flag for setting global httpConfig.raPassError value.

# v1.1.0

## Bug Fixes

- Fixed issue when there was no data coming from TimeSeriesSvc - Alarm grid and Transaction grid threw error.

- Fixed paths for source mapping files

- OperationSvc: Add cancelling promise to the getOperationData method that aborts the request when resolved.

- Fixed fqnSvc.getLastName method which was not escaping ']' character for '.' delimiter present at the end.

- Fixed issue with TimeSeriesSvc "live mode" where data were appended incorrectly
(affected Trend widget in ThinUI applications)

## Features
- Added new subscriber service which is now being used by timeSeries and liveData services

# v1.0.0

## Deprecated

- instanceRequest, navigationHandlerRequest, navigationRequest and persistRequest objects

## Bug Fixes

- Fixed FQN splitting function in fqnSvc. It now handles also escaping of "]" character.

## Features

- Documentation created

- InstantceRequest object provides possibility to specify the "pageSize" parameter of added property FQN

## Breaking Changes

- Changed API for creating request objects for instanceSvc, navigationHandlerSvc, navigationSvc, operationSvc
and persistenceSvc. All these services now exposes "create[serviceName]Request" function for creating such object.

# v0.1.0

Initial version with extracted files from VantagePoint project.
