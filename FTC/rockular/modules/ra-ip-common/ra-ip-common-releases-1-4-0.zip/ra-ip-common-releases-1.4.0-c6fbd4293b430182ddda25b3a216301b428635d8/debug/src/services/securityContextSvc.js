/*
 * (c) Rockwell Automation 2014
 */

/* global angular */
/* global _ */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:securityContextSvc
 * @description
 * Service for Security Context Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("securityContextSvc",
    [ '$http', '$log', '$rootScope', '$q', 'instanceSvc',
        function ($http, $log, $rootScope, $q, instanceSvc) {
            'use strict';

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:securityContextSvc#getSecurityContextData
             * @methodOf RA.IPCommon.Services.service:securityContextSvc
             * @description
             * Makes a request to JSON Security Context service on the server.
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available.
             */
            var getSecurityContextData = function () {
                var defer = $q.defer();
                $http.get($rootScope.gBaseUrl + "api/1/securitycontext/",
                    $rootScope.gCommonHttpConfig).success(
                    function (result) {
                        defer.resolve(result);
                    }).error(
                    function (r) {
                        $log.error("Security service connection error: " + r);
                        defer.reject();
                    }
                );

                return defer.promise;
            };

            /**
             * Internal Method - Merge the Permissions
             * @param {object} roles - roles
             * @param {object} response - response
             * @returns {object} - the Access control list (ACL)
             */
            var mergePermissions = function (roles, response) {
                var acl = ['N', 'N', 'N', 'N'];
                response.roles.push('Everyone');

                angular.forEach(response.roles, function (value) {
                    var rolesAcl = _.first(_.pluck(_.where(roles, { role: value }), 'rwde'));

                    if (rolesAcl) {
                        var splitted = rolesAcl.split('');
                        angular.forEach(splitted, function (value, key) {
                            if (value === 'Y') {
                                acl[key] = 'Y';
                            }
                        });
                    }
                });
                return acl;
            };

            /**
             * Internal Method - Resolve the ACL
             * @param {object} roles - roles
             * @param {object} requiredPermissions - requiredPermissions
             * @returns {IPromise<T>} - the angular promise
             */
            var resolveAcl = function (roles, requiredPermissions) {
                var deferred = $q.defer();
                getSecurityContextData().then(function (response) {
                    var acl = mergePermissions(roles, response);
                    
                    var result = true;
                    var splittedRequiredPermissions = requiredPermissions.split('');
                    angular.forEach(acl, function (value, key) {
                        if (splittedRequiredPermissions[key] === 'Y' && value !== 'Y') {
                            result = false;
                        }
                    });
                    deferred.resolve(result);
                });
                return deferred.promise;
            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:securityContextSvc#checkPermissions
             * @methodOf RA.IPCommon.Services.service:securityContextSvc
             * @description
             * Makes a request to services on the server to get item's permissions.
             * @param {string} fqn - FQN of the item to get permissions for.
             * @param {string} requiredPermissions - permissions to check in VP rwde format 
             * e.g. 'YNNN' that checks whether item is read-only.
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available, the answer is boolean.
             */
            var checkPermissions = function (fqn, requiredPermissions) {
                var deferred = $q.defer();
                instanceSvc.getInstance(fqn, false, true, 0).then(function (response) {
                    var item = _.first(response.data.fqnsResults).item;
                    if (item) {
                        var roles = item.acl.roles;

                        if (!roles) {
                            var parent = _.first(response.data.fqnsResults).item.acl.inherited;
                            deferred.resolve(checkPermissions(parent, requiredPermissions));
                        } else {
                            roles.push({ role: 'SysAdmin', rwde: 'YYYY' });
                            resolveAcl(roles, requiredPermissions).then(function (result) {
                                deferred.resolve(result);
                            });
                        }
                    } else {
                        deferred.resolve(false);
                    }
                });
                return deferred.promise;
            };

            return {
                getSecurityContextData: getSecurityContextData,
                checkPermissions: checkPermissions
            };
        }
    ]
);
