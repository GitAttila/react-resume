/*
 * (c) Rockwell Automation 2013
 */
/*global angular*/
/*global _*/
/*global moment*/
/*jsHint maxlen: 120*/
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:timeSeriesSvc
 * @description
 * Service for TimeSeries Request and Manipulations, it uses
 * {@link RA.IPCommon.Services.object:Subscriber Subscriber} as a base so it has all it's methods available.
 */
angular.module('RA.IPCommon.Services')
    .provider("timeSeriesSvc", function () {
        "use strict";
        var self = this,
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:SamplingTypes
             * @description
             * List of available sampling types for samplingDefinition
             */
            samplingTypes = {
                Interpolative: "Retrieve interpolated values. The interpolation" +
                    "type is server specific.",
                SampleAndHold: "Taking the first of two given values",
                Linear: "Linear interpolation between two given values.",
                Total: "Retrieve the totalized value (time integral) of the " +
                    "data over the resample interval using linear " +
                    "interpolation between measured points.",
                Sum: "Retrieve the sum of all values in the resample interval.",
                Average: "Retrieve the average data over the resample interval.",
                TimeAverage: "Retrieve the time weighted average data over" +
                    "the resample interval.",
                Count: "Retrieve the number of raw values over the resample " +
                    "interval.",
                StandardDeviation: "Retrieve the standard deviation over the " +
                    "resample interval.",
                MinimumActualTime: "Retrieve the minimum value in the resample " +
                    "interval and the timestamp of the minimum value.",
                Minimum: "Retrieve the minimum value in the resample interval.",
                MaximumActualTime: "Retrieve the maximum value in the resample " +
                    "interval and the timestamp of the maximum value.",
                Maximum: "Retrieve the maximum value in the resample interval.",
                Start: "Retrieve the value at the beginning of the resample " +
                    "interval. The time stamp is the time stamp of the " +
                    "beginning of the interval.",
                End: "Retrieve the value at the end of the resample interval." +
                    "The time stamp is the time stamp of the end of the interval.",
                Delta: " Retrieve the difference between the first and last " +
                    "value in the resample interval.",
                Variance: "Retrieve the variance over the sample interval.",
                Range: "Retrieve the difference between the minimum and " +
                    "maximum value over the sample interval.",
                DurationGood: "Retrieve the duration (expressed in " +
                    "100-nanosecond units) of time in the interval during which " +
                    "the data is good.",
                DurationBad: "Retrieve the duration (expressed in " +
                    "100-nanosecond units) of time in the interval during which " +
                    "the data is bad.",
                PercentGood: "Retrieve the percent of data (1 equals 100 " +
                    "percent) in the interval which has good quality.",
                PercentBad: "Retrieve the percent of data (1 equals 100 " +
                    "percent) in the interval which has bad quality.",
                WorstQuality: "Retrieve the worst quality of data in the interval",
                TimeAverageSampleAndHold: "Retrieve the time weighted average " +
                    "data over the resample interval using sample and hold " +
                    "'interpolation' between measured values.",
                TotalSampleAndHold: "Retrieve the totalized value (time " +
                    "integral) of the data over the resample interval using " +
                    "sample and hold 'interpolation' between measured points.",
                MinSampleAndHold: "Retrieve the minimum value in the resample " +
                    "interval using sample and hold 'interpolation' between " +
                    "measured points.",
                MaxSampleAndHold: "Retrieve the maximum value in the resample " +
                    "interval using sample and hold 'interpolation' between " +
                    "measured points.",
                CumulativeTotal: "Retrieve the cumulative total in the resample " +
                    "interval."
            },
        injector,
            globalTimerInterval = 5000,
            maxRetryCount = 3,
            ERR_GET_DATA_ONCE = "TimeSeries connection error for GetDataOnce",
            ERR_PROCESS_DATA = "TimeSeries service - cannot process data",
            ERR_GET_DATA_REP = "TimeSeries connection for getDataRepeatedly " +
            "aborted (id: {{id}})",
            ERR_WRONG_DATE_FORMAT = "Wrong input for format time to text: {{date}}",
            WRN_SET_GEN_TIMER = "Warning: Custom timer is not a number or " +
            "lower than minimum {{min}}ms. Using default minimum value.";

        this.minimumTimerInterval = globalTimerInterval;
        this.serviceRelativePath = "api/1/timeseries/";

        this.$get = ['$http', '$log', '$timeout', '$q', '$rootScope', "$interpolate", 'raIdGenSvc',
            'raErrorHandlerSvc', 'subscriberSvc', 'raOpcQualitySvc', 'raErrorCollectorSvc',
            function ($http, $log, $timeout, $q, $rootScope, $interpolate, raIdGenSvc, raErrorHandlerSvc,
                subscriberSvc, raOpcQualitySvc, raErrorCollectorSvc) {

                var unsubscribedIds = {};

                /**
                 * @param {Object} postResult data returned from http post
                 * @param {Array} fqns list of requested fqns
                 * @returns {Object} hash of messages
                 */
                var processResult = function (postResult, fqns) {
                    var messages = {},
                        startTime = (new Date(postResult.timePeriod.start)).valueOf(),
                        endTime = (new Date(postResult.timePeriod.end)).valueOf();

                    angular.forEach(postResult.fqnsResults, function (el, idx) {
                        if (el) {
                            //default to null instead of empty array, default we suppose we have no fqn values 
                            //data in this el behavior of setting value null is the same as in else condition
                            this[el.fqn] = null;
                            if (el.values.length) {
                                // we create and fill array with data only if we know we have data
                                this[el.fqn] = [];
                                angular.forEach(el.values, function (data) {
                                    var timeStamp = new Date(data.t),
                                        timeStampValue = timeStamp.valueOf();

                                    if (timeStampValue >= startTime &&
                                        timeStampValue <= endTime) {
                                        this.push({
                                            timeStamp: timeStamp,
                                            value: data.v,
                                            quality: data.q
                                        });
                                    }
                                }, this[el.fqn]);
                            }
                        } else {
                            // The code is based on assumption that result contains
                            // data for fqns in the same order as request.
                            this[fqns[idx]] = null;
                        }

                    }, messages);

                    return {
                        messages: messages,
                        startTime: startTime,
                        endTime: endTime
                    };
                };

                /**
                 * Internal Method - Constructs request to be sent
                 * @param {object} data incoming data
                 * @param {object} repeatedly flag indication there is construction for repeated data request
                 * @returns {object} object with prepared request
                 */
                function constructRequest(data, repeatedly) {
                    var request = {
                        fqns: data.fqns,
                        timePeriod: {}
                    };

                    if (angular.isDefined(data.duration)) {
                        if (repeatedly && data.duration >= 0) {
                            throw raErrorHandlerSvc.getRAError('Error in timeSeriesSvc.getDataRepeatedly',
                                'Request data duration cannot be positive.');
                        }

                        request.timePeriod.duration = data.duration;
                    }

                    if (repeatedly && data.start) {
                        throw raErrorHandlerSvc.getRAError('Error in timeSeriesSvc.getDataRepeatedly',
                            'Request start time cannot be set.');
                    } else if (data.start) {
                        request.timePeriod.start = formatTimeForServer(data.start);
                    }

                    if ((data.duration === null || data.duration === undefined) &&
                        !(angular.isDefined(data.start) && angular.isDefined(data.end))) {
                        throw raErrorHandlerSvc.getRAError('Error in timeSeriesSvc.getDataRepeatedly',
                            'Request data duration, or request start and end time must be set.');
                    }

                    if (data.timeDeadBand) {
                        request.timeDeadBand = data.timeDeadBand;
                    }

                    if (data.valueDeadBand) {
                        data.valueDeadBand = parseFloat(data.valueDeadBand);
                        if (data.valueDeadBand > 0 && data.valueDeadBand <= 1) {
                            request.valueDeadBand = data.valueDeadBand;
                        }
                    }

                    if (data.samplingDefinition) {
                        request.samplingDefinition = data.samplingDefinition;
                    }

                    return request;
                }

                /**
                 * Internal Method - Formats date into string representation for server
                 * @param {object} date Date to be converted
                 * @returns {String} string representation of date
                 */
                function formatTimeForServer(date) {
                    if (!angular.isDate(date)) {
                        raErrorHandlerSvc.propagate(
                            raErrorHandlerSvc.getRAError(
                                $interpolate(ERR_WRONG_DATE_FORMAT)({date: date}))
                            );
                        return "";
                    }
                    return date.toISOString();
                }

                /**
                 * Sets the general timer for repeating data subscribers
                 * @param {number} intervalMilliseconds
                 * <p>The interval length in milliseconds</p>
                 */
                function setGeneralTimer(intervalMilliseconds) {
                    if (intervalMilliseconds > self.minimumTimerInterval) {
                        globalTimerInterval = intervalMilliseconds;
                    } else {
                        $log.warn($interpolate(WRN_SET_GEN_TIMER)({
                            min: self.minimumTimerInterval
                        }));
                        globalTimerInterval = self.minimumTimerInterval;
                    }
                }
                /**
                 * Gets start time for next request when getting data repeatedly.
                 * @param {Object} data result from previous call
                 * @param {Number} originalDuration - original request duration in milliseconds, always negative
                 * @return {Moment} moment object
                 */
                function getStartForNextRequest(data, originalDuration) {
                    function getLastValueToUse(fqnResult) {
                        var result = _.first(fqnResult.values).t;

                        for (var i = fqnResult.values.length - 1; i >= 0; i--) {
                            var val = fqnResult.values[i];
                            if (!raOpcQualitySvc.isHdaInterpolated(val.q)) {
                                return val.t;
                            }
                        }

                        return result;
                    }

                    var result = null;
                    var currentTimeMinusDuration = moment.utc().add(originalDuration, 'seconds');

                    angular.forEach(data.fqnsResults, function (fqnResult) {
                        var lastValue = moment.utc(getLastValueToUse(fqnResult));
                        if (!result || result.isAfter(lastValue)) {
                            result = lastValue.clone();
                        }
                    });

                    if (result === null) {
                        //no good quality - add period to response start time - as default for next request
                        result = moment.utc(data.timePeriod.start);
                    }

                    if (currentTimeMinusDuration.isAfter(result)) {
                        result = currentTimeMinusDuration;
                    }

                    return result;
                }

                /**
                 * Method to get first value before next request start time in current data.
                 * @param {Object} postResult data result from previous call
                 * @param {Moment} nextStartMoment starting date for next request
                 * @returns {Object} object which may be filled with values before next request start time
                 * structure: {
                 * 'Extruder.Stroke Length': 
                 *      [{q: 192, t:"2017-07-21T15:23:01.0629279Z", v:34}],
                 * 'Extruder.Hydraulic Pressure': [] 
                 *  ...
                 * }
                 */
                function getRequestDataNextStartValues(postResult, nextStartMoment) {
                    var beforeNextRequestValues = {}, last;
                    angular.forEach(postResult.fqnsResults, function (el) {
                        if (el) {
                            //default to null instead of empty array, default we suppose we have no fqn values 
                            //data in this el behavior of setting value null is the same as in else condition
                            this[el.fqn] = null;
                            if (el.values.length) {
                                last = _.findLast(el.values, function (value) {
                                    var utcTime = moment.utc(value.t);
                                    if (utcTime >= nextStartMoment) {
                                        return true;
                                    }
                                    return false;
                                });
                                this[el.fqn] = last;
                            }
                        }
                    }, beforeNextRequestValues);

                    return beforeNextRequestValues;
                }

                /**
                 * Function to optionally filter first value in repeated request when it is interpolated between 
                 * two good ones. Directly modifies postResult input parameter.
                 * @param {Object} postResult
                 * @param {Object} previousRequestNextStartValues
                 */
                function filterStartResultData(postResult, previousRequestNextStartValues) {
                    var firstVqt, firstVqtMoment, secondVqt;
                    angular.forEach(postResult.fqnsResults, function (el) {
                        if (el && previousRequestNextStartValues[el.fqn] && el.values.length > 1) {
                            firstVqt = el.values.slice(0, 1)[0];
                            firstVqtMoment = moment.utc(firstVqt.t);
                            if (raOpcQualitySvc.isHdaInterpolated(firstVqt.q)) {
                                secondVqt = el.values.slice(1, 2)[0];
                                if (firstVqtMoment > moment(previousRequestNextStartValues[el.fqn].t) &&
                                    firstVqtMoment < moment(secondVqt.t) &&
                                    raOpcQualitySvc.isGood(previousRequestNextStartValues[el.fqn].q) &&
                                    raOpcQualitySvc.isGood(secondVqt.q)) {
                                    el.values.splice(0, 1);
                                }
                            }
                        }
                    });
                }

                injector = {
                    setGeneralTimer: setGeneralTimer,
                    /**
                     * @ngdoc method
                     * @module RA.IPCommon.Services
                     * @name RA.IPCommon.Services.service:timeSeriesSvc#getGlobalTimerInterval
                     * @methodOf RA.IPCommon.Services.service:timeSeriesSvc
                     * @description
                     * Getter for the globalTimerInterval value
                     * @returns {Number} Global Time Interval
                     */
                    getGlobalTimerInterval: function () {
                        return globalTimerInterval;
                    },
                    /**
                     * @ngdoc method
                     * @module RA.IPCommon.Services
                     * @name RA.IPCommon.Services.service:timeSeriesSvc#getSamplingTypes
                     * @methodOf RA.IPCommon.Services.service:timeSeriesSvc
                     * @description
                     * Returns list of available sampling type names
                     * @returns {object} {@link RA.IPCommon.Services.object:SamplingTypes}
                     */
                    getSamplingTypes: function () {
                        return angular.copy(samplingTypes);
                    },
                    /**
                     * @ngdoc method
                     * @module RA.IPCommon.Services
                     * @name RA.IPCommon.Services.service:timeSeriesSvc#getDataOnce
                     * @methodOf RA.IPCommon.Services.service:timeSeriesSvc
                     * @description
                     * Get data from time series service
                     * @param {object} timeSeriesReq A structure:
                     *  {
                     *      fqns: {array(string)} List of fqns for request
                     *      duration: {number} duration time into history to look at
                     *      timeDeadBand: {string} timeDeadBand time dead band if
                     *        wanted
                     *      valueDeadBand: {number} valueDeadBand optional value dead
                     *        band
                     *      start: {date} start Optional start interval point other
                     *        than now
                     *      samplingDefinition: {object} Optional definition for
                     *        sampling data consisting of up to three parameters
                     *        <ul>
                     *          <li><b>samplingType: <i>string</i></b> <i>required</i>
                     *          One of the types returned in getSamplingTypes (the
                     *          string representation of key, not the
                     *          value/description)</li>
                     *          <li><b>sliceCount: <i>integer</i></b> <i>optional</i>
                     *          Number of slices to which the time interval should be
                     *          divided</li>
                     *          <li><b>deltaT: <i>integer</i></b> <i>optional</i>
                     *          Length of interval to which the time interval should be
                     *          divided</li>
                     *        </ul>
                     *        One of the optional parameters has to be defined
                     *  }
                     *
                     * @returns {IPromise<T>} Angular promise to be resolved later
                     */
                    getDataOnce: function (timeSeriesReq) {
                        var defered,
                            request = constructRequest(timeSeriesReq);

                        defered = $q.defer();
                        $http.post($rootScope.gBaseUrl + self.serviceRelativePath,
                            request, $rootScope.gCommonHttpConfig).then(
                            function success(result) {
                                var messages;
                                try {
                                    messages = processResult(result.data, timeSeriesReq.fqns);
                                } catch (error) {
                                    defered.reject(raErrorHandlerSvc
                                        .getRAError(ERR_PROCESS_DATA, error));
                                    return;
                                }

                                defered.resolve(messages);
                            },
                            function failure(reason) {
                                defered.reject(raErrorHandlerSvc
                                    .getRAHTTPError(ERR_GET_DATA_ONCE, reason));
                            });
                        return defered.promise;
                    },
                    /**
                     * @ngdoc method
                     * @module RA.IPCommon.Services
                     * @name RA.IPCommon.Services.service:timeSeriesSvc#getDataRepeatedly
                     * @methodOf RA.IPCommon.Services.service:timeSeriesSvc
                     * @description
                     * Get data from time series service repeatedly.
                     * @param {object} timeSeriesReq A structure:
                     *  {
                     *      fqns: {array(string)} List of fqns for request
                     *      duration: {number} duration time into history to look at, only negative values allowed
                     *      timeDeadBand: {string} timeDeadBand time dead band if
                     *        wanted
                     *      valueDeadBand: {number} valueDeadBand optional value dead
                     *        band
                     *      samplingDefinition: {object} Optional definition for
                     *        sampling data consisting of up to three parameters
                     *        <ul>
                     *          <li><b>samplingType: <i>string</i></b> <i>required</i>
                     *          One of the types returned in getSamplingTypes (the
                     *          string representation of key, not the
                     *          value/description)</li>
                     *          <li><b>sliceCount: <i>integer</i></b> <i>optional</i>
                     *          Number of slices to which the time interval should be
                     *          divided</li>
                     *          <li><b>deltaT: <i>integer</i></b> <i>optional</i>
                     *          Length of interval to which the time interval should be
                     *          divided</li>
                     *        </ul>
                     *        One of the optional parameters has to be defined
                     *  }
                     * @param {String} id identification
                     * @param {Number} ownRepeatInterval optional - set own repeat
                     *        interval
                     * @returns {IPromise<T>} Angular promise to resolve later
                     */
                    getDataRepeatedly: function (timeSeriesReq, id, ownRepeatInterval) {
                        if (id === undefined || id === null) {
                            id = raIdGenSvc.getStrId();
                        }
                        var data = {
                            req: constructRequest(timeSeriesReq, true),
                            id: id,
                            retryLeft: maxRetryCount,
                            requestCancel: null,
                            timer: $timeout(send, 0)
                        };

                        var promise = this.subscribe(id, data, {}, null, unsubscribed, null);
                        var consumer = injector.getConsumer(id);
                        var repeatInterval = ownRepeatInterval ? ownRepeatInterval : globalTimerInterval;
                        var originalDuration = consumer.data.req.timePeriod.duration;

                        function send() {
                            var httpConfig;
                            // cancel previous request if there is one
                            if (consumer.data.requestCancel) {
                                consumer.data.requestCancel.resolve();
                            }

                            if (consumer.data.timer) {
                                $timeout.cancel(consumer.data.timer);
                                consumer.data.timer = null;
                            }

                            if (unsubscribedIds[consumer.id]) {
                                return;
                            }
                            consumer.data.requestCancel = $q.defer();
                            httpConfig = $rootScope.gCommonHttpConfig ?
                                angular.copy($rootScope.gCommonHttpConfig) : {};
                            httpConfig.timeout = consumer.data.requestCancel.promise;
                            httpConfig.raPassError = true;
                            consumer.data.lastRequestTimestamp = new Date().valueOf();

                            //If we are using dataSampling, we want the whole bunch of data,
                            //not just the time slice from last result
                            if (timeSeriesReq.samplingDefinition) {
                                delete consumer.data.req.timePeriod.start;
                                delete consumer.data.req.timePeriod.end;
                                consumer.data.req.timePeriod.duration = timeSeriesReq.duration;
                            }

                            $http.post($rootScope.gBaseUrl + self.serviceRelativePath, consumer.data.req, httpConfig)
                                .then(function success(result) {
                                    var messages, latency, timeout = repeatInterval, nextRequestStartMoment,
                                        filteredResultData;
                                    latency = new Date().valueOf() - consumer.data.lastRequestTimestamp;
                                    timeout = latency > timeout ? 0 : timeout - latency;

                                    try {
                                        filteredResultData = result.data;
                                        if (consumer.data.previousRequestNextStartValues) {
                                            // we check previous values to current starting ones 
                                            // to filter out possible 
                                            // start interpolated ones if they are between good ones
                                            filterStartResultData(filteredResultData,
                                                consumer.data.previousRequestNextStartValues);
                                        }

                                        messages = processResult(filteredResultData, consumer.data.req.fqns);
                                        nextRequestStartMoment = getStartForNextRequest(filteredResultData,
                                            originalDuration);
                                        consumer.data.nextStart = nextRequestStartMoment.toDate();

                                        // we remember last value before nextStart in current request to check its 
                                        // quality vs. next request start time value quality, possibly 
                                        // to omit start value 
                                        // - it may be interpolated between two good quality values
                                        consumer.data.previousRequestNextStartValues =
                                            getRequestDataNextStartValues(filteredResultData, nextRequestStartMoment);
                                    } catch (e) {
                                        consumer.deferred.reject();
                                        raErrorHandlerSvc.getRAError(ERR_PROCESS_DATA, e);
                                        return;
                                    }
                                    consumer.data.req.timePeriod.start = formatTimeForServer(consumer.data.nextStart);
                                    consumer.data.req.timePeriod.duration = 0;
                                    consumer.data.retryLeft = maxRetryCount;
                                    consumer.data.requestCancel = null;
                                    consumer.data.timer = $timeout(send, timeout);
                                    consumer.deferred.notify(messages);
                                }, function failure(reason) {
                                    if (--consumer.data.retryLeft === 0) {
                                        var error = raErrorHandlerSvc.getRAHTTPError("Communication error",
                                            angular.extend(reason || {}, {
                                                causeMsg: $interpolate(ERR_GET_DATA_REP)({
                                                    id: consumer.id
                                                })
                                            }));
                                        raErrorCollectorSvc.addHttpError(error).then(function (retry) {
                                            if (retry) {
                                                send();
                                                consumer.data.retryLeft = 1;
                                            } else {
                                                injector.unsubscribe(consumer.id, null, error);
                                            }
                                        });
                                    } else {
                                        consumer.data.timer = $timeout(send, repeatInterval);
                                    }
                                });
                        }

                        return promise;
                    }
                };

                // Make Subscriber base of this.
                subscriberSvc.extend(injector);

                /**
                 * Called when subscriber un-subscribed.
                 * @param consumer
                 */
                function unsubscribed(consumer) {
                    unsubscribedIds[consumer.id] = true;

                    if (consumer.data.requestCancel) {
                        consumer.data.requestCancel.resolve();
                    }
                    if (consumer.data.timer) {
                        $timeout.cancel(consumer.data.timer);
                    }
                }
                return injector;
            }];
    });
