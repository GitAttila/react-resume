/* global angular */
angular.module('RA.IPCommon.Filters', []); // dependencies statement