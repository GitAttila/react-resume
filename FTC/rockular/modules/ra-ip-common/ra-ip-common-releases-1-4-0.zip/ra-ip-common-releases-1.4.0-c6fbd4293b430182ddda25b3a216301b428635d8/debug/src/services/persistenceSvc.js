/*
 * (c) Rockwell Automation 2013
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:persistenceSvc
 * @description
 * Service for Persistence Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("persistenceSvc",
    ['$http', '$rootScope', '$q', 'raErrorHandlerSvc',
        function ($http, $rootScope, $q, raErrorHandlerSvc) {
            'use strict';

            /**
            * @ngdoc method
            * @module RA.IPCommon.Services
            * @name RA.IPCommon.Services.service:persistenceSvc#commit
            * @methodOf RA.IPCommon.Services.service:persistenceSvc
            * @description
            * Makes a request to JSON Persistence service on the server.
            * @param {object} persistRequest {@link RA.IPCommon.Services.object:PersistRequest}
            * @param {boolean=} [raPassError] flag indicating whether to turn off
            * common error's interception mechanism
            * @returns {IPromise<T>} Promise to resolve when answer will be available.
            * 
            * It is strongly recommended to use the PropNameValues and PersistRequest utility objects
            * to assist in construction of the request object. Doing so provides protection against 
            * underlying changes to the JSON Persistence service. 
            *
            * Examples:
            *
            *  Creating items:  
            *
            *           var propNameValues = createPropNameValues();
            *           propNameValues.add('Name', 'DouglasFolder');
            *           propNameValues.add('Description', 'Douglas folder description');
            *
            *           var persistRequest = createPersistRequest();
            *           persistRequest.createItem('MyEnterprise.Public', 
            *             'TypeSystem.Packages.[Core.Package].ItemTypes.[Core.Folder]', 
            *             propNameValues)
            *
            *           persistenceSvc.commit(persistRequest);
            *
            *   Updating items:
            *
            *           var propNameValues = createPropNameValues();
            *           propNameValues.add('Description', 'Updated folder description');
            *
            *           var persistRequest = createPersistRequest();
            *           persistRequest.changeItem('MyEnterprise.Public.DouglasFolder', propNameValues);
            *
            *           persistenceSvc.commit(persistRequest);
            *
            *   Re-ordering an item collection:
            *           // NOTE: The collection property must be defined as "isOrdered" in the model item type.
            *           //       Also, you cannot add a collection and re-order it in the same transaction.
            *
            *           var propNameValues = createPropNameValues();
            *           propNameValues.reorder('Favorites', ['Item 5','Item 4','Item 3','Item 2','Item 1']);
            *
            *           var persistRequest = createPersistRequest();
            *           persistRequest.changeItem('System.Services.Profile.Users.PTM\User1.Mobile', propNameValues);
            *
            *           persistenceSvc.commit(persistRequest);
            *
            *    Rename item: (only one allowed per commit)
            *
            *           var persistRequest = createPersistRequest();
            *           persistRequest.renameItem('MyEnterprise.Public.DouglasFolder','RoseFolder')
            *
            *           persistenceSvc.commit(persistRequest);
            *
            *    Deleting items:
            *
            *           var persistRequest = createPersistRequest();
            *           persistRequest.deleteItem('MyEnterprise.Public.RoseFolder');
            *           persistRequest.deleteItem('MyEnterprise.Public.TestFolder');
            *
            *           persistenceSvc.commit(persistRequest);
            */

            var commit = function (persistRequest, raPassError) {
                var deferred = $q.defer(),
                    httpConfig = $rootScope.gCommonHttpConfig ? angular.copy($rootScope.gCommonHttpConfig) : {};

                if (typeof raPassError === "boolean") {
                    httpConfig.raPassError = raPassError;
                }

                $http.post($rootScope.gBaseUrl + "api/1/persistence/",
                    persistRequest, httpConfig).then(
                    function (result) {
                        deferred.resolve(result);
                    },
                    function failure(reason) {
                        deferred.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Persistence service error",
                                        reason
                                )
                            );
                    }
                );
                return deferred.promise;
            };
            
            /**
            * @ngdoc method
            * @module RA.IPCommon.Services
            * @name RA.IPCommon.Services.service:persistenceSvc#createPropNameValues
            * @methodOf RA.IPCommon.Services.service:persistenceSvc
            * @description
            * Create & Return Proerpty Name & Value Pairs
            * @returns {object} Property Name Value Pair
            */
            var createPropNameValues = function () {
                return new PropNameValues();
            };
            
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:PropNameValues
             * @description
             * Property Name Value Object
             * @property {dictionary} Properties Name Value Pair
             */
            var PropNameValues = (function () {
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PropNameValues#constructor
                 * @methodOf RA.IPCommon.Services.object:PropNameValues
                 * @description
                 * Create Property Name Value Pairs for New Item Creation
                 * via Persistence Service
                 */
                function PropNameValues() { }
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PropNameValues#add
                 * @methodOf RA.IPCommon.Services.object:PropNameValues
                 * @param {string} name Name of the property to add
                 * @param {object} value Value to add at Name property name
                 * @description
                 * Adds property Name Value Pair for New Item Creation
                 */
                PropNameValues.prototype.add = function (name, value) {
                    if (name) {
                        this[name] = value;
                    }
                };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PropNameValues#reorder
                 * @methodOf RA.IPCommon.Services.object:PropNameValues
                 * @param {string} name Name of the property to reorder
                 * @param {object} value Value to add at Name property name
                 * @description
                 * Reorder property Name Value Pair for New Item Creation
                 */
                PropNameValues.prototype.reorder = function (name, value) {
                    if (name) {
                        this[name] = {'finalOrder': value};
                    }
                };
                return PropNameValues;
            })();
            
            /**
            * @ngdoc method
            * @module RA.IPCommon.Services
            * @name RA.IPCommon.Services.service:persistenceSvc#createPersistRequest
            * @methodOf RA.IPCommon.Services.service:persistenceSvc
            * @description
            * Create & Return Persistence Request
            * @returns {object} Persistence Request Object
            */
            var createPersistRequest = function () {
                return new PersistRequest();
            };

            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:PersistRequest
             * @description
             * Persist Request Object
             * @property {array=} [newItems] List of new items to persist
             * @property {array=} [renamedItem] List of items to rename
             * @property {array=} [changedItems] List of changed items to persist
             * @property {array=} [deletedItems] List of items to delete
             */
            var PersistRequest = (function () {
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PersistRequest#constructor
                 * @methodOf RA.IPCommon.Services.object:PersistRequest
                 * @description
                 * Create Persistent Request Object
                 */
                function PersistRequest() {
                    this.newItems = undefined;
                    this.renamedItem = undefined;
                    this.changedItems = undefined;
                    this.deletedItems = undefined;
                }
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PersistRequest#createItem
                 * @methodOf RA.IPCommon.Services.object:PersistRequest
                 * @param {string=} [parentPropertyFqn] FQN of Parent Property
                 * @param {string=} [itemType] Item Type
                 * @param {array=} [propNameValues] Property Name Value Pairs
                 * @description
                 * Create Item via Persistence Service
                 */
                PersistRequest.prototype.createItem = function (parentPropertyFqn, itemType, propNameValues) {
                    var createRequest = {};
                    if (parentPropertyFqn) {
                        createRequest.parentPropertyFqn = parentPropertyFqn;
                    }
                    if (itemType) {
                        createRequest.itemType = itemType;
                    }
                    if (propNameValues) {
                        createRequest.props = propNameValues;
                    }
                    if (!this.newItems) {
                        this.newItems = [];
                    }
                    this.newItems.push(createRequest);
                    return this;
                };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PersistRequest#renameItem
                 * @methodOf RA.IPCommon.Services.object:PersistRequest
                 * @param {string=} [itemFqn] FQN of Item
                 * @param {string=} [newName] New Name of Item
                 * @description
                 * Rename Item via Persistence Service
                 */
                PersistRequest.prototype.renameItem = function (itemFqn, newName) {
                    if (!this.renamedItem) {
                        this.renamedItem = {};
                    }
                    if (itemFqn) {
                        this.renamedItem.fqn = itemFqn;
                    }
                    if (newName) {
                        this.renamedItem.newName = newName;
                    }
                    return this;
                };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PersistRequest#changeItem
                 * @methodOf RA.IPCommon.Services.object:PersistRequest
                 * @param {string=} [itemFqn] FQN of Item
                 * @param {string=} [propNameValues] Properties to change
                 * @description
                 * Change Item via Persistence Service
                 */
                PersistRequest.prototype.changeItem = function (itemFqn, propNameValues) {
                    var changeRequest = {};
                    if (propNameValues) {
                        propNameValues.add('FullyQualifiedName', itemFqn);
                        changeRequest = propNameValues;
                    }
                    if (!this.changedItems) {
                        this.changedItems = [];
                    }
                    this.changedItems.push(changeRequest);
                    return this;
                };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:PersistRequest#deleteItem
                 * @methodOf RA.IPCommon.Services.object:PersistRequest
                 * @param {string=} [itemFqn] FQN of Item to delete
                 * @description
                 * Delete Item via Persistence Service
                 */
                PersistRequest.prototype.deleteItem = function (itemFqn) {
                    if (!this.deletedItems) {
                        this.deletedItems = [];
                    }
                    this.deletedItems.push(itemFqn);
                    return this;
                };
                return PersistRequest;
            })();
        
            return {
                commit: commit,
                createPropNameValues: createPropNameValues,
                createPersistRequest: createPersistRequest
            };
        }
    ]
);
