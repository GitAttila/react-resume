/*
 * (c) Rockwell Automation 2014
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:viewSvc
 * @description
 * Service for View Service Requests and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("viewSvc",
    ['$rootScope', '$q', 'instanceSvc', 'fqnSvc', 'persistenceSvc', 'WELLKNOWN_LOCATIONS', 'WELLKNOWN_ITEM_TYPES',
        'VIEWS_PATH',
        function ($rootScope, $q, instanceSvc, fqnSvc, persistenceSvc, WELLKNOWN_LOCATIONS, WELLKNOWN_ITEM_TYPES,
                  VIEWS_PATH) {
            'use strict';

            var viewLocationParts = VIEWS_PATH;
            var viewType = WELLKNOWN_ITEM_TYPES.MOBILE_VIEW;

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#addView
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Add a View
             * @param {string} name view name
             * @param {string} anchorFqn - Anchor Fqn
             * @param {string} description view description
             * @returns {IPromise<T>} Promise to resolve when answer
             * will be available.
             */
            var addView = function (name, anchorFqn, description) {
                var defer = $q.defer();

                var propNameValues = persistenceSvc.createPropNameValues(),
                    persistRequest = persistenceSvc.createPersistRequest();

                propNameValues.add('Name', name);
                propNameValues.add('AnchoredFQN', encodeURIComponent(anchorFqn));
                propNameValues.add('Description', description);

                persistRequest.createItem(WELLKNOWN_LOCATIONS.MOBILE_VIEWS, viewType, propNameValues);

                persistenceSvc.commit(persistRequest)
                    .then(
                    function success(response) {
                        defer.resolve(response);
                    },
                    function error(reason) {
                        defer.reject(reason);
                    });

                return defer.promise;
            };

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#getViews
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Makes a request to JSON Navigation service on the server
             * to get list of views.
             * @returns {IPromise<T>} Promise to resolve when answer
             * will be available.
             */
            var getViews = function () {
                return instanceSvc.getInstance(WELLKNOWN_LOCATIONS.MOBILE_APPLICATION, false, false, 1);
            };

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#getFqnForViewName
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Get Fqn of the View Name
             * @param {string=} [viewName] name of the view
             * @returns {string} Fqn of the View
             */
            var getFqnForViewName = function (viewName) {
                if (!viewName) {
                    //"Default" view for the purpose of getting displays via navigation service
                    return WELLKNOWN_LOCATIONS.MOBILE_APPLICATION;
                }

                var parts = viewLocationParts.slice();
                parts.push(viewName);
                //TODO: switch to angular module
                return fqnSvc.buildFqn(parts);
            };

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#renameView
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Rename a view.
             * @param {string} fqn The original FQN of the view, Including the final Name node.
             * @param {string} newName  The new name to be used for the final Name node.
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             */
            var renameView = function (fqn, newName) {
                var defer = $q.defer();

                var persistRequest = persistenceSvc.createPersistRequest();
                persistRequest.renameItem(fqn, newName);

                persistenceSvc.commit(persistRequest).then(
                    function success(response) {
                        defer.resolve(response);
                    },
                    function failure(reason) {
                        defer.reject(reason);
                    });
                return defer.promise;
            };

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#updateView
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Update an existing view item with given information.
             * @param {string} fqn The view fqn of the properties that are being updated.
             * @param {object} viewInfo The object containing the information that can be
             * updated for the view, including:
             *   - description
             *   - anchorFqn
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             */
            var updateView = function (fqn, viewInfo) {
                var defer = $q.defer();

                var persistRequest = persistenceSvc.createPersistRequest();

                if (viewInfo.description !== undefined) {
                    var updatedDescriptionValues = persistenceSvc.createPropNameValues();
                    updatedDescriptionValues.add('Description', viewInfo.description);
                    persistRequest.changeItem(fqn, updatedDescriptionValues);
                }

                if (viewInfo.anchorFqn) {
                    var updatedAnchorFqnValues = persistenceSvc.createPropNameValues();
                    updatedAnchorFqnValues.add('AnchoredFQN', viewInfo.anchorFqn);
                    persistRequest.changeItem(fqn, updatedAnchorFqnValues);
                }

                if (persistRequest.changedItems) {
                    persistenceSvc.commit(persistRequest).then(
                        function success(response) {
                            defer.resolve(response);
                        },
                        function failure(reason) {
                            defer.reject(reason);
                        }
                    );
                }
                return defer.promise;
            };

             /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:viewSvc#removeView
             * @methodOf RA.IPCommon.Services.service:viewSvc
             * @description
             * Remove the View
             * @param {string} name - of the view to remove
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             */
            var removeView = function (name) {
                var defer = $q.defer();
                var persistRequest = persistenceSvc.createPersistRequest();

                persistRequest.deleteItem(fqnSvc.appendNamePart(WELLKNOWN_LOCATIONS.MOBILE_VIEWS, name));
                persistenceSvc.commit(persistRequest)
                    .then(
                    function success(response) {
                        defer.resolve(response);
                    },
                    function error(reason) {
                        defer.reject(reason);
                    });
                return defer.promise;
            };

            return {
                addView : addView,
                getViews : getViews,
                renameView: renameView,
                updateView: updateView,
                removeView: removeView,
                getFqnForViewName: getFqnForViewName
            };
        }
    ]
);
