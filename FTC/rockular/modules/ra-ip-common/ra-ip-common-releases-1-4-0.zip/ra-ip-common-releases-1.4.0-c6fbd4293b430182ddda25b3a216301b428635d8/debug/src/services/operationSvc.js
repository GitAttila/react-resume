/*
 * (c) Rockwell Automation 2014
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:operationSvc
 * @description
 * Service for Operation Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("operationSvc",
    [ '$http', '$rootScope', '$q', 'raErrorHandlerSvc',
        function ($http, $rootScope, $q,  raErrorHandlerSvc) {
            'use strict';

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:operationSvc#getOperationData
             * @methodOf RA.IPCommon.Services.service:operationSvc
             * @description
             * Makes a request to JSON Operation service on the server.
             * @param {OperationRequest} operationReq {@link RA.IPCommon.Services.object:OperationRequest}
             * @param {boolean=} [raPassError] - flag indicating whether to turn off
             * common error's interception mechanism
             * @param {object=} [cancelPromise] -  promise that should abort the request when resolved
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available.
             */
            var getOperationData = function (operationReq, raPassError, cancelPromise) {
                var defer = $q.defer();
                var httpConfig = $rootScope.gCommonHttpConfig;
                
                if (typeof raPassError === "boolean" ||
                    (cancelPromise && (typeof cancelPromise.then === 'function'))) {
                    if (httpConfig) {
                        httpConfig = angular.copy(httpConfig);
                    } else {
                        httpConfig = {};
                    }
                    // Setting raPassError flag in the httpConfig
                    httpConfig.raPassError = raPassError;
                    // Setting cancel promise
                    if (cancelPromise && (typeof cancelPromise.then === 'function')) {
                        httpConfig.timeout = cancelPromise;
                    }
                }

                $http.post($rootScope.gBaseUrl + "api/1/operation/",
                    operationReq, httpConfig).then(
                    function success(result) {
                        defer.resolve(result.data);
                    },
                    function error(r) {
                        // Pass errors if flag is set
                        if (typeof raPassError === 'boolean' && raPassError) {
                            defer.reject(r);
                        } else {
                            defer.reject(
                                raErrorHandlerSvc.getRAHTTPError(
                                    "Operation service connection error",
                                    r
                                )
                            );
                        }
                    });
                return defer.promise;

            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:operationSvc#createOperationRequest
             * @methodOf RA.IPCommon.Services.service:operationSvc
             * @description
             * Create or Return the Operation Request.
             * @param {string} target The FQN of target item
             * @param {string} operation The name of the operation
             * @param {string=} [parameters] The parameters for the request
             * @returns {OperationRequest} {@link RA.IPCommon.Services.object:OperationRequest}
             **/
            var createOperationRequest = function (target, operation, parameters) {
                return new OperationRequest(target, operation, parameters);
            };
            
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:OperationRequest
             * @description
             * Operation Request Object
             * @property {string} target The FQN of target item
             * @property {string} operation The name of the operation
             * @property {string=} [parameters] The parameters for the request
             */
            var OperationRequest = (function () {
                function OperationRequest(_target, _operation, _parameters) {
                    this.target = _target;
                    this.operation = _operation;
                    this.parameters = _parameters;
                }
                return OperationRequest;
            })();

            return {
                getOperationData: getOperationData,
                createOperationRequest: createOperationRequest
            };
        }
    ]
);
