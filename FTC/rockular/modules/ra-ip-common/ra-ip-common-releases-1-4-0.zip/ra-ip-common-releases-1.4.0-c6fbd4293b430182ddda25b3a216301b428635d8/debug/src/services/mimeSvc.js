/* 
 * (c) Rockwell Automation 2013
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:mimeSvc
 * @description
 * Service for Mime Data based Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory('mimeSvc',
    [ '$http', '$rootScope', '$q', 'raErrorHandlerSvc',
        function ($http, $rootScope, $q, raErrorHandlerSvc) {
            'use strict';

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:mimeSvc#getMimeProperty
             * @methodOf RA.IPCommon.Services.service:mimeSvc
             * @description
             * Get Mime Property Value
             * @param {object} fqn - Fqn of Mime
             * @returns {IPromise<T>} Angular promise to resolve later
             */
            var getMimeProperty = function (fqn) {
                var defer = $q.defer();

                $http.get(getServiceUrl(fqn), $rootScope.gCommonHttpConfig).then(
                        function onSuccess(result) {
                            defer.resolve(result.data);
                        },
                        function onError(reason) {
                            defer.reject(
                                raErrorHandlerSvc.getRAHTTPError(
                                    'mimeSvc error', reason)
                            );
                        });

                return defer.promise;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:mimeSvc#getServiceUrl
             * @methodOf RA.IPCommon.Services.service:mimeSvc
             * @description
             * Constructs a URL to the service using given parameter.
             * The parameter value is encoded using encodeURIComponent()
             * function.
             * @param {string=} [fqn] the FQN of MIME property
             * @returns {string} The URL to GetMimeProperty service with
             * properly encoded parameters, or just the base URL if called with
             * no parameters.
             */
            var getServiceUrl = function (fqn) {
                var url = $rootScope.gBaseUrl + 'api/1/mime';
                if (fqn) {
                    url = url + '/' + encodeURIComponent(fqn);
                }

                return url;
            };

            return {
                getMimeProperty: getMimeProperty,
                getServiceUrl: getServiceUrl
            };
        }
    ]
);


