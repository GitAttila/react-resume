/*
 * (c) Rockwell Automation 2014
 */

/* global angular */

/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:iconSvc
 * @description
 * Service for Icon Related Manipulations
 */
angular.module('RA.IPCommon.Services').factory('iconSvc',
    ['$rootScope', 'raErrorHandlerSvc',
        function ($rootScope, raErrorHandlerSvc) {
            'use strict';

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:iconSvc#getServiceUrl
             * @methodOf RA.IPCommon.Services.service:iconSvc
             * @description
             * Constructs a URL to service using given parameters, encoding each
             * parameter with encodeURIComponent() function.
             * @param {string=} [imageFqn] the FQN of image
             * @param {string=} [size] the desired image size;
             * if this parameter is omitted and the effect parameter is
             * passed, the 'small' value for size is used by default
             * @param {string=} [effect] the effect name to apply to an image
             * @throws RAError if size or effect parameters are provided without
             * providing the imageFqn parameter
             * @returns {string} The URL to IconService with properly encoded
             * parameters, or just the base URL if called with no parameters.
             */
            var getServiceUrl = function (imageFqn, size, effect) {
                var url = $rootScope.gBaseUrl + '/api/1/icon';

                if (imageFqn) {
                    url = url + '/' + encodeURIComponent(imageFqn);

                    if (size) {
                        url = url + '/' + encodeURIComponent(size);
                    }

                    if (effect) {
                        if (size) {
                            url = url + '/' + encodeURIComponent(effect);
                        }
                        else {
                            url = url + '/small/' + encodeURIComponent(effect);
                        }
                    }
                }
                else if (size || effect) {
                    // throw RAError if size or effect are supplied without
                    // the imageFqn parameter
                    throw new raErrorHandlerSvc
                        .RAError('Error in iconSvc.getServiceUrl()',
                        'The "imageFqn" parameter is required but was ' +
                            'not provided.');

                }

                return url;
            };

            return {
                getServiceUrl : getServiceUrl
            };
        }
    ]
);