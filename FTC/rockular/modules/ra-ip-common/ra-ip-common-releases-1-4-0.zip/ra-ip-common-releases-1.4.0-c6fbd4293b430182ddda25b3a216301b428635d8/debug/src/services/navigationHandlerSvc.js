/*
 * (c) Rockwell Automation 2013
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:navigationHandlerSvc
 * @description
 * Service for Navigation Handler Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("navigationHandlerSvc",
    ['$http', '$rootScope', '$q', 'raErrorHandlerSvc', 'viewSvc',
        'fqnSvc', 'WELLKNOWN_LOCATIONS',
        function ($http, $rootScope, $q, raErrorHandlerSvc, viewSvc, fqnSvc, WELLKNOWN_LOCATIONS) {
            'use strict';
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationHandlerSvc#getNavigationHandler
             * @methodOf RA.IPCommon.Services.service:navigationHandlerSvc
             * @description
             * Makes a request to JSON navigationhandler service on the server.
             * @param {object} navigationHandlerRequest {@link RA.IPCommon.Services.object:NavigationHandlerRequest}
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available.
             */
            var getNavigationHandler = function (navigationHandlerRequest) {
                var defer = $q.defer();

                $http.post($rootScope.gBaseUrl + "api/1/navigationhandler/",
                    navigationHandlerRequest, $rootScope.gCommonHttpConfig).then(
                    function success(result) {
                        defer.resolve(result.data);
                    },
                    function error(r) {
                        //$log.error("Navigation service connection error: " + r);
                        //defer.reject();
                        // Instead of above use as follows
                        // but errorCallback function in then() should
                        // propagate this error (see: viewSvc, and browserCtrl)
                        defer.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "navigationHandler service connection error",
                                r
                            )
                        );

                    }
                );
                return defer.promise;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationHandlerSvc#getNavigationView
             * @methodOf RA.IPCommon.Services.service:navigationHandlerSvc
             * @description
             * Create or Return the default view for the given FullyQualifiedName
             * if the currentView is not set, call a service to retrieve the fqn "available" view.
             * @param {object} currentFqn - Current FullyQualifiedName
             * @param {object=} [currentView] - Current View
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available.
             **/
            var getNavigationView = function (currentFqn, currentView) {
                var defer = $q.defer();
                var viewFqn;
                if (currentView !== undefined && currentView !== '') {
                    viewFqn = viewSvc.getFqnForViewName(currentView);
                }
                else {
                    viewFqn = currentView;
                }
                getNavigationHandler(createNavigationHandlerRequest(
                    currentFqn, viewFqn)).then(function success(data) {
                        defer.resolve(fqnSvc.getLastName(data.navhandlerfqn));
                    },
                    function failure(reason) {
                        // Since the error occurred you can propagate it to the
                        // error listener and $exceptionHandler
                        raErrorHandlerSvc.propagate(reason);
                        // if you want to send the error to the listener that
                        // writes only the message to the $log (without stack)
                        // us as below
                        // raErrorHandlerSvc.propagate(reason, undefined, '$log');
                    });

                return defer.promise;
            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationHandlerSvc#createNavigationHandlerRequest
             * @methodOf RA.IPCommon.Services.service:navigationHandlerSvc
             * @description
             * Create or Return the Navigation Handler Request.
             * @param {object} fqn - FullyQualifiedName
             * @param {object} viewFqn - View FullyQualifiedName
             * @returns {NavigationHandlerRequest} Navigation Handler Request
             * {@link RA.IPCommon.Services.object:NavigationHandlerRequest}
             **/
            var createNavigationHandlerRequest = function (fqn, viewFqn) {
                return new NavigationHandlerRequest(fqn, viewFqn);
            };
            
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:NavigationHandlerRequest
             * @description
             * Navigation Handler Request Object
             * @property {string} fqn The FQN of NavigationHandlerRequest
             * @property {string} currentNavHandlerFqn The FQN of current Navigation handler
             * @property {string} navHandlerProviderFqn The FQN of Navigation Handler Provider
             */
            var NavigationHandlerRequest = (function () {
                function NavigationHandlerRequest(_fqn, _viewFqn) {
                    this.fqn = _fqn;
                    this.currentNavHandlerFqn = _viewFqn;
                    this.navHandlerProviderFqn = WELLKNOWN_LOCATIONS.MOBILE_APPLICATION;
                }
                return NavigationHandlerRequest;
            })();

            return {
                getNavigationHandler: getNavigationHandler,
                getNavigationView: getNavigationView,
                createNavigationHandlerRequest: createNavigationHandlerRequest
            };
        }
    ]);
