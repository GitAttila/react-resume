/* global angular */
/**
 * @ngdoc filter
 * @module RA.IPCommon.Filters
 * @name RA.IPCommon.Filters.filter:nameFromFqn
 * @description
 * This filter Provides LastName from the given FQN with the help of FqnSvc
 * @returns {string} LastName from the provided FQN
 */
angular.module('RA.IPCommon.Filters').filter("nameFromFqn", ['fqnSvc', function (fqnSvc) {
    'use strict';
    return fqnSvc.getLastName;
}]);
