/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:fqnSvc
 * @description
 * Service for FQN Related Manipulations
 */
angular.module('RA.IPCommon.Services')
    .factory('fqnSvc', ['raErrorHandlerSvc',
    function (raErrorHandlerSvc) {
        'use strict';
        var delimiterChar = ".";
        var startPartChar = "[";
        var endPartChar = "]";
        var escapedEndPartChar = "]]";
        var rootFqn = "";
        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#getCombinedNameParts
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Combine anchor parts with relative parts
         * @param {string} anchorFqnParts - Parts of Anchor Fqn
         * @param {number} includedAnchorPartsCount - Count of included Anchor Parts
         * @param {string} relativeFqnParts - Parts of Relative Fqn
         * @returns {string} - Combined Name Parts
         */
        function getCombinedNameParts(anchorFqnParts, includedAnchorPartsCount, relativeFqnParts) {
            return anchorFqnParts.slice(0, includedAnchorPartsCount).concat(relativeFqnParts);
        }

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#unescapeRawPart
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Internal Method to Unescape (Remove Escapes) fom Raw Parts
         * @param {string} rawPart - raw Fqn
         * @returns {string} - Raw Parts with Escape Removed
         */
        function unescapeRawPart(rawPart) {
            var unescapedRawPart;
            if (rawPart.charAt(0) === startPartChar) {
                if (rawPart.charAt(rawPart.length - 1) === endPartChar) {
                    // starts and ends with a bracket
                    unescapedRawPart = rawPart.substr(1, rawPart.length - 2);
                } else {
                    // starts but does not end with bracket
                    unescapedRawPart = rawPart.substr(1);
                }
            } else if (rawPart.charAt(rawPart.length - 1) === endPartChar) {
                // only ends with a bracket
                unescapedRawPart = rawPart.substr(0, rawPart.length - 1);
            }

            if (unescapedRawPart) {
                // replace double brackets with single brackets
                var regex = new RegExp(escapedEndPartChar, "g");
                return unescapedRawPart.replace(regex, endPartChar);
            }
            // TK-427439
            if (rawPart === endPartChar || rawPart === startPartChar) {
                return "";
            }
            //if we made it this far, it was not changed spo return original
            return rawPart;
        }

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#escape
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Escapes the specified name if necessary
         * @param {string} part - name part to escape
         * @returns {string} escaped name part
         */
        function escape(part) {
            // add start bracket
            var escapedPart = startPartChar;

            // double up any end brackets
            var regex = new RegExp(endPartChar, "g");
            escapedPart = escapedPart.concat(part.replace(regex, escapedEndPartChar));

            // add end bracket
            return escapedPart.concat(endPartChar);
        }

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#requiresEscaping
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * (Internal Function) Test if name part needs to be escaped.
         * @param {string} part - name part to escape
         * @returns {string} escaped name part
         */
        function requiresEscaping(part) {
            // must escape if we start with an open bracket or contain a period
            return part.charAt(0) === startPartChar ||  part.indexOf(delimiterChar) >= 0;
        }

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#relativeFqnDepth
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Returns the number of leading dots for a string.
         * @param {string} relativeFqn - Relative FQN
         * @returns {number} relative depth
         */
        function relativeFqnDepth(relativeFqn) {
            if (relativeFqn[0] !== delimiterChar) {
                return 0;
            }

            var depth = 0;
            while (depth < relativeFqn.length &&
                relativeFqn[depth] === delimiterChar) {
                depth++;
            }
            return depth;
        }

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#getLastName
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Get the last part of a fully qualified name.
         * @param {string} fqn - fqn from which to extract the last name part.
         * @returns {string} The last name part.
         */
        var getLastName = function (fqn) {
            //if both empty string, return that
            if (this.areEqual(fqn, rootFqn)) {
                return "";
                ///otherwise, make sure it is valid, then parse it.
            } else {
                if (typeof fqn === 'string') {
                    var parts = this.splitFqn(fqn);
                    return parts[parts.length - 1];
                } else {
                    return undefined;
                }
            }
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#removeLastNamePart
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Removes the last name part of a fully qualified name. E.g. the result for the input string
         * "MyEnterprise.Pumps.Pump101.Temparature.Value" is "MyEnterprise.Pumps.Pump101.Temparature"
         * @param {string} fqn - fqn to be truncated.
         * @returns {string} The passed in fqn without its last name part.
         */
        var removeLastNamePart = function (fqn) {
            //if both empty string, return that
            var parts = this.splitFqn(fqn);
            parts.splice(-1, 1);

            return this.buildFqn(parts);
        };
        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#areEqual
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Case insensitive check to determine if two FQN's are equal
         * @param {string} fqn1 - fqn1 to check
         * @param {string} fqn2 - fqn2 to check
         * @returns {boolean} true if equal
         */
        var areEqual = function (fqn1, fqn2) {
            //handle the common case first, covers even if both undefined, null or empty string
            if (fqn1 === fqn2) {
                return true;
            }

            //if they are both strings but not equal from above, do a case compare
            if ((typeof fqn1 === 'string') && (typeof fqn2 === 'string')) {
                return fqn1.toLowerCase() === fqn2.toLowerCase();
            }

            //all other cases, from fqn's perspective, it is false
            return false;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#splitFqn
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Split a fully qualified name into an array of name parts.
         * @param {string} fqn - fqn to be split.
         * @returns {array|string} An array of name parts of the specified fully qualified name.
         */
        var splitFqn = function (fqn) {
            var parts = [];
            if (fqn && fqn.length > 0) {
                // break into period separated raw parts
                var rawParts = fqn.split(delimiterChar);
                for (var i = 0; i < rawParts.length; i++) {
                    if (rawParts[i].indexOf(startPartChar) === 0) {
                        // raw part is the start of an escaped part sequence
                        var partSequence = [];
                        for (; i < rawParts.length; i++) {
                            // save escaped raw parts in the sequence
                            partSequence.push(unescapeRawPart(rawParts[i]));

                            // until we find a raw part that ends the sequence
                            // (after removing all double brackets ...
                            var tmpString = rawParts[i].replace(new RegExp(escapedEndPartChar, "g"), "");
                            // ... a single bracket at the end exists)
                            if (tmpString.charAt(tmpString.length - 1) === endPartChar) {
                                break;
                            }
                        }

                        // concatenate all unescaped raw parts into period separated part
                        parts.push(partSequence.join(delimiterChar));
                    }
                    else {
                        // this part was not escaped, use as is
                        parts.push(rawParts[i]);
                    }
                }
            }
            return parts;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#buildFqn
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Build a fully qualified name from an array of name parts.
         * @param {array|string} parts - The name parts used to build the fully qualified name.</param>
         * @returns {string} The fully qualified name built.
         */
        var buildFqn = function (parts) {
            var fqn = [];
            for (var i = 0; i < parts.length; i++) {
                if (requiresEscaping(parts[i])) {
                    fqn.push(escape(parts[i]));
                } else {
                    fqn.push(parts[i]);
                }
            }
            return fqn.join(delimiterChar);
        };


        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#buildFqn
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Build a fully qualified name for a Query from an array of name parts.
         * @param {array|string} parts - The name parts used to build the fully qualified name.</param>
         * @returns {string} The fully qualified name built.
         */
        var buildFqnForQuery = function (parts) {
            var fqn = [], matchValue;
            for (var i = 0; i < parts.length; i++) {
                matchValue =
                    parts[i].search(/[.*+?^=!:${}()|\[\]\/\\]|from|to|where|select|with|and|or|\s/i);
                if (matchValue >= 0) { // needs query escaping
                    fqn[i] = startPartChar + parts[i] + endPartChar;
                } else {
                    fqn[i] = parts[i];
                }
            }
            return fqn.join(delimiterChar);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#escapeForJsonRequest
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Escape any special characters for the JSON request
         * @param {array|string} parts - parts of the fqn to escape
         * @returns {array|string} parts of the fqn escaped for JSON request
         */
        var escapeForJsonRequest = function (parts) {
            var retValue = [];
            for (var i = 0; i < parts.length; i++) {
                /*var jsonString = JSON.stringify(parts[i]).replace(/]/g, ']]');*/
                var jsonString = parts[i].replace(/]/g, ']]');
                retValue[i] = jsonString;
            }
            return retValue;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#appendNamePart
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Appends name parts to a given base name.
         * @param {string} baseName - to append name parts to
         * @param {string} part - The name to append to the base name. Dots in the name will be escaped.
         * @returns {string} Full FQN with Appended name part
         */
        var appendNamePart = function (baseName, part) {
            return [baseName, this.buildFqn([part])].join(delimiterChar);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#appendNameParts
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Appends name parts to a given base name.
         * @param {string} baseName - to append name parts to
         * @param {array|string} parts - unescaped fqn parts
         * @returns {string} Full FQN with Appended name part(s)
         */
        var appendNameParts = function (baseName, parts) {
            return [baseName, this.buildFqn(parts)].join(delimiterChar);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#isRelative
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Test if an FQN is relative
         * @param {string} fqn - to test
         * @returns {bool} true if this is a relative FQN
         */
        var isRelative = function (fqn) {
            // must escape if we start with an open bracket or contain a period
            return fqn[0] === delimiterChar;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#absoluteToRelative
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Calculates a relative FQN to resolve to the passed FQN from the anchor FQN,
         * that could be used with the FQN.Resolve method.
         * @param {string} anchorFqn to which fqn the result would be relative
         * @param {string} fqn absolute fqn for which we want the relative calculated
         * @returns {String} Relative Fqn
         */
        var absoluteToRelative = function (anchorFqn, fqn) {
            if (!anchorFqn) {
                if (this.isRelative(fqn)) {
                    return fqn;
                } else {
                    return delimiterChar + fqn;
                }
            }

            var anchorFqnParts = this.splitFqn(anchorFqn);
            var fqnParts = this.splitFqn(fqn);
            var commonCount = 0;
            var ii;
            for (ii = 0; ii < anchorFqnParts.length; ii++) {
                if (!this.areEqual(anchorFqnParts[ii], fqnParts[ii])) {
                    break;
                }
                commonCount++;
            }
            var relativeFqnParts = fqnParts.slice(commonCount, fqnParts.length);
            var relativeFqn = this.buildFqn(relativeFqnParts);
            commonCount = (anchorFqnParts.length - commonCount) + 1;
            for (ii = 0; ii < commonCount; ii++) {
                relativeFqn = delimiterChar + relativeFqn;
            }
            return relativeFqn;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#relativeToAbsolute
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Calculates the FQN from the anchor FQN and provided relative FQN.
         * @param {string} anchorFqn - to resolve the path with
         * @param {string} relativeFqn - path to resolve
         * @returns {string} FQN that results from resolution with anchor
         */
        var relativeToAbsolute = function (anchorFqn, relativeFqn) {
            var trimmedAnchorFqn = anchorFqn.trim();
            var trimmedRelativeFqn = relativeFqn.trim();

            if (relativeFqn.length === 0) {
                return trimmedAnchorFqn;
            }

            var relativeDepth = relativeFqnDepth(trimmedRelativeFqn);
            var finalRelativeFqn = (relativeDepth < 1) ? trimmedRelativeFqn :
                trimmedRelativeFqn.slice(relativeDepth, trimmedRelativeFqn.length);

            var relativeFqnParts = this.splitFqn(finalRelativeFqn);
            var anchorFqnParts = this.splitFqn(trimmedAnchorFqn);

            if (relativeDepth > anchorFqnParts.length + 1) {
                throw  raErrorHandlerSvc.getRAError('Error in fqnSvc.relativeToAbsolute',
                    'Relative FQN is deeper than root object');
            }

            if (relativeDepth > 0) {
                relativeDepth--; // Strip the first dot
            }
            var fullNameParts =
                getCombinedNameParts(anchorFqnParts, anchorFqnParts.length - relativeDepth, relativeFqnParts);

            return this.buildFqn(fullNameParts);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#isEmptyOrUnassigned
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Check if Fqn is empty or not
         * @param {string} fqn - to check
         * @returns {string} true or false based on if Fqn is empty or unassigned
         */
        var isEmptyOrUnassigned = function (fqn) {
            return !fqn;
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#buildFqnForQueryWithEscaping
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Build escaped fully qualified name for a Query from a fully qualified name or an array of name parts.
         * @param {array|string} fqn The fully qualified name or the name parts used to build the escaped fully
         * qualified name.</param>
         * @returns {string} The escaped fully qualified name built.
         */
        var buildFqnForQueryWithEscaping = function (fqn) {
            if (angular.isString(fqn)) {
                fqn = splitFqn(fqn);
            }

            fqn = escapeForJsonRequest(fqn);

            return buildFqnForQuery(fqn);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#cutFqnPart
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * Cut fqn part from - to
         * @param {string} fqn The fully qualified name
         * @param {int} from
         * @param {int} to
         * @returns {string} cuted string
         */
        var cutFqnPart = function (fqn, from, to) {
            return fqn.slice(from, to);
        };

        /**
         * @ngdoc method
         * @module RA.IPCommon.Services
         * @name RA.IPCommon.Services.service:fqnSvc#findParameterInFqn
         * @methodOf RA.IPCommon.Services.service:fqnSvc
         * @description
         * find string in fqn string
         * @param {string} fqn The fully qualified name
         * @returns {int} -1 if parameter doesn't exists or number when parameter starts
         */
        var findParameterInFqn = function (fqn, parameter) {
            return  fqn.search(parameter);
        };

        return  {
            getLastName : getLastName,
            removeLastNamePart : removeLastNamePart,
            areEqual : areEqual,
            splitFqn : splitFqn,
            buildFqn : buildFqn,
            buildFqnForQuery : buildFqnForQuery,
            escapeForJsonRequest: escapeForJsonRequest,
            appendNamePart : appendNamePart,
            appendNameParts : appendNameParts,
            isRelative : isRelative,
            absoluteToRelative : absoluteToRelative,
            relativeToAbsolute : relativeToAbsolute,
            isEmptyOrUnassigned : isEmptyOrUnassigned,
            buildFqnForQueryWithEscaping: buildFqnForQueryWithEscaping,
            findParameterInFqn: findParameterInFqn,
            cutFqnPart: cutFqnPart
        };
    }
]);

