/* 
 * (c) Rockwell Automation 2013
 */

/*jshint maxlen: false*/

//This rule makes code unreadable, so I'm not willing to follow it

//ZK4 use some kind of config object (config service) instead of the scope



/*global angular*/
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:liveDataSvc
 * @description
 * Service for Live Data based Request and Manipulations, it uses
 * {@link RA.IPCommon.Services.object:Subscriber Subscriber} as a base so it has all it's methods available.
 */
angular.module('RA.IPCommon.Services').provider("liveDataSvc", function () {
    "use strict";
    var minimumTimerValue = 1000,
        maxRetryCount = 3;

    /**
     * Service related Options
     */
    var options =
        {
            /**
             * generic update interval
             * @type {number}
             */
            updateInterval: minimumTimerValue,
            /**
             * relative path to service
             * @type {string}
             */
            serviceRelativePath: "api/1/live/",
            /**
             * Whether to log into console
             * @type {boolean}
             */
            logToConsole: false
        };

    /**
     * @ngdoc method
     * @module RA.IPCommon.Services
     * @name RA.IPCommon.Services.service:liveDataSvc#init
     * @methodOf RA.IPCommon.Services.service:liveDataSvc
     * @description
     * Initialize Parameters
     * @param {object} params - additional options
     */
    this.init = function (params) {
        angular.extend(options, params);
    };

    this.$get = ['$http', '$log', '$rootScope', '$q', '$interval', 'raIdGenSvc', 'raErrorHandlerSvc', 'subscriberSvc',
        'raErrorCollectorSvc',
        function ($http, $log, $rootScope, $q, $interval, raIdGenSvc, raErrorHandlerSvc, subscriberSvc,
        raErrorCollectorSvc) {
            var fqns = {}, failureState,
                retryLeft = maxRetryCount,

            /**
             * Add Fqn to list
             * @param {string} fqn - to add
             */
            addFqn = function (fqn) {
                if (fqns[fqn] === undefined) {
                    fqns[fqn] = 1;
                }
                else {
                    fqns[fqn]++;
                }
            },
            /**
             * Remove Fqn to list
             * @param {string} fqn - to remove
             */
            removeFqn = function (fqn) {
                if (fqns[fqn] !== undefined) {
                    fqns[fqn]--;
                    if (fqns[fqn] === 0) {
                        delete fqns[fqn];
                    }
                }
            },
            /**
             * Prepares data for request
             * @returns {object} data prepared for JSON request
             */
            _buildRequestJSON = function () {
                var item;
                var consumersRequestArray = [];
                for (item in fqns) {
                    if (fqns.hasOwnProperty(item)) {
                        consumersRequestArray.push(item);
                    }
                }
                return { fqns: consumersRequestArray };

            };
            var _injector =
            {
                /**
                 * @ngdoc method
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.service:liveDataSvc#getOnce
                 * @methodOf RA.IPCommon.Services.service:liveDataSvc
                 * @description
                 * Subscribe for retrieve data once
                 * @param {array} fqns list of fqns
                 * @param {bool} immediatelly whether get data immediatelly
                 * @param {string} id handle of subscription
                 * @param {boolean} bHash (optional default true) wheter return hash or array
                 * @returns {IPromise<T>} Angular promise to be resolved later
                 */
                getOnce: function (fqns, immediatelly, id, bHash) {
                    var el, defer;
                    if (bHash === undefined) {
                        bHash = true;
                    }
                    if (immediatelly) {
                        defer = $q.defer();
                        $http.post($rootScope.gBaseUrl + options.serviceRelativePath, { fqns: fqns },
                        $rootScope.gCommonHttpConfig).success(
                        function (resultObject) {
                            var ret, result, i;

                            try {
                                if (typeof (resultObject) === "string") {
                                    throw ("Returned string in place of array");
                                }
                                result = resultObject.fqnsResults;
                                if (bHash) {
                                    ret = {};
                                    el = result.length;
                                    for (i = 0; i < el; i += 1) {
                                        ret[fqns[i]] = result[i].value;
                                    }
                                }
                                else {
                                    ret = [];
                                    el = result.length;
                                    for (i = 0; i < el; i += 1) {
                                        ret[i] = result[i].value;
                                    }
                                }
                                defer.resolve(ret);
                            }
                            catch (e) {
                                defer.reject("Connection error: " + e);
                            }
                        }).error(
                            function (r) {
                                defer.reject("Connection error: " + r);
                            }
                        );
                        return defer.promise;
                    }
                    if (!id) {
                        id = raIdGenSvc.getStrId();
                    }

                    var data = {
                        fqns: fqns,
                        isHash: bHash,
                        isOnce: true
                    };

                    return this.subscribe(id, data, {allAtOnce: true}, subscribed, unsubscribed, update);
                },
                /**
                 * @ngdoc method
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.service:liveDataSvc#getRepeatedly
                 * @methodOf RA.IPCommon.Services.service:liveDataSvc
                 * @description
                 * Subscribe to get data repeatedly according to 
                 * interval used in setTimer
                 * @param {string} id handle of subscription
                 * @param {string} fqns optional base string for fqn tails
                 * @param {bool} bHash return value is hash by default(true), array if false
                 * @returns {IPromise<T>} Promise that can be extended
                 * by service-generated id (RAServiceAutoGeneratedId) if
                 * id is not defined (or is null)
                 */
                getRepeatedly: function (id, fqns, bHash) {
                    bHash = bHash === undefined || bHash === null ? true : bHash;
                    id = id || raIdGenSvc.getStrId();

                    var data = {
                        fqns: fqns,
                        isHash: bHash
                    };

                    return this.subscribe(id, data, {allAtOnce: true}, subscribed, unsubscribed, update);
                }
            };

            /**
             * Called when consumer subscribed.
             * @param consumer
             */
            function subscribed(consumer) {
                var fqns = consumer.data.fqns;

                // init request
                consumer.fqnsArray = [];
                for (var i = 0; i < fqns.length; i += 1) {
                    consumer.fqnsArray.push({ fqn: fqns[i], index: i });
                    addFqn(fqns[i]);
                }
            }

            /**
             * Called when consumer un-subscribed.
             * @param consumer
             */
            function unsubscribed(consumer) {
                for (var i = 0; i < consumer.fqnsArray.length; i += 1) {
                    removeFqn(consumer.fqnsArray[i].fqn);
                }
            }

            /**
             * Called when data retrieved from the server.
             * @param consumer
             */
            function update(consumers) {
                var httpConfig,
                    requestArray = _buildRequestJSON();

                if (requestArray.fqns.length === 0) {
                    return;
                }

                if (options.logToConsole) {
                    $log.info(requestArray);
                }

                httpConfig = $rootScope.gCommonHttpConfig ? angular.copy($rootScope.gCommonHttpConfig) : {};
                httpConfig.raPassError = true;

                $http.post($rootScope.gBaseUrl + options.serviceRelativePath, requestArray, httpConfig).then(
                    // Success
                    function (resultObject) {
                        if (failureState) {
                            _injector.setTimer(_injector.getUpdateInterval());
                            failureState = false;
                        }

                        var el, resultsHash, i, rfqn, index, consumer, dataDefined, itemId, data, result;

                        retryLeft = maxRetryCount;

                        try {
                            resultsHash = {};
                            if (typeof (resultObject.data) === "string") {
                                throw ("Returned string in place of array");
                            }
                            result = resultObject.data.fqnsResults;
                            el = result.length;
                            for (i = 0; i < el; i += 1) {
                                resultsHash[result[i].fqn] = result[i].value;
                            }
                            index = 0;
                            dataDefined = true;
                            for (itemId in consumers) {
                                if (consumers.hasOwnProperty(itemId)) {
                                    consumer = consumers[itemId];
                                    if (consumer.deferred !== undefined) {
                                        dataDefined = true;
                                        if (!consumer.data.isHash) {
                                            data = [];
                                            el = consumer.fqnsArray.length;
                                            for (i = 0; i < el; i += 1) {
                                                rfqn = consumer.fqnsArray[i];
                                                data[rfqn.index] = {};
                                                if (resultsHash[rfqn.fqn] === undefined) {
                                                    dataDefined = false;
                                                    break;
                                                }
                                                data[rfqn.index] = resultsHash[rfqn.fqn];
                                            }
                                        }
                                        else {
                                            data = {};
                                            el = consumer.fqnsArray.length;
                                            for (i = 0; i < el; i += 1) {
                                                rfqn = consumer.fqnsArray[i];
                                                if (resultsHash[rfqn.fqn] === undefined) {
                                                    dataDefined = false;
                                                    break;
                                                }
                                                data[rfqn.fqn] = resultsHash[rfqn.fqn];
                                            }

                                        }
                                        if (dataDefined) {
                                            if (consumer.data.isOnce) {
                                                _injector.unsubscribe(itemId, data);
                                            }
                                            else {
                                                consumer.deferred.notify(data);
                                            }
                                        }
                                    }
                                    index++;
                                }
                            }
                        }
                        catch (e) {
                            _injector.rejectAll("Bad data: " + resultObject.data.toString());
                        }
                    },
                    // Failure
                    function (reason) {
                        if (--retryLeft === 0) {
                            var error = raErrorHandlerSvc.getRAHTTPError("Communication error", "Connection error: " + reason);
                            failureState = true;
                            _injector.clearTimer();
                            raErrorCollectorSvc.addHttpError(error).then(function (retry) {
                                if (retry) {
                                    update(consumers);
                                    retryLeft = 1;
                                }
                                else {
                                    _injector.rejectAll("Connection error: " + reason);
                                }
                            });
                        }
                    }
                );
            }

            // Make Subscriber base of this.
            subscriberSvc.extend(_injector);

            if (options.updateInterval !== 0) {
                _injector.setTimer(options.updateInterval);
            }

            return _injector;
        }
    ];
});


