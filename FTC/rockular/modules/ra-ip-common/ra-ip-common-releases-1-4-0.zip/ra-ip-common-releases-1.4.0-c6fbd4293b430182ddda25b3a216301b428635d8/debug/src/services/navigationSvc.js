/*
 * (c) Rockwell Automation 2013
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:navigationSvc
 * @description
 * Service for Navigation Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("navigationSvc",
    [ '$http', '$rootScope', '$q', 'raErrorHandlerSvc',
        function ($http, $rootScope, $q, raErrorHandlerSvc) {
            'use strict';

            var lastResult;
            var defaultHideSkipRules = { };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationSvc#getLastResult
             * @methodOf RA.IPCommon.Services.service:navigationSvc
             * @description
             * Returns the result of the most recent Navigation request.
             * @returns {object} - the most recent result of a getNavigationData request.
             * will be available.
             */
            var getLastResult = function () {
                return lastResult;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationSvc#getNavigationData
             * @methodOf RA.IPCommon.Services.service:navigationSvc
             * @description
             * Makes a request to JSON Navigation service on the server.
             * @param {object} navigationRequest {@link RA.IPCommon.Services.object:NavigationRequest}
             * @returns {IPromise<T>} - Promise to resolve when answer
             * will be available.
             */
            var getNavigationData = function (navigationRequest) {
                var defer = $q.defer();

                // TODO: uncomment it and fix UTs
//                if (fqn === undefined || fqn === null) {
//                    defer.reject(raErrorHandlerSvc.getRAError(
//                        'Navigation service error.',
//                        'Incorrect parameters for navigation service.FQN is empty'));
//                    return defer.promise;
//                }

                $http.post($rootScope.gBaseUrl + "api/1/navigation/",
                        navigationRequest, $rootScope.gCommonHttpConfig).then(
                    function success(result) {
                        lastResult = result;
                        defer.resolve(result.data);
                    },
                    function error(r) {
                        // Instead of above use as follows
                        // but errorCallback function in then() should
                        // propagate this error (see: viewSvc, and browserCtrl)
                        defer.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Navigation service connection error",
                                r
                            )
                        );
                    }
                );

                return defer.promise;
            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationSvc#createNavigationRequest
             * @methodOf RA.IPCommon.Services.service:navigationSvc
             * @description
             * Create and return Navigation Request Object
             * Note : If navHandlerFqn is specified then the Hide & Skip Rules
             * will be ignored.
             * @param {object} fqn - FullyQualifiedName
             * @param {object} propNames - Property Names
             * @param {object} includeParents - true if parents are included 
             * @param {object=} [navHandlerFqn] - FullyQualifiedName of Navigation Handler
             * @param {object=} [hideRules] - Hide Rules
             * @param {object=} [skipRules] - Skip Rules
             * @returns {object} - {@link RA.IPCommon.Services.object:NavigationRequest}
             * will be available.
             */
            var createNavigationRequest = function (
                    fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules
                ) {
                return new NavigationRequest(fqn, propNames, includeParents, navHandlerFqn, hideRules, skipRules);
            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:navigationSvc#setHideSkipRules
             * @methodOf RA.IPCommon.Services.service:navigationSvc
             * @description
             * Sets the default hide and skip rules - called at app startup
             * @param {object=} [hideRules] - Hide Rules
             * @param {object=} [skipRules] - Skip Rules
             */
            var setDefaultHideSkipRules = function (hideRules, skipRules) {
                var newHideRules, newSkipRules;
                if (angular.isArray(hideRules) || hideRules === undefined)
                {
                    newHideRules = hideRules;
                }
                else
                {
                    raErrorHandlerSvc.propagate(
                        raErrorHandlerSvc.getRAError("NavigationSvc: HideRules Should be an array")
                    );
                }
                if (angular.isArray(skipRules) || skipRules === undefined)
                {
                    newSkipRules = skipRules;
                }
                else
                {
                    raErrorHandlerSvc.propagate(
                        raErrorHandlerSvc.getRAError("NavigationSvc: SkipRules Should be an array")
                    );
                }
                defaultHideSkipRules = { hideRules: newHideRules,
                                         skipRules: newSkipRules };
            };
            
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:NavigationRequest
             * @description
             * Navigation Request Object
             * @property {string} fqn The FQN of NavigationRequest
             * @property {array} propNames The Property Names
             * @property {boolean} includeParents Whether to include parents in results
             * @property {string=} [navHandlerFqn] The FQN of Navigation Handler Item
             * @property {array=} [hideRules] The Hide Rules for Navigation
             * @property {array=} [skipRules] he Skip Rules for Navigation
             */
            var NavigationRequest = (function () {
                function NavigationRequest(_fqn, _propNames, _includeParents, _navHandlerFqn, _hideRules, _skipRules)
                {
                    this.fqn = _fqn;
                    this.propNames = _propNames;
                    this.includeParents = _includeParents;

                    if (_navHandlerFqn) {
                        this.navHandlerFqn = _navHandlerFqn;
                    } else {
                        if (_hideRules || _skipRules)
                        {
                            if (_hideRules) {
                                this.hideRules = _hideRules;
                            }
                            if (_skipRules) {
                                this.skipRules = _skipRules;
                            }
                        }
                        else
                        {
                            this.hideRules = defaultHideSkipRules.hideRules;
                            this.skipRules = defaultHideSkipRules.skipRules;
                        }
                    }
                }
                return NavigationRequest;
            })();

            return {
                getLastResult: getLastResult,
                getNavigationData: getNavigationData,
                createNavigationRequest: createNavigationRequest,
                setDefaultHideSkipRules: setDefaultHideSkipRules
            };
        }
    ]
);
