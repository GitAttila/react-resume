/*
 * (c) Rockwell Automation 2013
 */

/* global angular */
/**
 * @ngdoc service
 * @module RA.IPCommon.Services
 * @name RA.IPCommon.Services.service:instanceSvc
 * @description
 * Service for Instance based Request and Manipulations
 */
angular.module('RA.IPCommon.Services').factory("instanceSvc",
    ['$http', '$rootScope', '$q', 'raErrorHandlerSvc',
        function ($http, $rootScope, $q, raErrorHandlerSvc) {
            'use strict';
            var svcPath = 'api/1/instance/';

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:instanceSvc#getInstance
             * @methodOf RA.IPCommon.Services.service:instanceSvc
             * @description
             * Makes a request to JSON Instance service on the server.
             * @param {string} fqn - FQN of the item to get data for.
             * @param {boolean=} [isProperty] Tells if the fqn given refers to a property
             *                               (or if an item, should apply to its default property)
             * @param {boolean=} [includeAcl] Tells the query service to return item ACL
             *                               information for the item
             * @param {number=} [depth] Tells the query service to prefetch N-Levels
             *                               of items for the item returned
             * @param {number=} [includeShortcuts] Tells the query service to prefetch N-Levels
             *                               of items for the item returned
             * @param {boolean=} [camelCasePropertyNames] Tells the service to return property names
             *                                           either in camelCase or using original
             *                                           casing
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             *
             * Example:
             *   instanceSvc.getInstance("System.Applications.Portal").then(function (item) {
                    var portalAppName = item.props.AppName;}
             */

            var getInstance = function (fqn, isProperty, includeAcl, depth, includeShortcuts, camelCasePropertyNames) {
                var instanceRequest, deferred;
                if (angular.isString(fqn)) {
                    instanceRequest = createInstanceRequest(camelCasePropertyNames);
                    if (isProperty === true) {
                        instanceRequest.addPropertyFqn(fqn, includeAcl, depth, includeShortcuts);
                    } else {
                        instanceRequest.addItemFqn(fqn, includeAcl, depth, includeShortcuts);
                    }
                } else {
                    instanceRequest = fqn;
                }
                deferred = $q.defer();
                $http.post($rootScope.gBaseUrl + svcPath, instanceRequest, $rootScope.gCommonHttpConfig).then(
                    function success(result) {
                        // Since only a single item is expected, we extend the result.data object
                        // to allow access to the data without array notation.
                        if (result.data && result.data.fqnsResults && result.data.fqnsResults[0]) {
                            angular.extend(result.data, result.data.fqnsResults[0]);
                        }
                        deferred.resolve(result);
                    },
                    function failure(reason) {
                        deferred.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Instance service error",
                                reason
                            )
                        );
                    });
                return deferred.promise;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:instanceSvc#getInstances
             * @methodOf RA.IPCommon.Services.service:instanceSvc
             * @description
             * Makes a multi-item request to the JSON Instance service on the server.
             * Request types (itemFqn, propertyFqn, query) can be freely intermixed in the request.
             *
             * @param {object} instanceRequest {@link RA.IPCommon.Services.object:InstanceRequest}
             * @param {boolean=} [raPassError] Flag indicating whether to turn off
             * common error's interception mechanism
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             *
             * Example:
             *    var includeAcl = true, depth = 2, includeShortcuts = true;
             *
             *    var instanceRequest = createInstanceRequest();
             *    instanceRequest.addItemFqn("MyEnterprise", includeAcl, depth, includeShortcuts);
             *    instanceRequest.addPropertyFqn("System.Applications");
             *    instanceRequest.addQuery("FROM MyEnterprise WHERE name = 'Extruder001'" );
             *
             *    instanceSvc.getInstances(instanceRequest).then(processResults);
             */
            var getInstances = function (instanceRequest, raPassError) {
                var deferred = $q.defer(),
                    httpConfig = $rootScope.gCommonHttpConfig ? angular.copy($rootScope.gCommonHttpConfig) : {};

                if (typeof raPassError === "boolean") {
                    httpConfig.raPassError = raPassError;
                }

                $http.post($rootScope.gBaseUrl + svcPath, instanceRequest, httpConfig).then(
                    function success(result) {
                        deferred.resolve(result);
                    },
                    function failure(reason) {
                        deferred.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Instance service error",
                                reason
                            )
                        );
                    });

                return deferred.promise;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:instanceSvc#execQuery
             * @methodOf RA.IPCommon.Services.service:instanceSvc
             * @description
             * Makes a single query request to the JSON Instance service on the server.
             * @param {string} queryExpression - a string containing a query expression.
             * @param {boolean=} [includeAcl] Tells the instance query to return item ACL
             *                               information for the item
             * @param {number=} [depth] Tells the query service to prefetch N-Levels
             *                               of items for the item returned
             * @param {number=} [includeShortcuts] Tells the query service to prefetch N-Levels
             *                               of items for the item returned
             * @param {boolean=} [camelCasePropertyNames] Tells the service to return property names
             *                                           either in camelCase or using original
             *                                           casing
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             *
             * Example:
             *   instanceSvc.execQuery("FROM MyEnterprise WHERE name = 'Extruder001'").then(processResults);
             */
            var execQuery = function (queryExpression, includeAcl, depth, includeShortcuts, camelCasePropertyNames) {
                var instanceRequest, deferred;
                if (angular.isString(queryExpression)) {
                    instanceRequest = createInstanceRequest(camelCasePropertyNames);
                    instanceRequest.addQuery(queryExpression, includeAcl, depth, includeShortcuts);
                }
                else {
                    instanceRequest = queryExpression;
                }
                deferred = $q.defer();
                $http.post($rootScope.gBaseUrl + svcPath, instanceRequest, $rootScope.gCommonHttpConfig).then(
                    function success(result) {
                        // Since only a single set of items are expected, we extend the result
                        // to allow access to the set without two-dimensional array notation.
                        if (result.data && result.data.queryResults && result.data.queryResults[0]) {
                            angular.extend(result.data, result.data.queryResults[0]);
                        }
                        deferred.resolve(result);
                    },
                    function failure(reason) {
                        deferred.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Instance service error",
                                reason
                            )
                        );
                    });
                return deferred.promise;
            };

            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:instanceSvc#execQuerySet
             * @methodOf RA.IPCommon.Services.service:instanceSvc
             * @description
             * Makes a multi-query request to the JSON Instance service on the server.
             * @param {object} instanceRequest {@link RA.IPCommon.Services.object:InstanceRequest}
             * @returns {IPromise<T>} Promise to resolve when answer will be available.
             *
             * Example:
             *    var includeAcl = true, depth = 2, includeShortcuts = true;
             *
             *    var q = createInstanceRequest();
             *    q.addQuery("FROM MyEnterprise WHERE name = 'Extruder001'", includeAcl, depth, includeShortcuts);
             *    q.addQuery("FROM MyEnterprise WHERE TypeName = "Portal.Hyperlink");
             *
             *    instanceSvc.execQuerySet(q).then(processResults);
             */
            var execQuerySet = function (instanceRequest) {
                var deferred = $q.defer();
                $http.post($rootScope.gBaseUrl + svcPath, instanceRequest, $rootScope.gCommonHttpConfig).then(
                    function success(result) {
                        deferred.resolve(result);
                    },
                    function failure(reason) {
                        deferred.reject(
                            raErrorHandlerSvc.getRAHTTPError(
                                "Instance service error",
                                reason
                            )
                        );
                    });

                return deferred.promise;
            };
            
            /**
             * @ngdoc method
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.service:instanceSvc#createInstanceRequest
             * @methodOf RA.IPCommon.Services.service:instanceSvc
             * @description
             * Create the Instance Request Object
             * @param {bool=} [camelCasePropertyNames] true if property names are camelCase
             * @returns {object} {@link RA.IPCommon.Services.object:InstanceRequest}
             */
            var createInstanceRequest = function (camelCasePropertyNames) {
                return new InstanceRequest(camelCasePropertyNames);
            };
            
            /**
             * @ngdoc object
             * @module RA.IPCommon.Services
             * @name RA.IPCommon.Services.object:InstanceRequest
             * @description
             * Instance Request Object
             * @property {array=} [fqns] list of FQNs
             * @property {array=} [queries] list of Queries
             * @property {boolean=} [camelCasePropertyNames] true if property names are camelCase
             */
            var InstanceRequest = (function () {
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#constructor
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {boolean=} [camelCasePropertyNames] true if property names are camelCase
                 * @description
                 * Create Instance Request Object
                 */
                function InstanceRequest(camelCasePropertyNames) {
                    this.queries = undefined;
                    this.fqns = undefined;

                    if (camelCasePropertyNames === true || camelCasePropertyNames === false) {
                        this.camelCasePropertyNames = camelCasePropertyNames;
                    }
                    else {
                        this.camelCasePropertyNames = true;
                    }
                }
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#addResponseFormat
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {object} request The Request Object
                 * @param {boolean=} [includeAccessControl] Whether to include ACL in response object or not
                 * @param {object=} [retrievalDepth] Depth of response object
                 * @param {boolean=} [includeShortcuts] Whether to include shortcuts in response object or not
                 * @description
                 * Add Response Format to Instance Request Object
                 */
                function addResponseFormat(request, includeAccessControl, retrievalDepth, includeShortcuts) {
                    request.responseFormat = {};
                    if (includeAccessControl) {
                        request.responseFormat.includeAcl = includeAccessControl;
                    }
                    if (retrievalDepth) {
                        request.responseFormat.depth = retrievalDepth;
                    }
                    if (includeShortcuts) {
                        request.responseFormat.includeShortcuts = includeShortcuts;
                    }
                }
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#addItemFqn
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {string} fqn FQN to add to the request
                 * @param {boolean=} [includeAccessControl] Whether to include ACL in response object or not
                 * @param {object=} [retrievalDepth] Depth of response object
                 * @param {boolean=} [includeShortcuts] Whether to include shortcuts in response object or not
                 * @description
                 * Add Item FQN to Instance Request Object
                 */
                InstanceRequest.prototype.addItemFqn =
                    function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
                        var request = {};
                        request.fqn = fqn;
                        addResponseFormat.call(this, request, includeAccessControl, retrievalDepth, includeShortcuts);
                        if (!this.fqns) {
                            this.fqns = [];
                        }
                        this.fqns.push(request);
                        return this;
                    };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#addItemFqnExcludeVolatile
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {string} fqn FQN to add to the request
                 * @param {boolean=} [includeAccessControl] Whether to include ACL in response object or not
                 * @param {object=} [retrievalDepth] Depth of response object
                 * @param {boolean=} [includeShortcuts] Whether to include shortcuts in response object or not
                 * @description
                 * Add Item FQN to Instance Request Object - Exclude Volatile Properties
                 */
                InstanceRequest.prototype.addItemFqnExcludeVolatile =
                    function (fqn, includeAccessControl, retrievalDepth, includeShortcuts) {
                        var request = {};
                        request.fqn = fqn;
                        request.excludeVolatileProperties = true;
                        addResponseFormat.call(this, request, includeAccessControl, retrievalDepth, includeShortcuts);
                        if (!this.fqns) {
                            this.fqns = [];
                        }
                        this.fqns.push(request);
                        return this;
                    };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#addPropertyFqn
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {string} fqn FQN to add to the request
                 * @param {boolean=} [includeAccessControl] Whether to include ACL in response object or not
                 * @param {object=} [retrievalDepth] Depth of response object
                 * @param {boolean=} [includeShortcuts] Whether to include shortcuts in response object or not
                 * @param {number=} [pageSize] Size of returned page (default 0 - do not use paging)
                 * @param {number=} [page] Index of returned page (default 0)
                 * @description
                 * Add Property FQN to Instance Request Object
                 */
                InstanceRequest.prototype.addPropertyFqn =
                    function (fqn, includeAccessControl, retrievalDepth, includeShortcuts, pageSize, page) {
                        var request = {};
                        request.propertyFqn = fqn;
                        addResponseFormat.call(this, request, includeAccessControl, retrievalDepth, includeShortcuts);
                        if (pageSize) {
                            request.pageSize = pageSize;
                        }
                        if (page) {
                            request.page = page;
                        }
                        if (!this.fqns) {
                            this.fqns = [];
                        }
                        this.fqns.push(request);
                        return this;
                    };
                /**
                 * @ngdoc object
                 * @module RA.IPCommon.Services
                 * @name RA.IPCommon.Services.object:InstanceRequest#addQuery
                 * @methodOf RA.IPCommon.Services.object:InstanceRequest
                 * @param {string} queryExpression Query Expression to add to the request
                 * @param {boolean=} [includeAccessControl] Whether to include ACL in response object or not
                 * @param {object=} [retrievalDepth] Depth of response object
                 * @param {boolean=} [includeShortcuts] Whether to include shortcuts in response object or not
                 * @description
                 * Add Query Expression to Instance Request Object
                 */
                InstanceRequest.prototype.addQuery =
                    function (queryExpression, includeAccessControl, retrievalDepth, includeShortcuts) {
                        var request = {};
                        request.query = queryExpression;
                        addResponseFormat.call(this, request, includeAccessControl, retrievalDepth, includeShortcuts);
                        if (!this.queries) {
                            this.queries = [];
                        }
                        this.queries.push(request);
                        return this;
                    };
                return InstanceRequest;
            })();

            return {
                getInstance: getInstance,
                getInstances: getInstances,
                execQuery: execQuery,
                execQuerySet: execQuerySet,
                createInstanceRequest: createInstanceRequest
            };
        }
    ]
);
