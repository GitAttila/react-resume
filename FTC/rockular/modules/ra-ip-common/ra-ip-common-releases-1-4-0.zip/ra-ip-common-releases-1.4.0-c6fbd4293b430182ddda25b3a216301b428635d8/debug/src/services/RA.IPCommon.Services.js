/*global angular*/
angular.module('RA.IPCommon.Services', ['mobile-toolkit-ra'])
.constant(
    "WELLKNOWN_LOCATIONS",
    {
        "MOBILE_APPLICATION" : "System.Applications.Mobile",
        "MOBILE_PUBLIC_DISPLAY_RULES" : "System.Applications.Mobile.DisplayRules",
        "MOBILE_VIEWS" : "System.Applications.Mobile.Views"
    }
)
.constant(
    "WELLKNOWN_ITEM_TYPES",
    {
        "MOBILE_DISPLAY" : "TypeSystem.Packages.[Mobile.UI].ItemTypes.[Mobile.UI.Display]",
        "MOBILE_VIEW" : "TypeSystem.Packages.[Mobile.UI].ItemTypes.[Mobile.UI.View]",
        "MOBILE_DISPLAY_RULE" : "TypeSystem.Packages.[Mobile.UI].ItemTypes.[Mobile.UI.DisplayRule]",
        "MOBILE_DISPLAY_TEMPLATE" : "TypeSystem.Packages.[Mobile.UI].ItemTypes.[Mobile.UI.DisplayTemplate]",
        "MOBILE_FAVORITES" : "TypeSystem.Packages.[Mobile.UI].ItemTypes.[Mobile.UI.Favorite]",
        "CORE_OBJECT" : "TypeSystem.Packages.Core.ItemTypes.Object",
        "CORE_TAG" : "TypeSystem.Packages.Core.ItemTypes.Tag",
        "CORE_PARAMETER_TYPE" : "TypeSystem.Packages.Core.ItemTypes.ParameterType",
        "CORE_STRING_DATA_TYPE" : "TypeSystem.Packages.Core.ItemTypes.StringDataType",
        "CORE_STRING" : "TypeSystem.Packages.Core.ItemTypes.String",
        "CORE_FOLDER" : "TypeSystem.Packages.Core.ItemTypes.Folder",
        "CORE_TREND_TEMPLATE" : "TypeSystem.Packages.Core.ItemTypes.TrendTemplate",
        "CORE_XY_PLOTTER_TEMPLATE" : "TypeSystem.Packages.Core.ItemTypes.XYPlotterTemplate"
    }
)
.constant(
    "VIEWS_PATH",
    ['System', 'Applications', 'Mobile', 'Views']
);