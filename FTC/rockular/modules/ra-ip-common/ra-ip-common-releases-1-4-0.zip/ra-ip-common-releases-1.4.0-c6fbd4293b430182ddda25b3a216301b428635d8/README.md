# Info Platform Common library (ra-ip-common)

This library contains reusable services proxy and other common components that can be used in any
Rockwell Automation web-based application which connects to InfoPlatfom services.


## Building ra-ip-common (for developers contributing to ra-ip-common)

### Prerequisites
1. Install Node.js.
   Note:  The 32-bit version is needed if you intend to interoperate with any
   other 32-bit applications.
2. Install Bower (run `npm install -g bower`).
3. Install Gulp (run `npm install -g gulp-cli`).
4. Install Grunt (run `npm install -g grunt-cli`).
5. Install kamra (run `npm install -g karma-cli`).

### Setup

1. Clone or Download the source from this repo.
   For clonning HTTPS:// protocole is suggested one to use.
2. Run `npm install`.  Note:  This will also install Bower modules.
3. Run `gulp build:prod`.

The build output will be in the *dist/prod* folder.  This contains minified and
non-minified versions.

## Testing ra-ip-common

Run ```gulp runTests``` .


## Client Setup (for projects consuming ra-ip-common)

This library has dependencies on 3rd-party and `mobile-toolkit-ra` libraries. The easiest way
to download `ra-ip-common` and its dependencies is to do the following:

1. Install Node.js.
   Note:  The 32-bit version is needed if you intend to interoperate with any
   other 32-bit applications.
2. Install Bower (run `npm install -g bower`).
3. Use Bower to install ra-ip-common and its dependencies:
```
bower install --save https://mft.ra-int.com/gitlab/InfoPlatform/ra-ip-common-releases.git
```

If you prefer to manage these dependencies manually instead, the dependencies
are listed in the `dependencies` section of the `client_bower.json` file.
