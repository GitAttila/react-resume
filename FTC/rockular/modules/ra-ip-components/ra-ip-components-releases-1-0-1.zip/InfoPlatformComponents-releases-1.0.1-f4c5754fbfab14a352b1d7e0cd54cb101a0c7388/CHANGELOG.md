<meta name="ngdocTitle" content="Changelog" />

<!-----------------------------------------------------------------------------
Changelog documentation should be updated for all changes to toolkit, especially breaking changes.
Since we do not have a process to generate this changelog file, and at the time the changelog is updated on a branch,
we won't know the version number, we'll keep a "v.next" section at the top that we can all append to and merge into.
Then, before merge to master from develop, this can be updated.  Let's stick with the following format (comes from
AngularJS changelog.md file:

# [version number]

## Deprecated

## Bug Fixes

## Features

## Breaking Changes

Then on the final release before build, we can delete sections that do not apply for that build.

IMPORTANT: KEEP ONE LINE EMPTY AFTER THIS COMMENT TO GENERATE IT PROPERLY !!!
-->

# v1.0.1

## Features

- updated MFT dependency to version 8.0.0

# v1.0.0

## Features

New generic search component
New generic toolbox component


