NG_DOCS={
  "sections": {
    "api": "API Documentation",
    "nonapi": "Other docs"
  },
  "pages": [
    {
      "section": "api",
      "id": "index",
      "shortName": "InfoPlatform Components JS API Documentation",
      "type": "overview",
      "moduleName": "API: InfoPlatform Components JS API Documentation",
      "shortDescription": "This page contains descriptions of JavaScript components of the InfoPlatform Components JS API.",
      "keywords": "api click components description descriptions docs documentation infoplatform javascript js left lib-related overview title view"
    },
    {
      "section": "api",
      "id": "RA.IPComponents.component:raIpFilterSearch",
      "shortName": "raIpFilterSearch",
      "type": "directive",
      "moduleName": "RA.IPComponents",
      "shortDescription": "The component filters data, it has multiple modes, and filter methods have to be provided by user. Filter has three modes. Basic without combining filters, combining filters using input element and custom combining.",
      "keywords": "$q $scope action activated active advanced allen angular api apply argument array attribute background ball basic belongs blue boolean bradley button buttons callback called cancel cancelbutton category chars check checkbox checkmark choose choosen chosen class clicking clicks color combinefilters combining component configuration confirm control controller css custom data debounce default defer deferred delay depend desc details directive do-confirm doconfirm element ellipse enter equipment erased example example1 false field filter filters foreach format foundinitem fulltext function general graphic handles header higher html icon implementation indexof input ipcomponents item js json key keyword keywords label lastquery length margin menu method methods min min-chars minchars minimal mobile-toolkit-ra mode modes module ms multiple newresults ng-change ng-click ng-controller ng-model ng-repeat ng-show number numeric objcat objects objid objname okbutton option options orange overwritten placeholder promise properties property props provided push queries query querydata ra ra-icon-home ra-icon-information raipfiltersearchctrl reinit reinitialize reject rejectitem representation representing reset resolve result return returns script search search-results send sending set set-api setapi sets splice sth string style tank text three time tolowercase true type undefined uniq unique user valve var visible wheel whisper whisper-last-query whisperlastquery whispers write writing"
    },
    {
      "section": "api",
      "id": "RA.IPComponents.directive:raIpToolbox",
      "shortName": "raIpToolbox",
      "type": "directive",
      "moduleName": "RA.IPComponents",
      "shortDescription": "The directive lists given items and divides them into defined categories. Items can be draggable and selectable, they can be displayed either in grid or in lines. Categories are displayed in collapsible tree. There is a button to collapse all tree nodes. Toolbox can be minimized to side of parent container.",
      "keywords": "$apply $http $scope $trigger active angular api argument array basic black boolean break button call callback callbacks called case categories category categoryid checkbox class classname collapse collapsible color commonly commonlyused config configuration console container context contextdisplay contextmenu controller copy css currently custom customsvc dataset default defined delay desc description details directive display displayed displayopts divides doconfirm dragdrop draggable dropdown element elementid enable enabled example1 expanded false fill filter filters function functions grid html inline ipcomponents ishtmlname item items itemsvariant js json label leave lines listed lists log max menu min min-panel minchars minimized minpanel mobile-toolkit-ra mode modes module myitem named newitems ng-click ng-controller ng-model nodes normal object olditems onselectcategory onselectelement ontoggleminpanel ontoggletoolbox open opt option order orderby pane panel parameter parent parse passed placeholder position properties property ra ra-flex-column raipfiltersearchcomponent raiptoolboxctrl raiptoolboxsvc refresh refreshes refreshtree relative response return returns row screen script select selectable selectcategory selected selectelement selection selects service set-api setapi shapes side single squares sth string style subcategory success switch switchdisplay switches takes tb-categories tb-items text toggle toggled toggleminpanel toggles toolbox toolbox-wrapper tree true type undefined updates var version whispers wide width"
    },
    {
      "section": "nonapi",
      "id": "index",
      "shortName": "Other docs",
      "type": "overview",
      "moduleName": "NONAPI: Other docs",
      "shortDescription": "This page contains a bunch of additional information related to the InfoPlatform Components JS library, such as the changelog,",
      "keywords": "additional api bunch changelog click components description docs documentation guidelines infoplatform js left library nonapi overview recommendations specification tips title view"
    },
    {
      "section": "nonapi",
      "id": "CHANGELOG.md",
      "shortName": "Changelog",
      "type": "overview",
      "moduleName": "RA.IPComponents",
      "shortDescription": "<!-----------------------------------------------------------------------------",
      "keywords": "angularjs append apply branch breaking bug build changelog changes comment component delete dependency deprecated develop documentation empty features file final fixes format generate generic ipcomponents ll master md merge mft nonapi number overview process properly ra release search sections stick time toolbox toolkit top updated v1 version won"
    },
    {
      "section": "nonapi",
      "id": "docgen.md",
      "shortName": "Generating documentation",
      "type": "overview",
      "moduleName": "RA.IPComponents",
      "shortDescription": "Generating documentation",
      "keywords": "annotate annotated apostrophes attribute bare builddocs command configured content conversion correctly currently define defining directory docs document documentation documents don double enclose file files folder forget generate generated generating gulp hosted included ipcomponents location malformed markdown markdown-formatted md ngdoc ngdoctitle nonapi note order output overview plugin provide quotes ra recognize recognized recognizes renamed running server skipped tag tags task text title values view web wrapper"
    }
  ],
  "apis": {
    "api": true,
    "nonapi": false
  },
  "html5Mode": false,
  "editExample": true,
  "startPage": "/api",
  "scripts": [
    "jquery.min.js",
    "angular.min.js",
    "angular-animate.min.js",
    "mobile-toolkit-ra.min.js",
    "ra-ip-common.min.js",
    "ra-ip-components.js"
  ]
};