# Info Platform Components library (ra-ip-components)

This library contains reusable components which are either too complex to be in MFT mobile toolkit or need a connection
on (InfoPlatform) back-end.


## Building ra-ip-components (for developers contributing to ra-ip-components)

### Prerequisites
1. Install Node.js.
   Note:  The 32-bit version is needed if you intend to interoperate with any
   other 32-bit applications.
2. Install Bower (run `npm install -g bower`).
3. Install Gulp (run `npm install -g gulp-cli`).
4. Install Grunt (run `npm install -g grunt-cli`).
5. Install karma (run `npm install -g karma-cli`).

### Setup

1. Clone or Download the source from this repo.
   For clonning HTTPS:// protocole is suggested one to use.
2. Run `npm install`.  Note:  This will also install Bower modules.
3. Run `gulp build:prod`.

The build output will be in the *dist/prod* folder.  This contains minified and
non-minified versions.

## Testing ra-ip-components

TODO.


## Client Setup (for projects consuming ra-ip-components)

This library has dependencies on 3rd-party, `mobile-toolkit-ra` and `ra-ip-common` libraries. The easiest way
to download `ra-ip-common` and its dependencies is to do the following:

1. Install Node.js.
   Note:  The 32-bit version is needed if you intend to interoperate with any
   other 32-bit applications.
2. Install Bower (run `npm install -g bower`).
3. Use Bower to install ra-ip-components and its dependencies:
```
bower install --save https://mft.ra-int.com/gitlab/InfoPlatform/InfoPlatformComponents-releases.git
```

If you prefer to manage these dependencies manually instead, the dependencies
are listed in the `dependencies` section of the `client_bower.json` file.
