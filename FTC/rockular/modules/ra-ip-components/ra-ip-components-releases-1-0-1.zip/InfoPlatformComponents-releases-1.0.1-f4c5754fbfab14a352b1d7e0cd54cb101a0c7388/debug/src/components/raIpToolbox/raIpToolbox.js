/* (c) Rockwell Automation 2016 */
/* global _ */

//disable jshint line length for these api comments, some are required to be long for formatting
//reenabled after these comments.
/* jshint -W101 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.directive:raIpToolbox
 * @module RA.IPComponents
 *
 * @param {boolean} expanded Is toolbox expanded?
 * @param {object} minPanel Minimized pane configuration.
 *
 * | Property                       | Type             | Details                                                                   | Default value                                                                           |
 * |------------------------------- |------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
 * | enabled                        | {@type boolean}  | If there should be added option to switch to minPanel                     | undefined                                                                               |
 * | active                         | {@type boolean}  | If minPanel is currently active                                           | undefined                                                                               |
 *
 * @param {string} display How items are displayed ('inline'/'grid')
 * @param {object} config
 *
 * | Property                       | Type             | Details                                                                   | Default value                                                                           |
 * |------------------------------- |------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
 * | service (optional)             | {@type string}   | Name of custom service to use instead of default raIpToolboxSvc           | undefined                                                                               |
 * | items                          | {@type array}    | Array of items to put into toolbox. If not using default service          | undefined                                                                               |
 * | commonlyUsed                   | {@type array}    | Array of commonly used items                                              | undefined                                                                               |
 * | filter                         | {@type object}   | Filter configuration object, see raIpFilterSearchComponent                                               | undefined                                                                               |
 * | orderBy                        | {@type string}   | By which property to order items                                          | undefined                                                                               |
 * | dragDrop                       | {@type boolean}  | Enable dragdrop items                                                     | undefined                                                                               |
 * | selection                      | {@type boolean}  | Enable selection of items                                                 | undefined                                                                               |
 * | contextMenu                    | {@type object}   | contextMenu config object                                                 | undefined                                                                               |
 *
 * @param {object} callbacks
 *
 * | Property                       | Type             | Details                                                                   | Default value                                                                           |
 * |------------------------------- |------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
 * | onToggleMinPanel               | {@type function} | Function to call on toggle minimized panel                                | undefined                                                                               |
 * | onToggleToolbox                | {@type function} | Function to call on toggle toolbox                                        | undefined                                                                               |
 * | onSelectElement                | {@type function} | Function to call on select element                                        | undefined                                                                               |
 * | onSelectCategory               | {@type function} | Function to call on select category                                       | undefined                                                                               |
 *
 *
 * @param {function} setApi
 * A callback function that returns an API object. It takes a single parameter named 'api'
 * that will contain the API object when called.
 *
 * The object passed to the callback function has the functions and properties listed below.
 *
 * - **switchDisplay()** - `{function}` -
 *   A function that switches between item display modes.
 * - **toggleMinPanel()** - `{function}` -
 *   A function that toggles between normal (wide) pane and minimized pane.
 * - **selectElement('id')** - `{function}` -
 *   A function that selects element(item) from displayed category.
 * - **selectCategory('category.subcategory')** - `{function}` -
 *   A function that selects category.
 * - **updateContextMenu([object])** - `{function}` -
 *   A function that updates context menu. Takes one argument - configuration object of $.contextMenu.
 * - **refreshTree(newItems, category, element)** - `{function}` -
 *   A function that refreshes tree.
 *   - newItems - items to fill toolbox with, if using customSvc, leave this out
 *   - category - category to select after refresh (type string) eg. 'Basic.Shapes'
 *   - element - element to select after refresh (type string), id of element eg. '4' or 'myItem'
 *
 * @description
 * The directive lists given items and divides them into defined categories. Items can be draggable and selectable, they can be displayed either in grid or in lines. Categories are displayed in collapsible tree. There is a button to collapse all tree nodes. Toolbox can be minimized to side of parent container.
 *
 * ## Minimized version
 * Items are displayed in squares, one item per row. There is a button to open category tree dropdown and another button to return to wide panel display.
 *
 @example
 <example module="example1">
 <file name="style.css">
 .toolbox-wrapper {
    position: relative;
    color: black;
    width: 220px;
 }
 </file>
 <file name="index.html">
 <div ng-controller="raIpToolboxCtrl">
     <div class="toolbox-wrapper ra-flex-column">
         <ra-ip-toolbox
             min-panel="minPanel"
             display="display"
             config="config"
             callbacks="callbacks"
             expanded="expanded"
             set-api="setApi(api)"
             >
         </ra-ip-toolbox>
     </div>
     <h4>Configuration</h4>
     <div>
         <label for="expanded">expanded</label>
         <input id="expanded" type="checkbox" ng-model="expanded">
         <br />
         <button ng-click="api.switchDisplay()">Switch display</button>
         <br />

         <h3>MinPanel</h3>
         <button ng-click="api.toggleMinPanel()">Toggle minPanel</button>
         <br />
         <button ng-click="refreshTree()">Refresh tree with new items</button>
         <br />
         <label for="elementID">element ID</label>
         <input id="elementID" type="text" ng-model="elementID">
         <button ng-click="api.selectElement(elementID)">Select element</button>
         <br />
         <label for="categoryID">category ID</label>
         <input id="categoryID" type="text" ng-model="categoryID">
         <button ng-click="api.selectCategory(categoryID)">Select category</button>
     </div>
 </div>
 </file>
 <file name="script.js">
 angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
 angular.module('example1')
     .controller('raIpToolboxCtrl', ['$scope', '$http',
     function ($scope, $http) {
        var itemsVariant = 'old';
        $scope.refreshTree = function () {
            if (itemsVariant === 'old') {
                $scope.api.refreshTree(newItems);
                itemsVariant = 'new';
            } else {
                $scope.api.refreshTree(oldItems, 'Basic', 3);
                itemsVariant = 'old';
            }
        };

        $scope.displayOpts = [
            {
                value: 'inline',
                label: 'Inline'
            },
            {
                value: 'grid',
                label: 'Grid'
            }
        ];

        var items = [];

        var commonlyUsed = {
            max: 5,
            label: 'Most commonly used',
            items: []
        };
        var filter = {
            mode: 'basic',
            whispers: true,
            doConfirm: false,
            delay: 2000,
            minChars: 3,
            filters: [
                {
                    name: 'name',
                    label: 'Name',
                    placeholder: 'Type sth...'
                },
                {
                    name: 'category',
                    label: 'Category',
                    placeholder: 'Type some category...'
                },
                {
                    name: 'description',
                    label: 'Description',
                    placeholder: 'Type some desc...'
                }
            ]
        };
        var contextMenu = {
            items: {
                callback: function (key, opt) {
                    $scope.$apply(function () {
                        var id = JSON.parse(opt.$trigger.context.dataset.id);
                        switch (key) {
                            case 'console':
                                console.log(id);
                                break;
                            case 'screen':
                                $scope.contextDisplay = id;
                                break;
                        }
                    });
                },
                className: 'tb-items',
                items: {
                    console: {
                        name: 'console.log',
                        isHtmlName: false
                    },
                    screen: {
                        name: 'show on screen',
                        isHtmlName: false
                    }
                }
            },
            categories: {
                callback: function (key, opt) {
                    $scope.$apply(function () {
                        var item = JSON.parse(opt.$trigger.context.dataset.items);
                        switch (key) {
                            case 'console':
                                console.log(item.category);
                                break;
                            case 'screen':
                                $scope.contextDisplay = item.category;
                                break;
                        }
                    });
                },
                className: 'tb-categories',
                items: {
                    console: {
                        name: 'console.log',
                        isHtmlName: false
                    },
                    screen: {
                        name: 'show on screen',
                        isHtmlName: false
                    }
                }
            }
        };
        var oldItems = angular.copy(items);
        var newItems = [
            items[0]
        ];

        $scope.expanded = true;
        $scope.minPanel = {
            active: false,
            enabled: true
        };
        $scope.display = 'grid';
        $scope.expanded = true;
        $scope.config = {
            service: undefined,
            items: items,
            commonlyUsed: commonlyUsed,
            filter: filter,
            orderBy: 'name',
            dragDrop: true,
            selection: true,
            contextMenu: contextMenu
        };
        $scope.callbacks = {
            onToggleMinPanel: function() {
                console.log('Min panel toggled.');
            },
            onToggleToolbox: function() {
                console.log('Toolbox toggled');
            },
            onSelectElement: function() {
                console.log('Element was selected');
            },
            onSelectCategory: function() {
                console.log('Category was selected');
            }
        };
        $scope.setApi = function (api) {
            $scope.api = api;
        };

        $http.get('../grunt-styles/docs/toolboxItems.json').success(function(response) {
            items = response.items;
            $scope.api.refreshTree(items);
        });
    }
 ]);
 </file>
 </example>
 */
/* jshint +W101 */

angular.module('RA.IPComponents')
.directive('raIpToolbox', [ function () {
    "use strict";
    return {
        restrict: 'EA',
        templateUrl: 'components/raIpToolbox/raIpToolbox.tpl.html',
        replace: true,
        controller: 'raIpToolbox',
        scope: {
            expanded: "=",
            minPanel: "=",
            display: "<",
            config: "=",
            callbacks: "<",
            setApi: "&"
        }
    };
}])

.filter('dotToSlash', function () {
    'use strict';
    /**
     * @description Function replaces dots by slashes.
     * @param input String to modify
     * @returns {String}
     */
    return function (input) {
        if (input !== undefined) {
            return input.replace(/\./g, '/');
        }
    };
});

angular.module('RA.IPComponents').controller('raIpToolbox', ['$scope', '$element', '$injector', 'orderByFilter',
    'contextMenuSvc', 'raErrorHandlerSvc', '$q', '$timeout',
    function ($scope, $element, $injector, orderBy, contextMenuSvc, raErrorHandlerSvc, $q, $timeout) {
        "use strict";

        //if not defined custom service, use default
        var svc = $injector.get($scope.config.service || 'raIpToolboxSvc'),
            defaultToolboxWidth = '100%';

        if (!$scope.config.service && $scope.config.items) {
            svc.setAllResources($scope.config.items);
        }

        $scope.display = $scope.display || 'grid';
        $scope.dropdownMenu = false;
        $scope.minPanel = $scope.minPanel || {};
        $scope.minPanel.width = $scope.minPanel.width || 80;
        $scope.inProgress = {
            categories: true,
            items: true
        };

        if ($scope.minPanel.enabled) {
            var setWidth = function () {
                if ($scope.minPanel.active) {
                    $element.width($scope.minPanel.width);
                } else {
                    $element.width(defaultToolboxWidth);
                }
            };
            /**
             * @description Function toggles between wide toolbox and minimized toolbox.
             */
            $scope.minOrMax = function () {
                if ($scope.dropdownMenu) {
                    $scope.toggleDropdownMenu();
                }
                $scope.minPanel.active = !$scope.minPanel.active;
                if ($scope.callbacks && angular.isFunction($scope.callbacks.onToggleMinPanel)) {
                    $scope.callbacks.onToggleMinPanel($scope.minPanel.active);
                }
                setWidth();
            };
            $element.find(".toolbox-dropdown-menu").css("left", $scope.minPanel.width);
            setWidth();
        }

        /**
         * @description Function toggles dropdown menu.
         */
        $scope.toggleDropdownMenu = function () {
            $scope.dropdownMenu = !$scope.dropdownMenu;
            var el = $($element).find('.toolbox-dropdown-menu');
            el.animate({width: 'toggle'});
        };

        /**
         * @description Function toggles toolbox.
         */
        $scope.toggleToolbox = function () {
            $scope.expanded = !$scope.expanded;
            if ($scope.callbacks && angular.isFunction($scope.callbacks.onToggleToolbox)) {
                $scope.callbacks.onToggleToolbox($scope.expanded);
            }
        };

        //tree section

        var apis = {
            treeAPI: [],
            treeAPIMin: []
        },
            previous = {};

        /**
         * @description Function sets api object to control api of raTree in wide version of toolbox.
         */
        $scope.setTreeApi = function (api) {
            apis.treeAPI = api;
        };

        /**
         * @description Function sets api object to control api of raTree in minimized version of toolbox.
         */
        $scope.setTreeApiMin = function (api) {
            apis.treeAPIMin = api;
        };

        /**
         * @description Sort by numbers, not alphabetically.
         */
        function sortByNumber(a, b) {
            return b[1] - a[1];
        }

        if ($scope.config.commonlyUsed) {
            var commonlyUsedIds = [];
            $scope.config.commonlyUsed.label = $scope.config.commonlyUsed.label || 'Most commonly used';
            updateCommonlyUsedList();
            var commonlyUsedObj = {
                label: $scope.config.commonlyUsed.label,
                data: {
                    category: $scope.config.commonlyUsed.label
                },
                children: []
            };
        }

        svc.getCategoryTree()
        .then(
            //select first node
            function success(tree) {
                $scope.inProgress.categories = false;
                $scope.tree = tree;
                if ($scope.config.commonlyUsed) {
                    tree.unshift(commonlyUsedObj);
                }
                $timeout(function () {
                    apis.treeAPI.selectNode('0');
                    apis.treeAPIMin.selectNode('0');
                    $scope.userSelectCallback($scope.tree[0]);
                });
            },
            function error() {
                $scope.tree = [];
                throw new raErrorHandlerSvc.RAError('Server error', 'Error retrieving data');
            }
        );

        /**
         * @description Function selects particular node in particular raTree.
         * @param treeAPI Api to control selected tree
         * @param node Which node to select
         */
        function selectAndExpandNode(treeAPI, node) {
            apis[treeAPI].collapseNodes();
            var length = (node.length + 1) / 2;
            var expand = [];
            for (var i = 0; i < length; i++) {
                expand.push(node.substr(0, i * 2 + 1));
            }
            apis[treeAPI].setExpandedNodes(expand);
            apis[treeAPI].selectNode(node);
        }

        /**
         * @description Function handles selection of category.
         * @param node Tree node to select
         * @returns {Object} Promise
         */
        $scope.userSelectCallback = function (node) {
            var deferred = $q.defer();
            $scope.categoryName = node.label;
            previous.node = node;
            $scope.inProgress.items = true;
            //if commonly used is selected
            if ($scope.config.commonlyUsed && node.data.category === $scope.config.commonlyUsed.label) {
                svc.getResourcesByIds(commonlyUsedIds)
                .then(
                    function success(resources) {
                        $scope.inProgress.items = false;
                        $scope.graphics = resources;
                        if ($scope.callbacks && angular.isFunction($scope.callbacks.onSelectCategory)) {
                            $scope.callbacks.onSelectCategory(node);
                        }
                        deferred.resolve();
                    },
                    function error(reason) {
                        $scope.graphics = [];
                        deferred.reject(reason);
                    }
                );
            }
            //if normal category is selected
            else {
                svc.getResourcesByCategory(node.data.category)
                .then(
                    function success(resources) {
                        $scope.inProgress.items = false;
                        $scope.graphics = orderBy(resources, $scope.config.orderBy);
                        if ($scope.callbacks && angular.isFunction($scope.callbacks.onSelectCategory)) {
                            $scope.callbacks.onSelectCategory(node);
                        }
                        deferred.resolve();
                    },
                    function error(reason) {
                        deferred.reject(reason);
                    }
                );
            }
            if ($scope.minPanel.active) {
                selectAndExpandNode('treeAPI', apis.treeAPIMin.getSelectedNode());
                $scope.toggleDropdownMenu();
            } else {
                selectAndExpandNode('treeAPIMin', apis.treeAPI.getSelectedNode());
            }
            scrollToSelectedItem();
            return deferred.promise;
        };

        /**
         * @description Function collapses all tree nodes.
         */
        $scope.collapseAll = function () {
            apis.treeAPI.collapseNodes();
        };

        /**
         * @description Function expands all tree nodes.
         */
        // UNCOMMENT WHEN NEEDED
        // $scope.expandAll = function () {
        //     var allNodes = [];
        //     function getNodes(node, prefix) {
        //         angular.forEach(node, function (item, index) {
        //             allNodes.push(prefix + index);
        //             getNodes(item.children, prefix + index + '_');
        //         });
        //     }
        //     getNodes($scope.tree, '');
        //     apis.treeAPI.setExpandedNodes(allNodes);
        // };

        var selectedItem;

        /**
         * @description Function scrolls to selected item or category, if it is not visible.
         */
        var scrollToSelectedItem = function (item) {
            $timeout(function () {
                var selectedElem = $element.find((item ? '.item.selected' : '.ra-tree-node-selected') + ':visible');

                if (!selectedElem.length) { return; }

                var itemsElem = $element.find((item ? '.category-elements' : 'div[ra-tree]') + ':visible'),
                    selectedElemPos = selectedElem.offset().top - $(window).scrollTop(),
                    itemsElemPos = itemsElem.offset().top - $(window).scrollTop();

                if (selectedElemPos !== undefined) {
                    // is hidden on bottom or on top
                    if (itemsElemPos + itemsElem.height() < selectedElemPos + selectedElem.height() ||
                        itemsElemPos > selectedElemPos) {
                        itemsElem.animate({
                            scrollTop: itemsElem.scrollTop() + selectedElemPos - itemsElemPos - itemsElem.height() / 2
                        }, "fast");
                    }
                }
            });
        };

        /**
         * @description Function selects item.
         * @param graphic selected item
         */
        $scope.selectItem = function (graphic) {
            if (selectedItem) {
                if (graphic.id !== selectedItem.id) {
                    selectedItem.selectedClass = undefined;
                    graphic.selectedClass = 'selected';
                    selectedItem = graphic;
                } else {
                    selectedItem.selectedClass = undefined;
                    selectedItem = undefined;
                }
            } else {
                graphic.selectedClass = 'selected';
                selectedItem = graphic;
            }
            if ($scope.callbacks && angular.isFunction($scope.callbacks.onSelectElement)) {
                $scope.callbacks.onSelectElement(graphic);
            }
            if ($scope.config.selection) {
                updateCommonlyUsedCount(graphic.id);
            }
            scrollToSelectedItem(true);
        };


        if ($scope.minPanel.enabled) {
            $(window).click(function () {
                $scope.$apply(function () {
                    //hide dropdown menu
                    if ($scope.dropdownMenu && $scope.minPanel.active) {
                        $scope.toggleDropdownMenu();
                    }
                });
            });
            //do not hide dropdown menu
            $($element).find('.button-categories').click(function (event) {
                event.stopPropagation();
            });
        }

        //filter section

        if ($scope.config.filter) {

            var filterOptions = [];
            $scope.filterActive = false;

            //fill filterOptions
            angular.forEach($scope.config.filter.filters, function (filter) {
                filterOptions.push(filter.name);
            });

            /**
             * @description Filter callback function.
             * @param queryData data from filter component
             */
            $scope.config.filter.callback = function (queryData) {
                //on cancel
                if (queryData[0].cancel) {
                    $scope.filterActive = false;
                    if (previous.display) {
                        $scope.display = previous.display;
                        $scope.userSelectCallback(previous.node);
                    }
                } else {
                    $scope.inProgress.items = true;
                    if (queryData[0].name === 'all') {
                        queryData[0].filterOptions = filterOptions;
                    }
                    svc.getResourcesByFilter(queryData, false)
                    .then(
                        function success(resources) {
                            $scope.inProgress.items = false;
                            $scope.graphics = resources;
                        },
                        function error() {
                            $scope.graphics = [];
                            throw new raErrorHandlerSvc.RAError('Server error', 'Error retrieving data');
                        }
                    );
                    if (!$scope.filterActive) {
                        $scope.filterActive = true;
                        previous.display = $scope.display;
                        $scope.display = 'inline';
                    }
                }
            };
            /**
             * @description Filter whispers function.
             * @param queryData data from filter component
             * @returns {Object} Promise
             */
            $scope.config.filter.whispers = function (queryData) {
                if (queryData[0].name === 'all') {
                    queryData[0].filterOptions = filterOptions;
                }
                var deferred = $q.defer();
                svc.getResourcesByFilter(queryData, true)
                .then(
                    function success(resources) {
                        deferred.resolve(resources);
                    },
                    function error(reason) {
                        deferred.reject(reason);
                    }
                );
                return deferred.promise;
            };
            /**
             * @description Filter whispers function.
             * @param api Object with api methods from filter.
             * @returns {Object} Promise
             */
            $scope.config.filter.setApi = function (api) {
                $scope.filterApi = api;
            };
        }


        //commonly used

        /**
         * @description Function adds item in commonly used array or it increments its count.
         * @param id
         */
        function updateCommonlyUsedCount(id) {
            var add = false;
            angular.forEach($scope.config.commonlyUsed.items, function (item) {
                if (item[0] === id) {
                    item[1]++;
                    $scope.config.commonlyUsed.items.sort(sortByNumber);
                    add = true;
                }
            });
            if (!add) {
                if ($scope.config.commonlyUsed.items[$scope.config.commonlyUsed.max - 1]) {
                    $scope.config.commonlyUsed.items.splice($scope.config.commonlyUsed.max - 1, 1);
                }
                $scope.config.commonlyUsed.items.push([id, 1]);
                updateCommonlyUsedList();
            }
        }

        /**
         * @description Function updates list of commonly used after change.
         */
        function updateCommonlyUsedList() {
            commonlyUsedIds = $scope.config.commonlyUsed.items.map(function (value) {
                return value[0];
            });
        }

        //list of graphic elements

        $scope.categoryName = 'All items';

        /**
         * @description Changes helper style of element.
         * @param event
         * @returns {Object} helper object
         */
        function changeHelperStyle(event) {
            var el = angular.element(event.currentTarget);
            var helper = el.clone();
            helper.css('cursor', 'move');
            helper.css('width', $(event.currentTarget).css('width'));
            helper.addClass('ra-list-drag-source');
            return helper;
        }

        $scope.jqyouiOptions = {
            revert: 'invalid',
            helper: changeHelperStyle,
            revertDuration: 200
        };

        /**
         * @description Drag stop event handler function.
         * @param event
         * @param ui
         */
        $scope.stop = function (event, ui) {
            if (ui.helper.data('dropped') && !$scope.config.selection) {
                updateCommonlyUsedCount(ui.helper.context.dataset.id);
            }
        };

        /**
         * @description Function updates context menu.
         * @param forCategories Is it context menu for categories or for items?
         * @param config Configuration of $.context-menu
         * @param firstRun If it is run for the first time.
         */
        function updateContextMenu(forCategories, config, firstRun) {
            config.className += ' toolbox-context-menu';
            var selector = '.ra-ip-toolbox .item';
            if (forCategories) {
                selector = '.ra-ip-toolbox .ra-tree-node';
            }
            if (!firstRun) {
                contextMenuSvc.destroyContextMenu(selector);
            }
            contextMenuSvc.addNewContextMenu(selector, config);
        }

        //object that defines toolbox api
        $scope.toolboxApi = {
            /**
             * @description Function switches display mode of items.
             */
            switchDisplay: function () {
                if ($scope.display === 'inline') {
                    $scope.display = 'grid';
                } else {
                    $scope.display = 'inline';
                }
            },
            toggleMinPanel: function () {
                $scope.minOrMax();
            },
            /**
             * @description Function switches display mode of items.
             * @param newItems Items to show, only if default service is being used
             * @param category Category to select after refresh
             * @param element Element to select after refresh
             * @returns {Object} Promise
             */
            refreshTree: function (newItems, category, element) {
                var deferred = $q.defer();
                $scope.inProgress.items = true;
                if (!$scope.config.service) {
                    $scope.config.items = newItems;
                    svc.setAllResources($scope.config.items);
                }
                svc.getCategoryTree()
                .then(
                    function success(resources) {
                        $scope.inProgress.items = false;
                        $scope.tree = resources;
                        if ($scope.config.commonlyUsed) {
                            $scope.tree.unshift(commonlyUsedObj);
                        }
                        if (category) {
                            $scope.toolboxApi.selectCategory(category).then(
                                function success() {
                                    if (element) {
                                        if (selectedItem) {
                                            selectedItem.selectedClass = undefined;
                                            selectedItem = undefined;
                                        }
                                        $scope.toolboxApi.selectElement(element);
                                    }
                                }
                            );
                        } else {
                            apis.treeAPI.selectNode('0');
                            $scope.userSelectCallback($scope.tree[0]).then(
                                function success() {
                                    if (element) {
                                        $scope.toolboxApi.selectElement(element);
                                    }
                                }
                            );
                        }
                        deferred.resolve();
                    },
                    function error() {
                        $scope.tree = [];
                        throw new raErrorHandlerSvc.RAError('Server error', 'Error retrieving data');
                    }
                );
                return deferred.promise;
            },
            /**
             * @description Function selects element in toolbox.
             * @param id Unique id of element
             */
            selectElement: function (id) { //id is string
                var gr = _.find($scope.graphics, {'id': id.toString()});
                if (gr) {
                    $scope.selectItem(gr);
                }
            },
            /**
             * @description Function selects category in toolbox.
             * @param category Whole category name
             */
            selectCategory: function (category) { //eg. 'General Equipment.Tanks'
                var deferred = $q.defer();
                apis.treeAPI.collapseNodes();
                /**
                 * @description Function finds node in tree.
                 * @param tree In which tree to search
                 * @param category Unique category
                 */
                var findNode = function (tree, category) {
                    category = category.split('.');
                    var foundDeeper, found = {
                        id: ''
                    };
                    angular.forEach(tree, function (node, index) {
                        if (node.label === category[0]) {
                            if (category.length === 1) {
                                found.id += index;
                                found.obj = node;
                            } else if (node.children.length > 0) {
                                category.shift();
                                found.id += index;
                                apis.treeAPI.expandNode(found.id);
                                foundDeeper = findNode(node.children, category.join('.'));
                                if (foundDeeper.id !== '') {
                                    found.id += '_' + foundDeeper.id;
                                    found.obj = foundDeeper.obj;
                                }
                            }
                        }
                    });
                    return found;
                };
                var node = findNode($scope.tree, category);
                if (!node.id.length) {
                    node.id = '0';
                    node.obj = $scope.tree[0];
                }
                apis.treeAPI.selectNode(node.id);
                $scope.userSelectCallback(node.obj).then(
                    function success() {
                        deferred.resolve();
                    },
                    function error(reason) {
                        deferred.reject(reason);
                    }
                );
                return deferred.promise;
            },
            updateContextMenu: updateContextMenu
        };

        $scope.setApi({api: $scope.toolboxApi});

        if ($scope.config.contextMenu) {
            if ($scope.config.contextMenu.items) {
                updateContextMenu(false, $scope.config.contextMenu.items, true);
            }
            if ($scope.config.contextMenu.categories) {
                updateContextMenu(true, $scope.config.contextMenu.categories, true);
            }
        }

        $scope.$on('$destroy', function () {
            $(window).unbind('click');
            contextMenuSvc.destroyContextMenu('.ra-ip-toolbox .item');
            contextMenuSvc.destroyContextMenu('.ra-ip-toolbox .ra-tree-node');
        });
    }
]);
