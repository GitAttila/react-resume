/*
 * (c) Rockwell Automation 2017
 */
/* global angular */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpWizard
 * @module RA.IPComponents
 * @restrict E
 * @scope true
 * @description
 * This component is responsible for rendering wizard.
 * The component expects to receive {object} **`config`**.
 *
 * @param {object} config
 * - **`sharedViewConfig`** {object} object to be shared across all controllers - used to pass data to and between 
 *      controllers
 * - **`initialViewIndex`** {integer} index at which will wizard open its view on first render, defaults to 0
 * - **`showButtons`** {boolean} flag indicating if wizard should have action buttons at bottom (prev/next actions)
 * - **`hideSteps`** {boolean} flag indicating if wizard should hide steps
 * - **`previousStepsAutoSuccess`** {boolean} flag indicating if wizard should mark previous 
 *      steps automatically as success (defaults to false)
 * - **`stepsConfig`** {array} array with steps definition, see {@link RA.IPComponents.component:raIpSteps}
 * - **`views`** {array} array with definition for each step - if no template and templateUrl is set then default 
 *      template 'components/raIpWizard/raIpWizardDefault.tpl.html' is used
 *      - **`template`** {string} optional definition for inline template to be used for wizard content view
 *      - **`templateUrl`** {string} url for template to be used for wizard content view, template is loaded 
 *          only from $templateCache
 *          ("components/raIpWizard/raIpWizard.tpl.html" cannot be used as templateUrl)
 *      - **`controller`** {string} controller name, controller will be created
 *      - **`controllerAs`** {string} optional - alternative name for controller for template (controller scope alias),
 *          if not set then default $ctrl is used
 *
 *
 * There is wizard api which is passed to controller created for actual step as 'wizardApi' injection.
 * 
 * 
 @example
 The example below shows how to use raIpWizard.
 
 <example module="example1">
 <file name="index.html">
 <div ng-controller="myCtrlA" style="min-height: 280px;">
 <div ng-if="initialized">
 <div>With action buttons:</div>
 <ra-ip-wizard config="config"></ra-ip-wizard>
 </div>
 <div ng-if="!initialized">Loading example...</div>
 </div>
 </file>
 <file name="script.js">
 angular.module('example1', ['pascalprecht.translate', 'mobile-toolkit-ra', 'RA.IPComponents']);
 angular.module('example1')
    .config(['$translateProvider',
        function ($translateProvider) {
        'use strict';
        $translateProvider.useStaticFilesLoader({
            "files": [
            {
                prefix: 'dependencies/locale/locale-',
                suffix: '.json'
            }]
        })
        // Registering a fallback language
        .fallbackLanguage('en')
        .registerAvailableLanguageKeys(['en'], {
            'en-*': 'en'
        })
        // tells angular-translate to use the English
        .preferredLanguage('en')
        .useSanitizeValueStrategy('escaped');
    }
 ])
 .controller('myCtrlA',['$scope', '$translate',
    function($scope, $translate) {
        function init() {
            $scope.config = {
                showButtons: true,
                stepsConfig: {
                    type: 'icons',
                    size: 'medium',
                    autofillConnector: true,
                steps: [
                    {
                        iconClass: 'ra-icon-home',
                        tooltip: 'Tooltip text',
                        active: true,
                        clickable: false,
                        title: 'Step 1',
                        onAction: function () {
                        $scope.config.stepsConfig.steps[1] = 
                            angular.extend($scope.config.stepsConfig.steps[1], {
                        active: false,
                        clickable: true
                });
                $scope.config.stepsConfig.steps[0] = 
                angular.extend($scope.config.stepsConfig.steps[0], {
                active: true,
                clickable: false
            });
        }
    },
 {
    tooltip: 'Tooltip text',
    iconClass: 'ra-icon-no-data',
    title: 'Step 2',
    clickable: true,
    onAction: function () {
        $scope.config.stepsConfig.steps[0] = 
        angular.extend($scope.config.stepsConfig.steps[0], {
        active: false,
        clickable: true
    });
    $scope.config.stepsConfig.steps[1] = 
        angular.extend($scope.config.stepsConfig.steps[1], {
    active: true,
    clickable: false
 });
 }
 }
 ]
 },
 views: [
    {
    template: '<div class="ra-flex-column ra-height-100 ra-flex-align-main-center' + 
    ' ra-flex-align-cross-center">First step template</div>'
    },
    {
    template: '<div class="ra-flex-column ra-height-100 ra-flex-align-main-center' + 
    ' ra-flex-align-cross-center">Second step template</div>'
    }
    ]
    };
    $scope.initialized = true;
    }
 
 $translate.onReady(init);
 }]);
 </file>
 </example>
 <example module="example2">
 <file name="index.html">
 <div ng-controller="myCtrlB" style="min-height: 280px;">
 <div ng-if="initialized">
 <div ng-if="initialized">
 <div>With shared view data passed:</div>
 <ra-ip-wizard config="config"></ra-ip-wizard>
 </div>
 <div ng-if="!initialized">Loading example...</div>
 </div>
 </file>
 <file name="script.js">
 angular.module('example2', ['pascalprecht.translate', 'mobile-toolkit-ra', 'RA.IPComponents']);
 angular.module('example2')
 .config(['$translateProvider',
 function ($translateProvider) {
 'use strict';
 $translateProvider.useStaticFilesLoader({
 "files": [
 {
 prefix: 'dependencies/locale/locale-',
 suffix: '.json'
 }]
 })
 // Registering a fallback language
 .fallbackLanguage('en')
 .registerAvailableLanguageKeys(['en'], {
 'en-*': 'en'
 })
 // tells angular-translate to use the English
 .preferredLanguage('en')
 .useSanitizeValueStrategy('escaped');
 }
 ])
 .controller('wizardContentCtrl', ['config', function (config) {
 this.sharedCount = ++config.sharedCount;
 }])
 .controller('myCtrlB',['$scope', '$translate',
 function($scope, $translate) {
 function init() {
 $scope.config = {
 sharedViewConfig: {
 sharedCount: 0
 },
 showButtons: false,
 stepsConfig: {
 type: 'icons',
 size: 'medium',
 autofillConnector: true,
 steps: [
 {
 iconClass: 'ra-icon-home',
 tooltip: 'Tooltip text',
 active: true,
 clickable: false,
 title: 'Step 1',
 onAction: function () {
 $scope.config.stepsConfig.steps[1] = 
 angular.extend($scope.config.stepsConfig.steps[1], {
 active: false,
 clickable: true
 });
 $scope.config.stepsConfig.steps[0] = 
 angular.extend($scope.config.stepsConfig.steps[0], {
 active: true,
 clickable: false
 });
 }
 },
 {
 tooltip: 'Tooltip text',
 iconClass: 'ra-icon-no-data',
 title: 'Step 2',
 clickable: true,
 onAction: function () {
 $scope.config.stepsConfig.steps[0] = 
 angular.extend($scope.config.stepsConfig.steps[0], {
 active: false,
 clickable: true
 });
 $scope.config.stepsConfig.steps[1] = 
 angular.extend($scope.config.stepsConfig.steps[1], {
 active: true,
 clickable: false
 });
 }
 }
 ]
 },
 views: [
 {
 template: '<div class="ra-flex-column ra-height-100 ra-flex-align-main-center' + 
 ' ra-flex-align-cross-center">First step template ' + 
 'with sharedCount <span ng-bind="$ctrl.sharedCount"></span></div>',
 controller: 'wizardContentCtrl'
 },
 {
 template: '<div class="ra-flex-column ra-height-100 ra-flex-align-main-center' + 
 ' ra-flex-align-cross-center">Second step template ' + 
 'with sharedCount <span ng-bind="$ctrl.sharedCount"></span></div>',
 controller: 'wizardContentCtrl'
 }
 ]
 };
 $scope.initialized = true;
 }
 
 $translate.onReady(init);
 }]);
 </file>
 </example>
 */
angular.module("RA.IPComponents")
    .component("raIpWizard", {
        template: ['$templateCache', function ($templateCache) {
                "use strict";
                return $templateCache.get('components/raIpWizard/raIpWizard.tpl.html');
            }
        ],
        bindings: {
            config: "<"
        },
        controller: ['$log', '$compile', '$element', '$scope', '$controller', '$templateCache', '$animate',
            '$translate', 'raErrorHandlerSvc',
            function ($log, $compile, $element, $scope, $controller, $templateCache, $animate, $translate,
                raErrorHandlerSvc) {
                "use strict";
                var self = this;

                /**
                 * @description Helper method to check id wizard has steps defined
                 * @returns {boolean}
                 */
                function hasSteps() {
                    return angular.isArray(self.config.stepsConfig.steps) && self.config.stepsConfig.steps.length > 0;
                }

                /**
                 * @description Method to clear actual wizard page content.
                 */
                function clearWizardContent() {
                    if (self.ctrlLocals.$scope) {
                        self.wizardContentEl.empty();
                        self.ctrlLocals.$scope.$destroy();
                        delete self.ctrlLocals.$scope;
                        delete self.ctrlLocals.$controller;
                    }
                }

                /**
                 * @description Method for normalizing config object.
                 */
                function normalizeConfig() {
                    self.config = self.config || {};
                    self.config.stepsConfig = self.config.stepsConfig || {};
                    self.config.stepsConfig.steps = self.config.stepsConfig.steps || [];
                    self.config.views = self.config.views || [{}];
                    self.config.initialViewIndex = self.config.initialViewIndex || 0;
                    self.config.sharedViewConfig = self.config.sharedViewConfig || {};
                    self.config.showButtons = angular.isDefined(self.config.showButtons) ?
                        self.config.showButtons : false;
                    self.config.hideSteps = angular.isDefined(self.config.hideSteps) ?
                        self.config.hideSteps : false;
                    self.config.previousStepsAutoSuccess = angular.isDefined(self.config.previousStepsAutoSuccess) ?
                        self.config.previousStepsAutoSuccess : false;
                }

                /**
                 * @description Helper method to initialize wizard api next / prev buttons.
                 */
                function initializeButtons() {
                    self.buttonActionsConfig = {
                        align: 'right',
                        actions: [
                            {
                                type: 'button',
                                class: 'ra-icon-back',
                                tooltip: $translate.instant('RA_IP_COMPONENTS.RA_IP_WIZARD.PREV_BTN'),
                                onAction: function () {
                                    if (angular.isDefined(self.wizardApi.prev.onBeforeActionAsync)) {
                                        self.wizardApi.prev.onBeforeActionAsync().then(function () {
                                            self.moveAction(self.actualStep - 1);
                                        });
                                    } else {
                                        self.moveAction(self.actualStep - 1);
                                    }
                                }
                            },
                            {
                                type: 'button',
                                class: 'ra-icon-forward',
                                tooltip: $translate.instant('RA_IP_COMPONENTS.RA_IP_WIZARD.NEXT_BTN'),
                                onAction: function () {
                                    if (angular.isDefined(self.wizardApi.next.onBeforeActionAsync)) {
                                        self.wizardApi.next.onBeforeActionAsync().then(function () {
                                            self.moveAction(self.actualStep + 1);
                                        });
                                    } else {
                                        self.moveAction(self.actualStep + 1);
                                    }
                                }
                            }
                        ]
                    };
                }

                /**
                 * @description Helper method to initialize / set default state for wizard api.
                 */
                function initializeWizardApi() {
                    self.wizardApi = {
                        steps: {
                            actualStep: function () {
                                return self.config.stepsConfig.steps[self.actualStep];
                            }
                        },
                        move: function (stepIndex) {
                            // move to next wizard page if any
                            if (!self.config.views[stepIndex]) {
                                // there is no page
                                return;
                            }
                            if (canMoveToViewIndex(stepIndex)) {
                                self.actualStep = stepIndex;
                                self.setAllNextStepsInactive(self.actualStep);
                                if (self.config.previousStepsAutoSuccess) {
                                    self.setAllPreviousStepsSuccess(self.actualStep);
                                }
                                compileViewContent(self.config.views[self.actualStep]);
                                self.config.stepsConfig.steps[self.actualStep].active = true;
                            }
                        },
                        next: {
                            button: {
                                setDisabled: function (flag) {
                                    self.buttonActionsConfig.actions[1].disabled = flag ? true : false;
                                }
                            },
                            //onBeforeActionAsync: angular.noop,
                            has: function () {
                                return angular.isDefined(self.config.views[self.actualStep + 1]);
                            },
                            move: function () {
                                self.moveAction(self.actualStep + 1);
                            }
                        },
                        prev: {
                            button: {
                                setDisabled: function (flag) {
                                    self.buttonActionsConfig.actions[0].disabled = flag ? true : false;
                                }
                            },
                            //onBeforeActionAsync: angular.noop,
                            has: function () {
                                return self.actualStep > 0 &&
                                    angular.isDefined(self.config.views[self.actualStep - 1]);
                            },
                            move: function () {
                                self.moveAction(self.actualStep - 1);
                            }
                        }
                    };
                }

                /**
                 * @description Method to check whether we can be move to specific step index.
                 * @param {Integer} index
                 * @returns {Boolean}
                 */
                function canMoveToViewIndex(index) {
                    if (self.config.stepsConfig.steps && self.config.stepsConfig.steps.length > 0 &&
                        self.config.views.length > 0) {

                        if (!self.config.stepsConfig.steps[index]) {
                            $log.debug('raIpWizard: No step defined for view.', self.config.stepsConfig.steps,
                                self.config.views);
                            return false;
                        }
                        return true;
                    }
                    return false;
                }

                /**
                 * @description Method for compiling current page content into wizard-page-content.
                 * @param {Object} pageConfig page config given to specific page to be rendered
                 */
                function compileViewContent(pageConfig) {
                    var addDomEl, controllerAs = pageConfig.controllerAs || '$ctrl';

                    if (pageConfig.templateUrl === 'components/raIpWizard/raIpWizard.tpl.html') {
                        throw raErrorHandlerSvc.getRAError('Logic error',
                            'raIpWizard: Cannot use template "components/raIpWizard/raIpWizard.tpl.html"' +
                            ' for wizard page definition.');
                    }

                    clearWizardContent(); // remove all inner wizard content
                    initializeButtons(); // initialize buttons with default config
                    self.updateButtonsDisabledState();
                    initializeWizardApi(); //initialize wizard api for each view - reset to default

                    self.ctrlLocals.wizardApi = self.wizardApi; //wizardApi
                    if (angular.isString(pageConfig.template)) {
                        addDomEl = pageConfig.template;
                    } else {
                        addDomEl = $templateCache.get(pageConfig.templateUrl ? pageConfig.templateUrl :
                            'components/raIpWizard/raIpWizardDefault.tpl.html');
                    }

                    self.ctrlLocals.$scope = $scope.$new(true);
                    self.ctrlLocals.$element = addDomEl;
                    if (pageConfig.controller) {
                        self.ctrlLocals.$scope[controllerAs] = $controller(pageConfig.controller, self.ctrlLocals);
                    }

                    var compiledEl = $compile(addDomEl)(self.ctrlLocals.$scope);
                    $animate.enter(compiledEl, self.wizardContentEl);
                }

                // init section
                normalizeConfig();

                self.ctrlLocals = {};
                self.actualStep = 0;

                /**
                 * @description Method to invoke button defined actions for previous and next button.
                 * @param {integer} index step index to trigger action for - move to
                 * @param {function} callback callback function to be trigered before step move action
                 */
                self.invokeDoAction = function (index, callback) {
                    if (self.actualStep === index) {
                        //already on current step
                        return;
                    }

                    var direction = self.actualStep > index ? 'prev' : 'next';
                    if (angular.isDefined(self.wizardApi[direction].onBeforeActionAsync)) {
                        self.wizardApi[direction].onBeforeActionAsync().then(
                            self.moveAction.bind(undefined, index, callback));
                    } else {
                        self.moveAction(index, callback);
                    }
                };

                /**
                 * @description Method to move to specific step given by index.
                 * @param {integer} stepIndex step index
                 * @param {function} callback optional function which will be triggered, 
                 * may be defined in stepsConfig for each step
                 */
                self.moveAction = function (stepIndex, callback) {
                    if (angular.isFunction(callback)) {
                        callback();
                    }
                    self.wizardApi.move(stepIndex);
                };

                /**
                 * @description Method to mark all previous steps as active in success state
                 */
                self.setAllPreviousStepsSuccess = function (stepIndex) {
                    if (hasSteps() && stepIndex > 0) {
                        for (var i = stepIndex - 1; i >= 0; i--) {
                            self.config.stepsConfig.steps[i].active = true;
                            self.config.stepsConfig.steps[i].status = 'success';
                        }
                    }
                };

                /**
                 * @description Method to mark all next steps as inactive also removing state
                 */
                self.setAllNextStepsInactive = function (stepIndex) {
                    if (hasSteps()) {
                        for (var i = stepIndex; i < self.config.stepsConfig.steps.length; i++) {
                            self.config.stepsConfig.steps[i].active = false;
                            self.config.stepsConfig.steps[i].status = 'default';
                        }
                    }
                };

                /**
                 * @description Method to update bottom buttons disabled state in case we are at start/end of steps,
                 * we cannot go beyond.
                 */
                self.updateButtonsDisabledState = function () {
                    if (self.actualStep === 0) {
                        self.buttonActionsConfig.actions[0].disabled = true;
                    }
                    if (self.actualStep === self.config.stepsConfig.steps.length - 1 ||
                        !angular.isDefined(self.config.views[self.actualStep + 1])) {
                        self.buttonActionsConfig.actions[1].disabled = true;
                    }
                };

                /**
                 * @description Method to set all buttons disabled. Used in case of an wizard configuration error.
                 */
                self.setAllButtonsDisabledState = function () {
                    self.buttonActionsConfig.actions[0].disabled = true;
                    self.buttonActionsConfig.actions[1].disabled = true;
                };

                self.wizardContentEl = angular.element($element.find('.wizard-page-content'));

                initializeButtons();

                // define wrapper for steps onAction to trigger proper move automatically
                if (angular.isDefined(self.config.stepsConfig && angular.isArray(self.config.stepsConfig.steps))) {
                    self.config.stepsConfig.steps.forEach(function (value, index) {
                        value.onAction = self.invokeDoAction.bind(undefined, index, value.onAction);
                    });
                }

                self.ctrlLocals.config = self.config.sharedViewConfig; //shared object between wizard views
                if (hasSteps() && self.config.views.length > 0) {

                    if (!self.config.stepsConfig.steps[self.config.initialViewIndex]) {
                        $log.debug('raIpWizard: No step defined for view.', self.config.stepsConfig.steps,
                            self.config.views);
                        self.setAllButtonsDisabledState();
                        return;
                    }
                    else if (!self.config.views[self.config.initialViewIndex]) {
                        $log.debug('raIpWizard: No view defined for initial view index.', self.config.views,
                            self.config.initialViewIndex);
                        self.setAllButtonsDisabledState();
                        return;
                    }
                    self.actualStep = self.config.initialViewIndex;
                    self.updateButtonsDisabledState();
                    compileViewContent(self.config.views[self.config.initialViewIndex]);
                }
                // end init section
            }
        ]
    });
