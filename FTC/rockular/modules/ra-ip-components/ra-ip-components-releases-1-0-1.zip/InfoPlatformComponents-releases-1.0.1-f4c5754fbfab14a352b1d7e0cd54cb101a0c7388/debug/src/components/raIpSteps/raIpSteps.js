/*
 * (c) Rockwell Automation 2017
 */
/*global angular*/
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpSteps
 * @module RA.IPComponents
 * @restrict E
 * @scope true
 * @description
 * This component is responsible for rendering steps, used e.g. in wizard component.
 * The component expects to receive {object} **`config`**.
 *
 * @param {object} config
 * - **`size`** {string} steps size, possible values 'small', 'medium', 'large', defaults to 'medium'
 * - **`type`** {string} steps type, possible values 'numeric', 'icons', defaults to 'numeric'
 * - **`theme`** {string} steps theme, possible values 'rockwell', defaults to 'rockwell'
 * - **`enableTitles`** {boolean} flag to turn on/off step title
 * - **`autofillConnector`** {boolean} flag to turn automatic color filling for connector between two active steps,
 *      defaults to false
 * - **`disableStatusColor`** {boolean} flag to disable coloring of statuses for current theme
 * - **`steps`** {array} array with step configuration, possible step object definition:
 *      - **`step`** {object} step definition
 *          - **`tooltip`** {string} step tooltip
 *          - **`title`** {string} title to show unsder step, enableTitles flag must be turned on to show title
 *          - **`iconClass`** {string} with class definition example:
 *                 "ra-icon-home"
 *          - **`disabled`** {boolean} flag indicating disabled step
 *              (is not clickable if true - onAction cannot be triggered)
 *          - **`clickable`** {boolean} flag indicating step is clickable (onAction can be trigered)
 *          - **`active`** {boolean} flag indicating step is active, has active visual
 *          - **`onAction`** {function} funtion to be triggered for clickable step on step click
 *              (clickable must be true to work properly)
 *
 @example
 The example below shows how to use raIpSteps.

 <example module="example1">
 <file name="index.html">
 <div ng-controller="myCtrl">
    <div>With icons and tooltip text (small size):</div>
    <ra-ip-steps config="stepsConfigA"></ra-ip-steps>
    <div>With icons and second item active (medium size):</div>
    <ra-ip-steps config="stepsConfigB"></ra-ip-steps>
    <div>With click actions (large size):</div>
    <ra-ip-steps config="stepsConfigC"></ra-ip-steps>
    <div>Numeric steps (small size):</div>
    <ra-ip-steps config="stepsConfigD"></ra-ip-steps>
    <div>With titles (small size):</div>
    <ra-ip-steps config="stepsConfigE"></ra-ip-steps>
    <div>With statuses:</div>
    <ra-ip-steps config="stepsConfigF"></ra-ip-steps>
 </div>
 </file>
 <file name="script.js">
 angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
 angular.module('example1')
 .controller('myCtrl',['$scope',
 function($scope) {
                    $scope.stepsConfigA = {
                        type: 'icons',
                        steps: [
                            {
                                iconClass: 'ra-icon-home',
                                tooltip: 'Tooltip text',
                                active: true,
                                status: 'default' | 'error' | 'success' | 'warning'
                            },
                            {
                                disabled: true,
                                tooltip: 'Tooltip text',
                                iconClass: 'ra-icon-no-data'
                            }
                        ],
                        size: 'small'
                    };
                    $scope.stepsConfigB = {
                        type: 'icons',
                        steps: [
                            {
                                iconClass: 'ra-icon-home',
                            },
                            {
                                active: true,
                                iconClass: 'ra-icon-no-data'
                            }
                        ],
                        size: 'medium'
                    };
                    $scope.stepsConfigC = {
                        type: 'icons',
                        enableTitles: true,
                        steps: [
                            {
                                iconClass: 'ra-icon-home',
                                active: true,
                                clickable: false,
                                title: 'Can\'t click me!',
                                onAction: function () {
                                    $scope.stepsConfigC.steps[1] = angular.extend($scope.stepsConfigC.steps[1], {
                                        active: false,
                                        clickable: true,
                                        title: 'Click me!'
                                    });
                                    $scope.stepsConfigC.steps[0] = angular.extend($scope.stepsConfigC.steps[0], {
                                        active: true,
                                        clickable: false,
                                        title: 'Can\'t click me!'
                                    });
                                }
                            },
                            {
                                iconClass: 'ra-icon-no-data',
                                clickable: true,
                                title: 'Click me!',
                                onAction: function () {
                                    $scope.stepsConfigC.steps[0] = angular.extend($scope.stepsConfigC.steps[0], {
                                        active: false,
                                        clickable: true,
                                        title: 'Click me!'
                                    });
                                    $scope.stepsConfigC.steps[1] = angular.extend($scope.stepsConfigC.steps[1], {
                                        active: true,
                                        clickable: false,
                                        title: 'Can\'t click me!'
                                    });
                                }
                            }
                        ],
                        size: 'large'
                    };
                    $scope.stepsConfigD = {
                        type: 'numeric',
                        steps: [
                            {},
                            {
                                disabled: true,
                            },
                            {
                                active: true
                            },
                        ],
                        size: 'small'
                    };
                    $scope.stepsConfigE = {
                        enableTitles: true,
                        type: 'numeric',
                        steps: [
                            {
                                title: 'Title 1'
                            },
                            {
                                title: 'Title 2'
                            },
                            {
                                active: true
                            },
                        ],
                        size: 'small'
                    };
                    $scope.stepsConfigF = {
                        type: 'numeric',
                        enableTitles: true,
                        steps: [
                            {
                                status: 'warning',
                                title: 'warning'
                            },
                            {
                                status: 'error',
                                title: 'error'
                            },
                            {
                                status: 'success',
                                title: 'success'
                            },
                            {
                                status: 'default',
                                title: 'default'
                            }
                        ],
                        size: 'medium'
                    };
                }]);
 </file>
 </example>
 */
angular.module("RA.IPComponents")
    .component("raIpSteps", {
        template: ['$templateCache', function ($templateCache) {
                "use strict";
                return $templateCache.get('components/raIpSteps/raIpSteps.tpl.html');
            }
        ],
        bindings: {
            config: "<"
        },
        controller: [
            function () {
                "use strict";
                var self = this;

                function normalizeConfig() {
                    self.config = self.config || {};
                    self.config.size = self.config.size || 'medium';
                    self.config.type = self.config.type || 'numeric';
                    self.config.theme = self.config.theme || 'rockwell';
                    self.config.orientation = 'horizontal';
                    self.config.autofillConnector = angular.isDefined(self.config.autofillConnector) ?
                        self.config.autofillConnector : false;
                    self.config.steps = self.config.steps || [];
                    self.config.disableStatusColor = angular.isDefined(self.config.disableStatusColor) ?
                        self.config.disableStatusColor : false;
                }

                // init section
                normalizeConfig();
                self.statusIcons = {
                    error: 'ra-icon-clear',
                    success: 'ra-icon-commit',
                    warning: 'ra-icon-warning'
                };
            }
        ]
    });
