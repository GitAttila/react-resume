/*
 * (c) Rockwell Automation 2017
 */
/*global angular*/
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpColumn
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering columns body. Column body component has predefined logic to
 * divide items to columns. Parameter hidden allows to hide whole item in a column. For icon is used raIpBadge.
 *
 * @param {object}
 * - **`numberOfColumns`** {int} columns number of columns
 * - **`items`** {Array} items
 *      - **`label`** {string}
 *      - **`value`** {string} or [array] raIpBadge {@link RA.IPComponents.component:raIpBadge}
 *      - **`hidden`** {bool} to hide
 *
 @example

 <example module="example1">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-column config="config"></ra-ip-column>
        </div>
    </file>
    <file name="script.js">
        angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1')
            .controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        numberOfColumns: 3,
                        items: [
                            {
                                label: "label 1",
                                value: "value 1"
                            },
                            {
                                label: "label 2",
                                value: "value 2"
                            },
                            {
                                label: "label 3",
                                value: "value 3"
                            },
                            {
                                label: "label 4",
                                value: "value 4"
                            },
                            {
                                label: "label 5",
                                value: [
                                    {
                                        class: "ra-icon-home",
                                        badgeNumber: 2,
                                        size: "small"
                                    },
                                    {
                                        class: "ra-icon-clear",
                                        tooltip: "tooltip text",
                                        badgeNumber: 2,
                                        size: "medium"
                                    },
                                    {
                                        class: "ra-icon-edit",
                                        disabled: true,
                                        badgeNumber: 2,
                                        size: "large"
                                    }
                                ]
                            },
                            {
                                label: "label 6",
                                value: ""
                            }
                        ]
                    }
                }]);
 </file>
 </example>
 */
angular.module("RA.IPComponents")
    .component("raIpColumn", {
        templateUrl: "components/raIpColumn/raIpColumn.tpl.html",
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';

            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
                self.config.items = self.config.items || [];
            }

            normalizeConfig();

            self.columns = splitItemsToCols(spliceHiddenItems(self.config.items), self.config.numberOfColumns);

            /**
             * @description split array to the columns
             * @param {Array} items
             * @return {array} split items into array by columns
             */
            function splitItemsToCols(items, numberOfColumns) {
                var usedLength = 0,
                    splitItems = [];
                if (numberOfColumns > 1) {

                    for (var i = numberOfColumns; i > 0; --i) {
                        var itemPerColumn = Math.ceil((items.length - usedLength) / i);
                        splitItems.push(items.slice(usedLength, usedLength + itemPerColumn));
                        usedLength += itemPerColumn;
                    }

                } else {
                    splitItems.push(items);
                    self.columns = 1;
                }

                return splitItems;
            }

            /**
             * @description function to check if item.value is array to set item.icon visualization
             * @param item
             */
            function checkIconValue(item) {
                if (angular.isArray(item.value)) {
                    item.icon = true;
                }
            }

            /**
             * @description function to add to value - if the value is empty or undefined
             * @param item
             */
            function checkEmptyValues(item) {
                if (item.value === undefined || item.value === "") {
                    item.value = "-";
                }
            }

            /**
             * @description remove hidden items from array
             * @param {Array} all items
             * @return {Array} items without hidden
             */
            function spliceHiddenItems(items) {
                var spliceArray = [];
                for (var i = 0; i < items.length; ++i) {
                    if ((angular.isDefined(items[i].hidden) && !items[i].hidden) ||
                        angular.isUndefined(items[i].hidden)) {
                        checkIconValue(items[i]);
                        checkEmptyValues(items[i]);
                        spliceArray.push(items[i]);
                    }
                }
                return spliceArray;
            }
        }]
    });
