/* (c) Rockwell Automation 2016 */
/*global angular*/

//disable jshint line length for these api comments, some are required to be long for formatting
//reenabled after these comments.
/* jshint -W101 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpFilterSearch
 * @module RA.IPComponents
 *
 * @param {array} filters An array of objects representing filter and
 * its configuration. When no filter is choosen, callback will be called with default filter 'all' (search in all properties).
 *
 * | Property                       | Type             | Details                                                                   | Default value                                                                           |
 * |------------------------------- |------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
 * | icon (optional)                | {@type String}   | CSS class of the filter icon                                              | undefined                                                                               |
 * | name                           | {@type String}   | Unique name of filter, will be used as ID                                 | undefined                                                                               |
 * | label (optional)               | {@type String}   | Filter label will be visible in filter options menu                       | same as name                                                                            |
 * | color (optional)               | {@type String}   | Background color of filter icon                                           | undefined                                                                               |
 * | placeholder (optional)         | {@type String}   | Input placeholder                                                         | undefined                                                                               |
 *
 * @param {boolean} doConfirm Does user has to confirm search query by clicking enter or check icon? //default: false
 * @param {number} delay Time in ms after which callback function will be called, if query length is same or higher than minChars. //default: 300
 * @param {number} debounce Input debounce in ms. //default: 1000
 * @param {number} minChars Minimal number of chars after which callback function will be called. //default: 1
 * @param {string} mode ('basic'/'string'/'advanced') Which mode to use. //required
 * @param {boolean} reset Only in advanced mode. If chosen filter should reset to default after sending callback.
 * @param {boolean} whisperLastQuery Only in string mode. Should apply whisper only to last keyword in input. //default: false
 * @param {object} buttons Makes buttons visible/invisible. They are visible by default.
 *
 * | Property                       | Type             | Details                                                                   | Default value                                                                           |
 * |------------------------------- |------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
 * | okButton                       | {@type Boolean}  | Visible?                                                                  | true                                                                                    |
 * | cancelButton                   | {@type Boolean}  | Visible?                                                                  | true                                                                                    |
 *
 * @param {number} default Only for advanced mode. Index of default filter from filters array. //default: 0 (first element in array)
 * @param {function} callback Function which handles filter action. Query is provided as attribute. When no filter is chosen, it get filter with name 'all' //required
 * @param {function} whispers Function which returns whisper for given search query. Query is provided as attribute. Only when combineFilters.
 * @param {function} setApi Function which sets api to control filter. Has only one method - reinit. It can be used to reinitialize filter in different mode.
 *
 * @description
 * The component filters data, it has multiple modes, and filter methods have to be provided by user. Filter has three modes. Basic without combining filters, combining filters using input element and custom combining.
 *
 * ## Basic mode – fulltext search
 * Very basic fulltext search. No menu to choose filter options. No keywords can be used in input line. Callback function has to be provided.
 Argument to callback function ($ctrl.callback) example:
 * <pre>
 * queryData: [{
 *     name: 'all',
 *     query: "controller"
 * }]
 * </pre>
 *
 * ## String mode – keywords in input
 * After clicking on filter option, its name will be added to input line. User can write query after that string. Multiple filters can be added. E.g. “name:text category:basic name:field”. Filter results depend on filter implementation. Query can be erased by clicking cancel icon. Default is fulltext search without option choosen.
 * Argument to callback function ($ctrl.callback) example:
 * <pre>
 * queryData: [{
 *     name: "name",
 *     query: "ellipse"
 * },{
 *     name: "category",
 *     query: "general"
 * }]
 * </pre>
 *
 * ## Advanced mode – custom implementation of graphic representation of active filters
 * After clicking on filter option, user can write query which belongs only this filter, after clicking on another filter option and writing another query, this query will be overwritten. After clicking on enter or checkmark, data will be sent to callback function which handles the search.
 * Argument to callback function ($ctrl.callback) example:
 * <pre>
 * queryData: [{
 *     name: "name",
 *     query: "controller"
 * }]
 * </pre>
 *
 * ## Cancel callback
 * When user clicks on cancel button, callback is send in this format:
 * <pre>
 * queryData: [{
 *     cancel: true
 * }]
 * </pre>
 *
 *
 * ## delay and minChars
 * When not specified delay will be set to 300ms and minChars to 1. Whispers will be activated when query >= minChars. Callback will be activated when query >= minChars and after delay.
 *
  @example
  <example module="example1">
   <file name="style.css">
    label { margin: 0 2px 0 5px; }
   </file>
   <file name="index.html">
     <div ng-controller="raIpFilterSearchCtrl">
     <ra-ip-filter-search filters="filters" default="default" do-confirm="doConfirm" delay="delay" debounce="debounce" min-chars="minChars" mode="mode" placeholder="placeholder" reset="reset" callback="callback(query)" whispers="whispers(query)" whisper-last-query="whisperLastQuery" set-api="setApi(api)"></ra-ip-filter-search>
     <h4 ng-show="results">Filtered results:</h4>
         <ul class="search-results">
            <li ng-repeat="result in results">{{result}}</li>
         </ul>
         <h4>Configuration</h4>
             <div>
                 <label for="doConfirm">doConfirm</label>
                 <input id="doConfirm" type="checkbox" ng-model="doConfirm">
                 <label for="delay">delay</label>
                 <input id="delay" type="number" min="0" ng-model="delay">
                 <label for="minChars">minChars</label>
                 <input id="minChars" type="number" min="0" ng-model="minChars">
             </div>
             <div>
                <label for="mode">mode</label>
                 <select id="mode" ng-model="mode" ng-change="api.reinit(mode)">
                 <option value="basic">Basic</option>
                 <option value="string">String</option>
                 <option value="advanced">Advanced</option>
                 </select>
                 <label for="whisperLastQuery">whisperLastQuery</label>
                 <input id="whisperLastQuery" type="checkbox" ng-model="whisperLastQuery">
                 <label for="reset">reset</label>
                 <input id="reset" type="checkbox" ng-model="reset">
             </div>
         <h4>Array of objects to filter:</h4>
         <pre>{{array | json}}</pre>

         <h4>Push item to array</h4>
         <label for="objName">name:</label>
         <input id="objName" type="text" ng-model="objName">
         <label for="objCat">category:</label>
         <input id="objCat" type="text" ng-model="objCat">
         <button ng-click="array.push({name: objName, category: objCat})">Push</button>
         <h4>Delete item from array</h4>
         <label for="objId">ID</label>
         <input id="objId" type="number" min="0" ng-model="objId">
         <button ng-click="array.splice(objId,1)">Delete</button>
     </div>
   </file>
   <file name="script.js">
       angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
       angular.module('example1')
       .controller('raIpFilterSearchCtrl', ['$scope', '$q',
       function ($scope, $q) {
        $scope.filters = [
            {
                icon: 'ra-icon-home',
                name: 'name',
                label: 'Name',
                color: 'orange',
                placeholder: 'Type sth...'
            },
            {
                icon: 'ra-icon-information',
                name: 'category',
                label: 'Category',
                color: 'blue',
                placeholder: 'Type some desc...'
            }
        ];
        $scope.default = undefined;
        $scope.doConfirm = true;
        $scope.reset = true;
        $scope.delay = 2000;
        $scope.debounce = 500;
        $scope.minChars = 3;
        $scope.mode = 'basic';
        $scope.placeholder = 'Type something.';
        $scope.whisperLastQuery = true;
        $scope.array = [{
            name: 'Controller',
            category: 'Allen Bradley'
        },
        {
            name: 'Ellipse',
            category: 'Basic'
        },
        {
            name: 'Text',
            category: 'Basic'
        },
        {
            name: 'Text Field',
            category: 'Basic'
        },
        {
            name: 'Numeric',
            category: 'Basic'
        },
        {
            name: 'Ball Valve Wheel',
            category: 'General Equipment'
        },
        {
            name: 'Tank',
            category: 'General Equipment'
        }];
        $scope.callback = function (queryData) {
            if (queryData[0].cancel) {
                $scope.results = [];
                return;
            }
            var queries = {};
            var results = $scope.array;
            angular.forEach(queryData, function(filter) {
                queries[filter.name] = queries[filter.name] || [];
                queries[filter.name].push(filter.query);
            });
            angular.forEach(queries, function (queries, filter) {
                if (filter !== 'all') {
                    results = results.filter(function (it) {
                        var found = false;
                        angular.forEach(queries, function(query) {
                            if (it[filter].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
                                found = true;
                            }
                        });
                        return found;
                    });
                } else {
                    var newResults = [];
                    angular.forEach(results, function (item) {
                        var found = false;
                        angular.forEach(item, function (prop, key) {
                            var foundInItem = false;
                            angular.forEach(queries, function(query) {
                                if (it[filter].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
                                    foundInItem = true;
                                }
                            });
                            if (key !== '$$hashKey' && foundInItem && !found) {
                                newResults.push(item);
                                found = true;
                            }
                        });
                    });
                    results = newResults;
                }
            });
            $scope.results = results;
        };
        $scope.whispers = function (queryData) {
            var deferred = $q.defer(),
                queries = {},
                results = $scope.array,
                props = [],
                lastQuery = queryData[queryData.length - 1];

            angular.forEach(queryData, function(filter) {
                queries[filter.name] = queries[filter.name] || [];
                queries[filter.name].push(filter.query);
            });
            angular.forEach(queries, function (queries, filter) {
                if (filter !== 'all') {
                    results = results.filter(function (it) {
                        var found = false, reject = false;
                        angular.forEach(queries, function(query) {
                            if (it[filter].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
                                found = true;
                            } else if (query === lastQuery.query && filter === lastQuery.name) {
                                reject = true;
                            }
                        });
                        return found && !reject;
                    });
                } else {
                    var newResults = [];
                    angular.forEach(results, function (item) {
                        var found = false;
                        angular.forEach(item, function (prop, key) {
                            var foundInItem = false, rejectItem = false;
                            angular.forEach(queries, function(query) {
                                if (item[key].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
                                    foundInItem = true;
                                } else if (query === lastQuery.query && key === lastQuery.name) {
                                    rejectItem = true;
                                }
                            });
                            if (key !== '$$hashKey' && foundInItem && !rejectItem && !found) {
                                newResults.push(item);
                                props.push(prop);
                                found = true;
                            }
                        });
                    });
                    results = newResults;
                }
            });
            if (lastQuery.name !== 'all') {
                angular.forEach(results, function (item) {
                    props.push(item[lastQuery.name]);
                });
            }
            deferred.resolve({
                header: 'search',
                results: _.uniq(props)
            });
            return deferred.promise;
        };
        $scope.setApi = function(api) {
            $scope.api = api;
        };
       }]);
   </file>
  </example>
 */
/* jshint +W101 */

angular.module('RA.IPComponents')
.component('raIpFilterSearch', {
    templateUrl: 'components/raIpFilterSearch/raIpFilterSearch.tpl.html',
    bindings: {
        filters: '<',
        default: '<',
        doConfirm: '<',
        delay: '<',
        minChars: '<',
        mode: '<',
        whisperLastQuery: '<',
        buttons: '<',
        reset: '<',
        debounce: '<',
        placeholder: '<',
        callback: '&',
        whispers: '&',
        setApi: '&'
    },
    controller: ['$timeout', '$window', '$scope', '$element', 'raErrorHandlerSvc',
        function ($timeout, $window, $scope, $element, raErrorHandlerSvc) {
        'use strict';

        var self = this;

        var searchAll = {
            name: 'all',
            query: ''
        };

        self.defaultColor = 'grey';
        self.default = self.default || 0;
        self.buttons = self.buttons || {};
        self.okButton = self.buttons.okButton;
        self.cancelButton = self.buttons.cancelButton;
        self.currentPlaceholder = self.placeholder;

        if (self.okButton === undefined) {
            self.okButton = true;
        }
        if (self.cancelButton === undefined) {
            self.cancelButton = true;
        }
        if (self.delay === undefined) {
            self.delay = 300;
        }
        if (self.minChars === undefined) {
            self.minChars = 1;
        }
        if (self.debounce === undefined) {
            self.debounce = 1000;
        }

        self.modelOptions = {
            debounce: self.debounce
        };

        /**
         * @description Function to return if filter is configured correctly.
         * @returns {Boolean}
         */
        function areFiltersValid() {
            if (!self.doConfirm && !self.delay && !self.minChars) {
                return false;
            }
            var invalid;
            switch (self.mode) {
                case 'basic':
                    break;
                case 'string':
                    if (angular.isArray(self.filters) && self.filters.length > 0) {
                        invalid = false;
                        angular.forEach(self.filters, function (filter) {
                            if (typeof filter.name !== 'string') {
                                invalid = true;
                            }
                        });
                        if (invalid) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                    break;
                case 'advanced':
                    if (angular.isArray(self.filters) && self.filters.length > 0) {
                        invalid = false;
                        angular.forEach(self.filters, function (filter) {
                            if (typeof filter.name !== 'string' || typeof filter.icon !== 'string') {
                                invalid = true;
                            }
                        });
                        if (invalid) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                    break;
                default:
                    return false;
            }
            return true;
        }

        /**
         * @description Function sets initial values.
         */
        function setInitialValues() {
            self.active = undefined;
            if (self.mode === 'advanced') {
                self.active = self.filters[self.default];
                self.currentPlaceholder = self.active.placeholder;
                self.queryData = [{
                    name: self.active.name,
                    query: ''
                }];
            } else {
                self.queryData = [angular.copy(searchAll)];
                self.currentPlaceholder = self.placeholder;
            }
            self.showOptions = false;
            self.whisperData = undefined;
            self.query = '';
            self.iconsSet = self.filters.some(function (filter) {
                return !!filter.icon;
            });
        }

        /**
         * @description Function gets cursor position. Zero means cursor is behind first letter.
         * @returns {Number} Cursor position
         */
        function getCursorPosition() {
            var input = $element.find('input').get(0);
            if ('selectionStart' in input) {
                // Standard-compliant browsers
                return input.selectionStart - 1;
            } else if (document.selection) {
                // IE
                input.focus();
                var sel = document.selection.createRange();
                var selLen = document.selection.createRange().text.length;
                sel.moveStart('character', -input.value.length);
                return sel.text.length - selLen - 1;
            }
        }

        /**
         * @description Function sets cursor position.
         * @param {Number} pos Cursor position
         */
        function setCursorPosition(pos) {
            var input = $element.find('input').get(0);
            if (input.setSelectionRange) {
                input.setSelectionRange(pos, pos);
            } else if (input.createTextRange) {
                var range = input.createTextRange();
                range.collapse(true);
                range.moveEnd('character', pos);
                range.moveStart('character', pos);
                range.select();
            }
        }

        /**
         * @description Function to initialize component.
         * @returns {Boolean} Initialized correctly
         */
        self.init = function () {
            if (areFiltersValid()) {
                setInitialValues();
                return true;
            }
        };

        if (!self.init()) {
            throw new raErrorHandlerSvc.RAError('Config exception', 'raIpFilterSearch component was configured badly');
        } else {
            /**
             * @description Function handles selection of filter option.
             * @param {Object} option Filter option
             */
            self.optionClick = function (option) {
                self.showOptions = false;
                switch (self.mode) {
                    case 'string':
                        if (self.query === '') {
                            self.query = option.name + ':';
                        } else {
                            self.query += ' ' + option.name + ':';
                        }
                        $element.find('input')[0].focus();
                        break;
                    case 'advanced':
                        if (!self.active || self.active.name !== option.name) {
                            self.active = option;
                            self.currentPlaceholder =
                                option.placeholder === undefined ? self.placeholder : option.placeholder;
                            self.query = '';
                            self.queryData = [{
                                name: self.active.name,
                                query: ''
                            }];
                        }
                        break;
                }
                self.inputActive = true;
                self.write();
            };
            /**
             * @description Function toggles filter options menu.
             */
            self.toggleOptions = function () {
                self.showOptions = !self.showOptions;
                self.whisperObj = undefined;
            };

            /**
             * @description Function deactivates filter and sets initial values.
             */
            self.cancel = function () {
                setInitialValues();
                self.inputActive = false;
                self.whisperObj = undefined;
                self.callback({query: [{cancel: true}]});
            };

            /**
             * @description Function handles selecting whisper from whispers dropdown.
             */
            self.whisperClick = function (whisper) {
                if (self.mode === 'string') {
                    var trimIndex = getCursorPosition();
                    var curPos = trimIndex;
                    for (var i = curPos; i >= 0; i--) {
                        if (self.query[i] === ':' || self.query[i] === ' ') {
                            break;
                        }
                        trimIndex--;
                    }
                    self.query = self.query.slice(0, trimIndex + 1) + whisper + self.query.slice(curPos + 1);
                } else {
                    self.query = whisper;
                }
                self.write(true);
            };

            /**
             * @description Function handles query change. Edited filter (where is actually cursor) is at the end.
             * @param {Boolean} confirm Flag indicating whether query was explicitly confirmed. If so, callback will
             * @param {Boolean} onlyWhispers Flag indicating whether just whispers have to be updated and not callback
             * evoked.
             * be sent without looking at minChars and delay parameters.
             */
            self.write = function (confirm, onlyWhispers) {
                /**
                 * @description Function parses query in string mode, creates array. Active object is last.
                 * @param {Boolean} str Query string to parse.
                 * @returns {Array} Active filters.
                 */
                var parse = function (str) {
                    var parts = str.split(' '),
                        cursorPos = getCursorPosition(),
                        active = 'all',
                        filters = [],
                        namesEqual = function (filter) { return active === filter.name; },
                        editedWord,
                        editedFilter;

                    //save edited element
                    var word = '', wordIndex = 0;
                    for (var i = 0; i < str.length; i++) {
                        if (i === cursorPos) {
                            editedWord = wordIndex;
                            break;
                        }
                        if (str[i] === ' ') {
                            wordIndex++;
                        } else {
                            word += str[i];
                        }
                    }

                    for (i = 0; i < parts.length; i++) {
                        if (parts[i].lastIndexOf(':') > -1) {
                            active = parts[i].split(':')[0];
                            parts[i] = parts[i].split(':')[1];
                        }

                        if (!parts[i]) { continue; }

                        if (self.filters.some(namesEqual) || active === 'all') {
                            if (i === editedWord) {
                                editedFilter = {
                                    name: active,
                                    query: parts[i]
                                };
                            } else {
                                filters.push({
                                    name: active,
                                    query: parts[i]
                                });
                            }
                        }
                    }

                    filters.push(editedFilter);

                    return filters;
                };
                /**
                 * @description Function invokes callback function defined by user.
                 * @param {Boolean} hideWhispers Whispers dropdown will be hidden.
                 */
                var callback = function (hideWhispers) {
                    switch (self.mode) {
                        case 'basic':
                            self.queryData[0].query = self.query;
                            self.callback({query: self.queryData});
                            break;
                        case 'string':
                            var queryObj = parse(self.query);
                            if (queryObj.length) {
                                self.callback({query: queryObj});
                            }
                            self.queryData = [angular.copy(searchAll)];
                            break;
                        case 'advanced':
                            self.callback({query: self.queryData});
                            if (self.mode === 'advanced' && self.reset && confirm &&
                                self.active.name !== self.filters[self.default].name) {
                                self.optionClick(self.filters[self.default]);
                            }
                            break;
                    }
                    if (hideWhispers) {
                        self.whisperObj = undefined;
                    }
                };

                var value = self.query;

                var checkQueryLength = function () {
                    if (self.mode === 'string') {
                        var curPos = getCursorPosition(), word = '';
                        for (var i = curPos; i >= 0; --i) {
                            if (value[i] === ':' || value[i] === ' ') {
                                break;
                            } else {
                                word += value[i];
                            }
                        }
                        for (i = curPos; i < value.length; i++) {
                            if (value[i] === ' ') {
                                break;
                            } else if (value[i] === ':') {
                                word = '';
                                break;
                            }
                        }
                        return word.length >= self.minChars;
                    } else {
                        return value.length >= self.minChars;
                    }
                };

                var greaterOrEqualMinChars = checkQueryLength();
                if (value === undefined || value === "" || !greaterOrEqualMinChars ||
                    value[value.length - 1] === ":") {
                    self.whisperObj = undefined;
                }
                if (!onlyWhispers) {
                    self.inputActive = true;
                }
                self.showOptions = false;

                switch (self.mode) {
                    case 'basic':
                        self.queryData[0].query = self.query;
                    /* falls through */
                    case 'string':
                        if (self.query === '' && !onlyWhispers) {
                            self.cancel();
                        }
                        break;
                    case 'advanced':
                        if (self.query.length && self.query.indexOf(':') === self.query.length - 1) {
                            var name = self.query.split(':')[0];
                            angular.forEach(self.filters, function (filter) {
                                if (name === filter.name) {
                                    self.query = '';
                                    self.optionClick(filter);
                                }
                            });
                        }
                        self.queryData[self.queryData.length - 1].query = self.query;
                        break;
                }
                if (greaterOrEqualMinChars && !confirm) {
                    self.selectedWhisper = -1;
                    switch (self.mode) {
                        case 'basic':
                            self.queryData[0].single = true;
                            self.whispers({query: self.queryData}).then(
                                function success(response) {
                                    self.whisperObj = response;
                                }
                            );
                            break;
                        case 'string':
                            var queryData = parse(self.query),
                                lastQuery = [queryData[queryData.length - 1]];
                            if (self.whisperLastQuery && lastQuery[0]) {
                                lastQuery[0].single = true;
                            }
                            if (lastQuery[0]) {
                                self.whispers({query: self.whisperLastQuery ? lastQuery : queryData}).then(
                                    function success(response) {
                                        self.whisperObj = response;
                                    }
                                );
                            }
                            break;
                        case 'advanced':
                            var data = [{
                                name: self.active.name,
                                query: self.query,
                                single: true
                            }];
                            self.whispers({query: data}).then(
                                function success(response) {
                                    self.whisperObj = response;
                                }
                            );
                            break;
                    }
                }
                if (onlyWhispers) { return; }
                if (confirm) {
                    callback(true);
                } else if (!self.doConfirm && greaterOrEqualMinChars) {
                    $timeout(callback, self.delay);
                }
            };

            /**
             * @description Function handles keypress events.
             * @param {Object} event
             */
            self.onKeyPress = function (event) {
                switch (event.keyCode) {
                    case 8: //backspace
                        var curPos = getCursorPosition(), startTrim;
                        //deactivates filter
                        if (self.query === '') {
                            self.cancel();
                        }
                        //deletes whole filter option from query
                        else if (self.query[curPos] === ':') {
                            self.searchForm.$commitViewValue();
                            for (var i = curPos; i >= 0; i--) {
                                if (self.query[i] === ' ') {
                                    startTrim = i + 1;
                                    break;
                                }
                            }
                            if (startTrim === undefined) {
                                self.query = '';
                                self.cancel();
                            } else {
                                self.query = self.query.slice(0, startTrim) + self.query.slice(curPos + 1);
                                $timeout(function () {
                                    setCursorPosition(startTrim);
                                });
                            }
                            event.preventDefault();
                        }
                        break;
                    case 13: //enter
                        self.modelOptions.debounce = 0;
                        self.searchForm.$commitViewValue();
                        //ordinary whisper selected
                        if (self.whisperObj && self.whisperObj.results.length > 0 && self.selectedWhisper !== -1) {
                            self.whisperClick(self.whisperObj.results[self.selectedWhisper]);
                        }
                        //confirm query or whispers header selected
                        else {
                            self.write(true);
                            self.whisperObj = undefined;
                        }
                        $timeout(function () {
                            self.modelOptions.debounce = self.debounce;
                        });
                        break;
                    case 27: //esc
                        //deactivates filter
                        self.cancel();
                        break;
                    case 38: //up
                        //move selection in whispers dropdown one place up
                        if (self.whisperObj && self.whisperObj.results.length > 0 && self.selectedWhisper !== -1) {
                            self.selectedWhisper--;
                        }
                        event.preventDefault();
                        break;
                    case 40: //down
                        //move selection in whispers dropdown one place down
                        if (self.whisperObj && self.whisperObj.results.length > 0 &&
                            self.selectedWhisper !== self.whisperObj.results.length - 1)
                        {
                            self.selectedWhisper++;
                        }
                        event.preventDefault();
                        break;
                    default:
                        $timeout(function () {
                            self.write(false, true);
                        });
                }
            };

            if (angular.isFunction(self.setApi)) {
                self.api = {
                    /**
                     * @description Function reinitializes filter in chosen mode.
                     * @param {String} mode
                     */
                    reinit: function (mode) {
                        self.mode = mode;
                        self.cancel();
                        self.init();
                    }
                };
                self.setApi({api: self.api});
            }

            var doc = $(document);
            /**
             * @description Function handles click event. When user clicks outside of dropdown, this dropdown should
             * close. But not if user clicks on dropdown menu or toggle buttons.
             * @param {Object} event
             */
            doc.click(function (event) {
                $scope.$apply(function () {
                    var clickedOnDropdown = function (target) {
                        return target.is($element.find('.ra-icon-drop-down')) ||
                            target.is($element.find('.filter-icon')) || target.is($element.find('.filter-options')) ||
                            target.closest($element.find('.filter-options')).length ||
                            target.is($element.find('.dropdown-menu')) ||
                            target.closest($element.find('.dropdown-menu')).length;
                    };
                    var target = $(event.target);
                    if (clickedOnDropdown(target)) {
                        event.preventDefault();
                        return;
                    }
                    if (self.showOptions) {
                        self.showOptions = false;
                    } else if (self.whisperObj && self.whisperObj.results.length > 0 && !self.showOptions &&
                        !target.is($element.find('input'))) {
                        self.whisperObj = undefined;
                    }
                });
            });
            /**
             * @description Function handles keydown event. Close dropdowns on esc press.
             * @param {Object} event
             */
            doc.keydown(function (event) {
                $scope.$apply(function () {
                    if (event.keyCode === 27) { //esc
                        self.showOptions = false;
                        self.whisperObj = undefined;
                    }
                });
            });

            $scope.$on('$destroy', function () {
                doc.unbind('click');
                doc.unbind('keydown');
            });

        }

    }]
});
