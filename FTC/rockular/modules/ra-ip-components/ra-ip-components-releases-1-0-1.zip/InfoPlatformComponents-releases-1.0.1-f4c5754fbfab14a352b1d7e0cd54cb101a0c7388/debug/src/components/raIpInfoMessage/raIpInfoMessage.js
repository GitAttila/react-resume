/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpInfoMessage
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering no data message with action button. The component expects to receive
 * {object} **`config`**.
 * @param {object} config
 * - **`class`** {string}
 * - **`text`** {string} text message
 * - **`action`** {object} raIpActions component.
 *      See also {@link RA.IPComponents.component:raIpActions}.
 * @example

 <example module="example1">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-info-message config="config"></ra-ip-info-message>
        </div>
    </file>
 <file name="script.js">
     angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1').controller('myCtrl',['$scope',
            function($scope) {
                $scope.config = {
                   text: "No data message.",
                   action: {
                        align: 'center',
                        actions: [
                            {
                                class: 'ra-btn-primary',
                                disabled: false,
                                onAction: function() {
                                    alert("Called function");
                                },
                                value: 'Some text',
                                size: 'small'
                            }
                        ]
                    }
                };
            }
        ]);
 </file>
 </example>
*/
/* global angular */
angular.module('RA.IPComponents')
    .component('raIpInfoMessage', {
        templateUrl: 'components/raIpInfoMessage/raIpInfoMessage.tpl.html',
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';
            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
                self.config.size = self.config.size || "medium";
            }

            normalizeConfig();

            /**
             * @description onClick function to check if the action is function
             * @param action
             */
            self.invokeDoAction = function (action) {
                if (typeof action.onAction === 'function') {
                    action.onAction();
                }
            };
        }]
    });
