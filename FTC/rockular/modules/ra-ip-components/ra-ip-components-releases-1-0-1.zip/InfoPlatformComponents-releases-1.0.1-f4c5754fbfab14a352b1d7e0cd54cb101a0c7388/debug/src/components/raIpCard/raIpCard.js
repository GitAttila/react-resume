/*
 * (c) Rockwell Automation 2017
 */

/* global angular */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpCard
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering card. It allows to put inside another component. Card is only wrapper
 * with hover effect which can be disabled.
 *
 * @param {Object} config
 *  - **`class`** {string} to add specific class
 *  - **`disabledHover`** {boolean} to disable hover effect

 @example
 Example of card component with hover effect.
  <example module="example1">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-card>Card content</ra-ip-card>
        </div>
    </file>

    <file name="script.js">
       angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1')
            .controller('myCtrl',['$scope',
                function() {}
        ]);
    </file>
 </example>

 Example of card component without hover effect.
 <example module="example2">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-card config="config">
            Card content
            </ra-ip-card>
        </div>
    </file>

     <file name="script.js">
        angular.module('example2', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example2')
            .controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        disabledHover: true
                    }
                }
            ]);
     </file>
 </example>

 Example of card component with body content.
 <example module="example3">
     <file name="index.html">
         <div ng-controller="myCtrl">
            <ra-ip-card config="config">
                <div style="padding: 15px;">Body content</div>
            </ra-ip-card>
         </div>
     </file>

     <file name="script.js">
         angular.module('example3', ['mobile-toolkit-ra', 'RA.IPComponents']);
         angular.module('example3')
            .controller('myCtrl',['$scope',
                function() {}
         ]);
     </file>
 </example>
 */


/* global angular */
angular.module("RA.IPComponents")
    .component("raIpCard", {
        templateUrl: "components/raIpCard/raIpCard.tpl.html",
        transclude: true,
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            "use strict";
        }]
    });
