/* global angular */

angular.module('RA.IPComponents').factory('contextMenuSvc', [ '$window',
    function ($window) {
        'use strict';

        var contextMenuSelectorsList = [];//list for all used by context menus selectors

        /**
         * Function used as "position" config parameter of jQuery Context menu.
         * @param {Object} menuOptions
         * @param {number} x The horizontal absolute position of clicked element or point (if right-clicked)
         * @param {number} y The vertical absolute position of clicked element or point (if right-clicked)
         */
        var positionMainMenu = function (menuOptions, x, y) {
            var winHeight = $window.innerHeight,
                winWidth = $window.innerWidth,
                menuHeight = menuOptions.$menu.outerHeight(true),
                menuWidth = menuOptions.$menu.outerWidth(true),
                menuTop,
                menuLeft,
            //small horizontal offset to avoid situation with opened context menu
            // and immediately selected option which is under clicked place
            //This situation happens only on right-click.
                xOffset = 2;

            //Calculating top position
            //most comfortable top menu position is in the middle of y
            menuTop = y - Math.round(menuHeight / 2);

            if (menuTop + menuHeight > winHeight) {
                //bottom edge of menu is below app window frame
                //so trying to position it higher (starting from bottom)
                menuTop = winHeight - menuHeight;
            }

            // check weather top edge of menu is higher than window
            if (menuTop < 0) {
                menuTop = 0;
            }

            if (menuTop + menuHeight > winHeight) {
                //there is really no place for whole menu.
                //  In this case positioning menu to equally protrude at the top and bottom
                menuTop = Math.round((winHeight - menuHeight) / 2);
            }

            //Calculating left position
            menuLeft = x + xOffset;// most expected position would be to have menu on right side
            if (menuLeft + menuWidth > winWidth) {
                //no space on the right so positioning on the left
                menuLeft = x - menuWidth - xOffset;
            }
            //not checking whether there is no space on the left,
            // cause we shouldn't cover the clicked point

            menuOptions.$menu.css({top: menuTop, left: menuLeft});
        };
        /**
         * Function used as "positionSubmenu" config parameter of jQuery Context menu.
         * It isn't officially documented
         * @param subMenu Current submenu element
         */
        var positionSubmenu = function sub(subMenu) {
            //Code mostly ripped off from jQuery.contextMenu.js/positionSubmenu function.
            //"this" here points to the context of currently selected LI element
            var offset,
                curLiAbsoluteOffset = this.offset(),
                menuHeight = subMenu.outerHeight(true),
                winHeight = $window.innerHeight,
                winWidth = $window.innerWidth;

            //open submenu on the left side, if it overflows the body of page
            if (this.parent()[0].offsetLeft + this.outerWidth() + this.children("ul").outerWidth() > winWidth) {
                offset = {
                    top: 0,
                    left: -this.children("ul").outerWidth()
                };
            } else {
                offset = {
                    top: 0,
                    left: this.outerWidth()
                };
            }

            //this is extension of original positionSubmenu implementation
            // It protects submenu from protruding beyond the window at the bottom.
            if (menuHeight + curLiAbsoluteOffset.top > winHeight) {
                offset.top = winHeight - (menuHeight + curLiAbsoluteOffset.top);
            }

            subMenu.css(offset);
        };

        /**
         * Creates jQuery contextMenu
         * @param {string} selector The jQuery selector
         * @param {object} contextMenuConfig The context menu config object
         */
        var addNewContextMenu = function (selector, contextMenuConfig) {

            angular.extend(contextMenuConfig, {
                position: positionMainMenu,
                positionSubmenu: positionSubmenu
            });

            $.contextMenu({
                selector: selector,
                //uses build function to return config object
                // which creates/destroys context menu DOM on demand.
                //Probably better approach, at least easier to use in this function.
                //Nevertheless we MUST properly destroy each configured contextMenu on component destroy.
                //search for "build" in http://medialize.github.io/jQuery-contextMenu/docs.html
                build: function () {
                    return contextMenuConfig;
                }
            });
            contextMenuSelectorsList.push(selector);
        };

        /**
         * Destroys all previously created context jQuery contextMenus
         */
        var destroyCreatedContextMenus = function () {
            angular.forEach(contextMenuSelectorsList, function (theSelector) {
                $.contextMenu('destroy', theSelector);
            });
        };

        /**
         * Destroys contextMenu with particular selector
         */
        var destroyContextMenu = function (selector) {
            $.contextMenu('destroy', selector);
        };


        return {
            addNewContextMenu: addNewContextMenu,
            destroyContextMenu: destroyContextMenu,
            destroyCreatedContextMenus: destroyCreatedContextMenus
        };
    }
]);

