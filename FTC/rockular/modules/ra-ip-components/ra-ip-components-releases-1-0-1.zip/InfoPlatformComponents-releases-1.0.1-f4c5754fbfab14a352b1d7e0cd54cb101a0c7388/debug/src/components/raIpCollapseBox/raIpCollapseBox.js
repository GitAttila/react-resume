/*
 * (c) Rockwell Automation 2017
 */

/* global angular */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpCollapseBox
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering the collapse box. The collapse box expects to receive a object
 * with some parameters and it is possible to add icons or buttons which will be shown in the header of collapse box.
 *
 * @param {Object} config
 * - **`theme`** {string} class theme definition: light, dark, rockwell
 * - **`shadow`** {boolean} shadow
 * - **`defaultClosed`** {boolean} default state of the collapse box
 * - **`disableCollapse`** {boolean} to disable collapsible functionality
 * - **`hideHeader`** {boolean} to hide header bar of the collapse box
 * - **`hideBorder`** {boolean} to hide border of the collapse box
 * - **`header`** {object} raIpHeader component.
 *      See also {@link RA.IPComponents.component:raIpHeader}.
 * - **`action`** {object} raIpActions component.
 *      See also {@link RA.IPComponents.component:raIpActions}.
 @example

 Example of Collapse box to show usage with individual content.
 <example module="example1">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-collapse-box config="config">
                <div style="padding: 15px; text-align: center;">
                    Body of the collapse box. It is possible to add here component or directive.
                </div>
            </ra-ip-collapse-box>
        </div>
    </file>

    <file name="script.js">
        angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1')
            .controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        theme: 'rockwell',
                        hideHeader: false,
                        disableCollapse: true,
                        header: {
                            titleAlign: 'row',
                            mainTitle: {
                                value: 'Main title'
                            },
                            subtitle: {
                                value: 'Subtitle'
                            }
                        },
                        action: {
                            actions: [
                                {
                                    class: 'ra-icon-home',
                                    active: true,
                                    size: 'small',
                                    type: 'button'
                                },
                                {
                                    class: 'ra-icon-edit',
                                    active: false,
                                    size: 'small',
                                    type: 'button'
                                },
                                {
                                    visible: true,
                                    class: "ra-btn-primary",
                                    value: "Add button",
                                    disabled: false,
                                    onAction: function() {alert("add dialog");}
                                }
                            ]
                        }
                    };
            }]);
    </file>
 </example>

/* global angular */
angular.module('RA.IPComponents')
    .component('raIpCollapseBox', {
        templateUrl: 'components/raIpCollapseBox/raIpCollapseBox.tpl.html',
        transclude: true,
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: ['$window', function () {
            'use strict';

            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
                self.config.theme = self.config.theme || 'rockwell';
                self.config.disableCollapse =
                    angular.isDefined(self.config.disableCollapse) ? self.config.disableCollapse : false;
            }

            normalizeConfig();

            /**
             * @description invoke external function
             * @param {function} actionItem has to be a function
             */
            self.invokeDoAction = function (actionItem) {
                if (typeof actionItem === 'function') {
                    actionItem();
                }
            };

            /**
             * @description disable collapsing of collapse box
             * @type {boolean}
             */
            if (!self.config.disableCollapse) {
                self.open = self.config.defaultClosed;
            } else {
                self.open = false;
            }

            /**
             * @description open and close collapse box
             * @type {boolean}
             */
            self.switchClosed = function () {
                if (!self.config.disableCollapse) {
                    self.open = !self.open;
                }
            };

        }]
    });
