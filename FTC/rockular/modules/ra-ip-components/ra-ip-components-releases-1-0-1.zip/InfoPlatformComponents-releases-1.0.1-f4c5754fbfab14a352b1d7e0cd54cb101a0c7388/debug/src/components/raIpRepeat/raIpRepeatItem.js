/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpRepeatItem
 * @module RA.IPComponents
 * @description
 * This component is responsible for compiling the item content.
 * @param {string} template html template string
 * @param {object} item for compiled component
 */
/* global angular */
angular.module("RA.IPComponents")
    .directive("raIpRepeatItem", function ($compile) {
        "use strict";
        return {
            scope: {
                config: '<',
                template: '<'
            },
            restrict: 'EA',
            compile: function (ele) {
                var transclude = ele.html();
                ele.html('');

                return function (scope, elem) {
                    var tpl = angular.element(scope.template);
                    tpl.append(transclude);

                    $compile(tpl)(scope);

                    elem.append(tpl);
                };
            }
        };
    });
