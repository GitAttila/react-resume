/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpActions
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering action buttons. Action button can be an icon or a button. Component
 * allows to set size of each action and align for whole component. For icon button is used raIpBadge component and
 * for button is used MFT button.
 *
 * @param {object} config
 * - **`class`** {string} to customize style of component
 * - **`align`** {string} left | center | right
 * - **`actions`** {array} actions
 *      - **`class`** {string} class for icon button
 *      - **`disabled`** {boolean} disabled action button
 *      - **`onAction`** {function} called on click
 *      - **`tooltip`** {string} information text shown on hover on button
 *      - **`value`** {string} for button when this value is undefined it set icon button
 *      - **`size`** {string} small | medium | large
 *
 *      raIpBadge component for icon action
 *      See also {@link RA.IPComponents.component:raIpBadge}.
 *
 * @example

 <example module="example1">
    <file name="index.html">
        <div ng-controller="myCtrl">
            <ra-ip-actions config="config"></ra-ip-actions>
        </div>
    </file>
    <file name="script.js">
        angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1').controller('myCtrl',['$scope',
            function($scope) {
                $scope.config = {
                    align: 'left',
                    actions: [
                        {
                            class: 'ra-icon-home',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            tooltip: 'Tooltip text',
                            size: 'small'
                        },
                        {
                            class: 'ra-icon-home',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            tooltip: 'Tooltip text',
                            size: 'medium'
                        },
                        {
                            class: 'ra-icon-home',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            tooltip: 'Tooltip text',
                            size: 'large'
                        },
                        {
                            class: 'ra-btn-primary',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            value: 'Some text',
                            size: 'small'
                        },
                        {
                            class: 'ra-btn-primary',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            value: 'Some text',
                            size: 'medium'
                        },
                        {
                            class: 'ra-btn-primary',
                            disabled: false,
                            onAction: function() {
                                alert("Called function");
                            },
                            value: 'Some text',
                            size: 'large'
                        }
                    ]
                };
            }
        ]);
    </file>
 </example>
 */
/* global angular */
angular.module("RA.IPComponents")
    .component("raIpActions", {
        templateUrl: "components/raIpActions/raIpActions.tpl.html",
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';
            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
            }

            normalizeConfig();

            /**
             * @description invoke external function
             * @param {function} action.onAction has to be a function
             */
            self.invokeDoAction = function (action) {
                if (typeof action.onAction === 'function') {
                    action.onAction();
                }
            };
        }]
    });
