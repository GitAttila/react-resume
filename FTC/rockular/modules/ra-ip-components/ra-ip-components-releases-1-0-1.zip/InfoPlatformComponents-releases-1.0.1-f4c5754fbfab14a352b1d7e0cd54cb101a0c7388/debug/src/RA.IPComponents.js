/*global angular*/
angular.module('RA.IPComponents', [
    'mobile-toolkit-ra',
    'RA.IPCommon',
    'ui.router'
]);
