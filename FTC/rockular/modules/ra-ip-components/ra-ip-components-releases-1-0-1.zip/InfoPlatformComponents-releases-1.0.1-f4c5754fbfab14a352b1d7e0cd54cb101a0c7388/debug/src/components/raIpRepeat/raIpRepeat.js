/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpRepeat
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for repeating items in array.
 * @param {object} config
 * - **`template`** {string} template html template string
 * - **`items`** {array} items for raIpRepeatItem
 *
 * @example

    <example module="example1">
        <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-repeat config="config"></ra-ip-repeat>
            </div>
        </file>
        <file name="script.js">
            angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example1').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        template: '<ra-ip-card>' +
                        '<span style="display:block; padding:30px 20px;">test</span></ra-ip-card>',
                        items:[{

                        },{}]
                    };
                }
            ]);
        </file>
    </example>
*/
/*global angular*/
angular.module("RA.IPComponents")
    .component("raIpRepeat", {
        templateUrl: "components/raIpRepeat/raIpRepeat.tpl.html",
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';
        }]
    });
