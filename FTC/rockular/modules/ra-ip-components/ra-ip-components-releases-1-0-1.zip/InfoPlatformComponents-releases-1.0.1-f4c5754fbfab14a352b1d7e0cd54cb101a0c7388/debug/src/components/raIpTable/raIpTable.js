/*
 * (c) Rockwell Automation 2017
 */

/* global angular */

/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpTable
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering the table.

 * @param {Array} config
 * - **`class`** {String}
 * - **`header`** {Array} header objects definitions
 *      - **`value`** {string} value
 * - **`items`** {Array} items array of objects with this structure
 *      - **`item`** {object} origin item not parsed
 *      - **`columns`** {Array} of column items
 *          - **`label`** {string}
 *          - **`value`** {string}
 *      - **`actions`** {Array} of action buttons raIpActions {@link RA.IPComponents.component:raIpActions}
 * @param {Object} setApi api
 *

 @example
 The example below shows how to use raIpCardBody

 <example module="example1">
     <file name="index.html">
         <div ng-controller="myCtrl">
            <ra-ip-table config="config" set-api="setApi">
            </ra-ip-table>
         </div>
     </file>

     <file name="script.js">
        angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
        angular.module('example1')
            .controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        header: [
                            {
                                value: "header 1"
                            },
                            {
                                value: "header 2"
                            },
                            {
                                value: "header 3"
                            },
                            {
                                value: "header 4"
                            },
                            {
                                value: ""
                            }
                        ],
                        items: [
                            {
                                action: {
                                    align: "right",
                                    actions: [
                                        {
                                            class:"ra-icon-edit",
                                            size: "small",
                                            onAction: function() {alert("edit window");}
                                        },
                                        {
                                            class:"ra-icon-clear",
                                            size: "small",
                                            onAction: function() {alert("remove window");}
                                        }
                                    ]
                                },
                                columns: [
                                    {
                                        label: "title 1",
                                        value: "value 1"
                                    },
                                    {
                                        label: "title 2",
                                        value: "value 2"
                                    },
                                    {
                                        label: "title 3",
                                        value: "value 3"
                                    },
                                    {
                                        label: "title 4",
                                        value: "value 4"
                                    }
                                ],
                                item: {}
                            },
                            {
                                action: {
                                    align: "right",
                                    actions: [
                                        {
                                            class:"ra-icon-edit",
                                            size: "small",
                                            onAction: function() {alert("edit window");}
                                        },
                                        {
                                            class:"ra-icon-clear",
                                            size: "small",
                                            onAction: function() {alert("remove window");}
                                        }
                                    ]
                                },
                                columns: [
                                    {
                                        label: "title 1",
                                        value: "value 1"
                                    },
                                    {
                                        label: "title 2",
                                        value: "value 2"
                                    },
                                    {
                                        label: "title 3",
                                        value: "value 3"
                                    },
                                    {
                                        label: "title 4",
                                        value: "value 4"
                                    }
                                ],
                                item: {}
                            },
                            {
                                action: {
                                    align: "right",
                                    actions: [
                                        {
                                            class:"ra-icon-edit",
                                            size: "small",
                                            onAction: function() {alert("edit window");}
                                        },
                                        {
                                            class:"ra-icon-clear",
                                            size: "small",
                                            onAction: function() {alert("remove window");}
                                        }
                                    ]
                                },
                                columns: [
                                    {
                                        label: "title 1",
                                        value: "value 1"
                                    },
                                    {
                                        label: "title 2",
                                        value: "value 2"
                                    },
                                    {
                                        label: "title 3",
                                        value: "value 3"
                                    },
                                    {
                                        label: "title 4",
                                        value: "value 4"
                                    }
                                ],
                                item: {}
                            },
                            {
                                action: {
                                    align: "right",
                                    actions: [
                                        {
                                            class:"ra-icon-edit",
                                            size: "small",
                                            onAction: function() {alert("edit window");}
                                        },
                                        {
                                            class:"ra-icon-clear",
                                            size: "small",
                                            onAction: function() {alert("remove window");}
                                        }
                                    ]
                                },
                                columns: [
                                    {
                                        label: "title 1",
                                        value: "value 1"
                                    },
                                    {
                                        label: "title 2",
                                        value: "value 2"
                                    },
                                    {
                                        label: "title 3",
                                        value: "value 3"
                                    },
                                    {
                                        label: "title 4",
                                        value: "value 4"
                                    }
                                ],
                                item: {}
                            }
                        ]
                    };
                }]);
 </file>
 </example>
 **/

angular.module('RA.IPComponents')
    .component('raIpTable', {
        templateUrl: 'components/raIpTable/raIpTable.tpl.html',
        replace: true,
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {

            'use strict';
            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
            }

            normalizeConfig();
        }
    ]
    })
    .filter('isArray', function () {
        "use strict";
        return function (input) {
            return angular.isArray(input);
        };
    });

