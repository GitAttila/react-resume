/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpBadge
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering icon. Icon can be used with some action as a button or can be used like
 * a information icon. Component allows to set size. The default size is medium.
 *
 * @param {object} config
 * - **`tooltip`** {string} information text shown on hover on button
 * - **`disabled`** {boolean} disabled action button
 * - **`badgeNumber`** {int} small number on the right side of icon
 * - **`class`** {string} icon class definition
 * - **`type`** {string} button | icon default is icon
 * - **`active`** {boolean} active state
 * - **`size`** {string} size settings small | medium | large
 * - **`onAction`** {function} called on click
 *
 * @example

    <example module="example1">
        <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-badge config="item1"></ra-ip-badge>
                <ra-ip-badge config="item2"></ra-ip-badge>
                <ra-ip-badge config="item3"></ra-ip-badge>
                <ra-ip-badge config="item4"></ra-ip-badge>
                <ra-ip-badge config="item5"></ra-ip-badge>
                <ra-ip-badge config="item6"></ra-ip-badge>
                <span style="width: 45px; display: block;"><ra-ip-badge config="item7"></ra-ip-badge></span>
                <span style="width: 45px; display: block;"><ra-ip-badge config="item8"></ra-ip-badge></span>
            </div>
        </file>
        <file name="script.js">
            angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example1').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.item1 = {
                        tooltip: "Tooltip text",
                        disabled: true,
                        badgeNumber: 4,
                        class: "ra-icon-home"
                    };
                    $scope.item2 = {
                        tooltip: "Tooltip text",
                        disabled: false,
                        badgeNumber: 4,
                        class: "ra-icon-home"
                    };
                    $scope.item3 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home"
                    };
                    $scope.item4 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home",
                        badgeNumber: 4,
                        size: "small"
                    };
                    $scope.item5 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home",
                        badgeNumber: 4,
                        size: "medium"
                    };
                    $scope.item6 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home",
                        badgeNumber: 4,
                        size: "large"
                    };
                    $scope.item7 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home",
                        active: true,
                        size: "medium",
                        type: 'button',
                        onAction: function () {}
                    };
                    $scope.item8 = {
                        tooltip: "Tooltip text",
                        class: "ra-icon-home",
                        active: false,
                        size: "medium",
                        type: 'button',
                        onAction: function () {}
                    };
                }
            ]);
        </file>
    </example>
 */
/* global angular */
angular.module("RA.IPComponents")
    .component("raIpBadge", {
        templateUrl: "components/raIpBadge/raIpBadge.tpl.html",
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';
            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
                self.config.type = self.config.type || "icon";
                self.config.size = self.config.size || "medium";
            }

            normalizeConfig();

            /**
             * @description invoke external function
             * @param {function} action.onAction has to be a function
             */
            self.invokeDoAction = function (action) {
                if (typeof action.onAction === 'function') {
                    action.onAction();
                }
            };
        }]
    });
