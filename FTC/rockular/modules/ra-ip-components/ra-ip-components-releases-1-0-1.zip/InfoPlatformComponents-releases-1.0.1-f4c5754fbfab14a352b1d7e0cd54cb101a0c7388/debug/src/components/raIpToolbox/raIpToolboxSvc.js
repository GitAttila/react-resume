// Copyright Rockwell Automation Technologies, Inc.
// All Rights Reserved.

/*
 * (c) Rockwell Automation 2016
 */

/* global angular */
/* global _ */

angular.module('RA.IPComponents').factory('raIpToolboxSvc', ['orderByFilter', '$q',
    function (orderBy, $q) {
        'use strict';

        var resources, tree;

        function setAllResources(resourceArray) {
            resources = orderBy(resourceArray, 'category');
            var createTree = function (items) {
                var tree = [];
                var categoryLabel;
                function createFolder(loc, path, index) {
                    if (loc.length === 0 || (loc[loc.length - 1].label !== path[0])) {
                        loc.push({
                            label: path[0],
                            data: {
                                category: categoryLabel
                            },
                            children: []
                        });
                    }
                    path.shift();
                    if (path.length) {
                        categoryLabel += '.' + path[0];
                    } else {
                        return;
                    }
                    createFolder(loc[loc.length - 1].children, path, index);
                }
                angular.forEach(items, function (widget, index) {
                    if (widget.category) {
                        var path = widget.category.split('.');
                        categoryLabel = path[0];
                        createFolder(tree, path, index);
                    }
                });
                return tree;
            };
            tree = createTree(resources);
        }

        function getResourcesByIds(ids) {
            var deferred = $q.defer();
            deferred.resolve(
                resources.filter(function (value) {
                    var found = false;
                    angular.forEach(ids, function (id) {
                        if (id == value.id) { //jshint ignore:line
                            found = true;
                        }
                    });
                    return found;
                })
            );
            return deferred.promise;
        }

        function getResourcesByCategory(category) {
            var deferred = $q.defer();
            deferred.resolve(
                resources.filter(function (value) {
                    return value.category.indexOf(category) === 0 &&
                        (value.category.length === category.length || value.category[category.length] === '.');
                })
            );
            return deferred.promise;
        }

        function getResourcesByFilter(queryData, whispers) {
            var results = angular.copy(resources),
                data,
                deferred = $q.defer(),
                convertToString = function (prop) {
                    var property;
                    if (typeof prop === 'number') {
                        property = prop.toString();
                    } else if (typeof prop === 'string') {
                        property = prop.toLowerCase();
                    } else {
                        property = '';
                    }
                    return property;
                };

            if (!whispers) {
                //for each active filter option
                angular.forEach(queryData, function (filter) {
                    //filter results array
                    if (filter.name !== 'all') {
                        results = results.filter(function (it) { //it = one data item
                            //return item if filter.name matches with item.property value
                            return convertToString(it[filter.name]).indexOf(filter.query.toLowerCase()) !== -1;
                        });
                    } else {
                        var queryString = filter.query.toLowerCase(), newResults = [];
                        angular.forEach(results, function (item) { //for each data item in results
                            var found = false;
                            angular.forEach(queryData[0].filterOptions, function (prop) {
                                if (convertToString(item[prop]).indexOf(queryString) !== -1 && !found) {
                                    newResults.push(item);
                                    found = true;
                                }
                            });
                        });
                        results = newResults;
                    }
                });
                data = results;
            } else {
                var props = [];
                angular.forEach(queryData, function (filter) {
                    //filter results array
                    if (filter.name !== 'all') {
                        results = results.filter(function (it) { //it = one data item
                            //return item if filter.name matches with item.property value
                            var prop = it[filter.name];
                            if (convertToString(prop).indexOf(filter.query.toLowerCase()) !== -1) {
                                props.push(prop);
                                return true;
                            }
                        });
                    } else {
                        var queryString = filter.query.toLowerCase(), newResults = [];
                        angular.forEach(results, function (item) { //for each data item in results
                            var found = false;
                            angular.forEach(queryData[0].filterOptions, function (prop) {
                                if (convertToString(item[prop]).indexOf(queryString) !== -1 && !found) {
                                    newResults.push(item);
                                    props.push(prop);
                                    found = true;
                                }
                            });
                        });
                        results = newResults;
                    }
                });
                if (!queryData[0].single || queryData[0].name === 'all') {
                    props = [];
                    angular.forEach(results, function (item) {
                        props.push(item.name);
                    });
                }
                data = {
                    header: 'search',
                    results: _.uniq(props)
                };
            }
            deferred.resolve(data);
            return deferred.promise;
        }

        function getCategoryTree() {
            var deferred = $q.defer();
            deferred.resolve(tree);
            return deferred.promise;
        }

        //not sure what this should return????
        function getSubCategory() {

        }

        return {
            setAllResources: setAllResources,
            getResourcesByIds: getResourcesByIds,
            getResourcesByCategory: getResourcesByCategory,
            getResourcesByFilter: getResourcesByFilter,
            getCategoryTree: getCategoryTree,
            getSubCategory: getSubCategory
        };
    }]);
