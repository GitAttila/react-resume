/*
 * (c) Rockwell Automation 2017
 */
/**
 * @ngdoc directive
 * @name RA.IPComponents.component:raIpHeader
 * @module RA.IPComponents
 * @restrict E
 * @description
 * This component is responsible for rendering header. For icon is used raIpBadge component.
 *
 * @param {object} config
 * - **`class`** {string} to customize style of component
 * - **`underline`** {boolean} underline
 * - **`value`** {string} text message for simple header with underline
 * - **`icon`** {object} icon definiton raIpBadge {@link RA.IPComponents.component:raIpBadge}
 * - **`image`** {object}
 *    - **`url`** {string} path to an image
 *    - **`class`** {string} class to customize title
 *    - **`alt`** {string} alternative image name
 * - **`titleAlign`** {object} column | row default is column
 * - **`mainTitle`** {object}
 *    - **`class`** {string} class to customize title
 *    - **`value`** {string} text for title
 * - **`subtitle`** {object}
 *    - **`class`** {string} class to customize subtitle
 *    - **`value`** {string} text for subtitle
 *
 * @example

    <example module="example1">
        <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-header config="config"></ra-ip-header>
            </div>
        </file>
        <file name="script.js">
            angular.module('example1', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example1').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        value: "Header text"
                    };
                }
            ]);
        </file>
    </example>

    <example module="example2">
        <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-header config="config"></ra-ip-header>
            </div>
        </file>
        <file name="script.js">
            angular.module('example2', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example2').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        icon: {
                            class: 'ra-icon-home'
                        },
                        mainTitle: {
                            value: 'Main title'
                        },
                        subtitle: {
                            value: 'Subtitle'
                        }
                    };
                }
             ]);
        </file>
    </example>

     <example module="example3">
         <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-header config="config"></ra-ip-header>
            </div>
         </file>
         <file name="script.js">
            angular.module('example3', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example3').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        image: {
                            url: '../grunt-styles/docs/ra-logo.svg',
                            alt: 'Rockwell Automation'
                        },
                        titleAlign: 'row',
                        mainTitle: {
                            value: 'Main title'
                        },
                        subtitle: {
                            value: 'Subtitle'
                        }
                    };
                }
            ]);
        </file>
     </example>

    <example module="example4">
        <file name="index.html">
            <div ng-controller="myCtrl">
                <ra-ip-header config="config"></ra-ip-header>
            </div>
        </file>
        <file name="script.js">
            angular.module('example4', ['mobile-toolkit-ra', 'RA.IPComponents']);
            angular.module('example4').controller('myCtrl',['$scope',
                function($scope) {
                    $scope.config = {
                        image: {
                            url: '../grunt-styles/docs/ra-logo.svg',
                            alt: 'Rockwell Automation'
                        },
                        mainTitle: {
                            value: 'Main title'
                        }
                    };
                }
            ]);
        </file>
    </example>

 */
/* global angular */
angular.module('RA.IPComponents')
    .component('raIpHeader', {
        templateUrl: 'components/raIpHeader/raIpHeader.tpl.html',
        bindings: {
            config: "<"
        },
        controllerAs: "ctrl",
        controller: [function () {
            'use strict';

            var self = this;

            /**
             * @description normalize config to set default values
             */
            function normalizeConfig() {
                self.config = self.config || {};
                self.config.titleAlign = self.config.titleAlign || "column";
            }

            normalizeConfig();
        }]
    });
